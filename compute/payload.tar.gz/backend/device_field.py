"""Exact resident field proposals, with explicit range/performance fallback."""
from pathlib import Path
import hashlib, json, os, statistics, struct, subprocess, sys, time

class DeviceField:
    def __init__(self, binary, original_field, output, policy='adaptive'):
        if policy not in ('adaptive','device'): raise ValueError('device policy')
        self.output=Path(output);self.original=original_field;self.policy=policy
        self.stderr=(self.output/'field-worker.stderr.txt').open('wb')
        self.process=subprocess.Popen([str(binary),os.environ.get('CIVSIM_FIELD_WORKERS','16')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.stderr)
        self.matrix=None;self.device_mode=None;self.current=None
        self.record=dict(schema='civsim.resident-exact-field.v1',scope='Experimental execution adapter. Independent canonical force checks remain active on every stage.', policy=policy,
                         binary_sha256=hashlib.sha256(Path(binary).read_bytes()).hexdigest(),calls=0,device_calls=0,cpu_calls=0,range_fallbacks=0,contexts=[])
        self.save()

    def save(self):
        p=self.output/'gravity-backend.json';tmp=p.with_suffix('.tmp')
        tmp.write_text(json.dumps(self.record,indent=2)+'\n',encoding='utf-8');tmp.replace(p)

    def receive(self,n):
        raw=bytearray()
        while len(raw)<n:
            b=self.process.stdout.read(n-len(raw))
            if not b:raise ValueError('field worker closed; retain worker stderr')
            raw.extend(b)
        return raw

    def prepare(self,matrix):
        radial,axial=matrix; n=len(radial)
        if not 1<=n<=8192 or len(axial)!=n or any(len(row)!=n for grid in (radial,axial) for row in grid): return False
        maximum=max(abs(k) for grid in (radial,axial) for row in grid for k in row)
        if any(type(k) is not int for grid in (radial,axial) for row in grid for k in row) or maximum>=2**256:return False
        start=time.monotonic();h=hashlib.sha256()
        self.process.stdin.write(b'P'+struct.pack('<I',n))
        for i in range(n):
            for grid in (radial,axial):
                raw=b''.join(abs(k).to_bytes(32,'little')+struct.pack('<I',k<0) for k in grid[i]);h.update(raw)
                self.process.stdin.write(raw)
        self.process.stdin.flush()
        line=self.process.stdout.readline()
        if not line:raise ValueError('field worker setup refused; retain stderr')
        info=json.loads(line)
        if info['cells']!=n:raise ValueError('worker cell binding')
        if info['backend']=='level_zero_b70_pair':
            if len(info['devices'])!=2 or len({d['pci'] for d in info['devices']})!=2 or any('B70' not in d['name'] for d in info['devices']):raise ValueError('worker physical GPU census')
        elif info['backend']!='cpu_integer_control':raise ValueError('worker backend')
        self.current=dict(cells=n,matrix_sha256=h.hexdigest(),max_coefficient=str(maximum),setup_seconds=time.monotonic()-start,
                          worker=info,cpu_samples_s=[],device_samples_s=[],calls=0,device_calls=0,mode='qualifying')
        self.record['contexts'].append(self.current);self.matrix=matrix;self.device_mode=self.policy=='device';self.save();return True

    def proposal(self,x,cells):
        from arithmetic import rounded
        self.process.stdin.write(b'F'+b''.join(row[0].to_bytes(32,'little') for row in cells));self.process.stdin.flush()
        raw=self.receive(len(cells)*2*68);out=[]
        for i in range(len(cells)):
            row=[]
            for k in range(2):
                at=(2*i+k)*68;mag=int.from_bytes(raw[at:at+64],'little');minus=struct.unpack_from('<I',raw,at+64)[0]
                if minus>1 or (minus and not mag):raise ValueError('noncanonical worker sign')
                total=-mag if minus else mag
                row.append(rounded(-x['gravity']*total,x['s']**2))
            out.append(row)
        self.record['device_calls']+=1;self.current['device_calls']+=1;return out

    def __call__(self,x,cells,matrix):
        self.record['calls']+=1
        masses=[row[0] for row in cells]
        if any(type(m) is not int or not 0<m<2**256 for m in masses) or sum(masses)>=2**256:
            self.record['range_fallbacks']+=1;self.record['cpu_calls']+=1;self.save();return self.original(x,cells,matrix)
        if self.matrix is not matrix and not self.prepare(matrix):
            self.record['range_fallbacks']+=1;self.record['cpu_calls']+=1;self.save();return self.original(x,cells,matrix)
        if sum(masses)*int(self.current['max_coefficient'])>=2**511:
            self.record['range_fallbacks']+=1;self.record['cpu_calls']+=1;self.save();return self.original(x,cells,matrix)
        self.current['calls']+=1;call=self.current['calls']
        qualification=len(self.current['cpu_samples_s'])<4
        shadow=(not self.device_mode and call%64==0)
        if qualification or shadow:
            start=time.monotonic();reference=self.original(x,cells,matrix);cpu=time.monotonic()-start
            start=time.monotonic();got=self.proposal(x,cells);device=time.monotonic()-start
            if got!=reference:raise ValueError('complete CPU/device force mismatch')
            self.record['cpu_calls']+=1
            if qualification:
                self.current['cpu_samples_s'].append(cpu);self.current['device_samples_s'].append(device)
                if len(self.current['cpu_samples_s'])==4:
                    c=statistics.median(self.current['cpu_samples_s'][1:]);d=statistics.median(self.current['device_samples_s'][1:])
                    self.device_mode=self.policy=='device' or d<=c*.9
                    self.current.update(mode='device' if self.device_mode else 'cpu_with_device_shadow',matched_cpu_median_s=c,matched_device_median_s=d,
                                        threshold_scope='Host execution policy only; equal exact forces cannot change physics.')
                    print('CIVSIM_DEVICE_CONTEXT '+json.dumps({k:self.current[k] for k in ('cells','mode','matched_cpu_median_s','matched_device_median_s')}),file=sys.stderr,flush=True)
            self.save();return got if self.device_mode else reference
        if self.device_mode:
            got=self.proposal(x,cells)
        else:
            self.record['cpu_calls']+=1;got=self.original(x,cells,matrix)
        if call%32==0:self.save()
        return got

    def close(self):
        if self.process.poll() is None:
            try:self.process.stdin.write(b'Q');self.process.stdin.flush()
            except BrokenPipeError:pass
            try:self.process.wait(timeout=30)
            except subprocess.TimeoutExpired:self.process.kill();self.process.wait()
        self.stderr.close();self.record['worker_exit']=self.process.returncode;self.save()
