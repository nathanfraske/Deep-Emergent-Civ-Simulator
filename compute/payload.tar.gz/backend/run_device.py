"""Experimental, source-bound execution adapter around the frozen gas model."""
from pathlib import Path
import argparse, hashlib, multiprocessing, sys
from device_field import DeviceField

def install(run, binary, output, policy):
    original_ids=run.implementations
    helper=Path(__file__).resolve().parent
    files={'device-execution/'+name:helper/name for name in ('run_device.py','device_field.py','field_worker.cpp','gravity-device-equations.txt')}
    files['device-execution/field_worker.binary']=Path(binary)
    def binding():
        return dict(original_ids(),**{name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in files.items()})
    run.implementations=binding
    adapter=DeviceField(binary,run.gravity.field,output,policy)
    run.gravity.field=adapter
    return adapter

def main():
    multiprocessing.set_start_method('spawn')
    parser=argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('--source-root',type=Path,required=True)
    parser.add_argument('--device-binary',type=Path,required=True)
    parser.add_argument('--device-record-dir',type=Path,required=True)
    parser.add_argument('--device-policy',choices=('device','adaptive'),default='adaptive')
    args,remaining=parser.parse_known_args()
    sys.path[:0]=[str(args.source_root),str(args.source_root/'scripts/radial_core')]
    from scripts.rotating_core import run
    args.device_record_dir.mkdir(parents=True,exist_ok=True)
    adapter=install(run,args.device_binary,args.device_record_dir,args.device_policy)
    try:
        sys.argv=[str(args.source_root/'scripts/rotating_core/run.py')]+remaining
        run.main()
    finally:adapter.close()

if __name__=='__main__':
    try:main()
    except (ValueError,OSError,KeyError,ZeroDivisionError) as e:
        print('device gas refusal: '+str(e),file=sys.stderr);raise SystemExit(2)

