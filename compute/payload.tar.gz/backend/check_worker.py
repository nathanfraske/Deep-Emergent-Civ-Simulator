"""Independent exact expectations and whole-gas controls for the device seam."""
from pathlib import Path
import argparse, copy, hashlib, json, struct, subprocess, sys, tempfile
from device_field import DeviceField

def main():
    p=argparse.ArgumentParser(allow_abbrev=False)
    p.add_argument('--source-root',type=Path,required=True);p.add_argument('--binary',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    args.output.mkdir(exist_ok=False)
    sys.path[:0]=[str(args.source_root),str(args.source_root/'scripts/radial_core')]
    from scripts.rotating_core import run
    from arithmetic import rounded
    checks=[]
    for n,bits in [(1,1),(3,128),(8,251),(128,128)]:
        m=[(1<<bits)+i+1 for i in range(n)]
        grids=tuple(tuple(tuple(((-1)**(i+j+k))*((1<<(255 if bits==251 else 131))+(i+1)*(j+1)+k) for j in range(n)) for i in range(n)) for k in range(2))
        folder=args.output/('limbs-'+str(n));folder.mkdir()
        adapter=DeviceField(args.binary,run.gravity.field,folder,'device')
        try:
            x=dict(s=1<<128,gravity=(1<<128)+1)
            cells=[[v,0,0,0] for v in m]
            for trial in range(5):
                expected=[[rounded(-x['gravity']*sum(cells[j][0]*grids[k][i][j] for j in range(n)),x['s']**2) for k in range(2)] for i in range(n)]
                assert adapter(x,cells,grids)==expected
                cells[-1][0]+=1
            checks.append(dict(test='signed_limb_products',cells=n,mass_bits=bits,complete_outputs=n*2*5))
        finally:adapter.close()
    folder=args.output/'rounding';folder.mkdir();adapter=DeviceField(args.binary,run.gravity.field,folder,'device')
    try:
        for coefficient in [2,6,-2,-6]:
            matrix=(((coefficient,),),((coefficient,),))
            assert adapter(dict(s=2,gravity=1),[[1,0,0,0]],matrix)==[[rounded(-coefficient,4)]*2]
        huge=[[2**256,0,0,0]]
        assert adapter(dict(s=2,gravity=1),huge,(((1,),),((1,),)))==[[-2**254,-2**254]]
        assert adapter.record['range_fallbacks']==1
        checks.append(dict(test='signed_half_even_and_explicit_range_fallback',outputs=10))
    finally:adapter.close()
    state=(args.source_root/'declared-controls/compact.state').read_text()
    config=(args.source_root/'declared-controls/long.numerics').read_text()
    config=config.replace('radial_cells=16','radial_cells=4').replace('vertical_cells=16','vertical_cells=8')
    model=run.models.load(args.source_root/'floor.json',run.FINITE_MODEL_ID)
    original=run.gravity.field
    reference=run.solve(state,config,model,workers=1,_stop_step=16)
    folder=args.output/'whole-gas';folder.mkdir();adapter=DeviceField(args.binary,original,folder,'device')
    try:
        run.gravity.field=adapter
        candidate=run.solve(state,config,model,workers=1,_stop_step=16)
        run.checkpoint_watchdog.strict_equal(reference,candidate)
        checks.append(dict(test='complete_gas_clock_geometry_force_accounts_trace_and_frames',steps=candidate['steps'],frames=len(candidate['frames']),calls=adapter.record['calls']))
        (args.output/'reference.json').write_text(run.canonical_json(reference),encoding='ascii')
        (args.output/'candidate.json').write_text(run.canonical_json(candidate),encoding='ascii')
    finally:run.gravity.field=original;adapter.close()
    folder=args.output/'corruption';folder.mkdir();adapter=DeviceField(args.binary,original,folder,'device')
    def changed(x,cells,matrix):
        got=adapter(x,cells,matrix);got[0][0]+=1;return got
    try:
        run.gravity.field=changed
        try:run.solve(state,config,model,workers=1,_stop_step=0)
        except ValueError as e:
            (folder/'independent-refusal.txt').write_text(str(e)+'\n',encoding='utf-8')
            checks.append(dict(test='independent_force_checker_rejects_one_bit_device_change',refusal=str(e)))
        else:raise AssertionError('changed device force admitted')
    finally:run.gravity.field=original;adapter.close()
    packets={'cell-capacity':b'P'+struct.pack('<I',8193),
             'coefficient-sign':b'P'+struct.pack('<I',1)+(1).to_bytes(32,'little')+struct.pack('<I',2)+(1).to_bytes(32,'little')+struct.pack('<I',0)}
    coeff=(2**256-1).to_bytes(32,'little')+struct.pack('<I',0)
    packets['accumulator-bound']=b'P'+struct.pack('<I',2)+coeff*8+b'F'+(2**255-1).to_bytes(32,'little')*2
    for name,packet in packets.items():
        result=subprocess.run([str(args.binary),'16'],input=packet,capture_output=True,timeout=60)
        (args.output/(name+'.stderr.txt')).write_bytes(result.stderr)
        (args.output/(name+'.stdout.bin')).write_bytes(result.stdout)
        assert result.returncode==2,(name,result.returncode)
        checks.append(dict(test='worker_rejects_'+name,exit_code=result.returncode))
    record=dict(schema='civsim.resident-gravity-controls.v1',passed=True,checks=checks,
                source_root=str(args.source_root),binary_sha256=hashlib.sha256(args.binary.read_bytes()).hexdigest(),
                scope='Exact field and bounded full-gas controls. No continuum or stellar/disk classification.')
    (args.output/'checks.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(record),flush=True)

if __name__=='__main__':main()
