"""Source-bound native CPU entrypoint; optional exact compiled proposer."""
from pathlib import Path
import argparse,hashlib,multiprocessing,sys

def main():
    multiprocessing.set_start_method('spawn')
    parser=argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('--source-root',type=Path,required=True)
    parser.add_argument('--device-binary',type=Path)
    parser.add_argument('--device-record-dir',type=Path,required=True)
    args,remaining=parser.parse_known_args()
    sys.path[:0]=[str(args.source_root),str(args.source_root/'scripts/radial_core')]
    from scripts.rotating_core import run
    adapter=None
    if args.device_binary:
        from run_device import install
        args.device_record_dir.mkdir(parents=True,exist_ok=True)
        adapter=install(run,args.device_binary,args.device_record_dir,'adaptive')
    original=run.implementations
    def binding():
        return dict(original(),**{'device-execution/run_native.py':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
    run.implementations=binding
    try:
        sys.argv=[str(args.source_root/'scripts/rotating_core/run.py')]+remaining
        run.main()
    finally:
        if adapter:adapter.close()
if __name__=='__main__':main()
