# Rotating gas entry

This is a declared cold rotating gas cylinder, using the same source-bound
barotropic pressure coefficients as the spherical protostar model. The cylinder
and nonzero rotation are new explicit hypotheses; this is not an upstream
continuation of the spherical zero-spin example or an inserted star/disk.

`cloud.state` has physical units in each key. `collapse.numerics` controls the
mesh, exact binary scale, ring quadrature, explicit metre softening, adaptive
timestep limits, work and sampling. Descriptions do not influence the physics.
No requested body count, star mass, planet or orbit is accepted.

Run `just rotating-core-example` or the Windows `scripts/dev.ps1` bridge.
The raw evidence and scientific plot appear in `artifacts/rotating-barotropic/regular-v2`.
See the [held results and controls](../../artifacts/rotating-barotropic/README.md).
An existing output directory refuses, so use a new `--output-dir` for another run.
The worker reports the requested-time and work-limit stopping distinction.

See [the model contract](../../docs/working/ROTATING_BAROTROPIC_MODEL.md) and
[equation map](../../sources/barotropic_core/rotating-equations.txt) for sources,
checks, the reflecting-boundary approximation and remaining physical limits.

`open-cloud.state` belongs to the explicit
`axisymmetric_bate1998_barotropic_open_v1` model. Select it with `--model` on
`run-rotating-core`, then choose the same numerical files and a fresh output
directory. It copies adjacent exterior gas, permits signed inflow/outflow and
requires `exterior_gravity=neglected`. Edge velocities declare initial bulk
motion; the supplied example starts at rest. Every crossing and cylindrical
source is accounted exactly in all four conserved fields. This exterior is
unresolved gas and has no finite reservoir evolution or vacuum interpretation.
See [the boundary contract](../../docs/working/ROTATING_OPEN_BOUNDARY.md) and
[its equation witness](../../sources/barotropic_core/rotating-open-equations.txt).
Open continuation refuses; `--wall-seconds` permits a checked execution cut.

`adaptive.numerics` enables conservative redistribution of the same cells
following the current gas mass. It uses the original physical state and fixed
softening, with an explicit remap cadence, count, regularization and relaxation.
Run the public `run-rotating-core` command with that numerical file and a fresh
output directory. See [the adaptive mesh contract](../../docs/working/ROTATING_ADAPTIVE_MESH.md)
for the exact overlap equations, independent checks and retained error observations.

`budgeted.numerics` adds explicit limits on optional mesh relocation. Each
accepted move must stay within both density and angular representation limits;
a rejected proposal leaves the original mesh and fields in place. The example
uses 2% cumulative budgets and a 0.25% ceiling per event. These bound measured
projection averaging, without enclosing later evolution or continuum error.
Use the same public command with this file and a fresh output directory.
See [the budget contract](../../docs/working/ROTATING_REMAP_BUDGET.md) and
[held controls](../../artifacts/rotating-remap-budget/README.md).

## Finite surrounding cloud

The separately selected `axisymmetric_bate1998_barotropic_finite_cloud_v1` model
uses `finite-cloud.state`, an explicit dilute inner gas and finite evolving
surrounding gas with full resolved gravity and a reflecting outer slip wall.
All numerical contracts remain separate. See
`docs/working/ROTATING_FINITE_CLOUD.md` for integrated moments, independent
checks, exact material accounts and boundary/physical limits.
