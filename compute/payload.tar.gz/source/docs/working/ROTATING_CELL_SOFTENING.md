# Gravity smoothing follows the resolved cells

Fixed gravity smoothing can remain larger than the dense structures after
cell refinement. Numerical v7 supplies a separate, explicit resolution rule:
use the smaller of the declared smoothing ceiling and a declared fraction
of the smallest current radial or vertical cell span. All sources and targets
share that scalar in the existing global Plummer ring operator. No individual
cell receives a different gravitational law.

The exact rule and residual proof are held in
[cell-softening-equations.txt](../../sources/barotropic_core/cell-softening-equations.txt).
It inherits the held Dehnen potential/gradient, cylindrical cell geometry,
selective Jeans refinement and original Newtonian domain. The new fraction is
a numerical input, not a physical constant, fitted observation or desired
formation outcome. The independent watchdog checks every upper bound and an
attained equality, reconstructing all actual spans without the producer's
selection function. It applies the potential screen to the effective scale.

Geometry construction, relocation and selective splitting recompute the
effective scale. It may shrink or widen. The kernel cache binds that exact
scale; changing it requires new complete coefficient checks. Both fluid
stages of a step use the same checked geometry and smoothing. Every saved
frame and final receipt records `effective_softening_m` separately from the
input ceiling. Precision, projection, complete force sums and all paired
physical checks remain.

The example
[cell-softening.numerics](../../examples/rotating-core/cell-softening.numerics)
uses the original dilute rotating cylinder and a numerical fraction of 0.5.
That choice is a declared resolution control whose sensitivity still needs
measurement. Fresh receipts use run.v9; continued receipts use run.v10.
They retain the complete selective execution cuts and lineage described in
[ROTATING_SELECTIVE_CONTINUATION.md](ROTATING_SELECTIVE_CONTINUATION.md).
Changing the smoothing mode, ceiling or fraction across a continuation
refuses. A new numerical v7 trajectory starts from its original gas entry,
with full original-gas replay required for every accepted continuation.

```powershell
pwsh -NoProfile -File scripts/dev.ps1 run-rotating-core --state examples/rotating-core/cloud.state --numerics examples/rotating-core/cell-softening.numerics --wall-seconds 1800 --output-dir artifacts/my-cell-softening-prefix
```

This removes a fixed smoothing ceiling as an automatic lower resolution
limit. It does not prove sufficient spatial or angular resolution, select
optimal smoothing, or add a thermal/energy account. Finite ring quadrature,
transport, physical angular momentum transport, boundary effects, radiation
and continuum convergence remain separate limits. Dense or pressure-stiffened
gas alone does not establish a supported core, disk or completed system.

> Decided. Make cell-limited global smoothing an explicit numerical mode,
> preserve complete force and gas checks, record its effective scale and
> compare original-gas controls without promoting numerical resolution into
> physical authority.
