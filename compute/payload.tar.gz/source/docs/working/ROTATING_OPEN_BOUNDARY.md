# Declared rotating exterior and exact crossing accounts

Status: supported finite numerical model. This does not classify a formed disk
or connect a thermal stellar evolution solver.

The separate `axisymmetric_bate1998_barotropic_open_v1` model combines the
existing Bate scalar pressure and cylindrical Euler/ring-gravity equations
with Clawpack's held extrapolated ghost prescription. It copies adjacent gas
without reversing normal momentum. Inflow and outflow are both possible.
Exterior gravity is explicitly neglected. A copied exterior is unresolved gas;
it is not an isolated vacuum or a finite evolving reservoir. Multidimensional
oblique waves and boundary-location sensitivity remain unresolved.

The exact primary anchors, licence, local derivations, approximation limits
and equations are held in
`sources/barotropic_core/rotating-open-equations.txt` and the closed
`sources/barotropic_core/rotating-open.toml` profile. Pressure, angular carrier,
gravity, mesh and integration anchors remain in `rotating-equations.txt`.
No new universal constant or source pressure coefficient is introduced.

## Input and compatibility

Physical state v2 requires `boundary=extrapolated_cylinder`,
`exterior_gravity=neglected`, and two signed edge velocities in m/s. They
declare `vR=vR_edge*R/A` and `vz=vz_edge*z/H` in the initial uniform cylinder.
Cell momentum integrates these profiles over exact cylindrical volumes.
Zero velocities recover the existing resting bulk projection. Gas must still
start dilute; no stellar mass, sink or desired outcome is accepted.

The model selection is explicit. State v1 belongs to the reflecting v1 model;
state v2 belongs to the open v1 model. Cross-pairing refuses. All numerical
schemas v2 through v7 retain their existing closed inputs and resource limits.
Original reflected fixed, adaptive, budgeted, band-refined, selectively refined
and cell-softened finite trajectories remain exact compatibility controls.

Run through `just run-rotating-core --model
axisymmetric_bate1998_barotropic_open_v1 --state
examples/rotating-core/open-cloud.state --numerics
examples/rotating-core/cell-softening.numerics --output-dir
artifacts/rotating-open-example --wall-seconds 600` on WSL/Linux. The Windows
entrypoint `scripts/dev.ps1 run-rotating-core` forwards the same arguments.
Output directories must be fresh. The native no-input exporter supplies the
admitted nominal floor; a caller-written constant is not a runnable floor.

## Accounts and independent checks

For conserved totals `Q=(mass,pR,pz,L)`, each accepted step satisfies
`Q_next-Q_old+B_step=S_step`, where `B` is signed outward boundary transfer
and `S=(0,SR,Sz,0)` is the cylindrical volume-source impulse. The cumulative
integer residual is exactly zero in all four fields. Initial mass units remain
the declared original mass; they do not renormalize as gas crosses the boundary.

Accounts use the actual rounded combined face and source impulses. Averaging
aggregated stage budgets would fail at half-even ties. Rejected trials do not
change the cumulative ledger. Remap/refinement transfers preserve the current
four-field totals and leave the boundary accounts unchanged. Gross inward and
outward mass totals accompany the signed net account.

`boundary.py` projects motion and accumulates accepted transfers.
`boundary_watchdog.py` independently integrates the entry moments, reconstructs
signed cell incidence, checks all four balances and validates each cumulative
change. The independent transport checker reconstructs the copied ghosts,
mass flux and regular angular carrier. Inward radial spin uses the copied
adjacent angular velocity at the face. This is the declared numerical trace;
it does not assert constant angular-momentum density at different radii.

Every open stage and endpoint keeps the EOS, Newtonian velocity and acoustic
screens. The potential bound uses the actual current enclosed mass and current
global softening, so inward gas cannot bypass it. Exterior mass and force are
not invented. Saved frames and the accepted-step trace bind the accounts.
The open receipt schema is `civsim.rotating-barotropic.open.run.v1` and the
underlying numerical schema remains explicit.

A host deadline stops at a checked endpoint with `execution_limit`. It is not
a physical completion. Open continuation refuses until the signed ledger and
history have their own independent original-gas restoration/replay pair.
Reflected continuation remains supported. Callback snapshots are detached from
stored receipt frames and deferred observations; diagnostic timing remains
outside causal state evolution.

This is a finite barotropic gas extension. Energy, radiation, chemical calorics,
nuclear burning, a star/disk coupling and a formed-disk classifier remain work.
