# Exact rotating-gas acceleration

This changes the evaluation cost of the existing finite operator. It retains
the physical model, numerical contract, arbitrary integers, exact rationals,
rounding points, independent checks and saved diagnostic precision. It does
not change the mesh, timestep policy, pressure law, angular carrier or gravity.
The implementation is CPU Python with no additional runtime dependency.

## Equation provenance and denominator clearing

The existing physical and numerical provenance is
[`sources/barotropic_core/rotating-equations.txt`](../../sources/barotropic_core/rotating-equations.txt),
in particular section F. It points to the held Clawpack notebook revision
`5b171f11fd7a3e810ee7a74a4d9f2dff01d65a6e`, cells4,8,11,13 for the
Rusanov face flux. Section M gives the exact cylindrical volumes and areas.
The following identities are local algebra derived from those equations,
not an additional physical law or empirical coefficient.

Let `s` be the integer scale, `d` the integer timestep, `A` the rational face
area, `Va,Vb` the rational cell volumes and `a,b` the integer conserved states.
Indices0,1,2 denote mass and the two linear momenta. Let `n=axis+1` denote
normal momentum, `pa,pb` the integer pressures and `alpha` the integer upper
signal speed. Before the existing single round-half-even projection, the
impulse of component `k` is

```text
Jk = d*A/(2*s) * [Fk(a,pa,Va) + Fk(b,pb,Vb)
                  - alpha/s * (bk/Vb - ak/Va)]
F0(y,p,V) = yn/V
Fk(y,p,V) = yk*yn/(y0*V) + delta(k,n)*p, k in {1,2}.
```

Write `Va=va/da`, `Vb=vb/db`, `A=h/e`, with positive denominators and
positive volumes. Define

```text
left  = (s*an + alpha*a0)*da*vb
right = (s*bn - alpha*b0)*db*va
factor = d*h
denominator = 2*s*s*e*va*vb

J0 = factor*(left+right)/denominator
Jk = factor*[ak*left*b0 + bk*right*a0
             + delta(k,n)*s*(pa+pb)*a0*b0*va*vb]
     /(denominator*a0*b0), k in {1,2}.
```

Substituting the volume ratios and distributing the Rusanov jump gives these
identities exactly. Every divisor is positive because validated cell mass
and volume are positive. `scripts/rotating_core/flux.py` evaluates these
integer numerators and denominators without intermediate division. The same
terminal round-half-even operation therefore selects the same integer,
including signed impulses and ties. No floating arithmetic, finite-width
overflow, approximation or intermediate rounding enters this change.

The independent transport watchdog does not import the integer flux helper.
It instead builds exact rational side weights

```text
wleft  = d*A/(2*s*Va) * (an/a0 + alpha/s)
wright = d*A/(2*s*Vb) * (bn/b0 - alpha/s)
Jk = ak*wleft + bk*wright + delta(k,n)*d*A*(pa+pb)/(2*s).
```

For mass the pressure term vanishes and `a0,b0` cancel their side velocities.
For linear momentum the expression reconstructs the same physical flux and
dissipative jump. It checks the resulting rounding cell against the producer's
integer. Angular momentum still follows the once-rounded mass carrier with
the unchanged donor choice and separate angular projection.

## Exact checks and bounded memoization

For exact rational `N/D`, with `D>0`, the round-half-even cell condition for
integer `q` is `2*abs(q*D-N)<D`, or equality with even `q`. Multiplication by
positive `D` proves equivalence to the previous rational distance check.
The mesh watchdog now uses this integer inequality directly. It neither
calls the producer rounding function nor allocates a rational for `q-N/D`.

Radial moment and centroid caches are separate in producer and watchdog.
The producer uses `(hi^2+lo^2)/2`; the watchdog uses the volume integral
`(hi^4-lo^4)/(2*(hi^2-lo^2))`. Both derive the radial centroid from its
cylindrical integral. Each cache is keyed by the exact immutable `(lo,hi)`
coordinates and holds at most128entries. Changing coordinates changes the
key; no mesh identifier substitutes for coordinates.

The watchdog alone memoizes its own independently computed timestep bound.
Each key snapshots every quantity that its bound reads: scale, radial count,
radial and axial faces, cell volumes, face incidence/areas, Courant fraction,
all four conserved fields, acoustic upper speeds and both force components.
It retains at most16immutable entries. It does not cache producer bounds,
stage acceptance or outcomes. A changed input recomputes the independent
bound. Remaining time, integer halving selection, stage impulses, residuals,
conserved totals and source/observer checks still execute on their normal path.
This removes repeated evaluation of identical bounds during an adaptive step.

## Independent generic flux residual

The independent transport checker now clears its own physical quotients
without normalizing temporary Fractions. Its starting point remains the
Rusanov face equation held in rotating-equations.txt. For the positive cell
mass `m`, scaled normal momentum `p`, acoustic upper bound `c`, cell volume
`V=v/d`, and lattice scale `s`, it computes the upper wave speed as
`ceil(abs(p)*s/m)+c`. It constructs each side's coefficient separately:
`L=(p_left*s+alpha*m_left)*d_left`, `DL=m_left*s*v_left`,
`R=(p_right*s-alpha*m_right)*d_right`, `DR=m_right*s*v_right`.

For each mass or linear-momentum component `q`, the generic flux quotient
has numerator `q_left*L*DR+q_right*R*DL` and denominator `DL*DR`.
The normal pressure term adds `(P_left+P_right)*DL*DR` to that numerator.
Multiplication by the exact face weight `dt*area/(2*s)` finishes the physical
impulse. No reduced fraction or rounded expected answer is constructed.
For final numerator `N`, positive denominator `D` and reported integer `Q`,
accept exactly when `2*abs(Q*D-N)<D`, or at equality when `Q` is even.
This is the same half-even rounding cell with unreduced integers.

Unlike the producer's simplified mass expression and paired momentum
denominators, this checker retains both generic side denominators for every
component. It imports no producer impulse helper. Angular transport, sources,
full account reconstruction, conservation and every timestep check still run.
This changes an exact evaluation path, without changing physics or precision.

Seven interleaved matched batches at the held later128-cell state and saved
256-cell state measure complete watchdog-stage gains of2.274x and2.220x.
Both implementations reject the same twelve one-bit face corruptions per
state. The integrated controls independently construct192asymmetric physical
Fraction fluxes across96/128/160bits, both directions, signed moving fields,
unequal non-dyadic volumes and zero areas. They cover signed halfway pressure
impulses and one-bit projection substitutions. Timings and the frozen original
checker live in artifacts/rotating-continuation. These are stage-check gains;
no additional whole-solver or GPU speed is inferred.

## Evidence and limits

Three interleaved comparisons per tree measure medians of21.365s
versus11.346s for128steps on128cells (1.883x), and
25.044s versus15.801s for64steps on256cells
(1.585x). All six pairs retain every scientific field exactly. The public
entry also completes all1915steps in157.467s of solver execution,
with identical saved-frame bytes and complete trajectory hash. Implementation
and execution metadata correctly change. Detailed raw scopes and receipts are
in [`artifacts/rotating-exact-speed/README.md`](../../artifacts/rotating-exact-speed/README.md).

The meaningful controls include128asymmetric signed face states across both
directions and96/128/160-bit scales, unequal non-dyadic volumes, negative and
positive halfway cells, changed-coordinate identities, and changed force,
acoustic speed, Courant and face-area cache inputs. Existing physical component,
mutation, source-custody, repeated-trajectory, observer, spin-sign and96/128-bit
controls remain active. Performance comparisons retain exact scientific
receipts and source snapshots in `artifacts/rotating-exact-speed/`.

Speed depends on state, grid and host workload. A timing observation does not
prove continuum accuracy, validate an unresolved core or establish a GPU
backend. Spatial refinement/remapping and an isolated boundary remain the
next physical work described in
[`ROTATING_BAROTROPIC_MODEL.md`](ROTATING_BAROTROPIC_MODEL.md).

> Decided. Clear exact face denominators, check integer rounding inequalities,
> and reuse independently computed bounds only for identical immutable inputs.
> Preserve every physical equation, rounding point and independent decision.
