# Prepared independent ring-field checks

Profiling real496-cell selective gas found that repeated immutable tuple
construction and hashing consumed most of the independent force-check time.
The source-major integer sum itself remained small. The checker can retain
its own already checked geometry and coefficients across fluid stages.

`gravity_watchdog.kernel` now returns a frozen private field context only
after every physical ring coefficient and symmetry check passes. It derives
the source-major traversal from actual rectangle centers, with no producer
matrix, expected answer or decision helper. It copies the rows and traversal
into immutable tuples, binding the scale and gravitational coupling once.
The live worker receives that context directly from the kernel check. A
serialized cache or caller-supplied Boolean cannot provide it. Every changed
leaf geometry regenerates and independently checks the kernel and creates a
new context. The previous one cannot authorize the new partition.

For each new positive integer mass vector the prepared checker still sums
all sources, verifies the complete force census and independently checks
both terminal half-even residual cells. It retains the384-bit storage domain
and exact arithmetic. Altered forces, types, census or coupling refuse.
Changing a caller's mutable row list cannot change its checked tuple copy.
The old directly keyed checker remains available for reconstruction and
controls. Tensor routes keep that existing path.

The equation remains the G sum in
[selective-equations.txt](../../sources/barotropic_core/selective-equations.txt):
`g_target = round(-G_scaled * sum mass_source * K_target_source / scale^2)`.
That witness retains the softened ring law, tangent quadrature, inverse root
cells, units, rounding and primary anchors. This change introduces no new
coefficient, physical branch or numerical approximation. It removes repeat
construction/hashing of the independently owned immutable traversal.

Controls compare the prepared and stock checks on real gas, refuse one-bit
field substitutions and malformed input, preserve immutable ownership, and
run original-gas repeat, observer and signed-spin trajectories. Long fleet
and local workers frozen before this optimization retain their executed
source snapshot and timings. New installed-source performance is reported
separately, without attributing it to those older executions.

> Decided. Retain independently checked immutable ring geometry across stages,
> while reconstructing each new mass-dependent force and residual exactly.
