# Selective rotating gas cells

Numerical v6 splits individual annular rectangles under the same gas model,
entry state and Jeans margin as v5. It addresses the tensor row expansion
that stopped the original-gas v5 controls near110..115thousand Julian years.
Those controls and their explicit stops remain evidence. V6 again begins
from the original dilute cylinder; it accepts no terminal cloud or star seed.

The complete local equation derivation and inherited primary anchors are in
[selective-equations.txt](../../sources/barotropic_core/selective-equations.txt).
The physical contract remains [ROTATING_BAROTROPIC_MODEL.md](ROTATING_BAROTROPIC_MODEL.md).
No new physical coefficient is introduced. Cell bounds, volumes, face areas,
overlaps, Jeans inequalities and all causal state retain exact rational or
96..160-bit integer arithmetic. Host floating arithmetic is observational.

When the maximum squared Jeans-width ratio exceeds the declared trigger,
each cell receives its minimum radial/axial dyadic depths to meet the target.
A cell already within that target remains intact. Parent averages supply
child density, linear momentum and regular angular velocity through exact
cylindrical integrals; a split supplies no finer fluctuations or particles.
The resulting leaf count is the sum of child counts. It does not multiply
whole radial and axial bands. The original domain, time and four global
integrated fields remain intact.

Coarse and fine neighbors exchange one conservative impulse per shared face
patch. Summing those patches covers each side exactly. The independent mesh
checker sweeps side planes, checks disjoint interiors and full volume, then
reconstructs actual ring-pair coverage. Gravity remains a full-cloud sum at
the original softened ring quadrature. It deduplicates only identical actual
center triples; it drops no distant source. Fixed softening still requires a
separate numerical control and can limit physical resolution.

`leaf_mesh.py` and `leaf_refine.py` implement geometry and splitting.
`leaf_mesh_watchdog.py` and `leaf_refine_watchdog.py` reconstruct their
decisions independently. The shared fluid/EOS/force/observer modules read
cell-local geometry, with separate checker access. Before the first split,
the existing mass-following tensor relocation and its complete budget ledger
remain active. Relocation then ceases. V2..v5 retain their scientific behavior.

Each accepted endpoint and both Euler auxiliary states passes EOS/storage,
Newtonian and four-cell Jeans screens in v6. The older v5 live screen covers
accepted endpoints and the first auxiliary state where force/EOS are
evaluated; its second auxiliary output has transport/storage checks. Its
held receipts remain unchanged. The broader v6 checks are explicit.

Depth, leaf, event and measured lattice-loss exhaustion produce a terminal
resource stop at resolved gas. Maximum4096leaves and64events are numerical
envelopes, not physical magnitudes. The independently reconstructed accepted
pair-step account remains sum N_before_step squared; it excludes kernel
construction, checks and bounded retries. Source-keyed checker caches store
only their own independent traversal. Separate process memory, disk and
wall-time limits govern large runs. Precision is not reduced on the fleet.

Receipt `run.v7` stores each leaf geometry as `coordinate_faces.cells`, an
ordered list of `[Rlo,Rhi,zlo,zhi]`, after selective splitting. Before that,
the same field retains tensor `r,z` arrays. Each frame owns its coordinates.
All split decisions, allocations, losses, kernel identities and clocks are
trace-bound. Geometry schemas are explicit, and a leaf cannot masquerade as
a full tensor array. Checkpoint continuation remains restricted to v4.

Run from original gas with `examples/rotating-core/selective.numerics` through
the existing native-floor `run-rotating-core` entrypoint. Results, exact
inputs, source hashes, negative controls and fleet cleanup are retained in
`artifacts/rotating-selective-cells/` and its standalone handoff archive.

This numerical change supplies no energy/radiation evolution, isolated
exterior, physical angular transport, 3D fragmentation, dust, nuclear burning,
stellar/disk promotion or completed generated system. Formation claims still
require physical closure and controlled softening/spatial comparisons.

> Decided. Resolve the evolving original gas with exact selective cell splits,
> complete shared face cover, global ring gravity and independent accounts.
> Keep explicit approximation/resource limits and the original gas history.
