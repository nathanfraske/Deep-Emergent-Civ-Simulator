# Exact ring and force acceleration

The rotating solver spends time normalizing temporary rational numbers in
each ring coefficient and looping over arbitrary integers in each force sum.
The new modules evaluate the same finite operator through exact integer
identities. Physical inputs, pressure, gravity softening, quadrature, precision,
step selection, conservation, independent acceptance and stopping rules remain
unchanged. This is CPU acceleration, with no GPU production claim.

[exact-gravity-equations.txt](../../sources/barotropic_core/exact-gravity-equations.txt)
holds the full local derivation. Its ancestry is the existing sourced softened
ring and selective-cell witnesses. The producer uses common coordinate and
quadrature denominators; the checker expands the squared distance separately,
checks each inverse square cell and folds rational numerators/denominators in
reverse node order. Each terminal half-even residual remains checked.

Tensor and leaf force matrices use immutable biased source columns in the producer.
The independent geometry traversal uses separately packed positive and negative
coefficients. Both prove that the positive conserved mass bound prevents
cross-digit carries, decode every target, and retain the original final rounding.
A call above the optimized mass bound uses the former exact traversal. This
preserves the existing384-bit cell domain. The watchdog imports no producer
packing, quadrature, force or expected-answer helper.

Tensor geometry now also returns an independently owned field context after
its complete kernel and symmetry checks. Its source-major indices are derived
separately from the producer matrix. Direct reconstruction remains available.
This supersedes the predecessor's tensor fallback in ROTATING_FIELD_BINDING.md;
earlier frozen workers and their receipts retain that prior implementation.

Focused controls compare the full Fraction equations at96/128/160bits, zero
and unequal radii, self interaction, several angular resolutions, signed force
components, positive/negative half ties, the exact mass-bound edge and384-bit
fallback. One-bit changes refuse. Real gas and full original-gas trajectory
comparisons retain the previous executed source as the reference. Raw timings
distinguish complete solves, complete stages and kernel-only work.

This acceleration does not remove fixed-softening sensitivity or supply a
star classifier. A resolved pressure-supported second core in the spherical
route remains the available fast protostar example. Rotating collapse still
needs controlled gravity resolution, isolated exterior and core/disk physics.

> Decided. Evaluate the same ring and force equations with bounded exact
> integer layouts, preserve independent residual checks and full precision,
> and measure complete-solver benefit before attributing a practical speedup.

Global diagnostic moments have no causal caller in this rotating model. Their
large exact rational sums are now deferred until a saved frame, event receipt,
progress reader or final receipt requests them. The read-only mapping captures
the exact geometry, state, pressure fields and force for that endpoint. Its
factory computes the unchanged values and independently reconstructs them
before returning any value. Physical EOS, force, transport, conservation,
Newtonian and refinement checks still execute at every required stage or
endpoint. No pressure-supported-core classifier is deferred or added here.
Complete scientific receipts and journal bytes match eager controls; observer
access and sampling still cannot change the gas or trace. This is execution
scheduling of existing diagnostics, with no new equation or approximation.
