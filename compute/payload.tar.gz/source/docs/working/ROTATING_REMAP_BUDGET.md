# Budgeted rotating gas mesh moves

Numerical v4 adds explicit limits on the averaging introduced by the optional
mass-following grid. It evolves the original declared gas under the same
source-bound barotropic model. No star, disk, outcome, new physical coefficient
or new starting state is supplied. V2 and v3 remain supported.

The exact numerical derivation is held in
[remap-budget-equations.txt](../../sources/barotropic_core/remap-budget-equations.txt).
It uses the existing [cylindrical overlap derivation](../../sources/barotropic_core/remap-equations.txt)
and [physical model](ROTATING_BAROTROPIC_MODEL.md). Its independent source
check binds the numerical witness before and after every v4 CLI run.

The old proposed coordinates still come from the independently checked
regularized marginal mass. A separate selector tries that proposal, then
successively halves its displacement from the original faces. Each trial
projects the original fields directly; rejected projections never become
inputs to another projection. The search makes no assumption that losses
decrease monotonically. It accepts the first positive-mass trial within both
the per-event and remaining cumulative limits. A bounded search that finds
none leaves the original fields and faces in place. An identical proposal
also avoids projection and kernel reconstruction.

The new closed fields are `remesh_density_budget`, `remesh_angular_budget`,
`remesh_event_fraction` and `remesh_backtracks`. The first three are explicit
numerical fractions in (0,1]; the last is an integer from 0 through 16.
The example supplies total density and angular representation budgets of 2%,
and an event fraction of 0.125, giving a 0.25% ceiling on each event for each
measure. Its twelve backtracks allow at most thirteen trial projections.
V4 counts every scheduled decision toward `remesh_max_events`, including
declined, exhausted and unchanged moves. Work is therefore bounded even when
no grid change is accepted.

Density loss is the exact volume integral of the absolute difference between
the old and new piecewise density fields, divided by conserved initial mass.
The angular measure compares the regular angular density profiles using the
integral of radius squared over volume and the current absolute angular
account. Its denominator can vary for mixed signs; it is not an energy or
velocity norm. It is zero for a zero angular field. Both include the integer
projection differences. The limits bound sums of these observed numerical
changes. Subsequent fluid evolution can amplify them; these sums do not bound
the final trajectory difference or the unknown continuum solution.

`remap_budget.py` owns the finite trial search. The independent
`remap_budget_watchdog.py` constructs each overlap partition, projects it with
Python Fraction's exact half-even primitive, integrates the two represented
differences and verifies the complete rejected prefix and first valid choice.
It imports no producer decision helper. Accepted transfers still pass the
original independently constructed remap account check. A separate final
ledger reconstruction checks every prior/new cumulative account, scheduled
decision order, accepted-event association and final total. A reset, omitted
decision or unbound applied event refuses.

Each decision records its original faces and fields, full proposal, ordered
exact trial losses, selected displacement and cumulative accounts. These are
bound into trajectory v4 before any accepted remap event. Accepted geometry,
gravity kernels, EOS, forces, time integration and observations retain their
independent checks. Description and saved-frame cadence remain noncausal.
An event limit is a numerical resource constraint, not a physical stopping
condition or an instruction to create a particular core.

Run a fresh directory through the existing public native-floor entry:

```powershell
pwsh -NoProfile -File scripts/dev.ps1 run-rotating-core --state examples/rotating-core/cloud.state --numerics examples/rotating-core/budgeted.numerics --output-dir artifacts/rotating-remap-budget/budget128
```

Focused controls cover signed four-field conservation, remaining capacity,
full rejection, unchanged faces, spin reversal, zero
angular fields, loss and ledger mutations, complete-history omission, source
mutation, exact repeated gas runs and observer independence. A declined-move
gas run preserves the fixed-grid gas values at every saved sample. Full cases
and their independent reconstructions live in
[the evidence directory](../../artifacts/rotating-remap-budget/README.md).

This policy constrains an approximation already shown to average away detail.
It adds no higher-order reconstruction, nested refinement, continuum enclosure,
isolated exterior, radiation, chemistry, nuclear burning, dust or formed-disk
classification. Small-scale gravity and spatial sensitivity remain separate
work. The earlier spherical gas-derived second core remains within its model.

> Decided. Keep physics, declared gas entry and numerical budgets separate.
> Use an independently checked, finite displacement search and complete ledger
> for optional mesh relocation. Preserve exact conserved transfers and all
> refused or declined cases; no numerical limit establishes physical accuracy.
