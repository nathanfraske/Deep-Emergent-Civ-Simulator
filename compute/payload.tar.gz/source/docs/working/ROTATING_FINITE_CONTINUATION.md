# Continue the same finite surrounding gas

The finite-cloud restart uses the existing complete original-gas replay and
adds a separate producer/checker pair for cumulative finite boundary accounts.
It advances the declared nested gas under the same pressure, full resolved
gravity, transport and reflecting wall. It adds no physical starting object,
coefficient, thermal model or disk criterion. Exact equations and ancestry are
in [finite-continuation-equations.txt](../../sources/barotropic_core/finite-continuation-equations.txt),
C1-C4, inheriting the original finite projection and boundary-source anchors.

Only numerical v6/v7 continuation is supported. Fresh finite run.v1 receipts
retain their historical bytes and false continuation_supported metadata.
They may propose a restart; complete independent replay supplies admission.
Continued finite run.v2 records the existing continuation.v2 lineage. Every
segment retains its original capacities, clipped endpoint and host ordinal
cut. Historical executable claims must keep their own execution binding;
only current independently checked replay establishes the supplied state.

The sealed replay capability restores ordered leaf rectangles or tensor
faces, exact gas cells, clock, initial observations, prefix frames, remap and
refinement decisions/events, spent loss budgets, retries and cumulative pair
work. The new pair also restores the original four moments, signed wall
impulses, volume-source impulses, endpoint moments and zero residuals. Its
checker compares the original moments against the dilute original projection
and binds all restored fields to both the replayed endpoint and terminal
account. A rebalanced ledger with a new initial moment refuses.

The kernel is reconstructed and every coefficient independently checked.
Reading a large cache now uses the existing saved-frame reader's 1536 MiB
bound rather than refusing at 64 MiB. Binding or cache hashes cannot substitute
for coefficient mathematics. Large jobs retain actual allocation, C: space,
evidence-size and total wall guards. No precision or force shortcut is used.

Only cumulative max_steps, max_elapsed_s, max_pair_steps and sample_every may
extend through the existing monotonic numerical contract. Physical state,
precision, pressure, Courant fraction, quadrature, softening, refinement
policy/capacity and projection loss budgets stay fixed. Changed causal
contracts require a new original-gas run. Observer callbacks receive copies.

Use the existing run-rotating-core interface with the finite model, original
state, extended numerical capacity, accepted parent path and a fresh output
directory. For finite continuation --wall-seconds starts after complete replay
and limits forward evolution. A supervisor must bound replay plus evolution.
Replay is not accelerated formation and may remain costly; useful workers
may prepare independent controls while it runs. Earlier immutable evidence is
preserved and the new computation has its own source/execution identity.

The focused controls compare resumed gas and all cumulative accounts against
uninterrupted runs, including selective/width-limited modes, tensor/leaf
geometry, clipped clocks, chained cuts, signed motion and observer changes.
Corrupt or rebased accounts, history, types, source identities and unsupported
numerical modes refuse. This routine extension uses focused verification.
It does not establish a settled disk, continuum convergence, an isolated
surface, stellar radiation, nuclear burning, dust or a completed system.

> Decided. Continue the same finite original gas only after full independently
> checked reconstruction. Preserve all gas, numerical and wall-force history
> without resetting its initial state or cumulative budgets. Constants retain
> floor admission; declared state and numerical capacity stay separate.
> Unsupported and forged history refuses. A longer evolved interval grants
> no physical disk or completed-system classification.
