# Jeans-driven rotating gas refinement

Numerical v5 starts the same declared dilute cylinder and splits its mesh as
the independently reconstructed Jeans-width diagnostic approaches its limit.
It addresses the failed spatial screen in the longer128/256-cell histories.
Those late histories remain diagnostics. No terminal state, dense seed or
stellar object is supplied to this path.

The numerical derivation and physical anchors are held in
[refinement-equations.txt](../../sources/barotropic_core/refinement-equations.txt).
It inherits the sourced [barotropic model](ROTATING_BAROTROPIC_MODEL.md),
[cylindrical projection](ROTATING_ADAPTIVE_MESH.md) and
[relocation budget](ROTATING_REMAP_BUDGET.md). The Jeans four-cell criterion is
the Klein1998 printedp6 anchor already held in rotating-equations.txt.
No new physical law or coefficient enters. All causal arithmetic retains the
declared96..160-bit scale and exact rationals.

`refine.py` compares squared radial and axial widths with the current local
Jeans length. The explicit trigger stays at or below1/32, leaving a margin
below the diagnostic limit1/16. The target is lower than the trigger. Every
affected radial or axial band takes its minimal dyadic subdivision sufficient
for all associated cells. The union is a tensor partition; extra cells appear
along those bands. This is more limited than a sparse adaptive tree.

The original faces, domain, clock and physical units remain intact. The exact
overlap transfer apportions constant density and linear momentum by volume,
and regular angular momentum by the integral ofR squared over volume. Signed
mass/momentum/spin accounts close on the integer lattice. In the unrounded
limit a split preserves the old represented fields; it invents no smaller
fluctuations or particles. The independent checker measures projection loss
and adds it to separately declared density/angular budgets. Those measured
representation changes do not enclose continuum or final trajectory error.

`refine_watchdog.py` independently reconstructs the width inequalities, minimal
depths, count limits, nested geometry and split admission. The existing
independent overlap checker verifies all child allocations. Geometry, EOS,
force, actual-separation ring kernels, fluid stages and saved observations
retain their separate checks. Accepted endpoints and transient Euler states
must pass the1/16 Jeans-width screen. Refinement keeps gravity softening fixed;
mesh resolution does not establish adequate small-scale gravity.

The older mass-following relocation operates only before the first split. Its
entire accepted and declined history remains present. Relocation then ceases
to avoid averaging the new detail. Split decisions and events are trace-bound,
with original and refined cells, coordinates, observations, kernels and losses.
Each saved frame supplies its own dimensions and faces.

Depth, cell, axis and event capacity are bounded. A split that cannot fit, or
whose projection exceeds the remaining budget, stops at the last resolved gas
with an explicit reason. It does not relax precision or evolve an unresolved
state. Pair-step capacity bounds accepted steps by cell count squared; the
independent ledger reconstructs the live debit from mesh epochs. Kernel
construction, separate checks and bounded retries are excluded from that
definition and remain separate work. Host timing and plots never advance gas.

Run the public native-floor path in a fresh directory:

```powershell
pwsh -NoProfile -File scripts/dev.ps1 run-rotating-core --state examples/rotating-core/cloud.state --numerics examples/rotating-core/refining.numerics --output-dir artifacts/rotating-jeans-refinement/refining128 --workers 8
```

The example starts128cells at96bits and permits1024cells, twelve split events,
four dyadic levels per event, full32768-step capacity and a4.5e12s endpoint.
Softening is1.75e13m; trigger/target squared are1/32 and1/64. Separate split
loss budgets are1e-12, while the old relocation budgets remain2% each.
These are declared numerical controls. V2/v3/v4 and checked v4 continuation
remain available. V5 numerical inputs currently run from original gas and
refuse checkpoint continuation; its new full receipt isrun.v6.

Focused controls exercise the numerical inequalities and exact threshold
tie, signed four-field projection, nested geometry, loss/capacity stops,
unresolved transient rejection, altered faces/depths/counts/types/accounts,
complete loss/work history, original-gas integration, repeated trajectories,
signed spin and noncausal descriptions/sampling. Long cases, independent
result reconstruction, scope, performance and cleanup live in
[the results](../../artifacts/rotating-jeans-refinement/README.md).

The physical limits remain barotropic pressure, a reflecting exterior,
numerical softened ring gravity and axisymmetry. This change supplies no
thermal/radiative evolution, isolated exterior, physical angular transport,
non-axisymmetric fragmentation, dust, nuclear burning, disk classifier or
completed system. Controlled softening and spatial comparisons precede any
claim about resolved stellar formation.

> Decided. Refine the evolving original gas from independently checked
> Jeans-width inequalities, preserve its conserved fields and numerical
> history, and stop when the declared resources cannot maintain resolution.
> A passed width screen grants no star, disk or continuum-accuracy claim.
