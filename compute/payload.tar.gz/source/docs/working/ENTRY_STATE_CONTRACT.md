# Physics, entry state, and numerical contract

Owner decision, 2026-09-27: the current implementation path accepts an explicit
physical starting state. This supersedes the former sole-floor input rule for
this route. The strict `run_planet` route remains a separate deeper-origin
research path. Its unresolved species and initial-measure proofs do not prevent
a declared effective model from evolving a checked, conditional starting state.

## Three separate responsibilities

1. **Physics model.** Versioned laws, constants, effective approximations,
   validity domain, equations, evidence, and implementation identity. A citation
   alone does not validate a law. Constants keep their existing admission;
   proposed effective laws need explicit scope, derivation or primary evidence,
   independent mechanical checking, and meaningful physical benchmarks.
2. **Entry state.** Quantities with units, geometry, boundary conditions, and
   origin. Origins distinguish a declared hypothesis, observational inference,
   and a checked upstream simulation. Only declared hypotheses are implemented
   in v1. Future origin adapters must validate their evidence before activation.
   Validated means internally consistent and supported by the selected model;
   it does not mean observed, cosmologically generated, or uniquely predicted.
3. **Numerical contract.** Resolution, error enclosures, work limits, output
   sampling, and stopping conditions. These control approximation and resources.
   Changing them must not alter physical laws or the semantic initial state.

Observer names, file paths, formatting, and descriptions cannot affect physical
evolution. Receipts distinguish physical identity, execution identity, and
descriptive metadata. Every accepted input is recoverable from the receipt.
Unknown fields, duplicate fields, incompatible states, and unsupported model
identities refuse. The available model list is an implementation registry, not
an ontology of possible bodies or systems.

No entry adapter accepts requested stars, planets, orbital layouts, a desired
Solar System, or an undocumented Milky Way preset. A galaxy region must become
an explicit physical state with its inference or upstream-simulation evidence.
The eventual upstream handoff replaces the origin of a state, not the downstream
physics. It may require a richer versioned state schema.

## First executable model

`newtonian_uniform_dust_v1` is a Newtonian, isolated, spherical continuum with
uniform initial density, initially at rest, zero pressure, no rotation, and
no other interactions. It is a collapse benchmark. It is not a gas-cloud,
star-formation, disk, or planet model. The code stops before the central
singularity; it cannot create a sink, star, or completed planetary snapshot.

The example mass and radius are declared hypothetical conditions, not measured
Milky Way data. Effective-model incompleteness stays visible in every receipt.
The exact trajectory and numerical bounds are derived in
[SPHERICAL_COLLAPSE_MODEL.md](SPHERICAL_COLLAPSE_MODEL.md). Its independent pair
checks state admission and every emitted trajectory enclosure. Mechanical
agreement establishes this bounded computation, not astrophysical completeness.

## Gas pressure component

`monatomic_euler_1d_v1` adds a separate checked gas model with density, three
momentum components, internal/total energy, pressure and a passive mass marker.
Its periodic planar finite-volume implementation uses exact initial averages,
explicit rounded face transfers and independent checks of every step. Model,
physical zones and numerics retain separate identities. Equation provenance,
approximation bounds and applicability limits are in
[PLANAR_GAS_MODEL.md](PLANAR_GAS_MODEL.md); runnable inputs are in
`examples/gas/`. This component does not yet couple gas pressure to gravity.
The marker is not an element, and there is no particle mass or temperature
census. Three momentum components in one spatial dimension do not establish
rotating three-dimensional cloud or disk dynamics.

## Coupled spherical gas and gravity

`newtonian_spherical_gas_v1` connects pressure work and self-gravity in a
moving radial mesh. The declared hypothesis supplies mass, initial radius,
central specific internal energy and outer radial velocity, with uniform
initial density, a quadratic thermal profile, linear radial velocity and a
vacuum surface. Every step has an independent force/work residual check and
an explicit energy-drift budget. Mass is fixed exactly. The geometry supports
radial motion, not angular momentum. No particles or elements are supplied.

`collapse-demo` runs cooler and hotter states through the solver, a separate
continuum reference and an offline replay. `collapse-benchmark` compares three
meshes of each physical state. Equations, exact source anchors, numerical
choices and scope are in [SPHERICAL_GAS_MODEL.md](SPHERICAL_GAS_MODEL.md).
The observer displays saved frames and never advances the physics.

The v2 radial state schema supplies smooth density, internal-energy and radial
velocity curves using explicit bounded coefficient arrays. Exact shell masses
and mass-weighted thermal averages are independently reconstructed before
evolution. It uses the same scoped gas-gravity model and supports concentrated
clouds without an inserted stellar object. See
[RADIAL_CLOUD_PROFILES.md](RADIAL_CLOUD_PROFILES.md) and `collapse-radial`.

## Rotating affine gas and gravity

`newtonian_affine_spheroid_v1` evolves a uniform monatomic spheroid with
explicit equatorial/polar radii, axis velocities, central specific energy,
mass and signed angular momentum. Its quadratic thermal profile and affine
velocity family are declared restrictions. A separate checker reconstructs
shape-coefficient bounds, rounded time steps, Newtonian screens and energy
and entropy budgets. The state admits either spin sign and prolate or oblate
geometry within its numerical envelope. Mass and angular momentum are exact.

`affine-demo` supplies no-spin, spinning, reversed-spin and time-refined cases,
with a separate high-precision SI reference. Equations, source custody and
limits are in [ROTATING_CLOUD_MODEL.md](ROTATING_CLOUD_MODEL.md). This family
does not include cooling, spatially resolved transport, fragmentation or a
formed disk. Its geometry restriction is not derived from a galactic region.

## Progression toward a system

Supported composition now includes fully ionized hydrogen with Kramers
free-free cooling and dilute neutral H/H2 with GA08 molecular cooling.
The latter declares its molecular fraction, fixed spin ratio and thin-line
escape assumption; it does not form molecules or solve level populations.
Both retain a matched adiabatic control, material census and independently
checked escaped-radiation account. See `HYDROGEN_THERMAL_MODEL.md` and
`MOLECULAR_CLOUD_MODEL.md` for their distinct domains and evidence.

Next extend chemistry and radiation beyond those limited domains and couple
spatially resolved angular momentum, gas transport and cooling.
The independent shock and contact benchmarks are component evidence, not
gas-collapse evidence. The separate spherical reference tests the coupled
smooth-flow calculation; it supplies no general shock or continuum-error theorem.
Follow with rotating collapse and disk evolution, solids and growth, and orbital
dynamics. Each new physical approximation carries its own evidence and limits.
An early galactic-region generator is an upstream project after the local
state-to-collapse path works, rather than a new prerequisite for that path.

Review uses the current contract here. The old ban on explicit starting states
is not a finding against this owner-approved route. The bounded-review rule
still applies: only reproduced, reachable failures block; no audit loops.
