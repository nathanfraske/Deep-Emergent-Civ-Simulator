# Checked continuation from original rotating gas

The saved 128 and 256 cell cases were still compressing at their common
requested endpoint of 2.45e12 seconds. Both passed the existing Jeans-width
screen. Repeated spatial and timestep controls stopped at that same endpoint;
they did not advance to a later formation state. Numerical continuation now
lets the same gas evolve further under its original physical assumptions.

The exact recurrence and admission contract are held in
[continuation-equations.txt](../../sources/barotropic_core/continuation-equations.txt).
It inherits the [physical model](ROTATING_BAROTROPIC_MODEL.md),
[mass-following mesh](ROTATING_ADAPTIVE_MESH.md) and
[representation budget](ROTATING_REMAP_BUDGET.md). No additional physical
constant, pressure law or starting condition enters this change.

`checkpoint.py` reads bounded exact JSON and formats the original decimal
inputs. `checkpoint_watchdog.py` admits a checkpoint by integrating the
original dilute gas and every prior continuation segment with the existing
independent geometry, pressure, force, transport, timestep, observation and
remap checks. It requires exact typed equality of the complete scientific
receipt. Supplied terminal cells, hashes or historical executable claims do
not bypass this replay. Historical implementation claims retain their internal
execution binding as custody metadata; the current replay establishes the
scientific state.

The checker seals the reconstructed prefix. The integrator restores its exact
cell lattice, coordinate faces, clock, initial conserved accounts, prior
frames, remap events and decisions, spent budgets, accepted steps and retry
count. All subsequent cadence and resource accounting use the original
global step index. No projection of the prefix or reset of its density,
momentum, spin or representation budget occurs. A trajectory marker binds the
parent identity, step, clock and new numerical contract before the next step.
Labels, paths, historical executable claims and saved-frame cadence do not
enter that marker.

Only cumulative step capacity, requested end time, saved-frame cadence and
cumulative pair-work capacity can change. Capacities cannot shrink, and the
new endpoint must exceed the current clock. Mesh sizes, pressure, precision,
softening, angular quadrature, Courant fraction and remap policy stay fixed.
The numerical input remains v4; an accepted continuation receipt is v5 and
records its original contract and each parent cut. Subsequent admission
replays that whole lineage, with at most eight continuation segments.

The old final timestep may have been clipped to its requested end time.
A continuation therefore need not equal a single run originally requesting
the later time. Its exact cut and timestep history are part of the receipt.
The prefix frames remain intact, and physical time advances only by checked
accepted steps.

Use a fresh output directory with an accepted parent receipt:

```powershell
pwsh -NoProfile -File scripts/dev.ps1 run-rotating-core --state examples/rotating-core/cloud.state --numerics examples/rotating-core/continuation.numerics --continue-from artifacts/rotating-remap-budget/budget128/receipt.json --output-dir artifacts/rotating-continuation/continued128
```

The public example still acquires the native floor and retains raw parent
bytes, inputs, journal, kernels, logs and status. Its later requested time is a
numerical work limit, not an instruction to create a star. The checker still
refuses unsupported states and domains. The existing gas model remains
barotropic with softened ring gravity and a reflecting exterior; continuation
adds no radiation, energy evolution, isolated boundary, nuclear burning or
formed-disk classification. Resolution sensitivity still requires evidence.

Focused controls cover uninterrupted work-limited gas values, exact prefix
preservation, cumulative budgets and capacities, clipped endpoint clocks,
repeatability, labels and sampling, chained replay, altered cells, omitted
history, false star claims, type substitutions, lineage binding, source
mutation and historical execution binding. These controls establish the
scoped numerical mechanism, without establishing continuum accuracy.

> Decided. Continue the same checked original gas only after complete replay
> through independent numerical checks. Preserve global history and budgets,
> keep constants and declared physical entry separate from numerical capacity,
> and refuse forged, incomplete or changed causal contracts. A later numerical
> endpoint confers no stellar, disk or completed-system classification.
