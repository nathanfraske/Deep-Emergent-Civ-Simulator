# Continuing selective rotating gas

Long selective-cell computations previously lost their complete receipts when
the outer supervisor killed the worker at its deadline. Their saved journals
remain partial evidence and cannot become initial clouds or checkpoints. The
new execution cut finalizes a fully checked finite gas prefix before returning.
Numerical v6 can then continue that prefix under its original physical and
causal numerical contract. No star, sink, late cloud preset or law is inserted.

The complete local recurrence is in
[selective-continuation-equations.txt](../../sources/barotropic_core/selective-continuation-equations.txt).
It inherits the original continuation, selective geometry, sourced pressure,
cylindrical Euler and softened global ring-gravity equations. The arithmetic
precision and independent stage/endpoint checks remain unchanged.

`--wall-seconds` asks the worker to stop at a complete accepted endpoint. Host
time never determines a fluid timestep or force. The returned receipt retains
the original numerical input, exact cell geometry, all saved observations,
remap and split events/decisions, projection-loss accounts and cumulative
accepted-step pair work. Its `execution_limit` means the requested physical
time was not completed. Kernel construction or a step can run past the wall
deadline; an outer hard stop remains a failure with partial evidence.

An archived prefix still needs independent full replay from the original
dilute gas. A deadline-stopped receipt is reconstructed by its checked step
ordinal, without reproducing host timing. No step or past stage is skipped.
The continuation checker requires typed equality of the entire scientific
receipt before sealing it. Kernel caches can avoid producer construction, but
their complete independent coefficient checks remain. Continuation does not
make replay free or establish continuum accuracy.

The solver restores exact tensor faces or ordered leaf rectangles and rebuilds
their independently checked geometry and gravity. It retains both cumulative
histories and loss accounts, accepted work, original conserved quantities,
global clock, retries and frame history. There is no reinitialization or
projection. Only cumulative step/time/work capacity and observer sampling may
extend. Precision, softening, quadrature, Courant policy, refinement and
representation-loss limits cannot change at a continuation boundary.

Fresh selective receipts remain run.v7. Continued selective receipts are
run.v8 with lineage.v2, binding every parent's stop reason, step, clock, trace
and numerical contract. Earlier numerical v2..v5 and normal v4 continuation
retain their scientific output. Altered cells, geometry, histories, work,
losses, cut clocks, stop reasons, lineage or causal controls refuse on replay.

Use a fresh output directory and a complete accepted parent:

```powershell
pwsh -NoProfile -File scripts/dev.ps1 run-rotating-core --state examples/rotating-core/cloud.state --numerics examples/rotating-core/selective.numerics --wall-seconds 1800 --output-dir artifacts/my-rotating-prefix
```

For continuation, add `--continue-from` with the parent receipt and supply a
numerical file with nonshrinking cumulative capacity and a later endpoint.
An incomplete journal or zero-byte receipt is not a parent. The existing
barotropic, reflecting-boundary and gravity-resolution limits remain explicit;
stellar/disk classification is still absent from this rotating model.

> Decided. Preserve full checked selective gas prefixes at execution cuts,
> replay their original history before continuation, retain both complete
> numerical accounts and refuse changed causal contracts. Host work limits
> authorize neither a new physical state nor a formation outcome.
