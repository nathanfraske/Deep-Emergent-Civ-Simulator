# Conserved adaptive core and envelope mesh

Numerical contract `civsim.rotating-barotropic.numerics.v3` redistributes the
same R-z cells as the gas evolves. It starts from the original dilute uniform
cylinder, carries no core seed, and retains the current Bate1998 pressure law,
sealed nominal G, reflecting domain, numerical mass-carried angular transport,
96 through160 fraction bits, and explicit fixed gravity softening. The physical
model and entry identity stay separate from this numerical choice. V2 fixed
meshes remain supported and keep their trace and frame schema.

The numerical equation and provenance record is
[`remap-equations.txt`](../../sources/barotropic_core/remap-equations.txt).
It derives coordinate redistribution, exact overlap integrals, conservative
integer allocation, root rounding cells and information-loss observations
locally from the held cylindrical geometry. Those identities introduce no new
physical coefficient. The physical primary anchors remain in
[`rotating-equations.txt`](../../sources/barotropic_core/rotating-equations.txt)
and [the model contract](ROTATING_BAROTROPIC_MODEL.md). A separately pinned
watchdog checks the new numerical witness before and after a run.

## Following the resolved gas

`adapt.py` sums current radial and vertical marginal mass and blends each
normalized distribution with a uniform geometric measure. The supplied
`remesh_regularization` reserves coverage of the dilute envelope. Inverse CDF
targets are the original power mesh's uniform-cylinder mass fractions. The
targets therefore follow the gas without specifying a desired core radius or
stellar mass. Coordinates use exact rationals and square-root rounding at the
full declared binary scale. `remesh_relaxation` blends old and proposed faces;
its upper bound of1/2 limits one-event width contraction to a factor of1/2.

`remesh_interval` counts accepted fluid steps independently of saved frames.
`remesh_max_events` caps redistribution at32. Outer faces and cell count stay
fixed. No accepted time interval is jumped, and the normal two-stage timestep
checks continue on each new geometry. The exact actual-separation ring kernel
is regenerated and independently checked after every event. Per-step pairwise
gravity cost stays at the same cell count, although finer cells can require
more fluid steps and each remap has kernel-construction cost.

## Transfer and independent acceptance

`remap.py` integrates every overlap in cylindrical volume. Constant density
and linear momentum density use the volume fraction. Regular cell rotation
uses the fraction of the integral of R squared over volume for angular
momentum. This preserves a uniform-density rigid-rotation profile up to the
explicit integer projection error. Treating angular momentum as uniform
within the cell would change that rotational profile near the axis.

Each old cell allocates its signed fields by differences of cumulative
half-even projections. The final cumulative fraction is exactly1, so each
source cell and all four global remap accounts close exactly. There is no
clipping, rescaling or arbitrary leftover destination. Nonpositive target
mass refuses. `remap_watchdog.py` independently builds the overlap product
measure, checks each cumulative residual, reconstructs each destination and
checks complete source and global accounts. `adapt_watchdog.py` separately
checks the inverse-CDF equations and root cells without importing producer
decision helpers. `mesh_watchdog.py` rebuilds geometric coverage, volumes,
areas and all actual separation indices.

Remapping changes the finite approximation. Its receipts record the density
and angular-profile L1 differences between the two represented fields, plus
before/after spatial moments and rotational quadratic quantity. These are
observed information loss, not error bounds against the unknown continuum
solution. There is no evolved energy field, so conserving these four fields
does not establish energy conservation. The inner-quarter observer now
integrates partially covered cells so moving a face cannot silently discard
gas from its observation window; fixed example meshes give the old result.

V3 receipts retain every old/new face partition, pre-remap field, ordered
transfer, post-remap field, diagnostics and gravity-kernel identity in a
trace-bound event. Each saved frame includes its own coordinates and mesh
revision. Descriptions, plot changes and sample cadence cannot alter remap
decisions. All implementation and numerical witness hashes are checked again
at completion. A cached kernel still requires independent mathematical
validation under its exact geometry binding.

Exact remap diagnostics can contain rational integers longer than Python's
default4300-digit conversion limit. The shared low-level receipt primitive
now writes and reads decimal chunks with an explicit1048576-bit integer cap.
It preserves the same canonical rational text and keeps the host's input
conversion guard enabled. Physical input parsers retain their short closed
contracts. Progress renders nine significant decimal digits from exact
diagnostics; the complete rational values remain in the receipt. No state or
diagnostic precision is reduced. A held256-cell attempt exposes the old
serialization refusal, and its repaired continuation uses the same gas,
operator, rounding and numerical controls from the beginning.

## Running and validation

The normal native-floor public command is:

```powershell
pwsh -NoProfile -File scripts/dev.ps1 run-rotating-core --state examples/rotating-core/cloud.state --numerics examples/rotating-core/adaptive.numerics --output-dir artifacts/rotating-core-remap/adaptive128
```

Choose a fresh output directory. The example uses128cells,96fraction bits,
fixed1.75e13m softening, regularization0.25, relaxation0.5, interval256 and
at most16remaps. These are numerical controls, not physical constants.
The source and resource screens remain mandatory. The same path accepts
signed entry spin and different supported dilute cylinder states.

Focused tests cover inverse-CDF admission, strict face coverage, constant
density and rigid rotation, signed field conservation, same-grid identity,
96/128/160-bit overlap controls, balanced transfer corruption, missing
coverage, changed geometry, witness tampering, partial-window integration,
three remaps in a real gas trajectory, exact repetition, spin reversal and
observer independence. They run through the existing rotating-core gate.
Longer trajectories, controls, raw progress, comparison and replay receipts
live in [the evidence directory](../../artifacts/rotating-core-remap/README.md).

The remaining physical gaps include small-scale gravity and spatial
convergence, an isolated exterior, accretion and a resolved disk. This
increment supplies no particle census, dust collision law, radiation or
thermal energy closure, nuclear burning, fragmentation, inserted star or
completed system. The separately formed spherical second core remains valid
within its own model. Adaptive internal particle samples remain the separate
[weighted population candidate](CELL_PARTICLE_POPULATIONS.md).

Numerical v4 adds an optional independently checked finite displacement search
and complete density/angular averaging ledger. Its rejected trials always
project the original fields, and a declined move leaves them in place. V3
retains its prior operator and receipts. See [the explicit budget contract](ROTATING_REMAP_BUDGET.md)
and [new complete controls](../../artifacts/rotating-remap-budget/README.md).
