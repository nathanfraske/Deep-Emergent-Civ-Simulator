# Finite surrounding gas with full resolved gravity

The separate `axisymmetric_bate1998_barotropic_finite_cloud_v1` model starts
from physical state v3: dilute inner gas and a finite surrounding gas region
inside an outer cylinder. Both evolve under the existing source-bound
barotropic pressure, conservative transport and global softened ring gravity.
All resolved surrounding mass contributes to every gravitational field. The
outer reflecting slip wall supplies no gas or axial torque. Its pressure
impulses are recorded. This is a confined finite cloud; an isolated vacuum
surface and boundary-independent formation remain unsupported.

The original open model exposed material supplied by its copied exterior.
This route gives the surrounding gas an explicit mass, extent, state and
evolution. No supplied star, sink, external fixed field or target disk enters.
The old uniform reflecting and copied-exterior models keep their separate
identities, input schemas and finite scientific controls.

## State, projection and ownership

`mass_kg`, `radius_m` and `half_height_m` describe the whole represented gas
domain. `inner_mass_kg`, `inner_radius_m` and `inner_half_height_m` describe
one nested dilute gas region. Remaining mass occupies the disjoint surrounding
volume. Positive mass and strict nesting are required. Both continuous density
values pass the dilute entry screen before meshing, so a tiny hidden dense
region cannot pass by dilution into a coarse cell. All magnitudes retain their
declared hypothetical origin and physical units.

Solid rotation and the signed linear radial/axial velocity profiles have exact
mass-weighted cell moments. `finite_cloud.py` integrates the entire cell plus
its clipped inner intersection. `finite_cloud_watchdog.py` independently cuts
the cell into disjoint rectangles and integrates each with its own density.
Cumulative half-even allocation gives exactly the total declared mass; cell
momentum uses the represented positive mass and checked integral moments.
There is no particle census or advected region-of-origin tracer.

The same global kernel and independent force contraction process every gas
cell. An inner-only force substitution refuses the complete-field check.
Every stage retains EOS, acoustic, velocity, total-mass and current-softening
Newtonian screens. Accepted per-face and source impulses supply the cumulative
four-field ledger. Mass and axial angular momentum remain exact, while outer
wall normal force and cylindrical volume sources remain separately visible.
Remap/refinement retains the whole domain and these represented accounts.

## Source and execution

The closed model profile is `sources/barotropic_core/rotating-finite.toml`.
Local integrals, source ancestry, exact anchors and limits are held in
`sources/barotropic_core/rotating-finite-equations.txt`. The existing Bate
pressure, Skinner/Ostriker fluid, Dehnen softened gravity, numerical Rusanov,
Jeans and Clawpack reflected-boundary bytes retain their custody and licences.
No physical coefficient or thermal inference is introduced.

Run on WSL/Linux with `just run-rotating-core --model
axisymmetric_bate1998_barotropic_finite_cloud_v1 --state
examples/rotating-core/finite-cloud.state --numerics
examples/rotating-core/cell-softening.numerics --output-dir
artifacts/finite-cloud-example --wall-seconds 600`. The Windows development
entrypoint forwards the same arguments. Use a fresh evidence directory; the
demo obtains the admitted native no-input floor before evolution.

All numerical v2 through v7 contracts remain explicit. Checked host cuts are
execution limits, not formation. Numerical v6/v7 continuation uses complete
original-profile replay and separately checked restoration of all cumulative
wall/source accounts; unsupported modes refuse. See
[ROTATING_FINITE_CONTINUATION.md](ROTATING_FINITE_CONTINUATION.md).
Radiation, chemical calorics, nuclear burning, dust and a formed-disk classifier
remain separate work. A finite ledger and exact replay establish the declared
numerical computation, not physical or continuum completeness.

> Decided. Evolve the declared finite surrounding gas in the same sourced
> global pressure, gravity and transport model as the inner gas. Constants
> retain floor admission; physical state v3 and numerical controls remain
> separate. Independent disjoint-region projection, complete-force checks and
> signed accounts refuse unsupported or corrupted states. Reflecting-boundary
> influence and barotropic physical error remain explicit.
