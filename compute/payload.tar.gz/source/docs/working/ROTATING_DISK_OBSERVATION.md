# Read-only disk development measurements

The annular observer measures gas produced by the finite rotating cloud
model. It reports rotational and pressure support against the full resolved
gas gravity, radial and axial motion relative to rotation, and vertical
thickness relative to radius. A flattened picture or one support ratio does
not establish a persistent disk. The receipt keeps formation and completed
system flags false.

`disk_observe.py` integrates exact cylindrical moments over clipped annuli.
`disk_observe_watchdog.py` independently integrates polynomials over disjoint
cell intersections and reconstructs pressure from incident faces. Both use
checked fluid contexts and exact integer/Fraction inputs. They do not mint
authority for unchecked cells or a supplied physical force. Analytic test
forces are observer benchmarks, without a physically generated disk claim.

All equations and units are mapped in
`sources/barotropic_core/disk-observation-equations.txt` D1-D8. Existing gas
pressure, fluid, gravity, boundary and numerical source custody remains.
Aso and Machida (2020), held PDF pages8-10, provides background for comparing
several dynamical and morphological measurements. Its star term and numerical
classification thresholds are excluded. Its restricted original remains in
private custody, with resolving URLs, hashes and exact anchors recorded in
`sources/disk_identification/citation.toml`.

The separate case reader reconstructs one saved frame's geometry, EOS, full
kernel mathematics, global force contraction, old observations and finite
accounts before measuring. It hashes the frame and observer source. A live
frame remains provisional; full causal replay and complete mesh histories
are separate evidence. Use a fresh output file:

```text
python -B scripts/rotating_core/disk_case.py --case-dir artifacts/disc-progress/compact128 --output artifacts/disc-progress/compact128-observation.json --workers 8
```

The default annuli are dyadic radial windows from zero to the declared outer
radius. Density cuts at zero, ten and one hundred times the original maximum
cell density are explicit views. These choices never affect transport, time,
refinement, gravity or admission. Gas outside a cut still contributes to the
global force and to neighbouring pressure faces. Results show signed forces
and null ratios for undefined or outward-gravity denominators. Constant
pressure cancels exactly; the pressure measurement is a cell-average Euler
term, without numerical momentum diffusion or a continuum equilibrium proof.

The compact cloud example is a declared dilute physical hypothesis with
finite surrounding gas. Its mass, extent and spin are input conditions.
The numerical example declares precision, timestep, mesh/refinement, work
and softening controls. Neither defines a star or target disk. The reflecting
wall confines gas. Changing its distance also changes represented surrounding
mass and its gravity at fixed surrounding density; such a comparison alone
is not boundary convergence.

Thermal stellar evolution, radiation, magnetic fields, dust, three-dimensional
fragmentation and isolated-vacuum convergence remain separate work. Exact
conservation and replay validate the declared numerical computation within
its finite barotropic model.

> Decided. Measure annular support, motion and thickness without feeding any
> selection or desired shape into the gas. Keep independent exact observation
> checks, equation provenance, declared input origins and model limits visible.
