# Conditional spatial barotropic gas

`axisymmetric_bate1998_barotropic_v1` evolves cold rotating gas in radius and
height. This connects the pressure surrogate used by the formed spherical
protostar to spatial mass and angular momentum transport. It is a separately
declared model and entry state. It does not continue the zero-spin spherical
result, insert that core into a disk, or replace the older thermochemical model.

Run `pwsh -NoProfile -File scripts/dev.ps1 rotating-core-example` on Windows,
or `just rotating-core-example` in WSL/Linux. The command builds the native
sealed-floor exporter, creates a fresh evidence directory, evolves the gas,
and plots saved observations. `--output-dir` selects a fresh destination.
Raw receipt, input bytes, kernel, frame journal, stderr and status are retained
under `artifacts/rotating-barotropic/regular-v2`.
`rotating-core-test` runs the component and mutation controls.

## Physical premises and provenance

The explicit entry is a uniform gas cylinder with mass, radius, half height,
solid-body angular velocity and a reflecting slip boundary. Bulk radial and
axial velocities begin at zero. Its density must be below one sixteenth of the
first barotropic transition; desired objects and dense starting cores refuse.
The checked hypothesis is internally supported by this effective model. It is
not Milky Way data or a cosmological prediction. The boundary confines the
gas, so a later isolated-cloud adapter must account for escaping material.

Pressure is the unchanged Bate1998 scalar surrogate, including all four density
regimes, continuity factors and the nominal200m/s low-density sound speed.
The radial and spatial producers share `scripts/radial_core/constitutive.py`.
Their separate watchdogs prove exponent/root cells, density, pressure and sound
derivatives without importing that producer. G comes from the existing native
admitted floor. The floor facts and all referenced law witnesses are pinned.

The complete equation/coefficient map is
[`rotating-equations.txt`](../../sources/barotropic_core/rotating-equations.txt).
It cites Bate1998 printedp3 Eq1, Skinner/Ostriker2010 pp3-5 cylindrical
conservation, Dehnen2001 p3 Eq3 Plummer regularization, the held Clawpack
approximate-solver notebook, exact cylindrical mesh identities and Klein1998
printedp6 Jeans resolution. Source bytes, licences, restricted original custody,
anchors and unquantified physical uncertainty are preserved in their existing
witnesses and `docs/SOURCES.md`. New finite-volume and quadrature algebra is
labeled as local derivation; it is not presented as another published law.

The four conserved fields are cell mass, radial momentum, axial momentum and
axial angular momentum. Cylindrical momentum includes geometric pressure and
centrifugal sources. Within a cell `vphi=Omega*R`, with angular velocity inferred
from the integrated second radial moment. The centrifugal force uses the exact
volume mean radius. Numerical v2 carries spin with the shared mass impulse and
the donor's regular angular-velocity profile at radial faces. It preserves zero
angular transport for uniform rigid rotation at rest. The superseded v1 instead
diffused spin toward the central ring and produced artificial outflow near4km/s
in the retained pilot. That physical case is excluded; its raw trajectory,
source snapshot and diagnostic remain available. Numerical v1 now refuses.
There is no thermal energy field. This barotropic pressure
does not inherit the older solver's chemical or radiative energy accounting.

## Numerical contract and checks

Monotone power-graded faces define exact cell volumes and face areas. Uniform
initial density and solid-body angular momentum are integrated over each cell.
Fixed-point cumulative mass differences sum to precisely the declared mass;
individual angular moments have explicit round-half-even projection error.
Resolution stays outside physical identity. Ring gravity uses the same sourced
Plummer law and local tangent quadrature as the existing spatial solver.
Independent cells compress equal axial separations without replacing physical
distances with row-index differences. Kernel construction uses ordered CPU
workers; changing worker count cannot change a coefficient.

No float advances state. The example uses96fraction bits and arbitrary Python
integers/rationals. Exact inverse-distance cells and terminal kernel projections
are independently checked, including cached kernels. Producer force sums and
the source-major watchdog traverse their data separately. Each face impulse is
rounded once per Euler stage and used with opposite signs in neighboring cells.
Angular impulses use the once-rounded mass carrier and a separate checked
projection. The two stages are averaged by face/source before scattering into the original
state. This preserves exact global mass and axial angular momentum on the
lattice; momentum sources and impermeable boundary impulses are also checked.

Adaptive steps obey the declared incident-area Courant budget and acceleration
screen in both stages. If the second stage requires a smaller step, the worker
repeats from the old state with half the integer timestep, within32retries.
It never clips or rescales a fluid state. Every accepted endpoint also checks
Newtonian speed, acoustic speed and physical density. Sampling and descriptions
cannot alter the trajectory. Runtime source changes refuse at completion.

Tests exercise constant-pressure zero-force equilibrium, resting rigid-rotation
torque and exact volume-force benchmarks, analytic on-axis ring
gravity, all EOS regimes, force/source/face/state substitutions, no dense or
desired-object entry, spin-sign covariance, exact repeated trajectories,
observer independence and96/128-bit short controls. These are component and
finite computation evidence, not a general fluid convergence theorem.

## Observations and next physical work

Saved cell averages produce peak density, integrated radial/axial second moments,
the flattening ratio `2<z^2>/<R^2>`, the mass in a fixed inner-quarter window,
rotational/gravitational virial ratio and the local Jeans-width diagnostic.
These observations are independently reconstructed. None alone classifies a
disk. The receipt states `disk_assessed=false` and `completed_system=false`.

Mesh, quadrature, softening and timestep refinements remain separate. This
fixed mesh cannot yet connect the cloud-scale envelope to the much smaller
resolved spherical second core. The next physical block is conservative core
resolution/remapping and an isolated boundary, then sustained rotational
support and accretion. Radiation/thermal transport, physical angular-momentum
transport, non-axisymmetric fragmentation, magnetic fields, dust and planets
remain open. No new panel is required for this routine connection increment;
the first independently resolved disk/embryo result is the next major panel.

The finite runs, separate numerical sensitivities and the retained rejected
near-axis pilot are documented in
[`artifacts/rotating-barotropic/README.md`](../../artifacts/rotating-barotropic/README.md).
The proposed internal particle distribution and adaptive representative route
is recorded in [`CELL_PARTICLE_POPULATIONS.md`](CELL_PARTICLE_POPULATIONS.md).
It does not add dust or chemistry to this barotropic run.

Exact integer face evaluation and bounded independent-check memoization are
documented in [`ROTATING_EXACT_ACCELERATION.md`](ROTATING_EXACT_ACCELERATION.md).
They preserve the finite operator and all saved rational diagnostics.

> Decided. Connect the sourced pressure law to conserved spatial gas and spin.
> Retain the reproduced near-axis diffusion failure, use explicit regular
> angular transport with independent checks, and require adequate core/envelope
> resolution before reporting a formed disk or a complete system.

The separately selected v3 adaptive partition and exact source-cell overlap
accounts are documented in [ROTATING_ADAPTIVE_MESH.md](ROTATING_ADAPTIVE_MESH.md).
Five complete finite controls retain exact mass and angular momentum; measured
remap averaging and spatial/softening sensitivity still prevent a convergence
claim. V2 remains the fixed-mesh comparison. The adaptive prototype stays optional.
