"""Full residual derivatives and original-step equivalence, with measured cost."""
import argparse,copy,importlib.util,json,tempfile,time
from pathlib import Path
import numpy as np
from scripts.stellar_formation.hydro import Solver
from scripts.stellar_formation.step_context import StepContext
from scripts.stellar_formation.data import G
from .thermal_parallel import ParallelJacobian


def main():
    p=argparse.ArgumentParser();p.add_argument('output',type=Path);p.add_argument('--workers',type=int,default=4)
    p.add_argument('--original-hydro',type=Path);args=p.parse_args();args.output.mkdir(exist_ok=False)
    tests=[]
    with tempfile.TemporaryDirectory(prefix='thermal-columns-test-') as temporary:
        adapter=ParallelJacobian(args.workers,Path(temporary)/'execution',True)
        try:
            for n in (16,64,128):
                s=Solver(n=n,mass=2e30,radius=5e12,temp=300,shape='uniform')
                dt=(5e12**3/(G*2e30))**.5*1e-4;context=StepContext(s,dt)
                z=np.r_[np.linspace(-1e-5,1e-5,n),np.linspace(1e-6,-1e-6,n)]
                expected=context.jacobian(z)
                got=adapter(context,z);assert np.array_equal(expected,got)
                serial=[];parallel=[]
                for _ in range(3):
                    before=time.monotonic();one=context.jacobian(z);serial.append(time.monotonic()-before)
                    before=time.monotonic();many=adapter(context,z);parallel.append(time.monotonic()-before)
                    assert np.array_equal(one,many)
                tests.append(dict(test='all_original_finite_difference_columns',cells=n,columns=2*n,
                                  serial_seconds=serial,parallel_seconds=parallel))
            if args.original_hydro:
                spec=importlib.util.spec_from_file_location('scripts.stellar_formation.held_hydro',args.original_hydro)
                held=importlib.util.module_from_spec(spec);spec.loader.exec_module(held)
                a=held.Solver(n=16,mass=2e30,radius=5e12,temp=300,shape='uniform')
                b=Solver(n=16,mass=2e30,radius=5e12,temp=300,shape='uniform')
                Solver.jacobian_evaluator=adapter
                try:
                    for step in range(4):
                        a.step(dt);b.step(dt)
                        assert a.record(step+1,dt)==b.record(step+1,dt)
                finally:del Solver.jacobian_evaluator
                tests.append(dict(test='original_full_gas_step_radiation_nuclear_ledger_and_accounts',steps=4))
        finally:adapter.close()
        metrics=json.loads((adapter.output/'jacobian.json').read_text())
        assert len(metrics['worker_pids'])>=min(2,args.workers)
        record=dict(schema='civsim.parallel-thermal-controls.v1',status='PASS',tests=tests,metrics=metrics,
                    scope='Same full derivatives and physical steps; speed measurements cover Jacobians only.')
        (args.output/'controls.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(record),flush=True)

if __name__=='__main__':main()
