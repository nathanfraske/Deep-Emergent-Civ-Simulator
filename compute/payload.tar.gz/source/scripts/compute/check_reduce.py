"""Python integer check sums in separate processes, independent of native GMP."""
import multiprocessing,os,threading,time
from concurrent.futures import ProcessPoolExecutor
from .exact_reduce import available_cpus

_positive=None
_negative=None

def initialize(positive,negative):
    global _positive,_negative
    _positive=positive;_negative=negative

def partial(arguments):
    begin,end,mass=arguments;start=time.process_time()
    upper=sum(mass[j]*_positive[j] for j in range(begin,end))
    lower=sum(mass[j]*_negative[j] for j in range(begin,end))
    return upper,lower,os.getpid(),time.process_time()-start

class CheckReducer:
    def __init__(self,positive,negative,workers):
        if type(workers) is not int or not 1<=workers<=min(64,available_cpus()):raise ValueError('allocated check worker envelope')
        if len(positive)!=len(negative) or not 1<=len(positive)<=8192:raise ValueError('check column census')
        if any(type(v) is not int or v<0 for column in (positive,negative) for v in column):raise ValueError('check column domain')
        self.positive=positive;self.negative=negative;self.workers=min(workers,len(positive));self.calls=0;self.cpu_seconds=0;self.wall_seconds=0;self.pids=set()
        # The calling execution wrapper is single-threaded. Each worker owns its
        # Python arithmetic; fork shares only the immutable checked columns.
        method='fork' if 'fork' in multiprocessing.get_all_start_methods() else 'spawn'
        if method=='fork' and threading.active_count()!=1:raise ValueError('check pool requires a single-threaded caller')
        self.pool=ProcessPoolExecutor(max_workers=self.workers,mp_context=multiprocessing.get_context(method),initializer=initialize,initargs=(positive,negative))
    def sum(self,mass):
        if len(mass)!=len(self.positive) or any(type(m) is not int or m<=0 for m in mass):raise ValueError('check mass domain')
        start=time.monotonic();width=(len(mass)+self.workers-1)//self.workers
        jobs=[(a,min(a+width,len(mass)),tuple(mass)) for a in range(0,len(mass),width)]
        results=list(self.pool.map(partial,jobs))
        self.calls+=1;self.wall_seconds+=time.monotonic()-start
        self.pids.update(row[2] for row in results);self.cpu_seconds+=sum(row[3] for row in results)
        # Exact addition permits any partial-sum grouping. There is no rounded
        # intermediate and no floating reduction in either sign partition.
        return sum(row[0] for row in results),sum(row[1] for row in results)
    def metrics(self):
        return dict(backend='independent_python_integer_processes',workers_requested=self.workers,worker_pids=sorted(self.pids),calls=self.calls,arithmetic_cpu_seconds=self.cpu_seconds,host_wall_seconds=self.wall_seconds)
    def close(self):self.pool.shutdown(wait=True,cancel_futures=True)
    def __enter__(self):return self
    def __exit__(self,*args):self.close()
