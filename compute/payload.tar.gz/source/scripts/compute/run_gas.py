"""Measured parallel CPU execution, optionally with exact resident B70 proposals."""
import argparse,hashlib,sys,os
from pathlib import Path
from .exact_reduce import available_cpus

def main():
    parser=argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('--exact-binary',type=Path,required=True);parser.add_argument('--execution-record-dir',type=Path,required=True)
    parser.add_argument('--execution-workers',type=int,default=min(16,available_cpus()))
    parser.add_argument('--gpu-binary',type=Path);parser.add_argument('--gpu-policy',choices=('adaptive','device'),default='adaptive')
    args,remaining=parser.parse_known_args()
    for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
    root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'scripts/radial_core'))
    from scripts.rotating_core import run
    from scripts.rotating_core.parallel_execution import ParallelExecution
    with ParallelExecution(run,args.exact_binary,args.execution_workers,args.execution_record_dir) as parallel:
        adapter=None;original_field=run.gravity.field;original_ids=run.implementations
        if args.gpu_binary:
            from .device_field import DeviceField
            folder=args.execution_record_dir/'gpu';folder.mkdir()
            paths={'execution/device_field.py':root/'scripts/compute/device_field.py','execution/field_worker.cpp':root/'scripts/compute/field_worker.cpp','execution/field_worker.binary':args.gpu_binary,'execution/run_gas.py':Path(__file__)}
            run.implementations=lambda:dict(original_ids(),**{name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in paths.items()})
            starting=dict(run.implementations());adapter=DeviceField(args.gpu_binary,original_field,folder,args.gpu_policy);run.gravity.field=adapter
        try:
            sys.argv=[str(root/'scripts/rotating_core/run.py')]+remaining;run.main()
        finally:
            if adapter:
                adapter.close();run.gravity.field=original_field
                ending=run.implementations();run.implementations=original_ids
                if ending!=starting:raise ValueError('device execution source changed during run')

if __name__=='__main__':main()
