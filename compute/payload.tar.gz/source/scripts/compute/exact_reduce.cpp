// Copyright 2026 Nathan M. Fraske. Apache-2.0.
// Positive arbitrary-integer weighted sums. No physical rounding occurs here.
#include <gmpxx.h>
#include <omp.h>
#include <chrono>
#include <ctime>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <vector>

using Clock=std::chrono::steady_clock;
std::uint32_t integer() {
  unsigned char b[4];
  if(!std::cin.read(reinterpret_cast<char*>(b),4))throw std::runtime_error("short header");
  return std::uint32_t(b[0])|(std::uint32_t(b[1])<<8)|(std::uint32_t(b[2])<<16)|(std::uint32_t(b[3])<<24);
}
void integer(std::uint32_t n) {
  unsigned char b[4];for(unsigned j=0;j<4;++j)b[j]=n>>(8*j);
  std::cout.write(reinterpret_cast<char*>(b),4);
}
double cpu_clock() {
  timespec t{};if(clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t))throw std::runtime_error("CPU clock");
  return double(t.tv_sec)+double(t.tv_nsec)*1e-9;
}
mpz_class read_number(std::vector<unsigned char>&buffer) {
  if(!std::cin.read(reinterpret_cast<char*>(buffer.data()),buffer.size()))throw std::runtime_error("short integer");
  mpz_class x;mpz_import(x.get_mpz_t(),buffer.size(),-1,1,0,0,buffer.data());return x;
}
int main(int argc,char**argv) {
  try {
    if(argc!=2)throw std::runtime_error("usage: exact_reduce threads");
    const unsigned threads=std::stoul(argv[1]);if(!threads||threads>64)throw std::runtime_error("thread domain");
    omp_set_dynamic(0);omp_set_num_threads(threads);std::ios::sync_with_stdio(false);
    std::vector<mpz_class> columns;std::uint64_t calls=0;double elapsed=0,cpu=0;unsigned team=0;
    char op;
    while(std::cin.get(op)) {
      if(op=='Q')break;
      if(op=='P') {
        if(!columns.empty())throw std::runtime_error("immutable context already loaded");
        const auto n=integer(),width=integer();
        if(!n||n>8192||!width||width>2*1024*1024||std::uint64_t(n)*width>8ULL*1024*1024*1024)throw std::runtime_error("context resource domain");
        std::vector<unsigned char> buffer(width);columns.reserve(n);
        for(unsigned j=0;j<n;++j)columns.emplace_back(read_number(buffer));
        std::cout<<"{\"backend\":\"gmp_openmp_exact_integer\",\"gmp_version\":\""<<gmp_version<<"\",\"threads_requested\":"<<threads<<",\"columns\":"<<n<<",\"column_bytes\":"<<width<<"}\n";std::cout.flush();continue;
      }
      if(op=='M') {
        std::cout<<"{\"calls\":"<<calls<<",\"threads_used\":"<<team<<",\"arithmetic_wall_seconds\":"<<elapsed<<",\"arithmetic_cpu_seconds\":"<<cpu<<",\"scope\":\"Measured arithmetic only; transfer and solver wall time are separate\"}\n";std::cout.flush();continue;
      }
      if(op!='F'||columns.empty())throw std::runtime_error("operation domain");
      const auto width=integer();if(!width||width>64)throw std::runtime_error("positive weight domain");
      std::vector<unsigned char> buffer(width);std::vector<mpz_class> weights;weights.reserve(columns.size());
      for(unsigned j=0;j<columns.size();++j){weights.emplace_back(read_number(buffer));if(weights.back()<=0)throw std::runtime_error("positive weight required");}
      std::vector<mpz_class> partial(threads);double batch_cpu=0;unsigned batch_team=0;const auto start=Clock::now();
      #pragma omp parallel reduction(+:batch_cpu)
      {
        const auto tid=omp_get_thread_num();const auto began=cpu_clock();mpz_class term;
        #pragma omp single
        batch_team=omp_get_num_threads();
        #pragma omp for schedule(runtime)
        for(std::size_t j=0;j<columns.size();++j) {
          mpz_mul(term.get_mpz_t(),weights[j].get_mpz_t(),columns[j].get_mpz_t());
          mpz_add(partial[tid].get_mpz_t(),partial[tid].get_mpz_t(),term.get_mpz_t());
        }
        batch_cpu+=cpu_clock()-began;
      }
      mpz_class sum;for(const auto&part:partial)mpz_add(sum.get_mpz_t(),sum.get_mpz_t(),part.get_mpz_t());
      elapsed+=std::chrono::duration<double>(Clock::now()-start).count();cpu+=batch_cpu;team=batch_team;++calls;
      const auto bytes=(mpz_sizeinbase(sum.get_mpz_t(),2)+7)/8;if(bytes>4*1024*1024)throw std::runtime_error("result resource domain");
      std::vector<unsigned char> result(bytes);std::size_t written=0;mpz_export(result.data(),&written,-1,1,0,0,sum.get_mpz_t());
      integer(written);std::cout.write(reinterpret_cast<char*>(result.data()),written);std::cout.flush();
    }
    return 0;
  }catch(const std::exception&e){std::cerr<<"exact reduction refusal: "<<e.what()<<'\n';return 2;}
}
