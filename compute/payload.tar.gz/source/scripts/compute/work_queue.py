"""Owner-authorized unordered, bounded queue of useful compute experiments."""
import argparse,json,os,random,shutil,signal,subprocess,time
from pathlib import Path
from .exact_reduce import available_cpus


def atomic(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8');tmp.replace(path)


def physical_memory():
    limits=[int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemTotal:')))*1024]
    if os.environ.get('FLEET_MEMORY_MIB'):limits.append(int(os.environ['FLEET_MEMORY_MIB'])*1024**2)
    for line in Path('/proc/self/cgroup').read_text().splitlines():
        if line.startswith('0::'):
            path=Path('/sys/fs/cgroup')/line[3:].lstrip('/')
            for directory in (path,*path.parents):
                if directory==Path('/sys'):break
                try:
                    raw=(directory/'memory.max').read_text().strip()
                    if raw!='max':limits.append(int(raw))
                except (OSError,ValueError):pass
    return min(limits)


def census(groups,previous):
    totals={g:dict(cpu_seconds=0.,pss_bytes=0,processes=0) for g in groups}
    current={};ticks=os.sysconf('SC_CLK_TCK')
    for p in Path('/proc').iterdir():
        if not p.name.isdecimal():continue
        try:
            row=(p/'stat').read_text().rsplit(')',1)[1].split();group=int(row[2])
            if group not in totals:continue
            key=(int(p.name),int(row[19]));cpu=(int(row[11])+int(row[12]))/ticks
            current[key]=cpu;totals[group]['cpu_seconds']+=max(0.,cpu-previous.get(key,0.))
            totals[group]['processes']+=1
            roll=(p/'smaps_rollup').read_text().splitlines()
            totals[group]['pss_bytes']+=int(next(x.split()[1] for x in roll if x.startswith('Pss:')))*1024
        except (OSError,ValueError,StopIteration):continue
    return totals,current


def terminate(process):
    try:os.killpg(process.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    try:process.wait(timeout=15)
    except subprocess.TimeoutExpired:
        try:os.killpg(process.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        process.wait()


def execute(plan,output,wall_seconds,opportunistic=False):
    output=Path(output);output.mkdir(parents=True,exist_ok=False)
    capacity=available_cpus();memory=physical_memory();limit=int(memory*.88)
    if capacity<2:raise ValueError('parallel workstation allocation unavailable')
    pending=[dict(x) for x in plan];active=[];completed=[];previous={};stop=[False]
    for job in pending:
        if not 2<=job['cpu_slots']<=capacity:raise ValueError('queue CPU envelope')
        if not isinstance(job['command'],list) or not job['command']:raise ValueError('queue command')
    prior={s:signal.getsignal(s) for s in (signal.SIGTERM,signal.SIGINT)}
    for s in prior:signal.signal(s,lambda number,frame:stop.__setitem__(0,True))
    began=time.monotonic();last=began;nonce=os.urandom(16).hex();rng=random.SystemRandom();reason=None;measured=None;backfilled=False
    if opportunistic and os.environ.get('FLEET_GPU_PROFILE')!='b70-pair':
        raise ValueError('opportunistic mode requires the quota-bound ATC pair job')
    (output/'plan.json').write_text(json.dumps(dict(unordered=True,nonce=nonce,cpu_slots=capacity,memory_bytes=memory,jobs=pending),indent=2)+'\n',encoding='utf-8')
    try:
        with (output/'usage.jsonl').open('w',encoding='utf-8') as usage:
            while pending or active:
                now=time.monotonic()
                if stop[0]:reason='interrupted'
                elif now-began>=wall_seconds:reason='wall_budget'
                elif shutil.disk_usage(output).free<8*1024**3:reason='disk_floor'
                if reason:break
                for item in list(active):
                    process=item['process'];job=item['job'];elapsed=now-item['began']
                    if process.poll() is None and elapsed>job['hard_wall_seconds']:
                        item['stop_reason']='case_wall_guard';terminate(process)
                    if process.poll() is not None:
                        item['stdout'].close();item['stderr'].close();active.remove(item)
                        row=dict(name=job['name'],cpu_slots=job['cpu_slots'],exit_code=process.returncode,
                                 elapsed_s=elapsed,resource_stop=item.get('stop_reason'))
                        completed.append(row);atomic(item['folder']/'status.json',row)
                        print('CIVSIM_QUEUE_COMPLETED '+json.dumps(row),flush=True)
                free=capacity-sum(item['job']['cpu_slots'] for item in active)
                while True:
                    fits=[x for x in pending if x['cpu_slots']<=free];extra=False
                    # ATC's enclosing systemd unit enforces the physical CPU
                    # quota. When phase barriers leave it idle, permit bounded
                    # additional cases rather than reserving idle worker slots.
                    if not fits and opportunistic and measured is not None and not backfilled:
                        committed=sum(x['job']['cpu_slots'] for x in active)
                        if measured['cpu_cores']<capacity*.92 and len(active)<8:
                            fits=[x for x in pending if committed+x['cpu_slots']<=2*capacity
                                  and measured['pss_bytes']+x.get('peak_memory_bytes',1024**3)<limit]
                            extra=bool(fits)
                    if not fits:break
                    # Favor useful quick answers; independently shuffled ties and
                    # as-completed dispatch make this an explicitly unordered run.
                    job=max(fits,key=lambda x:x.get('priority',1)/max(1,x.get('estimate_seconds',1))*rng.uniform(.8,1.2))
                    pending.remove(job);folder=output/job['name'];folder.mkdir(exist_ok=False)
                    stdout=(folder/'stdout.txt').open('wb');stderr=(folder/'stderr.txt').open('wb')
                    env=dict(os.environ,**job.get('environment',{}));env.update(OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_SCHEDULE='dynamic,1')
                    process=subprocess.Popen(job['command'],stdout=stdout,stderr=stderr,env=env,start_new_session=True)
                    active.append(dict(job=job,folder=folder,process=process,stdout=stdout,stderr=stderr,began=time.monotonic()))
                    free-=job['cpu_slots'];backfilled=backfilled or extra
                    print('CIVSIM_QUEUE_STARTED '+json.dumps(dict(name=job['name'],pid=process.pid,cpu_slots=job['cpu_slots'],opportunistic=extra)),flush=True)
                if now-last>=10:
                    counts,previous=census([x['process'].pid for x in active],previous);duration=now-last;last=now
                    rows=[dict(name=x['job']['name'],pid=x['process'].pid,cpu_slots=x['job']['cpu_slots'],
                               cpu_cores=counts[x['process'].pid]['cpu_seconds']/duration,
                               **{k:v for k,v in counts[x['process'].pid].items() if k!='cpu_seconds'}) for x in active]
                    size=sum(p.stat().st_size for p in output.rglob('*') if p.is_file())
                    row=dict(elapsed_s=now-began,active=rows,completed=len(completed),pending=len(pending),
                             cpu_cores=sum(x['cpu_cores'] for x in rows),pss_bytes=sum(x['pss_bytes'] for x in rows),
                             allocation_cpus=capacity,memory_limit_bytes=limit,evidence_bytes=size,free_bytes=shutil.disk_usage(output).free)
                    row['committed_worker_slots']=sum(x['job']['cpu_slots'] for x in active)
                    row['opportunistic']=opportunistic;measured=row;backfilled=False
                    usage.write(json.dumps(row)+'\n');usage.flush();atomic(output/'progress.json',row)
                    print('CIVSIM_WORKSTATION_USAGE '+json.dumps(row),flush=True)
                    if row['pss_bytes']>limit:reason='physical_memory_guard';break
                    if size>12*1024**3:reason='evidence_guard';break
                time.sleep(.25)
    finally:
        for item in active:
            terminate(item['process']);item['stdout'].close();item['stderr'].close()
            completed.append(dict(name=item['job']['name'],exit_code=item['process'].returncode,resource_stop=reason or 'driver_exit',elapsed_s=time.monotonic()-item['began']))
        for s,handler in prior.items():signal.signal(s,handler)
        result=dict(schema='civsim.unordered-workstation.v1',unordered=True,nonce=nonce,elapsed_s=time.monotonic()-began,
                    reason=reason,completed=completed,pending=[x['name'] for x in pending],owned_process_groups_closed=True,
                    stellar_admission=False,completed_system=False)
        atomic(output/'completion.json',result)
    return result


def main():
    p=argparse.ArgumentParser(allow_abbrev=False);p.add_argument('plan',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--wall-seconds',type=float,required=True);args=p.parse_args()
    print(json.dumps(execute(json.loads(args.plan.read_text(encoding='utf-8')),args.output,args.wall_seconds)),flush=True)

if __name__=='__main__':main()
