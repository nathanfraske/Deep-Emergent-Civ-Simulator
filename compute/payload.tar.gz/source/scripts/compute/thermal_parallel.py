"""Persistent process workers for the unchanged implicit thermal Jacobian."""
import argparse,hashlib,json,multiprocessing,os,random,sys,time
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
from .exact_reduce import available_cpus


def columns(arguments):
    context,z,base,indices=arguments
    from scripts.stellar_formation.data import np
    np.seterr(over='raise',invalid='raise',divide='raise')
    began=time.process_time()
    result=[(j,context.column(z,base,j)) for j in indices]
    return result,os.getpid(),time.process_time()-began


class ParallelJacobian:
    def __init__(self,workers,output,unordered=False):
        if not 1<=workers<=available_cpus():raise ValueError('Jacobian CPU allocation')
        self.workers=workers;self.output=Path(output);self.unordered=unordered
        self.output.mkdir(parents=True,exist_ok=False)
        self.pool=ProcessPoolExecutor(max_workers=workers,mp_context=multiprocessing.get_context('spawn'))
        self.calls=0;self.wall=0;self.cpu=0;self.pids=set();self.qualification=0
        self.save()
    def __call__(self,context,z):
        from scripts.stellar_formation.data import np
        began=time.monotonic();base=context.residual(z);count=2*context.n
        indices=list(range(count))
        if self.unordered:random.SystemRandom().shuffle(indices)
        width=max(1,(count+self.workers*2-1)//(self.workers*2))
        jobs=[(context,z,base,indices[a:a+width]) for a in range(0,count,width)]
        futures=[self.pool.submit(columns,job) for job in jobs]
        result=np.empty((count,count));seen=set()
        for future in as_completed(futures):
            values,pid,cpu=future.result();self.pids.add(pid);self.cpu+=cpu
            for j,column in values:
                if j in seen:raise ValueError('duplicate Jacobian column')
                seen.add(j);result[:,j]=column
        if seen!=set(range(count)):raise ValueError('missing Jacobian columns')
        if self.qualification<2:
            if not np.array_equal(result,context.jacobian(z)):raise ValueError('parallel Jacobian changed a derivative')
            self.qualification+=1
        self.calls+=1;self.wall+=time.monotonic()-began
        if self.calls%16==0:self.save()
        return result
    def save(self):
        row=dict(schema='civsim.parallel-thermal-jacobian.v1',workers=self.workers,unordered=self.unordered,calls=self.calls,
                 worker_pids=sorted(self.pids),worker_cpu_seconds=self.cpu,host_wall_seconds=self.wall,
                 scope='Independent finite-difference columns; full original residual and terminal nonlinear acceptance remain.')
        tmp=self.output/'jacobian.tmp';tmp.write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8');tmp.replace(self.output/'jacobian.json')
    def close(self):
        self.pool.shutdown(wait=True,cancel_futures=True);self.save()


def main():
    p=argparse.ArgumentParser(allow_abbrev=False)
    p.add_argument('--workers',type=int,required=True);p.add_argument('--execution-record-dir',type=Path,required=True)
    p.add_argument('--unordered',action='store_true');args,remaining=p.parse_known_args()
    for key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):os.environ[key]='1'
    from scripts.stellar_formation import run,hydro
    root=Path(__file__).resolve().parents[2];original=run.bindings
    paths=('scripts/compute/thermal_parallel.py','scripts/compute/exact_reduce.py','sources/compute/parallel-equations.txt')
    def bound():return dict(original(),**{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in paths})
    run.bindings=bound;adapter=ParallelJacobian(args.workers,args.execution_record_dir,args.unordered)
    hydro.Solver.jacobian_evaluator=adapter
    try:
        sys.argv=[str(root/'scripts/stellar_formation/run.py')]+remaining;code=run.main()
    finally:
        del hydro.Solver.jacobian_evaluator;adapter.close();run.bindings=original
    raise SystemExit(code)

if __name__=='__main__':main()
