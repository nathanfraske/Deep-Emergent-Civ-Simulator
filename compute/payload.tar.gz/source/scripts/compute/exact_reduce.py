"""Persistent native exact sums, with observed worker arithmetic counters."""
import hashlib,json,os,struct,subprocess,time
from pathlib import Path

def available_cpus():
    count=len(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else os.cpu_count() or 1
    limit=Path('/sys/fs/cgroup/cpu.max')
    if limit.exists():
        quota,period=limit.read_text().split()
        if quota!='max':count=min(count,max(1,(int(quota)+int(period)-1)//int(period)))
    fleet=os.environ.get('FLEET_CPU_COUNT','')
    if fleet.isdecimal():count=min(count,int(fleet))
    return max(1,count)

class ExactReducer:
    def __init__(self,binary,columns,threads):
        if type(threads) is not int or not 1<=threads<=min(64,available_cpus()):raise ValueError('allocated exact worker envelope')
        if not 1<=len(columns)<=8192 or any(type(x) is not int or x<0 for x in columns):raise ValueError('positive column domain')
        self.columns=tuple(columns);self.binary=Path(binary);self.threads=threads
        width=max(1,(max(x.bit_length() for x in columns)+7)//8)
        if width>2*1024**2 or width*len(columns)>8*1024**3:raise ValueError('native column resource envelope')
        self.process=subprocess.Popen([str(self.binary),str(threads)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        self.closed=False;self.host_calls=0;self.host_seconds=0
        try:
            self.process.stdin.write(b'P'+struct.pack('<II',len(columns),width))
            for x in columns:self.process.stdin.write(x.to_bytes(width,'little'))
            self.process.stdin.flush();self.info=json.loads(self.process.stdout.readline())
            if self.info['columns']!=len(columns) or self.info['threads_requested']!=threads:raise ValueError('native context binding')
        except BaseException:self.close();raise
    def receive(self,n):
        data=bytearray()
        while len(data)<n:
            chunk=self.process.stdout.read(n-len(data))
            if not chunk:raise ValueError('exact native worker closed')
            data.extend(chunk)
        return data
    def sum(self,weights):
        if self.closed or len(weights)!=len(self.columns) or any(type(x) is not int or x<=0 or x.bit_length()>512 for x in weights):raise ValueError('native positive weight census')
        width=max(1,(max(x.bit_length() for x in weights)+7)//8);start=time.monotonic()
        self.process.stdin.write(b'F'+struct.pack('<I',width)+b''.join(x.to_bytes(width,'little') for x in weights));self.process.stdin.flush()
        n=struct.unpack('<I',self.receive(4))[0]
        if n>4*1024**2:raise ValueError('native result envelope')
        answer=int.from_bytes(self.receive(n),'little');self.host_calls+=1;self.host_seconds+=time.monotonic()-start
        return answer
    def metrics(self):
        if self.closed:raise ValueError('native worker closed')
        self.process.stdin.write(b'M');self.process.stdin.flush();facts=json.loads(self.process.stdout.readline())
        return dict(self.info,**facts,host_calls=self.host_calls,host_wall_seconds=self.host_seconds,binary_sha256=hashlib.sha256(self.binary.read_bytes()).hexdigest())
    def close(self):
        if getattr(self,'closed',True):return
        self.closed=True
        if self.process.poll() is None:
            try:self.process.stdin.write(b'Q');self.process.stdin.flush()
            except (BrokenPipeError,OSError):pass
            try:self.process.wait(timeout=10)
            except subprocess.TimeoutExpired:self.process.kill();self.process.wait()
        error=self.process.stderr.read().decode(errors='replace')
        self.process.stdin.close();self.process.stdout.close();self.process.stderr.close()
        if self.process.returncode:raise ValueError('exact worker exit '+str(self.process.returncode)+': '+error)
    def __enter__(self):return self
    def __exit__(self,*args):self.close()
