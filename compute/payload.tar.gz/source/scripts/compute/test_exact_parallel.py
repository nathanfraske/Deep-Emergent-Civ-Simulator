"""Direct independent exact sums, physical gas parity and measured execution."""
import argparse,json,random,statistics,sys,tempfile,time,hashlib
from pathlib import Path
from .exact_reduce import ExactReducer
from .check_reduce import CheckReducer

def run(binary,output,workers):
    from scripts.rotating_core.parallel_execution import ParallelExecution
    from scripts.rotating_core import run as gas,packed_field,packed_field_watchdog,gravity_watchdog
    from fractions import Fraction
    rng=random.Random(73021);results=[]
    for n,bits in ((7,3),(19,384),(128,160),(512,256)):
        weights=[rng.getrandbits(min(bits,384))+1 for _ in range(n)]
        columns=[rng.getrandbits(n*bits) for _ in range(n)]
        expected=sum(weights[j]*columns[j] for j in range(n))
        with ExactReducer(binary,columns,workers) as native:
            for _ in range(3):assert native.sum(weights)==expected
            fact=native.metrics();assert fact['threads_used']==workers and fact['calls']==3
            results.append(dict(test='arbitrary_width_direct_integer_sum',terms=n,bits=bits,metrics=fact))
        positive=tuple(columns);negative=tuple(columns[::-1])
        with CheckReducer(positive,negative,workers) as check:
            got=check.sum(weights)
            assert got==(expected,sum(w*c for w,c in zip(weights,negative)))
            results.append(dict(test='independent_sign_partitions',terms=n,metrics=check.metrics()))
    for n in (128,512,1024):
        scale=1<<128;mass=[rng.randrange(1,scale//(n+1)) for _ in range(n)]
        radial=tuple(tuple(rng.randrange(-(1<<160),1<<160) for _ in range(n)) for _ in range(n))
        axial=tuple(tuple(rng.randrange(-(1<<160),1<<160) for _ in range(n)) for _ in range(n))
        cells=[[m,0,0,0] for m in mass];x=dict(s=scale,gravity=scale+1)
        matrix=packed_field.prepare(radial,axial,scale)
        own_columns=tuple((tuple(radial[i][j] for i in range(n)),tuple(axial[i][j] for i in range(n))) for j in range(n))
        context=packed_field_watchdog.prepare(own_columns,scale)
        authority=gravity_watchdog._PreparedField(scale,scale+1,own_columns,context)
        reference=matrix.force(x,cells);authority.check(cells,reference)
        base=[];candidate=[]
        with ParallelExecution(gas,binary,workers,output/('field-'+str(n)),minimum_cells=1) as execution:
            got=matrix.force(x,cells);assert got==reference;authority.check(cells,got)
            changed=[row.copy() for row in got];changed[n//2][1]+=1
            try:authority.check(cells,changed)
            except ValueError:pass
            else:raise AssertionError('one-bit force accepted')
            # Interleave complete proposer plus independent force checks. Metadata,
            # transfer and checker costs stay inside both timing scopes.
            for _ in range(5):
                start=time.monotonic();original=execution.original_force(matrix,x,cells)
                check=execution.original_check(context,cells)
                for i in range(n):
                    for k in (0,1):gas.mesh_watchdog.round_cell(original[i][k],Fraction(-check[i][k]*x['gravity'],scale*scale))
                base.append(time.monotonic()-start)
                start=time.monotonic();answer=matrix.force(x,cells);authority.check(cells,answer);assert answer==reference
                candidate.append(time.monotonic()-start)
            execution.save()
        results.append(dict(test='complete_exact_force_and_independent_check',cells=n,serial_seconds=base,parallel_seconds=candidate,median_gain=statistics.median(base)/statistics.median(candidate),one_bit_refused=True))
    root=Path(__file__).resolve().parents[2]
    # Reuse a real admitted finite-cloud entry and numerical contract, with only
    # the numerical mesh/work budget reduced for a causal 16-step comparison.
    state=(root/'examples/rotating-core/compact-cloud.state').read_text();cfg=(root/'examples/rotating-core/cell-softening.numerics').read_text()
    cfg=cfg.replace('radial_cells=8','radial_cells=4').replace('vertical_cells=16','vertical_cells=8')
    model=gas.models.load(root/'artifacts/disc-progress/floor.json',gas.FINITE_MODEL_ID)
    reference=gas.solve(state,cfg,model,workers=1,_stop_step=16)
    with ParallelExecution(gas,binary,workers,output/'whole-gas',minimum_cells=1):
        candidate=gas.solve(state,cfg,model,workers=1,_stop_step=16)
        gas.checkpoint_watchdog.strict_equal(reference,candidate)
    (output/'whole-gas-reference.json').write_text(gas.canonical_json(reference),encoding='ascii')
    (output/'whole-gas-parallel.json').write_text(gas.canonical_json(candidate),encoding='ascii')
    results.append(dict(test='complete_physical_gas_16_steps',scientific_fields_identical=True,steps=candidate['steps']))
    record=dict(schema='civsim.parallel-exact-controls.v1',status='PASS',binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),tests=results,scope='Exact execution controls and bounded complete gas. Physical continuum accuracy and stellar classification remain separate.')
    (output/'controls.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status='PASS',output=str(output),gains=[dict(cells=r['cells'],gain=r['median_gain']) for r in results if 'median_gain' in r])))

def main():
    p=argparse.ArgumentParser();p.add_argument('binary',type=Path);p.add_argument('output',type=Path);p.add_argument('--workers',type=int,default=4);args=p.parse_args()
    args.output.mkdir(parents=True,exist_ok=False)
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'radial_core'))
    run(args.binary,args.output,args.workers)

if __name__=='__main__':main()
