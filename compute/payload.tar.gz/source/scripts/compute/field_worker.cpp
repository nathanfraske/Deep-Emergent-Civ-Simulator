// Copyright 2026 Nathan M. Fraske. Apache-2.0.
// Resident exact field proposals. Independent Python checks admit each force.
#ifndef CPU_ONLY
#include <sycl/sycl.hpp>
#endif
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <thread>
#include <vector>

struct Operand { std::uint32_t v[8]{}; };
struct Wide { std::uint32_t v[16]{}; };
struct Coefficient { Operand magnitude; std::uint32_t negative{}; };
struct Result { Wide magnitude; std::uint32_t negative{}; };
static_assert(sizeof(Operand)==32 && sizeof(Coefficient)==36 && sizeof(Result)==68);

Wide multiply(Operand a, Operand b) {
  Wide out;
  for(unsigned i=0;i<8;++i) {
    std::uint64_t carry=0;
    for(unsigned j=0;j<8;++j) {
      const std::uint64_t term=std::uint64_t(a.v[i])*b.v[j]+out.v[i+j]+carry;
      out.v[i+j]=std::uint32_t(term); carry=term>>32;
    }
    out.v[i+8]=std::uint32_t(carry);
  }
  return out;
}
void add(Wide &a, Wide b) {
  std::uint64_t carry=0;
  for(unsigned i=0;i<16;++i) {
    const std::uint64_t term=std::uint64_t(a.v[i])+b.v[i]+carry;
    a.v[i]=std::uint32_t(term); carry=term>>32;
  }
}
Result difference(Wide a, Wide b) {
  bool minus=false;
  for(int i=15;i>=0;--i) if(a.v[i]!=b.v[i]) {minus=a.v[i]<b.v[i];break;}
  if(minus) {const auto t=a;a=b;b=t;}
  Result out;out.negative=minus;std::uint64_t borrow=0;
  for(unsigned i=0;i<16;++i) {
    const std::uint64_t sub=std::uint64_t(b.v[i])+borrow;
    out.magnitude.v[i]=std::uint32_t(std::uint64_t(a.v[i])-sub);
    borrow=std::uint64_t(a.v[i])<sub;
  }
  return out;
}
Result item(std::size_t index,unsigned cells,const Operand *mass,const Coefficient *coeff) {
  Wide positive,negative;
  for(unsigned j=0;j<cells;++j) {
    const auto c=coeff[index*cells+j];
    const auto value=multiply(mass[j],c.magnitude);
    if(c.negative)add(negative,value);else add(positive,value);
  }
  return difference(positive,negative);
}
template<class T> void read(T *data,std::size_t count) {
  std::cin.read(reinterpret_cast<char*>(data),std::streamsize(count*sizeof(T)));
  if(!std::cin)throw std::runtime_error("Incomplete worker input");
}
void emit(const std::vector<Result>&out) {
  std::cout.write(reinterpret_cast<const char*>(out.data()),std::streamsize(out.size()*sizeof(Result)));
  std::cout.flush();if(!std::cout)throw std::runtime_error("Worker output closed");
}
void validate_bound(const std::vector<Operand>&mass,Operand maximum) {
  Operand total;std::uint64_t carry=0;
  for(const auto &m:mass) {
    carry=0;
    for(unsigned i=0;i<8;++i) {
      const auto v=std::uint64_t(total.v[i])+m.v[i]+carry;
      total.v[i]=std::uint32_t(v);carry=v>>32;
    }
    if(carry)throw std::runtime_error("Mass sum exceeds 256 bits");
  }
  if(multiply(total,maximum).v[15]&0x80000000u)throw std::runtime_error("Accumulator bound exceeds 511 bits");
}
#ifndef CPU_ONLY
struct DeviceJob {
  sycl::device device;sycl::queue queue;sycl::event kernel_event;std::uint64_t calls=0,kernel_ns=0;
  Operand *mass=nullptr;Coefficient *coeff=nullptr;Result *output=nullptr;
  std::vector<Result> returned;std::size_t begin,length;
  DeviceJob(sycl::device d,unsigned n,std::size_t b,std::size_t len,const Coefficient *host):
    device(d),queue(d,sycl::property_list{sycl::property::queue::in_order{},sycl::property::queue::enable_profiling{}}),returned(len+8),begin(b),length(len) {
    const std::size_t bytes=std::size_t(n)*sizeof(Operand)+len*n*sizeof(Coefficient)+(len+8)*sizeof(Result);
    if(bytes>device.get_info<sycl::info::device::global_mem_size>()/2)throw std::runtime_error("GPU headroom");
    mass=sycl::malloc_device<Operand>(n,queue);
    coeff=sycl::malloc_device<Coefficient>(len*n,queue);
    output=sycl::malloc_device<Result>(len+8,queue);
    if(!mass||!coeff||!output)throw std::runtime_error("GPU allocation failed");
    queue.memcpy(coeff,host+b*n,len*n*sizeof(Coefficient));queue.wait_and_throw();
  }
  ~DeviceJob(){if(mass)sycl::free(mass,queue);if(coeff)sycl::free(coeff,queue);if(output)sycl::free(output,queue);}
};
#endif
int main(int argc,char **argv) {
  try {
    if(argc!=2)throw std::runtime_error("Usage: field_worker cpu_threads");
    const unsigned threads=std::stoul(argv[1]);
    if(!threads||threads>16)throw std::runtime_error("CPU worker bound");
    std::ios::sync_with_stdio(false);
    unsigned n=0;Operand maximum;std::vector<Coefficient> coeff;std::vector<Operand> mass;std::vector<Result> out;
#ifndef CPU_ONLY
    std::vector<sycl::device> devices;
    for(auto d:sycl::device::get_devices(sycl::info::device_type::gpu)) {
      if(d.get_backend()!=sycl::backend::ext_oneapi_level_zero)continue;
      if(d.get_info<sycl::info::device::name>().find("B70")==std::string::npos)throw std::runtime_error("Unselected GPU");
      devices.push_back(d);
    }
    if(devices.size()!=2)throw std::runtime_error("Expected allocated B70 pair");
    std::vector<std::unique_ptr<DeviceJob>> jobs;
#endif
    char operation;
    while(std::cin.get(operation)) {
      if(operation=='Q')break;
      if(operation=='P') {
        read(&n,1);if(!n||n>8192)throw std::runtime_error("Cell capacity");
        coeff.resize(std::size_t(n)*n*2);mass.resize(n);out.resize(std::size_t(n)*2);
        read(coeff.data(),coeff.size());
        maximum=Operand{};
        for(const auto &c:coeff) {
          if(c.negative>1)throw std::runtime_error("Coefficient sign");
          for(int i=7;i>=0;--i)if(c.magnitude.v[i]!=maximum.v[i]) {
            if(c.magnitude.v[i]>maximum.v[i])maximum=c.magnitude;
            break;
          }
        }
#ifdef CPU_ONLY
        std::cout<<"{\"backend\":\"cpu_integer_control\",\"cells\":"<<n<<",\"devices\":[]}\n";
#else
        jobs.clear();
        for(std::size_t d=0;d<2;++d) {
          const std::size_t begin=std::size_t(n)*2*d/2,end=std::size_t(n)*2*(d+1)/2;
          jobs.emplace_back(new DeviceJob(devices[d],n,begin,end-begin,coeff.data()));
        }
        const auto pci0=devices[0].get_info<sycl::ext::intel::info::device::pci_address>();
        const auto pci1=devices[1].get_info<sycl::ext::intel::info::device::pci_address>();
        if(pci0==pci1)throw std::runtime_error("Duplicate physical GPU");
        std::cout<<"{\"backend\":\"level_zero_b70_pair\",\"cells\":"<<n<<",\"devices\":[";
        for(std::size_t d=0;d<2;++d) {
          if(d)std::cout<<',';
          std::cout<<"{\"name\":\""<<devices[d].get_info<sycl::info::device::name>()
                   <<"\",\"pci\":\""<<devices[d].get_info<sycl::ext::intel::info::device::pci_address>()
                   <<"\",\"global_memory_bytes\":"<<devices[d].get_info<sycl::info::device::global_mem_size>()
                   <<",\"resident_bytes\":"<<std::size_t(n)*sizeof(Operand)+jobs[d]->length*n*sizeof(Coefficient)+(jobs[d]->length+8)*sizeof(Result)<<'}';
        }
        std::cout<<"]}\n";
#endif
        std::cout.flush();continue;
      }
      if(operation=='M') {
#ifdef CPU_ONLY
        std::cout<<"{\"backend\":\"cpu_integer_control\",\"devices\":[]}\n";
#else
        std::cout<<"{\"backend\":\"level_zero_b70_pair\",\"devices\":[";
        for(std::size_t d=0;d<jobs.size();++d) {
          if(d)std::cout<<',';
          std::cout<<"{\"pci\":\""<<jobs[d]->device.get_info<sycl::ext::intel::info::device::pci_address>()<<"\",\"kernel_calls\":"<<jobs[d]->calls<<",\"kernel_nanoseconds\":"<<jobs[d]->kernel_ns<<'}';
        }
        std::cout<<"]}\n";
#endif
        std::cout.flush();continue;
      }
      if(operation!='F'||!n)throw std::runtime_error("Worker operation");
      read(mass.data(),mass.size());validate_bound(mass,maximum);
#ifdef CPU_ONLY
      std::vector<std::thread> workers;
      for(unsigned t=0;t<threads;++t)workers.emplace_back([&,t]{for(std::size_t i=t;i<out.size();i+=threads)out[i]=item(i,n,mass.data(),coeff.data());});
      for(auto &w:workers)w.join();
#else
      // Both physical queues receive work before either completion wait.
      for(auto &ptr:jobs) {
        auto &job=*ptr;job.queue.memcpy(job.mass,mass.data(),mass.size()*sizeof(Operand));
        job.queue.memset(job.output,0xa5,(job.length+8)*sizeof(Result));
        const auto length=job.length;const auto *m=job.mass;const auto *k=job.coeff;auto *result=job.output;
        job.kernel_event=job.queue.parallel_for(sycl::range<1>(((length+255)/256)*256),[=](sycl::id<1> id){const auto i=id[0];if(i<length)result[i]=item(i,n,m,k);});
        job.queue.memcpy(job.returned.data(),job.output,(job.length+8)*sizeof(Result));
      }
      for(auto &ptr:jobs)ptr->queue.wait_and_throw();
      for(auto &ptr:jobs) {
        auto &job=*ptr;++job.calls;job.kernel_ns+=job.kernel_event.get_profiling_info<sycl::info::event_profiling::command_end>()-job.kernel_event.get_profiling_info<sycl::info::event_profiling::command_start>();const auto *guard=reinterpret_cast<const unsigned char*>(job.returned.data()+job.length);
        for(std::size_t i=0;i<8*sizeof(Result);++i)if(guard[i]!=0xa5)throw std::runtime_error("GPU output overrun");
        std::copy_n(job.returned.begin(),job.length,out.begin()+job.begin);
      }
#endif
      emit(out);
    }
    return 0;
  } catch(const std::exception &e) {std::cerr<<"field-worker refusal: "<<e.what()<<'\n';return 2;}
}
