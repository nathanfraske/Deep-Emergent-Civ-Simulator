"""Measured execution helpers; no physical models or admission decisions."""
