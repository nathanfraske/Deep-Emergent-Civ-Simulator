"""Thermodynamically consistent ideal LTE H/H2/H+/e mixture."""
from scipy.special import zeta
from .data import *

def eos(rho,T,amount):
    # Ideal-mixture mass action derived from Vaidya Eq8-9 and held H2 levels.
    if np.any(~np.isfinite(T)) or np.any(~np.isfinite(rho)) or np.any(T<=0) or np.any(rho<=0) or np.any(amount[:,0]<=0) or np.any(amount<0):raise ValueError('caloric_domain')
    nb=rho/B
    weights=WEIGHT[:,None]*np.exp(-EL[:,None]/(K*T[None,:]))
    sums=weights.sum(axis=0);internal=(EL[:,None]*weights).sum(axis=0)/sums
    power=(POWER[:,None]*weights).sum(axis=0)/sums
    p,d,a,b=amount.T
    other=d+a+b;charge=d+2*a+2*b
    logkd=math.log(16)+1.5*np.log(PI*B*K*T/H**2)-np.log(sums)-DISS/(K*T)
    logki=1.5*np.log(2*PI*ME*K*T/H**2)-CHI/(K*T)
    N=nb*p;logb=logki-np.log(N);loga=np.log(2*N)-logkd;electron=charge/p
    logz=np.minimum.reduce([np.zeros(len(T)),-loga/2,-logb])
    for _ in range(30):
        neutral=np.exp(logz);molecular=np.exp(loga+2*logz)
        q=np.exp(logb+logz)
        denom=electron+np.sqrt(electron*electron+4*q)
        ion=np.divide(2*q,denom,out=np.zeros_like(q),where=denom>0)
        denominator=2*ion+electron
        derivative=neutral+2*molecular+np.divide(ion*(ion+electron),denominator,out=np.zeros_like(ion),where=denominator>0)
        delta=(neutral+molecular+ion-1)/derivative
        logz-=np.clip(delta,-10,10)
        if np.max(abs(delta))<1e-12:break
    else:raise ValueError('chemical equilibrium root')
    y=neutral+ion;x=np.divide(ion,y,out=np.zeros_like(y),where=y>0)
    particles=p*(molecular/2+neutral+2*ion)+other+charge
    u=(1.5*particles*K*T+p*(molecular*(internal-DISS)/2+ion*CHI+DISS/2)+(2*d+3*a+4*b)*(DISS/2+CHI))/B
    pressure=nb*particles*K*T
    # Explicit nominal grey H2 proxy. Not a Rosseland line transfer solution.
    line=nb*p*molecular*power/2
    ne=nb*(p*ion+charge);ions=nb*(p*ion+d+4*a+4*b)
    emission=FF*ne*ions*np.sqrt(T)
    kp=(line+emission)/(4*SIG*T**4*rho)
    # Analytically integrated Kramers Rosseland mean, zeta6+zeta7.
    ratio=105*(zeta(6,1)+zeta(7,1))/zeta(4,1)
    krff=FF*LIGHT**2*H**3/(8*PI*K**4)*ne*ions/rho*T**-3.5/ratio
    kr=krff+ST*ne/rho+line/(4*SIG*T**4*rho)
    return u,pressure,kp,kr,y,x
