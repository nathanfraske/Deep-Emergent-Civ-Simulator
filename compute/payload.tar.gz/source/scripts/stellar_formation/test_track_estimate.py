"""Estimate boundaries and interpolation controls, without physics admission."""
import copy,json,math,tempfile,unittest
from pathlib import Path
from .track_estimate import SCHEMA,FIELDS,TrackEstimate,physical_key

ROOT=Path(__file__).resolve().parents[2]

class TrackTests(unittest.TestCase):
    def setUp(self):
        self.cfg=json.loads((ROOT/'examples/stellar-formation/cold-cloud.json').read_text())
        self.samples=[dict(time_s=0,peak_temperature_K=300.,radius_90pct_mass_m=1e12,
                           deposited_nuclear_energy_J=0.,escaped_photon_energy_J=-10.),
                      dict(time_s=99,peak_temperature_K=30000.,radius_90pct_mass_m=1e10,
                           deposited_nuclear_energy_J=100.,escaped_photon_energy_J=10.)]
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)/'model.json'
        self.document=dict(schema=SCHEMA,configuration=self.cfg,physical_key=physical_key(self.cfg),
                           tracks=[dict(name='synthetic_boundary_control',configuration=self.cfg,samples=self.samples)])
        self.path.write_text(json.dumps(self.document));self.model=TrackEstimate(self.path)
    def tearDown(self):self.tmp.cleanup()

    def test_exact_saved_endpoints(self):
        for sample in self.samples:
            result=self.model.query(self.cfg,sample['time_s'])
            self.assertEqual({k:result['references'][0][k] for k in ('time_s',)+FIELDS},sample)
            self.assertTrue(all(value is False for value in result['authority'].values()))

    def test_midpoint_preserves_positive_and_signed_domains(self):
        # x=ln(1+t) midpoint: t=9 between t=0 and t=99.
        sample=self.model.query(self.cfg,9)['references'][0]
        self.assertAlmostEqual(sample['peak_temperature_K'],3000.)
        self.assertAlmostEqual(sample['radius_90pct_mass_m']/1e11,1.)
        self.assertAlmostEqual(sample['deposited_nuclear_energy_J'],50.)
        self.assertAlmostEqual(sample['escaped_photon_energy_J'],0.)

    def test_uncovered_cloud_age_and_desired_object_refuse(self):
        for t in (-1,100,float('nan'),float('inf')):
            with self.assertRaises(ValueError):self.model.query(self.cfg,t)
        for mutate in ('mass','seed'):
            cfg=copy.deepcopy(self.cfg)
            if mutate=='mass':cfg['state']['mass_kg']='3e30'
            else:cfg['state']['star_mass_kg']='2e30'
            with self.assertRaises(ValueError):self.model.query(cfg,1)

    def test_bad_reference_clock_and_positive_quantity_refuse(self):
        for key,value in (('time_s',0),('peak_temperature_K',0)):
            bad=copy.deepcopy(self.document);bad['tracks'][0]['samples'][1][key]=value
            self.path.write_text(json.dumps(bad))
            with self.assertRaises(ValueError):TrackEstimate(self.path)

if __name__=='__main__':unittest.main()
