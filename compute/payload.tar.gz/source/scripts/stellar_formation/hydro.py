"""Compatible implicit radial gas work and gravity; source-bound diagnostic."""
from scipy.optimize import root,brentq
from .data import *
from .caloric import eos
from .burning import extents
from . import transfer

class Solver:
    def __init__(self,n=16,mass=2e30,radius=7e14,temp=30,bath=10,burn=True,shape="taper3",mass_floor=1e-5,mass_tail=1e-10,rad_tau_min=1e-3,step_change=.02):
        self.n=n;self.bath=bath;self.burn=burn
        self.mass_floor=mass_floor;self.mass_tail=mass_tail;self.rad_tau_min=rad_tau_min;self.step_change=step_change
        if shape=="taper3":
            q=np.r_[0,1/(1+np.exp(-np.linspace(math.log(self.mass_floor/(1-self.mass_floor)),math.log((1-self.mass_tail)/self.mass_tail),n-1))),1]
            def enclosed(z):return (z**3/3-3*z**5/5+3*z**7/7-z**9/9)/(16/315)
            positions=np.array([brentq(lambda z:enclosed(z)-a,0,1,xtol=2e-14) if a<1 else 1 for a in q[1:]])
        else:q=np.linspace(0,1,n+1)**3
        self.mass=mass*np.diff(q);self.enc=mass*q[1:]
        self.dual=(self.mass+np.r_[self.mass[1:],0])/2
        self.y=(radius*(positions if shape=="taper3" else np.cbrt(q[1:])),np.zeros(n),np.full(n,temp),np.tile([1.,0,0,0],(n,1)))
        self.erad=np.full(n,ARAD*bath**4)
        self.census=[(SCALE,0,0,0)]*n
        self.event_totals=[(0,0,0)]*n
        self.nuclear_ledger=[(Fraction(0),Fraction(0))]*n
        self.t=0;self.escaped=0;self.nuclear=0;self.viscous=0;self.beheat=0
    def volume(self,r):
        inner=np.r_[0,r[:-1]]
        return (4*PI/3)*(r-inner)*(r*r+r*inner+inner*inner)
    def energy(self,y):
        r,v,T,a=y;rho=self.mass/self.volume(r);u=eos(rho,T,a)[0]
        return np.sum(self.mass*u)+np.sum(self.erad*self.volume(r))+np.sum(self.dual*v*v/2)-np.sum(G*self.dual*self.enc/r)
    def step(self,dt):
        ro,vo,To,ao=self.y;Vo=self.volume(ro);uo,po,kpo,kro,*_=eos(self.mass/Vo,To,ao)
        tau=kro*self.mass/Vo*np.diff(np.r_[0,ro]);groups=[];start=0;total=0
        for j,amount in enumerate(tau):
            total+=amount
            if total>=self.rad_tau_min:groups.append((start,j+1));start=j+1;total=0
        if start<self.n:
            if groups:groups[-1]=(groups[-1][0],self.n)
            else:groups=[(0,self.n)]
        self.rad_groups=groups
        uscale=np.maximum(uo, G*self.enc/ro)
        vscale=np.maximum(np.sqrt(G*self.enc/ro),np.abs(vo))
        momentum_scale=np.maximum(vscale,dt*G*self.enc/ro**2)
        def unpack(z):
            delta=(3/(4*PI))*np.cumsum(Vo*np.expm1(z[:self.n]))
            r=ro*np.cbrt(1+delta/ro**3)
            displacement=delta/(r*r+r*ro+ro*ro)
            return r,To*np.exp(z[self.n:]),displacement/dt
        def terms(r,T,v):
            V=self.volume(r)
            if min(V)<=0:raise ValueError('crossing')
            rho=self.mass/V;amount,heat,nu,census,ledger,events=extents(ao,rho,T,dt,self.burn,self.census)
            u,p,kp,kr,y,x=eos(rho,T,amount)
            er,exchange,escape=transfer.advance(self,r,T,rho,V,Vo,kp,kr,dt)
            dv=np.diff(np.r_[0,v]);vis=rho*np.minimum(dv,0)**2*2
            area=4*PI/3*(r*r+r*ro+ro*ro)
            pressure=p+vis
            ap=area*(pressure-np.r_[pressure[1:],0])/self.dual
            ag=G*self.enc/(r*ro)
            diss=self.dual*(v-vo)**2/2
            dh=(diss+np.r_[0,diss[:-1]])/2;dh[-1]+=diss[-1]/2
            work=-(p+vis)*(V-Vo)/self.mass
            rhs=work+dh/self.mass+heat-exchange
            return v,ap-ag,u,amount,heat,nu,escape,rhs,vis*(Vo-V),sum(diss),er,census,ledger,events
        def residual(z):
            try:
                r,T,v=unpack(z)
                v,acc,u,a,heat,nu,loss,rhs,vis,diss,er,census,ledger,events=terms(r,T,v)
                return np.r_[(v-vo-dt*acc)/momentum_scale,(u-uo-rhs)/uscale]
            except (ValueError,FloatingPointError) as err:
                return np.full(2*self.n,1e20)
        np.seterr(over='raise',invalid='raise',divide='raise')
        trialr=ro+dt*vo
        guess=np.r_[np.zeros(self.n),np.zeros(self.n)]
        if min(np.diff(np.r_[0,trialr]))>0:
            guess[:self.n]=np.clip(np.log(self.volume(trialr)/Vo),-.01,.01)
        def jacobian(z):
            base=residual(z);columns=[]
            for j in range(2*self.n):
                shifted=z.copy();shifted[j]+=1e-5
                columns.append((residual(shifted)-base)/1e-5)
            return np.array(columns).T
        fit=root(residual,guess,jac=jacobian,tol=2e-9,options={'factor':.1})
        error=max(abs(residual(fit.x)))
        if not math.isfinite(error) or error>1e-7:raise ValueError('root '+str(error))
        r,T,v=unpack(fit.x)
        change=max(np.max(abs(np.log(r/ro))),np.max(abs(fit.x[self.n:])))
        if min(T)<1e-6 or max(T)>2e7:raise ValueError('temperature_domain '+str((min(T),max(T))))
        if change>self.step_change*1.2:raise ValueError('change '+str(change))
        v,acc,u,a,heat,nu,loss,rhs,vis,diss,er,census,ledger,events=terms(r,T,v)
        if min(a.flat)<-1e-14:raise ValueError('amount')
        self.y=(r,v,T,a);self.erad=er;self.t+=dt;self.escaped+=loss;self.nuclear+=sum(heat*self.mass);self.viscous+=sum(vis);self.beheat+=diss
        self.census=census
        self.nuclear_ledger=[(q+dq,e+de) for (q,e),(dq,de) in zip(self.nuclear_ledger,ledger)]
        self.event_totals=[tuple(x+y for x,y in zip(old,new)) for old,new in zip(self.event_totals,events)]
        return error,change
    def record(self,i,dt):
        r,v,T,a=self.y;rho=self.mass/self.volume(r);u,p,kp,kr,y,x=eos(rho,T,a)
        kinetic=sum(self.dual*v*v/2);gravity=sum(G*self.dual*self.enc/r)
        gas_energy=sum(self.mass*u);photon_energy=sum(self.erad*self.volume(r))
        ne=rho/B*(a[:,0]*y*x+a[:,1]+2*a[:,2]+2*a[:,3])
        spacing=(3/(4*PI*np.maximum(ne,1e-280)))**(1/3)
        gamma=COUL/(spacing*K*T)
        degeneracy=ne*(H*H/(2*PI*ME*K*T))**1.5/2
        radiation_ratio=self.erad/(3*p)
        return {'step':i,'t':self.t,'dt':dt,'r':r.tolist(),'v':v.tolist(),'T':T.tolist(),'rho':rho.tolist(),'mass':self.mass.tolist(),'dual_mass':self.dual.tolist(),'enclosed_mass':self.enc.tolist(),'amount':a.tolist(),'census':[[str(v) for v in row] for row in self.census],'events':[[str(v) for v in row] for row in self.event_totals],
            'nuclear_ledger_J_baryon':[[str(v) for v in row] for row in self.nuclear_ledger],
            'erad':self.erad.tolist(),'ion':x.tolist(),'mol':(1-y).tolist(),'energy':self.energy(self.y),'energy_parts':{'gas':gas_energy,'photons':photon_energy,'kinetic':kinetic,'gravity':-gravity},'max_photon_gas_pressure_ratio':max(radiation_ratio),'max_electron_degeneracy_parameter':max(degeneracy),'max_electron_coulomb_parameter':max(gamma),'escaped':self.escaped,'nuclear':self.nuclear,'beheat':self.beheat,'kinetic_fraction':kinetic/gravity,'viscous':self.viscous}
