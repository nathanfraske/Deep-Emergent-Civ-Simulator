"""Experimental coupled gas formation, never canonical stellar admission."""
