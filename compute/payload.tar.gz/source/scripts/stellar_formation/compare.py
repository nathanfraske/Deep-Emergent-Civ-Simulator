"""Compare checked cold-origin histories without admitting stellar outcomes."""
import argparse,hashlib,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .visual import read,mass_radius,YEAR
from .watchdog import history

EQUATIONS='''Read-only formation comparisons, local algebraic derivations.
The physical equations and source anchors remain those bound by each receipt.
No comparison quantity enters construction, acceptance or source admission.
Julian years=t_seconds/(365.25*86400), a display convention.
Saved-interval deposited nuclear power=(Q_after-Q_before)/(t_after-t_before).
Saved-interval signed photon power=(escape_after-escape_before)/(t_after-t_before).
These are finite-interval averages, not instantaneous luminosities.
Helium4 baryon fraction=sum(m_i*4*amount_He4_i)/sum(m_i), weighted census.
Radius enclosing90percent mass uses uniform within-cell density:
r_f^3=r_inner^3+w*(r_outer^3-r_inner^3), w=remaining_mass/cell_mass.
The90percent cut is an observer choice, never a physical stellar boundary.
Mechanical kinetic fraction=sum(mu_i*v_i^2/2)/abs(sum(-G*mu_i*M_i/r_i)).
Global residual=(E+escaped-Qdeposit-E_initial)/
                (abs(E)+abs(escaped)+abs(E_initial)).
Max local energy defect and restart counts describe saved steps only.
Unsaved steps are not inferred from these displays. Different meshes,
steps and evolving gray proxies do not establish physical convergence.
Authority: stellar_ignition=false, stellar_admission=false, completed_system=false.
'''


def comparison(directories,output):
    output=Path(output)
    if output.exists():raise ValueError('refuse to replace held comparison')
    cases=[];curves=[]
    for directory in map(Path,directories):
        checked=history(directory)
        receipt=json.loads((directory/'receipt.json').read_text())
        frames=read(directory);times=np.array([f['t'] for f in frames])
        if any(np.diff(times)<=0):raise ValueError('comparison clock ordering')
        final=frames[-1];dt=np.diff(times)
        heat=np.diff([f['nuclear'] for f in frames])/dt
        escape=np.diff([f['escaped'] for f in frames])/dt
        configuration=receipt['configuration'];n=configuration['numerics']
        name=f"{n['cells']} cells; change {n['relative_step_change']}"
        denominator=abs(final['energy'])+abs(final['escaped'])+abs(receipt['initial_energy_J'])
        residual=(final['energy']+final['escaped']-final['nuclear']-receipt['initial_energy_J'])/denominator
        row=dict(label=name,status=receipt['status'],cells=n['cells'],relative_step_change=n['relative_step_change'],
                 physical_id=receipt['physical_id'],time_s=final['t'],steps=final['step'],wall_seconds=receipt['runtime']['wall_seconds'],
                 peak_temperature_K=max(final['T']),radius_90percent_m=mass_radius(final),
                 last_saved_interval_deposited_power_W=float(heat[-1]),last_saved_interval_signed_photon_power_W=float(escape[-1]),
                 final_global_energy_relative_residual=residual,final_kinetic_fraction=final['kinetic_fraction'],
                 checked=checked,bindings=receipt['bindings'],history_sha256=receipt['history_sha256'],
                 final_state_sha256=receipt['final_state_sha256'],
                 receipt_sha256=hashlib.sha256((directory/'receipt.json').read_bytes()).hexdigest())
        cases.append(row);curves.append((name,frames,times,heat,escape))
    output.mkdir(parents=True)
    fig,axes=plt.subplots(2,3,figsize=(14,8),layout='constrained')
    fig.suptitle('Computed cold gas collapse and nominal hydrogen burning',fontsize=16)
    for name,frames,times,heat,escape in curves:
        years=times/YEAR
        line,=axes[0,0].plot(years,[max(f['T']) for f in frames],label=name)
        color=line.get_color()
        axes[0,1].plot(years,[mass_radius(f) for f in frames],color=color)
        axes[0,2].plot(years,[f['kinetic_fraction'] for f in frames],color=color)
        axes[1,0].plot(years[1:],np.where(heat>0,heat,np.nan),color=color)
        axes[1,1].plot(years[1:],np.where(escape>0,escape,np.nan),color=color)
        helium=[sum(m*4*a[3] for m,a in zip(f['mass'],f['amount']))/sum(f['mass']) for f in frames]
        axes[1,2].plot(years,np.where(np.array(helium)>0,helium,np.nan),color=color)
    labels=('Peak gas temperature (K)','Radius enclosing 90% of gas (m)','Kinetic / absolute gravity energy',
            'Saved-interval deposited nuclear power (W)','Saved-interval escaping photon power (W)','Helium-4 baryon fraction')
    maximum=max(f[-1]['t']/YEAR for _,f,_,_,_ in curves)
    for axis,label in zip(axes.flat,labels):
        axis.set_xlabel('Time from declared cold gas (Julian years)');axis.set_ylabel(label)
        axis.set_xscale('symlog',linthresh=10);axis.set_yscale('log');axis.set_xlim(0,maximum);axis.grid(alpha=.2)
    axes[0,0].legend(fontsize=9)
    fig.supxlabel('Experimental gray ideal hydrogen. These mesh and timestep histories do not establish a physically admitted star.',fontsize=10)
    figure=output/'cold-origin-comparison.png';fig.savefig(figure,dpi=155);plt.close(fig)
    equations=output/'observer-equations.txt';equations.write_text(EQUATIONS,encoding='utf-8')
    evidence=dict(schema='civsim.stellar-formation.readonly-comparison.v1',cases=cases,
                  observer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  shared_geometry_sha256=hashlib.sha256(Path(__file__).with_name('visual.py').read_bytes()).hexdigest(),
                  independent_checker_sha256=hashlib.sha256(Path(__file__).with_name('watchdog.py').read_bytes()).hexdigest(),
                  files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (figure,equations)},
                  authority=dict(stellar_ignition=False,stellar_admission=False,completed_system=False),
                  scope='Read-only saved-history comparison. Full source bindings and independent selected-state reconstruction; no stellar or convergence classification.')
    (output/'comparison.json').write_text(json.dumps(evidence,indent=2,allow_nan=False)+'\n')
    return evidence


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directories',type=Path,nargs='+');parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();result=comparison(args.directories,args.output)
    print(json.dumps(dict(status='PASS',cases=len(result['cases']),output=str(args.output))))

if __name__=='__main__':main()
