"""Independent held-fact custody checks; no evolution producer imports."""
from hashlib import sha256
import json

# Reviewed normalized source hashes are populated after the equation ledger.
PINS = {
    'sources/stellar_formation/model.json':'229881d7c614666f7648ee357980391847678abf6fd5388732ec7d9a4f7e08e3',
    'sources/stellar_formation/equations.txt':'3eb4ab482eee522cbd97195931a9bb6ea76f2485aff65e1a0db7b99b2497021b',
    'sources/molecular_hydrogen/roueff19-lte-levels.tsv':'bdaca344f24a1c6e58bd69d01e7e388d2ebf0dc8efb21ac52e29f7e35ee4ddbd',
}

def check(root):
    for name,expected in PINS.items():
        raw=(root/name).read_bytes().replace(b'\r\n',b'\n')
        if sha256(raw).hexdigest()!=expected:
            raise ValueError('formation source custody: '+name)
    model=json.loads((root/'sources/stellar_formation/model.json').read_text())
    if model['authority']!='diagnostic_only':
        raise ValueError('formation authority substitution')
    return {'checked':len(PINS),'authority':'diagnostic_only'}
