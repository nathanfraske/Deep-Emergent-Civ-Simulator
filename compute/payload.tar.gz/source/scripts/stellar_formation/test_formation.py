"""Focused independent numerical, conservation, refusal and replay controls."""
import copy,json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from . import watchdog
from .caloric import eos
from .data import ARAD,PI,LIGHT,NU,SCALE,B
from .hydro import Solver
from .burning import extents
from .transfer import advance
from .photon_groups import transparent_groups
from .run import validate,execute,clock_trial,digest

ROOT=Path(__file__).resolve().parents[2]

class FormationTests(unittest.TestCase):
    def test_independent_partition_and_trace(self):
        points=((1e-12,30),(1e-8,300),(1e-4,1800),(.1,3000),(10,8000),(100,2e4),(1000,1.2e7))
        for rho,T in points:
            for amounts in ((1.,0,0,0),(.998,.0001,.0002,.0003)):
                a=np.array([amounts]);p=eos(np.array([rho]),np.array([T]),a)
                q=watchdog.reference(rho,T,amounts)
                for index in range(6):watchdog.close(p[index][0],q[index],3e-8)

    def test_common_partition_thermodynamics(self):
        for rho,T in ((1e-8,300),(1e-4,2000),(1,8000),(1000,1.2e7)):
            a=np.array([[1.,0,0,0]]);h=1e-4
            def at(r,t):return eos(np.array([r]),np.array([t]),a)
            base=at(rho,T);hot=at(rho,T*np.exp(h));cold=at(rho,T*np.exp(-h))
            cv=(hot[0][0]-cold[0][0])/(2*h*T)
            self.assertGreater(cv,0)
            lhs=(at(rho*np.exp(h),T)[0][0]-at(rho*np.exp(-h),T)[0][0])/(2*h)
            rhs=(base[1][0]-(hot[1][0]-cold[1][0])/(2*h))/rho
            self.assertLess(abs(lhs-rhs),1e-7*max(base[0][0],abs(rhs)))

    def test_rosseland_and_neutrino_quadratures(self):
        self.assertGreater(float(watchdog.rosseland_quadrature()),100)
        watchdog.close(NU,watchdog.neutrino_reference(),2e-11)

    def test_exact_nuclear_events_and_disabled(self):
        a=np.array([[1.,0,0,0]]);rho=np.array([1000.]);T=np.array([1.2e7]);old=[(SCALE,0,0,0)]
        after,heat,nu,census,energy,events=extents(a,rho,T,1e10,True,old)
        frame={'census':[[str(v) for v in row] for row in census],'events':[[str(v) for v in row] for row in events],
               'nuclear_ledger_J_baryon':[[str(v) for v in row] for row in energy],'amount':after.tolist()}
        from .data import NU_EXACT
        watchdog.ledger(frame,NU_EXACT);self.assertGreater(heat[0],0);self.assertGreater(nu[0],0)
        zero=extents(a,rho,T,1e10,False,old)
        self.assertTrue(np.array_equal(zero[0],a));self.assertEqual(zero[-1],[(0,0,0)])
        mutated=copy.deepcopy(frame);mutated['events'][0][0]=str(int(mutated['events'][0][0])+1)
        with self.assertRaises(ValueError):watchdog.ledger(mutated,NU_EXACT)

    def test_photons_separate_and_conservative(self):
        for krvalue in (1e-20,1e-2,1e8):
            r=np.array([1e8,2e8,3e8]);V=4*PI/3*np.diff(np.r_[0,r]**3);rho=np.ones(3)
            T=np.array([3000.,1000.,300.]);kp=np.full(3,1e-6);kr=np.full(3,krvalue)
            holder=SimpleNamespace(n=3,bath=10,mass=rho*V,erad=np.full(3,ARAD*10**4))
            initial=sum(holder.erad*V)
            photons,loss,escape=advance(holder,r,T,rho,V,V,kp,kr,1e4)
            self.assertGreater(min(photons),0)
            balance=sum(photons*V)-initial+escape-sum(loss*holder.mass)
            self.assertLess(abs(balance),1e-12*(abs(escape)+sum(abs(loss*holder.mass))))
            # Test the actual solved LTE source, not a flux formula copy.
            source=1e4*LIGHT*kp*(ARAD*T**4-photons)
            self.assertLess(np.max(abs(source-loss)/np.maximum(abs(loss),1)),2e-7)

    def test_transparent_partition_keeps_opaque_boundaries(self):
        tau=[.2,.3,4.,.4,.7,.1,2.,.2]
        groups=transparent_groups(tau,1.)
        self.assertEqual(groups,[(0,2),(2,3),(3,5),(5,6),(6,7),(7,8)])
        self.assertEqual([i for a,b in groups for i in range(a,b)],list(range(len(tau))))
        for a,b in groups:
            if b-a>1:
                self.assertTrue(all(depth<1 for depth in tau[a:b]))
                self.assertLess(sum(tau[a:b]),2)
        self.assertEqual(transparent_groups([0.,0.],1.),[(0,2)])
        self.assertEqual(transparent_groups([1.,0.],1.),[(0,1),(1,2)])
        for bad in ([float('nan')],[-1.],[float('inf')]):
            with self.assertRaises(ValueError):transparent_groups(bad,1.)

    def test_transparent_tail_cannot_remap_opaque_storage_at_zero_step(self):
        from unittest.mock import patch
        from .step_context import StepContext
        s=Solver(n=8,mass=2e30,radius=5e12,temp=300,bath=10)
        r,v,T,a=s.y;V=s.volume(r);rho=s.mass/V
        old=eos(rho,T,a);kr=np.array([1.]*7+[1e-5])/(rho*np.diff(np.r_[0,r]))
        replacement=list(old);replacement[3]=kr
        s.erad=np.geomspace(1e-10,1e-2,8)
        with patch('scripts.stellar_formation.step_context.eos',return_value=tuple(replacement)):
            context=StepContext(s,0.)
        photons,exchange,escape=advance(s,r,T,rho,V,V,context.kpo,kr,0.)
        # The old tail join instantaneously mixed the last opaque cell's
        # photon storage into its transparent neighbour even at dt=0.
        np.testing.assert_allclose(photons,s.erad,rtol=2e-14,atol=0.)
        self.assertLess(np.max(abs(exchange*s.mass)),1e-13*np.sum(s.erad*V))
        self.assertEqual(escape,0.)

    def test_coupled_mechanical_energy(self):
        s=Solver(n=8,mass=2e30,radius=5e12,temp=300,bath=10)
        before=s.record(0,0);initial=s.energy(s.y);s.step(1e5)
        f=s.record(1,1e5)
        from .data import NU_EXACT
        watchdog.state(f,NU_EXACT,initial,all_cells=True)
        watchdog.momentum_interval(before,f,1e5)
        self.assertGreater(s.beheat,0)

    def test_energy_refusal_preserves_the_committed_state(self):
        from unittest.mock import patch
        from .step_context import StepContext
        s=Solver(n=8,mass=2e30,radius=5e12,temp=300,bath=10)
        before=copy.deepcopy(s.record(0,0))
        original=StepContext.terms
        def lost_escape(context,r,T,v):
            terms=list(original(context,r,T,v))
            terms[6]+=1e35
            return tuple(terms)
        # Escape is outside the local gas root. Corrupting only its global
        # account used to commit an energy-invalid step before run refusal.
        with patch.object(StepContext,'terms',lost_escape):
            with self.assertRaisesRegex(ValueError,'step_energy'):s.step(1e5)
        self.assertEqual(s.record(0,0),before)

    def test_input_refusals(self):
        cfg=json.loads((ROOT/'examples/stellar-formation/cold-cloud.json').read_text())
        validate(cfg)
        for path,value in ((('state','star_mass_kg'),'1'),(('state','temperature_K'),'nan'),(('numerics','cells'),True),(('interactions','pp_i'),1)):
            bad=copy.deepcopy(cfg);bad[path[0]][path[1]]=value
            with self.assertRaises((ValueError,ArithmeticError)):validate(bad)

    def test_clock_and_zero_opacity(self):
        with self.assertRaises(ValueError):clock_trial(1e15,1e-4,2e15)
        self.assertGreater(clock_trial(1e15,1,2e15),0)
        r=np.array([1e8,2e8]);V=4*PI/3*np.diff(np.r_[0,r]**3)
        holder=SimpleNamespace(n=2,bath=10,mass=V,erad=np.full(2,ARAD*10**4),rad_groups=[(0,2)])
        photons,loss,escape=advance(holder,r,np.ones(2)*.1,np.ones(2),V,V,np.zeros(2),np.zeros(2),1e4)
        self.assertTrue(np.all(loss==0));self.assertTrue(np.all(np.isfinite(photons)))

    def test_resume_cold_origin_and_adaptive_timestep(self):
        cfg=json.loads((ROOT/'examples/stellar-formation/cold-cloud.json').read_text())
        cfg['numerics'].update(cells=8,max_steps=6,max_wall_seconds=120,save_every=1)
        with tempfile.TemporaryDirectory(prefix='formation-resume-') as tmp:
            p=Path(tmp);direct=execute(cfg,p/'direct');cut=copy.deepcopy(cfg);cut['numerics']['max_steps']=3
            execute(cut,p/'cut');continued=execute(cut,p/'continued',p/'cut/snapshot.json')
            self.assertEqual(continued['final_state_sha256'],direct['final_state_sha256'])
            self.assertEqual(continued['final_time_s'],direct['final_time_s'])
            snapshot=json.loads((p/'cut/snapshot.json').read_text())
            snapshot['state']['T'][0]=1e7;snapshot['state_sha256']=digest(snapshot['state'])
            (p/'forged.json').write_text(json.dumps(snapshot))
            with self.assertRaisesRegex(ValueError,'cold-origin'):execute(cut,p/'forged-output',p/'forged.json')
            with self.assertRaisesRegex(ValueError,'chained'):execute(cut,p/'chain',p/'continued/snapshot.json')

    def test_cold_repeat_and_saved_mutation(self):
        cfg=json.loads((ROOT/'examples/stellar-formation/cold-cloud.json').read_text())
        cfg['numerics'].update(cells=8,max_steps=3,max_wall_seconds=120,save_every=1)
        with tempfile.TemporaryDirectory(prefix='formation-control-') as tmp:
            one=execute(cfg,Path(tmp)/'one');two=execute(cfg,Path(tmp)/'two')
            self.assertEqual(one['history_sha256'],two['history_sha256'])
            self.assertEqual(one['final_state_sha256'],two['final_state_sha256'])
            checked=watchdog.history(Path(tmp)/'one');self.assertEqual(checked['status'],'PASS')
            with self.assertRaises(ValueError):execute(cfg,Path(tmp)/'one')
            receipt=json.loads((Path(tmp)/'one/receipt.json').read_text());receipt['authority']['stellar_ignition']=True
            (Path(tmp)/'one/receipt.json').write_text(json.dumps(receipt))
            with self.assertRaises(ValueError):watchdog.history(Path(tmp)/'one')

def load_tests(loader,suite,pattern):
    from . import test_track_estimate,test_ignition_observe
    suite.addTests(loader.loadTestsFromModule(test_track_estimate))
    suite.addTests(loader.loadTestsFromModule(test_ignition_observe))
    return suite

if __name__=='__main__':unittest.main()
