"""Independent 60-digit partition, ledger and saved-state checker.

Imports no formation producer, EOS, rate, limiter or source-decision helper.
Saved-frame checks do not assert replay of unsaved integration intervals.
"""
import argparse,gzip,hashlib,json,math
from fractions import Fraction
from pathlib import Path
import mpmath as mp

ROOT=Path(__file__).resolve().parents[2]
SCALE=1<<192

def facts():
    floor=json.loads((ROOT/'artifacts/stellar-thermal/floor.json').read_text())
    c={k:mp.mpf(v) for k,v in floor['coordinates'].items()}
    c['B']=c['m_e']*(1+c['m_p_over_m_e'])
    c['chi']=c['alpha']**2*c['m_e']*c['m_p_over_m_e']/(1+c['m_p_over_m_e'])*c['c']**2/2
    c['D']=mp.mpf('4.48')*c['e']
    levels=[]
    for line in (ROOT/'sources/molecular_hydrogen/roueff19-lte-levels.tsv').read_text().splitlines():
        if line.startswith('#'):continue
        v,j,energy,power,_=line.split();j=int(j)
        levels.append(((2*j+1)*(1 if j%2==0 else 3),mp.mpf(energy),mp.mpf(power)))
    return c,levels

def reference(rho,temperature,amount=(1,0,0,0)):
    """Different neutral coordinate, bracket instead of producer log Newton."""
    with mp.workdps(60):
        c,levels=facts();t=mp.mpf(str(temperature));rho=mp.mpf(str(rho))
        p,d,a,b=[mp.mpf(str(x)) for x in amount];kt=c['k_B']*t;nb=rho/c['B'];N=nb*p
        weights=[g*mp.exp(-energy/kt) for g,energy,power in levels]
        Z=sum(weights);E=sum(w*l[1] for w,l in zip(weights,levels))/Z
        power=sum(w*l[2] for w,l in zip(weights,levels))/Z
        kd=(mp.pi*c['B']*kt/c['h']**2)**mp.mpf('1.5')*16/Z*mp.exp(-c['D']/kt)
        ki=(2*mp.pi*c['m_e']*kt/c['h']**2)**mp.mpf('1.5')*mp.exp(-c['chi']/kt)
        trace=(d+2*a+2*b)/p
        def fractions(logz):
            z=mp.exp(logz);molecule=2*N*z*z/kd;q=ki*z/N
            ion=2*q/(trace+mp.sqrt(trace*trace+4*q))
            return z,molecule,ion
        hi=mp.mpf(0);lo=-max(mp.log(2*N/kd),mp.log(ki/N),0)-100
        for _ in range(240):
            mid=(lo+hi)/2
            if sum(fractions(mid))>1:hi=mid
            else:lo=mid
        neutral,molecular,ion=fractions((hi+lo)/2)
        count=p*(molecular/2+neutral+2*ion)+d+a+b+d+2*a+2*b
        u=(mp.mpf('1.5')*count*kt+p*(molecular*(E-c['D'])/2+ion*c['chi']+c['D']/2)+(2*d+3*a+4*b)*(c['D']/2+c['chi']))/c['B']
        pressure=nb*count*kt
        coul=c['alpha']*c['h']*c['c']/(2*mp.pi)
        cf=16*(2*mp.pi/(3*c['m_e']))**mp.mpf('1.5')*coul**3*mp.sqrt(c['k_B'])/(c['h']*c['c']**3)
        sigma=2*mp.pi**5*c['k_B']**4/(15*c['h']**3*c['c']**2)
        ne=nb*(p*ion+d+2*a+2*b);iz=nb*(p*ion+d+4*a+4*b)
        line=nb*p*molecular*power/2;ff=cf*ne*iz*mp.sqrt(t)
        kp=(line+ff)/(4*sigma*t**4*rho)
        ir=105*(mp.zeta(6)+mp.zeta(7))/mp.zeta(4)
        kr=cf*c['c']**2*c['h']**3/(8*mp.pi*c['k_B']**4)*ne*iz/rho*t**mp.mpf('-3.5')/ir
        kr+=8*mp.pi/3*(coul/(c['m_e']*c['c']**2))**2*ne/rho+line/(4*sigma*t**4*rho)
        return tuple(map(float,(u,pressure,kp,kr,neutral+ion,ion/(neutral+ion))))

def close(x,y,rtol=3e-9,atol=1e-150):
    if not math.isfinite(float(x)) or abs(float(x)-float(y))>rtol*abs(float(y))+atol:
        raise ValueError('independent formation discrepancy: '+str((x,y)))

def rosseland_quadrature():
    with mp.workdps(60):
        # Direct harmonic integral, independent of the producer zeta evaluation.
        denominator=mp.quad(lambda x:x**4*mp.exp(-x)/(-mp.expm1(-x))**2,[0,1,10,100,mp.inf])
        numerator=mp.quad(lambda x:x**7*mp.exp(-x)/(-mp.expm1(-x))**3,[0,1,10,100,mp.inf])
        ratio=numerator/denominator
        expected=105*(mp.zeta(6)+mp.zeta(7))/mp.zeta(4)
        if abs(ratio-expected)>abs(expected)*mp.mpf('1e-40'):raise ValueError('Rosseland harmonic integral')
        return str(ratio)

def neutrino_reference():
    with mp.workdps(90):
        c,_=facts();profile=json.loads((ROOT/'sources/stellar_thermal/ppi.json').read_text())
        rest=c['m_e']*c['c']**2;q=mp.mpf(profile['reactions'][0]['q_MeV'])*10**6*c['e']-2*rest
        def probability(kinetic):
            if kinetic==0 or kinetic==q:return mp.mpf(0)
            momentum=mp.sqrt(kinetic*(kinetic+2*rest));total=kinetic+rest
            eta=2*mp.pi*c['alpha']*total/momentum
            return momentum*total*(q-kinetic)**2*eta/mp.expm1(eta)
        norm=mp.quad(probability,[q*i/8 for i in range(9)])
        return float(mp.quad(lambda kinetic:(q-kinetic)*probability(kinetic),[q*i/8 for i in range(9)])/norm)

def ledger(frame,nu_mean):
    profile=json.loads((ROOT/'sources/stellar_thermal/ppi.json').read_text())
    floor=json.loads((ROOT/'artifacts/stellar-thermal/floor.json').read_text())
    q=[Fraction(r['q_MeV'])*10**6*Fraction(floor['coordinates']['e']) for r in profile['reactions']]
    for census,events,energy,amount in zip(frame['census'],frame['events'],frame['nuclear_ledger_J_baryon'],frame['amount']):
        n=tuple(map(int,census));x,y,z=map(int,events)
        if min(n)<0 or n[0]+2*n[1]+3*n[2]+4*n[3]!=SCALE:raise ValueError('independent baryon census')
        if n!=(SCALE-2*x-y+2*z,x-y,y-2*z,z):raise ValueError('independent causal event census')
        expected=sum(coef*Fraction(event,SCALE) for coef,event in zip(q,(x,y,z)))
        if Fraction(energy[0])!=expected or Fraction(energy[1])!=nu_mean*Fraction(x,SCALE):raise ValueError('independent nuclear Q/neutrino ledger')
        for number,stored in zip(n,amount):close(stored,number/SCALE,1e-15)

def state(frame,nu_mean,initial_energy,all_cells=False):
    ledger(frame,nu_mean)
    n=len(frame['r']);keys=('v','T','rho','mass','dual_mass','enclosed_mass','amount','erad')
    if any(len(frame[k])!=n for k in keys):raise ValueError('independent saved-state shape')
    samples=range(n) if all_cells else sorted(set((0,n//2,n-1)))
    for i in samples:
        u,p,kp,kr,y,x=reference(frame['rho'][i],frame['T'][i],frame['amount'][i])
        # Conditional atomic ion fractions may underflow when almost no atoms
        # exist. Retain a binary64 fraction floor; full caloric/pressure energy
        # is reconstructed separately at every selected cell.
        close(frame['ion'][i],x,2e-8,5e-15)
        # The producer records 1-y, which cancels when the molecule is tiny.
        if 1-y>1e-10:close(frame['mol'][i],1-y,2e-5)
    with mp.workdps(60):
        c,_=facts();gas=mp.mpf(0);photons=mp.mpf(0);kinetic=mp.mpf(0);gravity=mp.mpf(0);old=mp.mpf(0)
        for i in range(n):
            radius=mp.mpf(str(frame['r'][i]));volume=4*mp.pi/3*(radius**3-old**3);old=radius
            if volume<=0:raise ValueError('independent shell crossing')
            close(frame['rho'][i],mp.mpf(str(frame['mass'][i]))/volume,3e-7)
            u=reference(frame['rho'][i],frame['T'][i],frame['amount'][i])[0]
            gas+=mp.mpf(str(frame['mass'][i]))*u
            photons+=mp.mpf(str(frame['erad'][i]))*volume
            kinetic+=mp.mpf(str(frame['dual_mass'][i]))*mp.mpf(str(frame['v'][i]))**2/2
            gravity-=c['G']*mp.mpf(str(frame['dual_mass'][i]))*mp.mpf(str(frame['enclosed_mass'][i]))/radius
        energy=gas+photons+kinetic+gravity
        deposited=sum((mp.mpf(Fraction(row[0]).numerator)/Fraction(row[0]).denominator-mp.mpf(Fraction(row[1]).numerator)/Fraction(row[1]).denominator)*mp.mpf(str(mass))/c['B'] for row,mass in zip(frame['nuclear_ledger_J_baryon'],frame['mass']))
        close(frame['nuclear'],deposited,2e-9)
        scale=abs(gas)+abs(photons)+abs(kinetic)+abs(gravity)
        if abs(energy-mp.mpf(str(frame['energy'])))>scale*mp.mpf('1e-8'):raise ValueError('independent saved mechanical/caloric energy')
        residual=energy+mp.mpf(str(frame['escaped']))-mp.mpf(str(frame['nuclear']))-mp.mpf(str(initial_energy))
        scale=abs(energy)+abs(mp.mpf(str(initial_energy)))+abs(mp.mpf(str(frame['escaped'])))
        if abs(residual)>scale*mp.mpf('3e-6'):raise ValueError('independent global energy residual')
    return dict(time_s=frame['t'],max_temperature_K=max(frame['T']),energy_relative_residual=float(abs(residual)/scale),exact_census='PASS')

def initial(frame,configuration):
    if frame['step']!=0:return 'continued segment; cold origin not independently reconstructed by this saved reader'
    entry=configuration['state'];mass=float(entry['mass_kg']);radius=float(entry['radius_m']);temperature=float(entry['temperature_K']);bath=float(entry['radiation_temperature_K']);edge=float(entry['edge_velocity_m_s'])
    if len(frame['r'])!=configuration['numerics']['cells'] or frame['t']!=0:raise ValueError('initial gas shape or clock')
    total=0.;old=0.
    with mp.workdps(60):
        c,_=facts();radiation=8*mp.pi**5*c['k_B']**4/(15*c['h']**3*c['c']**3)*bath**4
        for i,r in enumerate(frame['r']):
            total+=frame['mass'][i];x=r/radius
            f=x**3 if entry['density_profile']=='uniform' else (x**3/3-3*x**5/5+3*x**7/7-x**9/9)/(16/315)
            close(total/mass,f,3e-9,1e-14)
            close(frame['T'][i],temperature,1e-15);close(frame['erad'][i],radiation,1e-12)
            close(frame['v'][i],edge*x,1e-14)
            if frame['census'][i]!=[str(SCALE),'0','0','0']:raise ValueError('initial gas nuclear product seed')
            close(frame['enclosed_mass'][i],total,3e-15)
            expected_dual=(frame['mass'][i]+(frame['mass'][i+1] if i+1<len(frame['mass']) else 0))/2
            close(frame['dual_mass'][i],expected_dual,3e-15)
        close(total,mass,3e-15);close(frame['r'][-1],radius,1e-14)
    return 'declared cold hydrogen state independently reconstructed'

def momentum_interval(before,after,dt):
    with mp.workdps(60):
        c,_=facts();pressure=[];viscosity=[]
        for i,(rho,t,a) in enumerate(zip(after['rho'],after['T'],after['amount'])):
            pressure.append(mp.mpf(str(reference(rho,t,a)[1])))
            dv=mp.mpf(str(after['v'][i]))-(mp.mpf(str(after['v'][i-1])) if i else 0)
            viscosity.append(2*mp.mpf(str(rho))*min(dv,0)**2)
        maximum=mp.mpf(0)
        for i in range(len(after['r'])):
            rn=mp.mpf(str(after['r'][i]));ro=mp.mpf(str(before['r'][i]));dual=mp.mpf(str(after['dual_mass'][i]));enclosed=mp.mpf(str(after['enclosed_mass'][i]))
            area=4*mp.pi/3*(rn*rn+rn*ro+ro*ro)
            outside=pressure[i+1]+viscosity[i+1] if i+1<len(pressure) else 0
            acc=area*(pressure[i]+viscosity[i]-outside)/dual-c['G']*enclosed/(rn*ro)
            residual=(mp.mpf(str(after['v'][i]))-mp.mpf(str(before['v'][i])))/mp.mpf(str(dt))-acc
            scale=max(c['G']*enclosed/(rn*ro),abs(acc),mp.mpf('1e-100'))
            maximum=max(maximum,abs(residual)/scale)
        if maximum>mp.mpf('3e-7'):raise ValueError('independent gas momentum interval')
        return float(maximum)

def history(directory):
    directory=Path(directory);receipt=json.loads((directory/'receipt.json').read_text())
    if any(receipt['authority'][k] for k in ('stellar_ignition','stellar_admission','completed_system')):raise ValueError('unsupported stellar authority')
    if hashlib.sha256((directory/'history.jsonl.gz').read_bytes()).hexdigest()!=receipt['history_sha256']:raise ValueError('history custody')
    for name,expected in receipt['bindings'].items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=expected:raise ValueError('source binding: '+name)
    with gzip.open(directory/'history.jsonl.gz','rt') as stream:frames=[json.loads(line) for line in stream]
    origin=initial(frames[0],receipt['configuration'])
    indices=sorted(set((0,len(frames)//4,len(frames)//2,3*len(frames)//4,len(frames)-1)))
    # Determine the exact producer quadrature result from held rational ledger.
    mean=None
    for frame in reversed(frames):
        for events,energy in zip(frame['events'],frame['nuclear_ledger_J_baryon']):
            if int(events[0]):mean=Fraction(energy[1])*SCALE/int(events[0]);break
        if mean is not None:break
    if mean is None:mean=Fraction(0)
    close(receipt['neutrino_mean_J'],neutrino_reference(),2e-11)
    if mean:close(float(mean),receipt['neutrino_mean_J'],1e-15)
    for frame in frames:ledger(frame,mean)
    results=[state(frames[i],mean,receipt['initial_energy_J']) for i in indices]
    last=frames[-1]
    canonical=lambda value:hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    if canonical(last)!=receipt['final_state_sha256']:raise ValueError('final-state custody')
    return dict(schema='civsim.stellar-formation.saved-check.v1',status='PASS',origin_check=origin,saved_frames=len(frames),independent_full_energy_frames=len(indices),checked_frames=results,scope='Exact cumulative census and independent selected saved-state energies. Unsaved steps and physical opacity accuracy are not certified.')

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('directory',type=Path)
    args=parser.parse_args()
    try:print(json.dumps(history(args.directory),indent=2));return 0
    except (ValueError,KeyError,ArithmeticError) as error:print(json.dumps(dict(status='REFUSED',reason=str(error))));return 2

if __name__=='__main__':raise SystemExit(main())
