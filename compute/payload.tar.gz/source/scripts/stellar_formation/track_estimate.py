"""Fast read-only estimates of held cold-origin tracks; no state continuation.

Equations and limits: docs/working/FAST_FORMATION_ESTIMATES.md.
An unmatched cloud or age outside the held track refuses. No extrapolation.
"""
import argparse,bisect,gzip,hashlib,json,math,subprocess,sys,time
from pathlib import Path

SCHEMA='civsim.stellar-formation.track-estimate.v1'
FIELDS=('peak_temperature_K','radius_90pct_mass_m','deposited_nuclear_energy_J','escaped_photon_energy_J')
POSITIVE=set(FIELDS[:2])


def physical_key(configuration):
    state=dict(configuration['state']);state.pop('description',None)
    value=dict(model=configuration['model'],state=state,interactions=configuration['interactions'])
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def observation(frame):
    target=.9*sum(frame['mass']);total=0.
    for j,mass in enumerate(frame['mass']):
        if total+mass>=target:
            inner=frame['r'][j-1] if j else 0.
            radius=(inner**3+(target-total)/mass*(frame['r'][j]**3-inner**3))**(1/3)
            break
        total+=mass
    return dict(time_s=frame['t'],peak_temperature_K=max(frame['T']),radius_90pct_mass_m=radius,
                deposited_nuclear_energy_J=frame['nuclear'],escaped_photon_energy_J=frame['escaped'])


def bake(source_root,directories,output):
    from .run import validate
    source_root=Path(source_root).resolve();output=Path(output)
    if output.exists():raise ValueError('refuse to replace held estimate table')
    tracks=[];key=None;config=None
    for directory in directories:
        directory=Path(directory).resolve();raw=(directory/'receipt.json').read_bytes();receipt=json.loads(raw)
        validate(receipt['configuration'])
        if receipt['status']!='TIME_REACHED':raise ValueError('estimate reference is not a completed trajectory')
        current=physical_key(receipt['configuration'])
        if key is not None and current!=key:raise ValueError('estimate references have different physical entries')
        key=current;config=receipt['configuration']
        command=[sys.executable,'-B','-m','scripts.stellar_formation.watchdog',str(directory)]
        check=subprocess.run(command,cwd=source_root,capture_output=True,text=True,timeout=120)
        if check.returncode:raise ValueError('estimate reference saved checker refuses: '+check.stdout[-1200:]+check.stderr[-1200:])
        checked=json.loads(check.stdout)
        if checked['status']!='PASS' or checked['origin_check']!='declared cold hydrogen state independently reconstructed':
            raise ValueError('estimate reference lacks checked cold origin')
        with gzip.open(directory/'history.jsonl.gz','rt') as stream:
            samples={}
            for line in stream:
                sample=observation(json.loads(line));previous=samples.get(sample['time_s'])
                if previous is not None and previous!=sample:raise ValueError('estimate duplicate clock with different observations')
                samples[sample['time_s']]=sample
        tracks.append(dict(name=directory.parent.name,configuration=receipt['configuration'],
                           samples=[samples[t] for t in sorted(samples)],bindings=receipt['bindings'],
                           history_sha256=receipt['history_sha256'],receipt_sha256=hashlib.sha256(raw).hexdigest(),
                           saved_check=checked,checker_sha256=hashlib.sha256((source_root/'scripts/stellar_formation/watchdog.py').read_bytes()).hexdigest()))
    if not tracks:raise ValueError('estimate reference census')
    root=Path(__file__).resolve().parents[2]
    witness=root/'docs/working/FAST_FORMATION_ESTIMATES.md'
    value=dict(schema=SCHEMA,physical_key=key,configuration=config,tracks=tracks,
               observer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               equation_witness_sha256=hashlib.sha256(witness.read_bytes()).hexdigest(),
               scope='Interpolated observations of checked cold-origin references. No extrapolated cloud, causal evolved state, physical error bound or stellar admission.')
    output.parent.mkdir(parents=True,exist_ok=True);output.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
    return dict(status='BAKED',tracks=len(tracks),samples=sum(len(t['samples']) for t in tracks),
                output=str(output),sha256=hashlib.sha256(output.read_bytes()).hexdigest())


class TrackEstimate:
    def __init__(self,path):
        raw=Path(path).read_bytes();self.sha256=hashlib.sha256(raw).hexdigest();self.model=json.loads(raw)
        if self.model['schema']!=SCHEMA or physical_key(self.model['configuration'])!=self.model['physical_key']:
            raise ValueError('estimate table identity')
        self.tracks=self.model['tracks']
        if not self.tracks:raise ValueError('estimate table census')
        self.clocks=[]
        for track in self.tracks:
            if physical_key(track['configuration'])!=self.model['physical_key']:raise ValueError('estimate track entry')
            clocks=[row['time_s'] for row in track['samples']]
            if len(clocks)<2 or clocks[0]!=0 or any(not math.isfinite(t) for t in clocks) or any(b<=a for a,b in zip(clocks,clocks[1:])):
                raise ValueError('estimate clock order')
            for row in track['samples']:
                if any(not math.isfinite(row[field]) for field in FIELDS) or any(row[field]<=0 for field in POSITIVE):
                    raise ValueError('estimate table numerical domain')
            self.clocks.append(clocks)

    def query(self,configuration,time_s):
        from .run import validate
        validate(configuration)
        if physical_key(configuration)!=self.model['physical_key']:raise ValueError('unmatched cloud requires a new cold-origin reference; extrapolation unsupported')
        if not math.isfinite(time_s) or time_s<0:raise ValueError('estimate age domain')
        results=[]
        for track,clocks in zip(self.tracks,self.clocks):
            if time_s>clocks[-1]:raise ValueError('estimate age outside reference duration')
            j=bisect.bisect_left(clocks,time_s)
            if clocks[j]==time_s:sample=dict(track['samples'][j])
            else:
                left,right=track['samples'][j-1:j+1]
                w=(math.log1p(time_s)-math.log1p(left['time_s']))/(math.log1p(right['time_s'])-math.log1p(left['time_s']))
                sample=dict(time_s=time_s)
                for field in FIELDS:
                    a,b=left[field],right[field]
                    sample[field]=math.exp((1-w)*math.log(a)+w*math.log(b)) if field in POSITIVE else (1-w)*a+w*b
            results.append(dict(reference=track['name'],**sample))
        ranges={field:dict(min=min(row[field] for row in results),max=max(row[field] for row in results)) for field in FIELDS}
        return dict(schema='civsim.stellar-formation.track-query.v1',status='ESTIMATE',time_s=time_s,
                    table_sha256=self.sha256,physical_key=self.model['physical_key'],references=results,reference_ranges=ranges,
                    authority=dict(stellar_ignition=False,stellar_admission=False,completed_system=False),
                    scope='Saved-track interpolation and reference disagreement only; no physical uncertainty bound, evolved restart state or new formation solve.')


def main():
    parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='mode',required=True)
    build=sub.add_parser('bake');build.add_argument('runs',type=Path,nargs='+');build.add_argument('--source-root',type=Path,required=True);build.add_argument('--output',type=Path,required=True)
    query=sub.add_parser('query');query.add_argument('table',type=Path);query.add_argument('configuration',type=Path);query.add_argument('--time-s',type=float,required=True)
    args=parser.parse_args();started=time.perf_counter()
    try:
        result=bake(args.source_root,args.runs,args.output) if args.mode=='bake' else TrackEstimate(args.table).query(json.loads(args.configuration.read_text()),args.time_s)
        result['request_wall_seconds']=time.perf_counter()-started;print(json.dumps(result,indent=2));return 0
    except (ValueError,KeyError,ArithmeticError) as error:print(json.dumps(dict(status='REFUSED',reason=str(error))),file=sys.stderr);return 2


if __name__=='__main__':raise SystemExit(main())
