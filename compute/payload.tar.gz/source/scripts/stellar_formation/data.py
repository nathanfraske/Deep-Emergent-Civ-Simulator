"""Source facts and representation-derived coordinates. No state presets."""
import json,math
from pathlib import Path
import numpy as np
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[2]
PROFILE=json.loads((ROOT/'sources/stellar_formation/model.json').read_text())
F=json.loads((ROOT/'artifacts/stellar-thermal/floor.json').read_text())
C={k:float(v) for k,v in F['coordinates'].items()}
PI=math.pi;G=C['G'];K=C['k_B'];H=C['h'];LIGHT=C['c'];ME=C['m_e'];MP=ME*C['m_p_over_m_e'];B=MP+ME
CHI=C['alpha']**2*MP*ME/B*LIGHT**2/2;DISS=float(PROFILE['dissociation_eV'])*C['e']
ARAD=8*PI**5*K**4/(15*H**3*LIGHT**3);SIG=ARAD*LIGHT/4
COUL=C['alpha']*H*LIGHT/(2*PI)
FF=16*(2*PI/(3*ME))**1.5*COUL**3*math.sqrt(K)/(H*LIGHT**3)
ST=(8*PI/3)*(COUL/(ME*LIGHT**2))**2
rows=[]
for line in (ROOT/'sources/molecular_hydrogen/roueff19-lte-levels.tsv').read_text().splitlines():
    if not line.startswith('#'):
        v,j,e,p,a=line.split();rows.append((int(j),float(e),float(p)))
J,EL,POWER=np.array(rows).T;WEIGHT=(2*J+1)*np.where((J%2)==0,1,3)
RX=json.loads((ROOT/'sources/stellar_thermal/ppi.json').read_text())['reactions']
from ..stellar_core.source import load
from ..stellar_core.nuclear import neutrino
from ..stellar_core.arithmetic import pi as pi_decimal
from decimal import localcontext
with localcontext() as context:
    context.prec=64
    spectrum=neutrino(load(ROOT/'artifacts/stellar-thermal/floor.json'),pi_decimal(64))
    NU=float(spectrum['mean_J'])
NU_EXACT=Fraction(spectrum['mean_J'])
Q_EXACT=[Fraction(r['q_MeV'])*10**6*Fraction(F['coordinates']['e']) for r in RX]
SCALE=1<<192
