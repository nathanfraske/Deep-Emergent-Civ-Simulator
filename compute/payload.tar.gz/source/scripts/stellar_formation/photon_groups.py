"""Partition transparent photon cells; never mix an opaque cell into a group.

This is a numerical approximation, documented in the formation equation ledger.
Material cells and the represented physics are unchanged.
"""
import math


def transparent_groups(optical_depths, threshold):
    if not math.isfinite(threshold) or threshold <= 0:
        raise ValueError('photon grouping threshold')
    groups=[];start=0;total=0.;count=0
    for j,depth in enumerate(optical_depths):
        if not math.isfinite(depth) or depth < 0:
            raise ValueError('photon grouping optical depth')
        count=j+1
        if depth >= threshold:
            if start < j:groups.append((start,j))
            groups.append((j,j+1));start=j+1;total=0.
        else:
            total+=depth
            if total >= threshold:
                groups.append((start,j+1));start=j+1;total=0.
    if start < count:groups.append((start,count))
    return groups
