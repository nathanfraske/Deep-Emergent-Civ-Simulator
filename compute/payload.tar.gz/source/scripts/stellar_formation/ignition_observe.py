"""Read-only power and support histories of checked gas-derived calculations."""
import argparse, gzip, hashlib, json, math, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCHEMA = 'civsim.stellar-formation.power-support.v1'
SCOPE = ('Saved-interval power and spherical virial diagnostics of the nominal '
         'gray hydrogen model. Interval averages do not resolve unsaved transients '
         'or establish physical stellar admission, continuum accuracy or a disk.')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def unique_frames(frames):
    result = []
    for frame in frames:
        t = frame['t']
        if type(t) not in (int, float) or not math.isfinite(t) or t < 0:
            raise ValueError('finite nonnegative saved clock required')
        if result and t == result[-1]['t']:
            if frame != result[-1]:
                raise ValueError('unequal states at identical saved clocks')
            continue
        if result and t < result[-1]['t']:
            raise ValueError('saved clock reversal')
        result.append(frame)
    if len(result) < 2:
        raise ValueError('at least two distinct saved ages required')
    return result


def radius90(frame):
    target = .9 * math.fsum(frame['mass'])
    accumulated = 0.0
    inner = 0.0
    for mass, outer in zip(frame['mass'], frame['r']):
        if accumulated + mass >= target:
            weight = (target - accumulated) / mass
            return math.cbrt(inner**3 + weight * (outer**3 - inner**3))
        accumulated += mass
        inner = outer
    raise ValueError('saved mass radius coverage')


def snapshot(frame, coordinates):
    n = len(frame['mass'])
    if not n or any(len(frame[k]) != n for k in ('r','T','amount','ion','mol')):
        raise ValueError('saved caloric cell census')
    for key in ('mass','r','T'):
        if any(type(v) not in (int,float) or not math.isfinite(v) or v <= 0 for v in frame[key]):
            raise ValueError('saved positive finite material or geometry')
    if any(a >= b for a,b in zip(frame['r'],frame['r'][1:])):
        raise ValueError('saved radial order')
    parts = frame['energy_parts']
    if set(parts) != {'gas','kinetic','gravity','photons'} or parts['gravity'] >= 0:
        raise ValueError('saved spherical energy parts')
    for v in (*parts.values(), frame['nuclear'], frame['escaped'], frame['beheat'], frame['viscous']):
        if type(v) not in (int,float) or not math.isfinite(v):
            raise ValueError('saved finite energy account')
    b = float(coordinates['m_e']) * (1 + float(coordinates['m_p_over_m_e']))
    k = float(coordinates['k_B'])
    pressure_volume = []
    for mass,t,molecular,ion,amount in zip(frame['mass'],frame['T'],frame['mol'],frame['ion'],frame['amount']):
        if not 0 <= molecular <= 1 or not 0 <= ion <= 1 or len(amount) != 4:
            raise ValueError('saved material fractions')
        p,d,a,h = amount
        if any(not math.isfinite(v) or v < 0 for v in amount):
            raise ValueError('saved isotope fractions')
        particles = p*(molecular/2 + (1-molecular)*(1+ion)) + 2*d + 3*a + 3*h
        pressure_volume.append(mass*k*t*particles/b)
    pressure_virial = 3*math.fsum(pressure_volume)
    total = math.fsum(frame['mass'])
    r90 = radius90(frame)
    binding = -parts['gravity']
    return dict(time_s=frame['t'], step=frame['step'], peak_temperature_K=max(frame['T']),
                radius_90pct_mass_m=r90, mass_kg=total,
                dynamical_time_90pct_s=math.sqrt(r90**3/(float(coordinates['G'])*.9*total)),
                pressure_virial_J=pressure_virial,
                pressure_virial_to_binding=pressure_virial/binding,
                kinetic_to_binding=parts['kinetic']/binding,
                spherical_virial_residual_ratio=(2*parts['kinetic']+pressure_virial+parts['gravity'])/binding,
                max_photon_gas_pressure_ratio=frame['max_photon_gas_pressure_ratio'],
                max_electron_degeneracy_parameter=frame['max_electron_degeneracy_parameter'],
                max_electron_coulomb_parameter=frame['max_electron_coulomb_parameter'])


def measure(frames, coordinates):
    frames = unique_frames(frames)
    samples = [snapshot(f,coordinates) for f in frames]
    intervals = []
    for index,(left,right) in enumerate(zip(frames,frames[1:])):
        dt = right['t'] - left['t']
        a,b = samples[index:index+2]
        nuclear = (right['nuclear']-left['nuclear'])/dt
        escaping = (right['escaped']-left['escaped'])/dt
        rates = {key:(right['energy_parts'][key]-left['energy_parts'][key])/dt
                 for key in ('gas','kinetic','gravity','photons')}
        residual = math.fsum(rates.values()) + escaping - nuclear
        scale = math.fsum(abs(v) for v in (*rates.values(),escaping,nuclear))
        mean_dyn = math.sqrt(a['dynamical_time_90pct_s']*b['dynamical_time_90pct_s'])
        intervals.append(dict(start_time_s=left['t'],end_time_s=right['t'],duration_s=dt,
            nuclear_power_W=nuclear,escaped_photon_power_W=escaping,
            nuclear_to_escaping_power=nuclear/escaping if escaping>0 else None,
            gravitational_contraction_power_W=-rates['gravity'],stored_power_W=rates,
            numerical_mechanical_heating_W=((right['beheat']-left['beheat'])+
                                            (right['viscous']-left['viscous']))/dt,
            power_balance_residual_W=residual,
            relative_power_balance_residual=abs(residual)/scale if scale else 0.0,
            radius_log_change_per_dynamical_time=math.log1p((b['radius_90pct_mass_m']-a['radius_90pct_mass_m'])/a['radius_90pct_mass_m'])*mean_dyn/dt,
            sampled_dynamical_times=dt/mean_dyn))
    return dict(schema=SCHEMA,samples=samples,intervals=intervals,
                stellar_ignition=False,stellar_admission=False,completed_system=False,
                continuous_persistence_certified=False,scope=SCOPE)


def analyze(directory, source_root, output):
    directory, source_root, output = map(Path,(directory,source_root,output))
    if output.exists():
        raise ValueError('fresh power/support output required')
    receipt_raw = (directory/'receipt.json').read_bytes()
    receipt = json.loads(receipt_raw)
    from .run import validate
    validate(receipt['configuration'])
    if any(receipt['authority'][k] for k in ('stellar_ignition','stellar_admission','completed_system')):
        raise ValueError('unsupported stellar authority in reference')
    if digest((directory/'history.jsonl.gz').read_bytes()) != receipt['history_sha256']:
        raise ValueError('saved history hash mismatch')
    for path,expected in receipt['bindings'].items():
        target = source_root/path
        if not target.is_relative_to(source_root) or '..' in Path(path).parts:
            raise ValueError('source binding path escape')
        if digest(target.read_bytes()) != expected:
            raise ValueError('reference source binding: '+path)
    checked = subprocess.run([sys.executable,'-B','-m','scripts.stellar_formation.watchdog',str(directory.resolve())],
                             cwd=source_root,capture_output=True,timeout=600)
    independent = json.loads(checked.stdout)
    if checked.returncode or independent['status'] != 'PASS' or independent['origin_check'] != 'declared cold hydrogen state independently reconstructed':
        raise ValueError('independent cold-origin reference check refused')
    with gzip.open(directory/'history.jsonl.gz','rt') as stream:
        frames = [json.loads(line) for line in stream]
    coordinates = json.loads((source_root/'artifacts/stellar-thermal/floor.json').read_text())['coordinates']
    result = measure(frames,coordinates)
    from .ignition_watchdog import check
    checked_powers = check(frames,coordinates,result)
    paths = ('scripts/stellar_formation/ignition_observe.py','scripts/stellar_formation/ignition_watchdog.py',
             'sources/stellar_observation/power-support-equations.txt')
    result['provenance'] = dict(receipt_sha256=digest(receipt_raw),history_sha256=receipt['history_sha256'],
        reference_status=receipt['status'],physical_id=receipt['physical_id'],source_bindings=receipt['bindings'],
        observers={p:digest((ROOT/p).read_bytes()) for p in paths},
        saved_check=independent,saved_checker_sha256=digest((source_root/'scripts/stellar_formation/watchdog.py').read_bytes()),
        saved_check_stdout_sha256=digest(checked.stdout),saved_check_stderr_sha256=digest(checked.stderr),
        power_support_check=checked_powers)
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(status='MEASURED',reference_status=receipt['status'],samples=len(result['samples']),
                          final=result['samples'][-1],last_interval=result['intervals'][-1],
                          output=str(output),sha256=digest(output.read_bytes()))))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory',type=Path);parser.add_argument('output',type=Path)
    parser.add_argument('--source-root',type=Path,default=ROOT)
    args = parser.parse_args()
    analyze(args.directory,args.source_root,args.output)


if __name__ == '__main__':
    main()
