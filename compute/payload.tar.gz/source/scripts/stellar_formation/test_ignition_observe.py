"""Analytic budget controls and realistic saved-observation mutation refusals."""
import copy, unittest
from . import ignition_observe as producer, ignition_watchdog as checker

COORDINATES=dict(G='1',m_e='1',m_p_over_m_e='1',k_B='1')


def frame(t,heat,escape):
    return dict(t=t,step=int(t),mass=[2.0],r=[1.0],T=[4.0],amount=[[1.0,0.0,0.0,0.0]],
                mol=[0.0],ion=[1.0],energy_parts=dict(gas=12.0,kinetic=0.0,gravity=-24.0,photons=0.0),
                nuclear=heat,escaped=escape,beheat=0.0,viscous=0.0,
                max_photon_gas_pressure_ratio=0.0,max_electron_degeneracy_parameter=0.0,
                max_electron_coulomb_parameter=0.0)


class PowerSupportTests(unittest.TestCase):
    def test_balanced_burning_and_pressure_are_distinct_measured_conditions(self):
        history=[frame(0,0,0),frame(10,20,20),frame(20,40,40)]
        value=producer.measure(history,COORDINATES);checker.check(history,COORDINATES,value)
        self.assertEqual(value['intervals'][0]['nuclear_to_escaping_power'],1)
        self.assertEqual(value['samples'][-1]['pressure_virial_to_binding'],1)
        self.assertEqual(value['intervals'][-1]['gravitational_contraction_power_W'],0)
        self.assertFalse(value['stellar_ignition']);self.assertFalse(value['continuous_persistence_certified'])

    def test_signed_bath_and_contraction_power_do_not_hide_under_a_ratio(self):
        history=[frame(0,0,0),frame(10,0,-2)]
        history[-1]['energy_parts']['gas']+=2
        value=producer.measure(history,COORDINATES);checker.check(history,COORDINATES,value)
        self.assertIsNone(value['intervals'][0]['nuclear_to_escaping_power'])
        self.assertEqual(value['intervals'][0]['escaped_photon_power_W'],-.2)
        self.assertEqual(value['intervals'][0]['relative_power_balance_residual'],0)
        contracted=copy.deepcopy(history);contracted[-1]['energy_parts']['gravity']-=2
        self.assertGreater(producer.measure(contracted,COORDINATES)['intervals'][0]['gravitational_contraction_power_W'],0)

    def test_duplicate_clock_and_sparse_history_cannot_claim_persistence(self):
        a,b=frame(0,0,0),frame(10,20,20)
        self.assertEqual(producer.measure([a,b,b],COORDINATES),producer.measure([a,b],COORDINATES))
        unequal=copy.deepcopy(b);unequal['T'][0]+=1
        invalid_clock=copy.deepcopy(a);invalid_clock['t']=float('nan')
        for history in ([a,b,unequal],[b,a],[a],[invalid_clock,b]):
            with self.assertRaises(ValueError):producer.measure(history,COORDINATES)

    def test_changed_power_virial_and_stellar_flags_are_refused(self):
        history=[frame(0,0,0),frame(10,20,20)]
        value=producer.measure(history,COORDINATES)
        for container,key in (('intervals','nuclear_power_W'),('samples','pressure_virial_J'),
                              ('intervals','power_balance_residual_W')):
            changed=copy.deepcopy(value);changed[container][-1][key]+=1
            with self.assertRaises(ValueError):checker.check(history,COORDINATES,changed)
        for key in ('stellar_ignition','stellar_admission','completed_system','continuous_persistence_certified'):
            changed=copy.deepcopy(value);changed[key]=True
            with self.assertRaises(ValueError):checker.check(history,COORDINATES,changed)

    def test_hot_temperature_alone_is_not_an_ignition_decision(self):
        history=[frame(0,0,0),frame(10,0,20)];history[-1]['T'][0]=1e8
        value=producer.measure(history,COORDINATES);checker.check(history,COORDINATES,value)
        self.assertEqual(value['intervals'][0]['nuclear_power_W'],0)
        self.assertFalse(value['stellar_ignition']);self.assertGreater(value['intervals'][0]['relative_power_balance_residual'],0)


if __name__=='__main__':unittest.main()
