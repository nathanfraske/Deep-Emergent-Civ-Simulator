"""Separate photon energy, nominal gray emission, conservative limited flux."""
from types import SimpleNamespace
from scipy.linalg import solve_banded
from scipy.optimize import root
from .data import *

def advance(self,r,T,rho,V,Vo,kp,kr,dt):
    groups=getattr(self,'rad_groups',None)
    if groups and len(groups)<self.n:
        indices=np.array([b-1 for a,b in groups]);rr=r[indices]
        mg=np.array([sum(self.mass[a:b]) for a,b in groups]);vg=np.array([sum(V[a:b]) for a,b in groups]);vog=np.array([sum(Vo[a:b]) for a,b in groups])
        rhog=mg/vg;dr=np.diff(np.r_[0,r]);drg=np.diff(np.r_[0,rr])
        kg=np.array([sum(kp[a:b]*rho[a:b]*V[a:b]) for a,b in groups])/(rhog*vg)
        rg=np.array([sum(kr[a:b]*rho[a:b]*dr[a:b]) for a,b in groups])/(rhog*drg)
        tg=np.array([sum(kp[a:b]*rho[a:b]*V[a:b]*T[a:b]**4)/sum(kp[a:b]*rho[a:b]*V[a:b]) if sum(kp[a:b]*rho[a:b]*V[a:b])>0 else sum(V[a:b]*T[a:b]**4)/sum(V[a:b]) for a,b in groups])**.25
        aux=SimpleNamespace();aux.n=len(groups);aux.mass=mg;aux.bath=self.bath
        aux.erad=np.array([sum(self.erad[a:b]*Vo[a:b])/sum(Vo[a:b]) for a,b in groups])
        eg,qg,escape=advance(aux,rr,tg,rhog,vg,vog,kg,rg,dt)
        radiation=np.zeros(self.n);exchange=np.zeros(self.n)
        for j,(a,b) in enumerate(groups):
            radiation[a:b]=eg[j]
            raw=dt*LIGHT*kp[a:b]*(ARAD*T[a:b]**4-eg[j])
            correction=qg[j]*mg[j]-sum(raw*self.mass[a:b])
            absorption=sum(kp[a:b]*self.mass[a:b])
            exchange[a:b]=raw+correction*kp[a:b]/absorption if absorption>0 else 0
        return radiation,exchange,escape
    old=self.erad;ebg=ARAD*self.bath**4
    mid=(np.r_[0,r[:-1]]+r)/2;distance=np.diff(mid)
    chi=kr*rho;face=(chi[:-1]+chi[1:])/2
    source=dt*LIGHT*kp*rho*V
    radiation=(old*Vo+source*ARAD*T**4)/(V+source)
    tau=sum(chi*np.diff(np.r_[0,r]))
    if tau<1:
        absorption=sum(kp*rho*V)
        brightness=sum(kp*rho*V*ARAD*T**4)/absorption if absorption>0 else ebg
        radiation=np.maximum(ebg,brightness*tau/(1+tau)/(1+(mid/r[-1])**2))
    end=dt*4*PI*r[-1]**2*LIGHT/(2+3*chi[-1]*(r[-1]-mid[-1]))
    base=V+source
    rhs=old*Vo+source*ARAD*T**4;rhs[-1]+=end*ebg
    spacing=np.maximum(face*distance,1e-280);area=dt*4*PI*r[:-1]**2*LIGHT
    def faces(E):
        left,right=E[:-1],E[1:];maximum=np.maximum(left,right)
        R=np.abs(right/maximum-left/maximum)/spacing
        f=np.zeros_like(R);fp=np.zeros_like(R);small=R<1e6
        rs=R[small];denom=6+3*rs+rs*rs
        f[small]=rs*(2+rs)/denom;fp[small]=(rs*rs+12*rs+12)/denom**2
        inverse=1/R[~small];denom=1+3*inverse+6*inverse**2
        f[~small]=(1+2*inverse)/denom
        fp[~small]=(inverse**2+12*inverse**3+12*inverse**4)/denom**2
        greater=left>=right
        power=area*maximum*f*np.where(greater,1,-1)
        dl=area*np.where(greater,f+fp*right/(spacing*maximum),fp/spacing)
        dr=-area*np.where(greater,fp/spacing,f+fp*left/(spacing*maximum))
        return power,dl,dr
    fixed_scale=np.maximum(rhs,np.max(rhs)*1e-12)
    def photon_res(z):
        E=np.exp(z);power,dl,dr=faces(E)
        transport=np.r_[power,0]-np.r_[0,power];transport[-1]+=end*E[-1]
        return (base*E+transport-rhs)/fixed_scale
    def photon_jac(z):
        E=np.exp(z);power,dl,dr=faces(E)
        diag=base+np.r_[dl,0]-np.r_[0,dr];diag[-1]+=end
        jac=np.diag(diag)+np.diag(dr,1)+np.diag(-dl,-1)
        return jac*E[None,:]/fixed_scale[:,None]
    fit=None
    try:
        candidate=root(photon_res,np.log(radiation),jac=photon_jac,tol=1e-10,options={'factor':.01,'maxfev':500})
        if np.all(np.isfinite(candidate.x)) and max(abs(photon_res(candidate.x)))<1e-8:
            fit=candidate
    except (ValueError,FloatingPointError):
        pass
    if fit is not None:
        radiation=np.exp(fit.x)
        power,dl,dr=faces(radiation)
        transport=np.r_[power,0]-np.r_[0,power]
        escape=end*(radiation[-1]-ebg);transport[-1]+=escape
        exchange=(radiation*V-old*Vo+transport)/self.mass
        return radiation,exchange,escape
    for it in range(1000):
        power,dl,dr=faces(radiation)
        transport=np.r_[power,0]-np.r_[0,power];transport[-1]+=end*radiation[-1]
        residual=base*radiation+transport-rhs
        diag=base+np.r_[dl,0]-np.r_[0,dr];diag[-1]+=end
        band=np.zeros((3,self.n));band[0,1:]=dr;band[1]=diag;band[2,:-1]=-dl
        delta=solve_banded((1,1),band,-residual)
        step=min(1.,min(-.8*radiation[delta<0]/delta[delta<0],default=1.))
        scale=np.maximum(rhs,np.max(rhs)*1e-12)
        merit=np.max(abs(residual)/scale)
        for trial in range(40):
            answer=radiation+step*delta
            pp,dd,rr=faces(answer)
            tt=np.r_[pp,0]-np.r_[0,pp];tt[-1]+=end*answer[-1]
            trial_merit=np.max(abs(base*answer+tt-rhs)/scale)
            if trial_merit<merit or trial_merit<1e-9:break
            step/=2
        else:raise ValueError('radiation line search '+str(merit))
        relative=np.max(abs(answer-radiation)/np.maximum(answer,ebg*1e-6))
        radiation=answer
        if relative<1e-9 and trial_merit<1e-8:break
    else:raise ValueError('radiation convergence '+str(relative)+' range '+str((min(radiation),max(radiation))))
    power,dl,dr=faces(radiation)
    transport=np.r_[power,0]-np.r_[0,power]
    escape=end*(radiation[-1]-ebg);transport[-1]+=escape
    exchange=(radiation*V-old*Vo+transport)/self.mass
    return radiation,exchange,escape
