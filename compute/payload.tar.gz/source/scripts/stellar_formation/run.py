"""Reproducible experimental gas history, explicit state and bounded work."""
import argparse,gzip,hashlib,json,math,os,platform,sys,time,copy,tempfile
from pathlib import Path


def duplicate(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise ValueError('duplicate input field: '+key)
        result[key]=value
    return result


def object_fields(value,required):
    if type(value) is not dict or set(value)!=set(required):
        raise ValueError('unsupported or missing fields: '+str(required))


def number(value,lower,upper):
    if type(value) is not str or len(value)>80:raise ValueError('physical or numerical scalar must be a short decimal string')
    from decimal import Decimal
    decimal=Decimal(value)
    if not decimal.is_finite() or not Decimal(str(lower))<=decimal<=Decimal(str(upper)):raise ValueError('input scalar domain')
    return float(decimal)


def validate(configuration):
    object_fields(configuration,('schema','model','state','interactions','numerics'))
    if configuration['schema']!='civsim.stellar-formation.configuration.v1' or configuration['model']!='experimental_spherical_lte_hydrogen_gray_ppi_v1':raise ValueError('unsupported formation model')
    s=configuration['state'];n=configuration['numerics']
    object_fields(s,('origin','material','mass_kg','radius_m','temperature_K','radiation_temperature_K','edge_velocity_m_s','density_profile','description'))
    object_fields(n,('cells','central_mass_fraction','surface_mass_fraction','photon_group_optical_depth','relative_step_change','initial_step_dynamical_fraction','end_time_s','max_steps','max_wall_seconds','save_every'))
    object_fields(configuration['interactions'],('pp_i',))
    if s['origin']!='declared_hypothesis' or s['material']!='hydrogen_equilibrium' or s['density_profile'] not in ('uniform','taper3'):raise ValueError('unsupported gas entry')
    if type(s['description']) is not str or len(s['description'])>1000:raise ValueError('description')
    if type(configuration['interactions']['pp_i']) is not bool:raise ValueError('reaction switch must be explicit boolean')
    mass=number(s['mass_kg'],1e25,1e33);radius=number(s['radius_m'],1e8,1e17)
    temperature=number(s['temperature_K'],10,1e4);bath=number(s['radiation_temperature_K'],3,1e4)
    velocity=number(s['edge_velocity_m_s'],-1e5,1e5)
    for key,lo,hi in [('cells',8,128),('max_steps',1,1000000),('max_wall_seconds',1,86400),('save_every',1,1000)]:
        if type(n[key]) is not int or not lo<=n[key]<=hi:raise ValueError('numerical integer domain: '+key)
    mf=number(n['central_mass_fraction'],1e-8,.001);mt=number(n['surface_mass_fraction'],1e-12,1e-5)
    group=number(n['photon_group_optical_depth'],1e-4,.01);change=number(n['relative_step_change'],.002,.04)
    initial=number(n['initial_step_dynamical_fraction'],1e-7,.001);end=number(n['end_time_s'],1,1e16)
    return dict(n=n['cells'],mass=mass,radius=radius,temp=temperature,bath=bath,burn=configuration['interactions']['pp_i'],shape=s['density_profile'],mass_floor=mf,mass_tail=mt,rad_tau_min=group,step_change=change),velocity,initial,end


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def clock_trial(current,dt,end):
    trial=min(dt,end-current)
    if not math.isfinite(trial) or trial<1e-6 or current+trial<=current:
        raise ValueError('clock_precision: timestep cannot advance the stored clock')
    return trial


def bindings():
    root=Path(__file__).resolve().parents[2]
    files=[root/'scripts/stellar_formation'/name for name in ('__init__.py','data.py','caloric.py','burning.py','transfer.py','step_context.py','hydro.py','run.py','source_guard.py')]
    files+=list((root/'sources/stellar_formation').glob('*'))
    files += [root/'scripts/stellar_core'/name for name in ('__init__.py','source.py','source_watchdog.py','nuclear.py','arithmetic.py')]
    files += [root/'artifacts/stellar-thermal/floor.json',root/'sources/stellar_thermal/ppi.json',root/'sources/stellar_thermal/equations.txt',root/'sources/molecular_hydrogen/roueff19-lte-levels.tsv']
    return {str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files) if p.is_file()}


def execute(configuration,output,resume=None):
    kwargs,velocity,initial,end=validate(configuration)
    output=Path(output)
    if output.exists():raise ValueError('refuse to replace held formation output')
    initial_bindings=bindings()
    from .source_guard import check
    check(Path(__file__).resolve().parents[2])
    for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
    import numpy as np,scipy
    from .hydro import Solver
    from .data import G,C,B,ST,NU,PROFILE
    from .caloric import eos
    solver=Solver(**kwargs)
    solver.y=(solver.y[0],velocity*solver.y[0]/kwargs['radius'],solver.y[2],solver.y[3])
    dt=math.sqrt(kwargs['radius']**3/(G*kwargs['mass']))*initial
    initial_state=solver.record(0,dt)
    initial_energy=initial_state['energy'];physical=dict(configuration['state']);physical.pop('description')
    physical_id=digest(dict(model=configuration['model'],state=physical,interactions=configuration['interactions']))
    step0=0
    if resume:
        snapshot=json.loads(Path(resume).read_text(),object_pairs_hook=duplicate)
        if snapshot['bindings']!=initial_bindings or snapshot['physical_id']!=physical_id:raise ValueError('resume changes source or physical entry')
        if snapshot.get('resume_depth')!=0:raise ValueError('chained formation continuation requires complete segment replay; unsupported')
        old_numerics=snapshot['configuration']['numerics'].copy();new_numerics=configuration['numerics'].copy()
        for key in ('end_time_s','max_steps','max_wall_seconds'):old_numerics.pop(key);new_numerics.pop(key)
        if old_numerics!=new_numerics:raise ValueError('resume changes mesh or integration contract')
        replay_configuration=copy.deepcopy(snapshot['configuration'])
        replay_configuration['numerics']['max_steps']=snapshot['state']['step']
        replay_configuration['numerics']['max_wall_seconds']=min(configuration['numerics']['max_wall_seconds'],snapshot['configuration']['numerics']['max_wall_seconds'])
        with tempfile.TemporaryDirectory(prefix='formation-origin-replay-') as temporary:
            replay_directory=Path(temporary)/'replayed'
            replay=execute(replay_configuration,replay_directory)
            replay_snapshot=json.loads((replay_directory/'snapshot.json').read_text())
        if replay['physical_id']!=physical_id or replay['final_state_sha256']!=snapshot['state_sha256'] or replay['initial_energy_J']!=snapshot['initial_energy_J'] or replay_snapshot['next_dt_s']!=snapshot['next_dt_s']:
            raise ValueError('resume cold-origin replay mismatch')
        a=snapshot['state'];step0=a['step'];dt=snapshot['next_dt_s'];solver.t=a['t']
        solver.y=tuple(np.array(a[k]) for k in ('r','v','T','amount'));solver.erad=np.array(a['erad'])
        from fractions import Fraction
        solver.census=[tuple(map(int,row)) for row in a['census']]
        solver.event_totals=[tuple(map(int,row)) for row in a['events']]
        solver.nuclear_ledger=[tuple(map(Fraction,row)) for row in a['nuclear_ledger_J_baryon']]
        for key in ('escaped','nuclear','beheat','viscous'):setattr(solver,key,a[key])
        if digest(a)!=snapshot['state_sha256'] or solver.t>=end:raise ValueError('resume state digest or time')
        initial_energy=snapshot['initial_energy_J']
    output.mkdir(parents=True)
    (output/'configuration.json').write_text(json.dumps(configuration,indent=2)+'\n')
    started=time.monotonic();rejects={};run_status='WORK_LIMIT';last_error=None;last=solver.record(step0,dt)
    with (output/'history.jsonl.gz').open('wb') as raw:
        with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as stream:
            def save(record):
                stream.write((json.dumps(record,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode())
                stream.flush()
            save(last)
            for step in range(step0+1,step0+configuration['numerics']['max_steps']+1):
                if time.monotonic()-started>configuration['numerics']['max_wall_seconds']:run_status='WALL_LIMIT';break
                accepted=False
                for attempt in range(40):
                    try:
                        trial=clock_trial(solver.t,dt,end)
                        residual,change=solver.step(trial);accepted=True;break
                    except (ValueError,FloatingPointError) as error:
                        last_error=str(error);rejects[last_error]=rejects.get(last_error,0)+1;dt/=2
                        if dt<1e-6 or 'clock_precision' in last_error:break
                if not accepted:run_status='CLOCK_PRECISION_REFUSAL' if 'clock_precision' in (last_error or '') else 'NUMERICAL_REFUSAL';break
                last=solver.record(step,trial)
                last['nonlinear_residual']=residual;last['photon_groups']=len(solver.rad_groups)
                last['global_energy_residual']=last['energy']+last['escaped']-last['nuclear']-initial_energy
                scale=abs(last['energy'])+abs(last['escaped'])+abs(initial_energy)
                if abs(last['global_energy_residual'])>scale*2e-6:run_status='ENERGY_REFUSAL';save(last);break
                if max(abs(solver.y[1]))>C['c']*.001:run_status='NEWTONIAN_DOMAIN_REFUSAL';save(last);break
                if step%configuration['numerics']['save_every']==0:
                    save(last)
                    print(json.dumps(dict(step=step,time_s=solver.t,max_temperature_K=max(solver.y[2]),central_density_kg_m3=last['rho'][0],accepted_dt_s=trial,wall_seconds=time.monotonic()-started)),flush=True)
                    (output/'progress.json').write_text(json.dumps(last,sort_keys=True)+'\n')
                dt*=min(1.2,max(.6,kwargs['step_change']/max(change,1e-12)))
                if solver.t>=end:run_status='TIME_REACHED';save(last);break
            else:run_status='WORK_LIMIT'
            save(last)
    if bindings()!=initial_bindings:raise ValueError('formation implementation changed during execution; receipt refuses')
    snapshot=dict(schema='civsim.stellar-formation.snapshot.v1',configuration=configuration,physical_id=physical_id,bindings=initial_bindings,initial_energy_J=initial_energy,next_dt_s=dt,resume_depth=1 if resume else 0,state=last,state_sha256=digest(last))
    (output/'snapshot.json').write_text(json.dumps(snapshot,indent=2,allow_nan=False)+'\n')
    history_sha=hashlib.sha256((output/'history.jsonl.gz').read_bytes()).hexdigest()
    receipt=dict(schema='civsim.stellar-formation.diagnostic-run.v1',status=run_status,physical_id=physical_id,configuration=configuration,bindings=initial_bindings,history_sha256=history_sha,
        final_state_sha256=digest(last),source_model=PROFILE,neutrino_mean_J=NU,initial_energy_J=initial_energy,final_time_s=solver.t,final_step=last['step'],last_error=last_error,rejected_candidates=rejects,
        runtime=dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__,platform=platform.platform(),wall_seconds=time.monotonic()-started),
        observations=dict(max_temperature_K=max(last['T']),central_density_kg_m3=last['rho'][0],deposited_nuclear_energy_J=last['nuclear'],escaped_photon_energy_J=last['escaped'],gas_was_initially_cold=True),
        authority=dict(stellar_ignition=False,stellar_admission=False,completed_system=False,scope='Experimental nominal gray LTE hydrogen trajectory; not a physically admitted star or general system generator.'))
    (output/'receipt.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
    return receipt


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('configuration',type=Path);parser.add_argument('output',type=Path);parser.add_argument('--resume',type=Path)
    args=parser.parse_args()
    try:
        configuration=json.loads(args.configuration.read_text(),object_pairs_hook=duplicate)
        receipt=execute(configuration,args.output,args.resume)
        print(json.dumps({'status':receipt['status'],'receipt':str(args.output/'receipt.json')}))
        return 0 if receipt['status'] in ('TIME_REACHED','WORK_LIMIT','WALL_LIMIT') else 2
    except (ValueError,KeyError,ArithmeticError) as error:
        print(json.dumps({'status':'REFUSED','reason':str(error)}),file=sys.stderr);return 2


if __name__=='__main__':raise SystemExit(main())
