"""Nominal PP-I backward Euler, temperature supplied by the gas solve."""
from .data import *

def extents(old,rho,T,dt,enabled,census):
    if not enabled:return old.copy(),np.zeros(len(rho)),np.zeros(len(rho)),census,[(Fraction(0),Fraction(0))]*len(rho),[(0,0,0)]*len(rho)
    t=T/1e9;t13=np.cbrt(t)
    vector=np.array([np.ones(len(T)),1/t,1/t13,t13,t,t*t13**2,np.log(t)])
    rates=[]
    for r in RX:
        rates.append(sum(np.exp(np.minimum(690,np.array([float(z) for z in fs['coefficients']])@vector)) for fs in r['fit_sets'])*1e-6/C['N_A'])
    kp,kd,kh=np.array(rates)*rho[None,:]/B*dt
    p0,d0,a0,b0=old.T;p=p0.copy()
    for _ in range(12):
        pp=kp*p*p/2;q=kd*p;cap=(d0+pp)*q/(1+q);available=a0+cap
        a=2*available/(1+np.sqrt(1+4*kh*available))
        ap=(kp*p*q/(1+q)+(d0+pp)*kd/(1+q)**2)/(1+2*kh*a)
        residual=p-p0+2*pp-a0+a
        candidate=p-residual/(1+2*kp*p+ap)
        if np.max(abs(candidate-p))<2e-15:break
        p=np.clip(candidate,0,p0+a0)
    pp=kp*p*p/2;q=kd*p;cap=(d0+pp)*q/(1+q);available=a0+cap
    a=2*available/(1+np.sqrt(1+4*kh*available));hh=kh*a*a/2
    new_census=[];ledger=[];events=[];deposited=[];escaped=[]
    for before,pp_float,pd_float,hh_float in zip(census,pp,cap,hh):
        counts=[round(Fraction(float(z))*SCALE) for z in (pp_float,pd_float,hh_float)]
        counts[1]=min(counts[1],before[1]+counts[0])
        counts[2]=min(counts[2],(before[2]+counts[1])//2)
        x,y,z=counts
        after=(before[0]-2*x-y+2*z,before[1]+x-y,before[2]+y-2*z,before[3]+z)
        if min(after)<0 or after[0]+2*after[1]+3*after[2]+4*after[3]!=SCALE:raise ValueError('nuclear census refusal')
        released=sum(q*Fraction(n,SCALE) for q,n in zip(Q_EXACT,counts));neutrino=NU_EXACT*Fraction(x,SCALE)
        new_census.append(after);events.append(tuple(counts));ledger.append((released,neutrino))
        deposited.append(float(released-neutrino)/B);escaped.append(float(neutrino)/B)
    amounts=np.array([[n/SCALE for n in row] for row in new_census])
    return amounts,np.array(deposited),np.array(escaped),new_census,ledger,events
