"""Independent cold-origin studies in parallel processes with measured CPU use."""
import argparse,hashlib,json,os,re,shutil,signal,subprocess,sys,time
from pathlib import Path
from .run import duplicate,validate,bindings
from scripts.compute.exact_reduce import available_cpus

def usage(group):
    ticks=0;rss=0
    for p in Path('/proc').iterdir():
        if not p.name.isdecimal():continue
        try:
            if os.getpgid(int(p.name))!=group:continue
            fields=(p/'stat').read_text().rsplit(')',1)[1].split()
            ticks+=int(fields[11])+int(fields[12])
            rss+=int(next(s.split()[1] for s in (p/'status').read_text().splitlines() if s.startswith('VmRSS:')))*1024
        except (OSError,ValueError,ProcessLookupError,PermissionError,StopIteration):pass
    return ticks/os.sysconf('SC_CLK_TCK'),rss

def study(specification,output,workers,jacobian_workers=1):
    if type(specification) is not dict or set(specification)!= {'schema','cases'} or specification['schema']!='civsim.stellar-formation.study.v1':raise ValueError('study schema')
    cases=specification['cases'];names=[]
    if type(cases) is not list or not 1<=len(cases)<=64:raise ValueError('study case census')
    for case in cases:
        if set(case)!= {'name','configuration'} or not re.fullmatch('[a-z][a-z0-9-]{0,63}',case['name']):raise ValueError('study case identity')
        validate(case['configuration']);names.append(case['name'])
    if len(set(names))!=len(names):raise ValueError('duplicate study case')
    if type(workers) is not int or not 1<=workers<=min(64,available_cpus()):raise ValueError('allocated study worker envelope')
    if type(jacobian_workers) is not int or not 1<=jacobian_workers<=available_cpus():raise ValueError('study Jacobian worker envelope')
    case_slots=jacobian_workers+1 if jacobian_workers>1 else 1
    if workers*case_slots>available_cpus():raise ValueError('aggregate study CPU envelope')
    output=Path(output);output.mkdir(parents=True,exist_ok=False);(output/'study.json').write_text(json.dumps(specification,indent=2)+'\n')
    original_bindings=bindings();pending=list(cases);active={};done=[];started=time.monotonic();stop_reason=None
    root=Path(__file__).resolve().parents[2];env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    rss_cap=8*1024**3;byte_cap=2*1024**3;last=started
    interrupted=False
    def stopping(signum,frame):
        nonlocal interrupted
        interrupted=True
    old_signals={s:signal.signal(s,stopping) for s in (signal.SIGTERM,signal.SIGINT)}
    try:
        with (output/'usage.jsonl').open('w') as monitor:
            while pending or active:
                if interrupted:stop_reason='interrupted'
                while pending and len(active)<workers and not stop_reason:
                    case=pending.pop(0);folder=output/case['name'];folder.mkdir();cfg=folder/'input.json';cfg.write_text(json.dumps(case['configuration'],indent=2)+'\n')
                    stdout=(folder/'stdout.txt').open('wb');stderr=(folder/'stderr.txt').open('wb')
                    command=[sys.executable,'-B','-m','scripts.stellar_formation.run',str(cfg.resolve()),str((folder/'run').resolve())]
                    if jacobian_workers>1:
                        command=[sys.executable,'-B','-m','scripts.compute.thermal_parallel','--workers',str(jacobian_workers),
                                 '--execution-record-dir',str((folder/'execution').resolve()),str(cfg.resolve()),str((folder/'run').resolve())]
                    p=subprocess.Popen(command,cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
                    active[case['name']]=dict(process=p,stdout=stdout,stderr=stderr,folder=folder,last_cpu=0,last_wall=time.monotonic(),command=command)
                now=time.monotonic();readings=[]
                for name,job in list(active.items()):
                    p=job['process']
                    if p.poll() is not None:
                        job['stdout'].close();job['stderr'].close();folder=job['folder'];check_exit=None
                        if (folder/'run/receipt.json').exists():
                            with (folder/'check.stdout.txt').open('wb') as out,(folder/'check.stderr.txt').open('wb') as err:
                                q=subprocess.run([sys.executable,'-B','-m','scripts.stellar_formation.watchdog',str((folder/'run').resolve())],cwd=root,env=env,stdout=out,stderr=err)
                            check_exit=q.returncode;receipt=json.loads((folder/'run/receipt.json').read_text())
                            fact={k:receipt[k] for k in ('status','final_time_s','final_step','observations','authority')}
                        else:fact=dict(status='NO_COMPLETED_RECEIPT')
                        done.append(dict(name=name,exit_code=p.returncode,saved_check_exit=check_exit,command=job['command'],**fact));del active[name];continue
                    cpu,rss=usage(p.pid);wall=now-job['last_wall'];cores=(cpu-job['last_cpu'])/wall if wall>0 else 0
                    job['last_cpu']=cpu;job['last_wall']=now
                    progress=job['folder']/'run/progress.json';state={}
                    if progress.exists():
                        try:
                            frame=json.loads(progress.read_text());state=dict(step=frame['step'],time_s=frame['t'],peak_K=max(frame['T']))
                        except (OSError,ValueError):pass
                    readings.append(dict(name=name,pid=p.pid,cpu_cores=max(0,cores),rss_bytes=rss,**state))
                used=sum(r['rss_bytes'] for r in readings);size=sum(p.stat().st_size for p in output.rglob('*') if p.is_file());free=shutil.disk_usage(output).free
                if used>rss_cap:stop_reason='aggregate_rss_guard'
                elif size>byte_cap:stop_reason='study_byte_guard'
                elif free<8*1024**3:stop_reason='disk_floor'
                if now-last>=10:
                    row=dict(elapsed_s=now-started,active=readings,completed=len(done),pending=len(pending),cpu_cores=sum(r['cpu_cores'] for r in readings),rss_bytes=used,evidence_bytes=size,free_bytes=free)
                    monitor.write(json.dumps(row)+'\n');monitor.flush();print(json.dumps(row),flush=True);last=now
                if stop_reason:
                    for job in active.values():os.killpg(job['process'].pid,signal.SIGTERM)
                    break
                time.sleep(.5)
    finally:
        for job in active.values():
            p=job['process']
            if p.poll() is None:
                os.killpg(p.pid,signal.SIGTERM)
                try:p.wait(timeout=5)
                except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
            job['stdout'].close();job['stderr'].close()
        for signum,handler in old_signals.items():signal.signal(signum,handler)
    if bindings()!=original_bindings:raise ValueError('study producer source changed')
    receipt=dict(schema='civsim.stellar-formation.study-result.v1',status='RESOURCE_STOP' if stop_reason else 'CASES_FINISHED',resource_stop=stop_reason,workers=workers,jacobian_workers=jacobian_workers,allocated_cpu_slots=workers*case_slots,wall_seconds=time.monotonic()-started,cases=done,unfinished=list(active)+[c['name'] for c in pending],bindings=original_bindings,driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Separate whole cold-origin trajectories. Completion of study cases does not require reaching physical final time, prove convergence or admit stars.')
    (output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');return receipt

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('specification',type=Path);p.add_argument('output',type=Path);p.add_argument('--workers',type=int,default=min(8,available_cpus()))
    p.add_argument('--jacobian-workers',type=int,default=1);a=p.parse_args()
    result=study(json.loads(a.specification.read_text(),object_pairs_hook=duplicate),a.output,a.workers,a.jacobian_workers);print(json.dumps(dict(status=result['status'],completed=len(result['cases']))))

if __name__=='__main__':main()
