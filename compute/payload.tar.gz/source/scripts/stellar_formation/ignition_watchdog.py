"""Independent rational account differences and Decimal virial reconstruction."""
from decimal import Decimal, localcontext
from fractions import Fraction as F
import math


def demand(condition, message):
    if not condition:
        raise ValueError('independent power/support: '+message)


def decimal(value):
    q = F(value)
    return Decimal(q.numerator)/Decimal(q.denominator)


def close(got, expected, absolute=0.0):
    demand(type(got) in (int,float) and math.isfinite(got), 'finite observation')
    demand(abs(got-float(expected)) <= 2e-11*abs(float(expected))+absolute,
           'observation discrepancy '+str((got,float(expected))))


def check(frames, coordinates, got):
    demand(got['schema']=='civsim.stellar-formation.power-support.v1','schema')
    for key in ('stellar_ignition','stellar_admission','completed_system','continuous_persistence_certified'):
        demand(got[key] is False,'unsupported authority')
    demand(got['scope']==('Saved-interval power and spherical virial diagnostics of the nominal '
        'gray hydrogen model. Interval averages do not resolve unsaved transients '
        'or establish physical stellar admission, continuum accuracy or a disk.'),'scope')
    saved=[]
    for frame in frames:
        demand(type(frame['t']) in (int,float) and math.isfinite(frame['t']) and frame['t']>=0,'clock')
        if saved and frame['t']==saved[-1]['t']:
            demand(frame==saved[-1],'duplicate clock state');continue
        demand(not saved or frame['t']>saved[-1]['t'],'clock order')
        saved.append(frame)
    demand(len(saved)>=2 and len(got['samples'])==len(saved) and len(got['intervals'])==len(saved)-1,'saved inventory')
    b=F(coordinates['m_e'])*(1+F(coordinates['m_p_over_m_e']))
    k=F(coordinates['k_B']);g=F(coordinates['G'])
    snapshots=[]
    with localcontext() as context:
        context.prec=55
        for frame,row in zip(saved,got['samples']):
            masses=list(map(F,frame['mass']));radii=list(map(F,frame['r']))
            demand(len(masses)==len(radii)>0 and all(v>0 for v in masses+radii),'positive geometry')
            total=sum(masses);target=total*F(9,10);cut=F(0);old=F(0)
            for mass,radius in zip(masses,radii):
                if cut+mass>=target:
                    density_volume=mass/(radius**3-old**3)
                    cube=old**3+(target-cut)/density_volume
                    r90=decimal(cube)**(Decimal(1)/3)
                    break
                cut+=mass;old=radius
            pressure=F(0)
            for mass,t,molecule,ion,amount in zip(masses,frame['T'],frame['mol'],frame['ion'],frame['amount']):
                p,d,a,h=map(F,amount);molecule,ion=F(molecule),F(ion)
                # Sum separate molecular, neutral, charged H, trace nuclei and electrons.
                count=p*molecule/2+p*(1-molecule)*(1-ion)+2*p*(1-molecule)*ion
                count+=d+a+h+d+2*a+2*h
                pressure+=mass/b*k*F(t)*count
            pressure*=3
            binding=-F(frame['energy_parts']['gravity']);kinetic=F(frame['energy_parts']['kinetic'])
            demand(binding>0,'binding')
            dyn=(r90**3/(decimal(g)*decimal(total)*Decimal('0.9'))).sqrt()
            expected=dict(time_s=frame['t'],step=frame['step'],peak_temperature_K=max(frame['T']),
                radius_90pct_mass_m=r90,mass_kg=total,dynamical_time_90pct_s=dyn,
                pressure_virial_J=pressure,pressure_virial_to_binding=pressure/binding,
                kinetic_to_binding=kinetic/binding,
                spherical_virial_residual_ratio=(2*kinetic+pressure-binding)/binding,
                max_photon_gas_pressure_ratio=frame['max_photon_gas_pressure_ratio'],
                max_electron_degeneracy_parameter=frame['max_electron_degeneracy_parameter'],
                max_electron_coulomb_parameter=frame['max_electron_coulomb_parameter'])
            demand(set(row)==set(expected),'snapshot fields')
            for key,value in expected.items():
                close(row[key],value,2e-14 if key=='spherical_virial_residual_ratio' else 0)
            if 'nuclear_ledger_J_baryon' in frame:
                heat=sum(mass/b*(F(q)-F(nu)) for mass,(q,nu) in zip(masses,frame['nuclear_ledger_J_baryon']))
                close(frame['nuclear'],heat)
            snapshots.append((r90,dyn))
        for index,(left,right,row) in enumerate(zip(saved,saved[1:],got['intervals'])):
            dt=F(right['t'])-F(left['t']);nuclear=(F(right['nuclear'])-F(left['nuclear']))/dt
            escape=(F(right['escaped'])-F(left['escaped']))/dt
            rates={key:(F(right['energy_parts'][key])-F(left['energy_parts'][key]))/dt
                   for key in ('gas','kinetic','gravity','photons')}
            residual=sum(rates.values())+escape-nuclear
            scale=sum(map(abs,rates.values()))+abs(escape)+abs(nuclear)
            dynamics=(snapshots[index][1]*snapshots[index+1][1]).sqrt()
            radius_change=(snapshots[index+1][0].ln()-snapshots[index][0].ln())*dynamics/decimal(dt)
            expected=dict(start_time_s=left['t'],end_time_s=right['t'],duration_s=dt,
                nuclear_power_W=nuclear,escaped_photon_power_W=escape,
                nuclear_to_escaping_power=nuclear/escape if escape>0 else None,
                gravitational_contraction_power_W=-rates['gravity'],stored_power_W=rates,
                numerical_mechanical_heating_W=(F(right['beheat'])-F(left['beheat'])+F(right['viscous'])-F(left['viscous']))/dt,
                power_balance_residual_W=residual,relative_power_balance_residual=abs(residual)/scale if scale else F(0),
                radius_log_change_per_dynamical_time=radius_change,sampled_dynamical_times=decimal(dt)/dynamics)
            demand(set(row)==set(expected),'interval fields')
            for key,value in expected.items():
                if value is None:
                    demand(row[key] is None,'undefined power ratio')
                elif isinstance(value,dict):
                    demand(set(row[key])==set(value),'stored-power fields')
                    for part,rate in value.items():close(row[key][part],rate)
                else:
                    absolute=3e-15*float(scale) if key=='power_balance_residual_W' else 3e-15 if key=='relative_power_balance_residual' else 3e-14*float(dynamics/decimal(dt)) if key=='radius_log_change_per_dynamical_time' else 0
                    close(row[key],value,absolute)
    return dict(status='PASS',snapshots=len(saved),intervals=len(saved)-1,
                scope='Independent rational energy differences, exact represented cumulative heat and Decimal ideal-mixture spherical virial/radius reconstruction. No continuous trajectory or stellar admission.')
