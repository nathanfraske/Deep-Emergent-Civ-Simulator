"""Bounded root recovery in the existing dimensionless gas coordinates."""
import math
import numpy as np
from scipy.optimize import root

RESIDUAL_LIMIT=1e-10


def solve(context,guess,jacobian):
    fit=root(context.residual,guess,jac=jacobian,tol=2e-9,options={'factor':.1})
    error=float(np.max(np.abs(context.residual(fit.x))))
    restarts=0
    if not math.isfinite(error) or error>RESIDUAL_LIMIT:
        # A tiny extrapolated guess can give MINPACK a tiny initial trust
        # region. Log volumes and temperatures already have dimensionless
        # coordinates; a zero restart with unit diagonal removes that trap.
        retry=root(context.residual,np.zeros_like(guess),jac=jacobian,tol=1e-10,
                   options={'factor':.1,'diag':np.ones_like(guess),'maxfev':1000})
        alternative=float(np.max(np.abs(context.residual(retry.x))))
        restarts=1
        if math.isfinite(alternative) and (not math.isfinite(error) or alternative<error):
            fit,error=retry,alternative
    if not math.isfinite(error) or error>RESIDUAL_LIMIT:
        raise ValueError('root '+str(error))
    return fit.x,error,restarts
