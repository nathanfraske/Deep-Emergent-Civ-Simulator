"""Read-only residual of one implicit gas step; no scheduling or new physics."""
from .data import *
from .caloric import eos
from .burning import extents
from . import transfer


class StepContext:
    def __init__(self, solver, dt):
        self.solver=solver;self.dt=dt;self.n=solver.n
        self.ro,self.vo,self.To,self.ao=solver.y
        self.Vo=solver.volume(self.ro)
        self.uo,self.po,self.kpo,self.kro,*_=eos(solver.mass/self.Vo,self.To,self.ao)
        tau=self.kro*solver.mass/self.Vo*np.diff(np.r_[0,self.ro]);groups=[];start=0;total=0
        for j,amount in enumerate(tau):
            total+=amount
            if total>=solver.rad_tau_min:groups.append((start,j+1));start=j+1;total=0
        if start<self.n:
            if groups:groups[-1]=(groups[-1][0],self.n)
            else:groups=[(0,self.n)]
        solver.rad_groups=groups
        self.uscale=np.maximum(self.uo,G*solver.enc/self.ro)
        self.vscale=np.maximum(np.sqrt(G*solver.enc/self.ro),np.abs(self.vo))
        self.momentum_scale=np.maximum(self.vscale,dt*G*solver.enc/self.ro**2)

    def unpack(self,z):
        delta=(3/(4*PI))*np.cumsum(self.Vo*np.expm1(z[:self.n]))
        r=self.ro*np.cbrt(1+delta/self.ro**3)
        displacement=delta/(r*r+r*self.ro+self.ro*self.ro)
        return r,self.To*np.exp(z[self.n:]),displacement/self.dt

    def terms(self,r,T,v):
        s=self.solver;ro=self.ro;vo=self.vo;Vo=self.Vo;dt=self.dt
        V=s.volume(r)
        if min(V)<=0:raise ValueError('crossing')
        rho=s.mass/V;amount,heat,nu,census,ledger,events=extents(self.ao,rho,T,dt,s.burn,s.census)
        u,p,kp,kr,y,x=eos(rho,T,amount)
        er,exchange,escape=transfer.advance(s,r,T,rho,V,Vo,kp,kr,dt)
        dv=np.diff(np.r_[0,v]);vis=rho*np.minimum(dv,0)**2*2
        area=4*PI/3*(r*r+r*ro+ro*ro);pressure=p+vis
        ap=area*(pressure-np.r_[pressure[1:],0])/s.dual;ag=G*s.enc/(r*ro)
        diss=s.dual*(v-vo)**2/2
        dh=(diss+np.r_[0,diss[:-1]])/2;dh[-1]+=diss[-1]/2
        work=-(p+vis)*(V-Vo)/s.mass;rhs=work+dh/s.mass+heat-exchange
        return v,ap-ag,u,amount,heat,nu,escape,rhs,vis*(Vo-V),sum(diss),er,census,ledger,events

    def residual(self,z):
        try:
            r,T,v=self.unpack(z)
            v,acc,u,a,heat,nu,loss,rhs,vis,diss,er,census,ledger,events=self.terms(r,T,v)
            return np.r_[(v-self.vo-self.dt*acc)/self.momentum_scale,(u-self.uo-rhs)/self.uscale]
        except (ValueError,FloatingPointError):return np.full(2*self.n,1e20)

    def column(self,z,base,j):
        shifted=z.copy();shifted[j]+=1e-5
        return (self.residual(shifted)-base)/1e-5

    def jacobian(self,z):
        base=self.residual(z)
        return np.array([self.column(z,base,j) for j in range(2*self.n)]).T
