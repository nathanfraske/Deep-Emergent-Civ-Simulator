"""Read-only scientific views of held spherical gas, never a stellar image."""
import argparse,gzip,json,hashlib,io
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from PIL import Image
from .watchdog import history

YEAR=365.25*86400 # Julian-year display convention, not a physical coefficient.

def read(directory):
    with gzip.open(Path(directory)/'history.jsonl.gz','rt') as f:raw=[json.loads(line) for line in f]
    frames=[]
    for row in raw:
        if frames and row['step']==frames[-1]['step']:
            if row!=frames[-1]:raise ValueError('changed duplicate saved state')
        else:frames.append(row)
    return frames

def mass_radius(frame,fraction=.9):
    masses=np.array(frame['mass']);cumulative=np.cumsum(masses);target=fraction*cumulative[-1]
    j=int(np.searchsorted(cumulative,target));inner=frame['r'][j-1] if j else 0
    weight=(target-(cumulative[j-1] if j else 0))/masses[j]
    return (inner**3+weight*(frame['r'][j]**3-inner**3))**(1/3)

def projection(frame,extent,pixels=112):
    xy=np.linspace(-extent,extent,pixels);b2=xy[:,None]**2+xy[None,:]**2
    column=np.zeros_like(b2);temperature=np.zeros_like(b2);inner=0
    for outer,rho,t in zip(frame['r'],frame['rho'],frame['T']):
        length=2*(np.sqrt(np.maximum(outer*outer-b2,0))-np.sqrt(np.maximum(inner*inner-b2,0)))
        column+=rho*length;temperature+=rho*t*length;inner=outer
    result=np.divide(temperature,column,out=np.full_like(column,np.nan),where=column>0)
    # Independent analytic integration of the displayed spherical columns.
    projected_mass=sum(4*np.pi/3*rho*(outer**3-inner**3) for rho,inner,outer in zip(frame['rho'],[0]+frame['r'][:-1],frame['r']))
    if abs(projected_mass-sum(frame['mass']))>sum(frame['mass'])*3e-7:raise ValueError('display column mass balance')
    return result

def chart(directory,output):
    frames=read(directory);receipt=json.loads((Path(directory)/'receipt.json').read_text())
    t=np.array([x['t'] for x in frames]);years=t/YEAR
    fig,ax=plt.subplots(2,2,figsize=(11,7.8),layout='constrained')
    fig.suptitle('Cold hydrogen gas to modeled PP-I burning',fontsize=17)
    ax[0,0].plot(years,[max(x['T']) for x in frames],label='Peak gas temperature',color='#d1495b')
    ax[0,0].plot(years,[x['T'][0] for x in frames],label='Central cell',color='#3066be',alpha=.8)
    ax[0,0].set_ylabel('Gas temperature (K)');ax[0,0].set_yscale('log');ax[0,0].legend(fontsize=9)
    ax[0,1].plot(years,[mass_radius(x) for x in frames],color='#32936f')
    ax[0,1].set_yscale('log');ax[0,1].set_ylabel('Radius containing 90% of gas (m)')
    dt=np.diff(t);power_n=np.diff([x['nuclear'] for x in frames])/dt;power_r=np.diff([x['escaped'] for x in frames])/dt
    ax[1,0].plot(years[1:],np.where(power_n>0,power_n,np.nan),label='Deposited fusion heat',color='#d1495b')
    ax[1,0].plot(years[1:],np.where(power_r>0,power_r,np.nan),label='Escaping photon energy',color='#3066be')
    ax[1,0].set_yscale('log');ax[1,0].set_ylabel('Power averaged between saved states (W)');ax[1,0].legend(fontsize=9)
    for j,label in ((1,'Deuterium'),(2,'Helium-3'),(3,'Helium-4')):
        y=[sum(m*(j+1)*a[j] for m,a in zip(x['mass'],x['amount']))/sum(x['mass']) for x in frames]
        ax[1,1].plot(years,np.where(np.array(y)>0,y,np.nan),label=label)
    ax[1,1].set_yscale('log');ax[1,1].set_ylabel('Represented baryon fraction');ax[1,1].legend(fontsize=9)
    for a in ax.flat:
        a.set_xscale('symlog',linthresh=10);a.set_xlim(0,max(years));a.set_xlabel('Time from declared cold gas (Julian years)');a.grid(alpha=.2)
    fig.supxlabel('Experimental gray ideal hydrogen: dense EOS, opacity and spatial convergence remain open.',fontsize=10)
    path=Path(output)/'cold-to-burning.png';fig.savefig(path,dpi=160);plt.close(fig)
    return path

def animation(directory,output):
    frames=read(directory);indices=np.unique(np.linspace(0,len(frames)-1,min(90,len(frames)),dtype=int))
    norm=LogNorm(vmin=10,vmax=2e7);images=[];initial_extent=frames[0]['r'][-1]*1.1
    for index in indices:
        frame=frames[index];bulk=mass_radius(frame);fig,axs=plt.subplots(1,2,figsize=(9.4,5),layout='constrained')
        for a,extent,title in zip(axs,(initial_extent,bulk*1.25),('Fixed initial-cloud view','View scaled to 90% mass radius')):
            data=projection(frame,extent)
            plotted=a.imshow(data,extent=(-extent,extent,-extent,extent),origin='lower',cmap='inferno',norm=norm)
            a.set_title(title,fontsize=10);a.set_xlabel('Projected distance (m)');a.set_ylabel('Projected distance (m)');a.ticklabel_format(axis='both',style='sci',scilimits=(0,0))
        fig.colorbar(plotted,ax=axs,label='Column-weighted gas temperature (K)',shrink=.75)
        fig.suptitle(f"Computed spherical gas | {frame['t']/YEAR:,.2f} Julian years\nPeak {max(frame['T']):,.0f} K; 90% mass radius {bulk:.3g} m",fontsize=12)
        fig.supxlabel('Saved states; changing zoom. Gray hydrogen diagnostic, not an astronomical light image.',fontsize=9)
        buffer=io.BytesIO();fig.savefig(buffer,format='png',dpi=105);plt.close(fig);buffer.seek(0)
        images.append(Image.open(buffer).convert('RGB'))
    path=Path(output)/'cold-collapse-burning.gif'
    images[0].save(path,save_all=True,append_images=images[1:],duration=160,loop=0,optimize=False)
    return path

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('directory',type=Path);parser.add_argument('output',type=Path)
    args=parser.parse_args();checked=history(args.directory)
    args.output.mkdir(parents=True,exist_ok=False)
    paths=(chart(args.directory,args.output),animation(args.directory,args.output))
    evidence=dict(schema='civsim.stellar-formation.readonly-view.v1',saved_check=checked,
        observer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
        authority='No stellar or completed-system admission. Exact spherical column geometry, cell-mean temperatures; no frequency/emergent light calculation or interpolated gas states.')
    (args.output/'verification.json').write_text(json.dumps(evidence,indent=2)+'\n')
    print(json.dumps(dict(status='PASS',files=[str(p) for p in paths])))

if __name__=='__main__':main()
