"""Freeze a small parallel operator study and render its computed receipts."""
from concurrent.futures import ProcessPoolExecutor
from copy import deepcopy
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path
import argparse, hashlib, json, time
from . import source, run, benchmark, nuclear


def main():
    parser=argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('--floor',required=True,type=Path)
    parser.add_argument('--config',required=True,type=Path)
    parser.add_argument('--output-dir',required=True,type=Path)
    args=parser.parse_args()
    if args.output_dir.exists():raise ValueError('refuse overwrite of operator study')
    cfg=run.config(args.config.read_text(encoding='ascii'));model=source.load(args.floor)
    bindings=run.implementation_bindings();began=time.monotonic()
    configs={name:{**cfg,**patch} for name,patch in {
        'time1024':{'steps':1024},'time2048':{'steps':2048},
        'precision192':{'steps':2048,'fraction_bits':192,'decimal_digits':80},
        'disabled':{'steps':8,'nuclear_enabled':False}}.items()}
    with ProcessPoolExecutor(max_workers=4) as pool:
        jobs={name:pool.submit(run.solve,model,value) for name,value in configs.items()}
        results={name:job.result() for name,job in jobs.items()}
    if bindings!=run.implementation_bindings():raise ValueError('study implementation drift')
    with localcontext() as c:
        c.prec=64;r=model['profile']['reactions'][0]
        rates=[(str(t),nuclear.rate(r,model['constants'],Decimal(t))) for t in [10000000,12000000,16000000,20000000]]
    comparisons=benchmark.compare(model,rates)
    fine=results['time2048']['frames'][-1];coarse=results['time1024']['frames'][-1];other=results['precision192']['frames'][-1]
    def abundance(frame,bits,name):return Fraction(frame['amounts'][name],1<<bits)
    refinement={'temperature_difference_K':str(abs(Decimal(fine['temperature_K'])-Decimal(coarse['temperature_K']))),
        'he4_relative_difference':str(float(abs(abundance(fine,128,'he4')-abundance(coarse,128,'he4'))/abundance(fine,128,'he4'))),
        'precision_temperature_difference_K':str(abs(Decimal(fine['temperature_K'])-Decimal(other['temperature_K']))),
        'exact_energy_residual_J_baryon':results['time2048']['energy_balance_residual_J_baryon']}
    args.output_dir.mkdir(parents=True)
    records={}
    for name,result in results.items():
        result['implementations']=bindings
        target=args.output_dir/(name+'.json');target.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='ascii')
        records[name]={'path':target.name,'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
    (args.output_dir/'comparisons.json').write_text(json.dumps(comparisons,indent=2)+'\n',encoding='ascii')
    # Observer conversion happens only after causal receipts have been sealed.
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    figure,axes=plt.subplots(1,3,figsize=(13.2,4.3))
    frames=results['time2048']['frames'];baryon_mass=float(model['constants']['m_e']*(1+model['constants']['m_p_over_m_e']))
    clock=np.array([float(Fraction(f['time_s']))/31557600 for f in frames])/1e6
    axes[0].plot(clock,[float(f['temperature_K'])-float(frames[0]['temperature_K']) for f in frames],color='#e36538',label='Nuclear reactions')
    axes[0].plot([0,clock[-1]],[0,0],color='#64748b',linestyle='--',label='Reactions disabled')
    axes[0].set_ylabel('Temperature increase (K)');axes[0].legend(fontsize=8)
    for name,color in [('d','#47a1a8'),('he3','#8e6cc8'),('he4','#d19724')]:
        axes[1].plot(clock,[float(Fraction(f['amounts'][name],1<<128)) for f in frames],color=color,label=name)
    axes[1].set_yscale('log');axes[1].set_ylabel('Nuclei per baryon');axes[1].legend(fontsize=8)
    for name,color,label in [('released','#d19724','Released Q'),('escaped','#8e6cc8','Escaped neutrinos')]:
        axes[2].plot(clock,[float(Fraction(f[name]))/baryon_mass for f in frames],color=color,label=label)
    axes[2].plot(clock,[float(Fraction(f['released'])-Fraction(f['escaped']))/baryon_mass for f in frames],color='#47a1a8',label='Deposited heat')
    axes[2].set_ylabel('Cumulative energy (J/kg)');axes[2].legend(fontsize=8)
    for ax in axes:ax.set_xlabel('Elapsed time (million Julian years)');ax.grid(alpha=.2)
    figure.suptitle('Computed fusion heating in a closed validation parcel',fontsize=14)
    figure.text(.5,.025,'Explicit hot control: 1000 kg/m³, initially 12 million K, pure hydrogen. This is not gas-to-star ignition.',ha='center',fontsize=9)
    figure.tight_layout(rect=(0,.06,1,.92));figure.savefig(args.output_dir/'fusion-heating.png',dpi=160);plt.close(figure)
    report={'schema':'civsim.stellar-thermal.study.v1','status':'COMPONENT_STUDY_COMPLETE','stellar_ignition':False,
        'seconds':time.monotonic()-began,'parallel_workers':4,'cases':records,'refinement':refinement,
        'plot_sha256':hashlib.sha256((args.output_dir/'fusion-heating.png').read_bytes()).hexdigest(),
        'final_temperature_K':fine['temperature_K'],'scope':results['time2048']['limitation']}
    (args.output_dir/'study.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n',encoding='ascii')
    print(json.dumps(report))


if __name__=='__main__':main()
