"""Coupled PP-I backward Euler, analytically eliminating the fast deuterium.

Only a monotone scalar proton root and a caloric fixed point remain. Extents
are rounded once and deposited heat is fed back into the same interval.
"""
from collections import Counter
from decimal import Decimal
from fractions import Fraction
from .arithmetic import decimal, quantize
from . import nuclear, thermodynamics


def extents(old, tau, precision):
    p0=old['p'];d0=old['d'];h0=old['he3']
    kp,kd,kh=tau
    def evaluate(p):
        pp=kp*p*p/2
        q=kd*p;capture=(d0+pp)*q/(1+q)
        available=h0+capture
        h=2*available/(1+(1+4*kh*available).sqrt())
        hp=(kp*p*q/(1+q)+(d0+pp)*kd/(1+q)**2)/(1+2*kh*h)
        return p-p0+2*pp-h0+h,1+2*kp*p+hp,(pp,capture,(available-h)/2)
    lo=Decimal(0);hi=p0+h0;p=p0
    for _ in range(precision+20):
        residual,derivative,result=evaluate(p)
        if abs(residual)<=Decimal(10)**(8-precision):return result
        if residual<0:lo=p
        else:hi=p
        candidate=p-residual/derivative
        p=candidate if lo<candidate<hi else (lo+hi)/2
    raise ValueError('implicit monotone proton root did not converge')


def advance(model, old, density, dt, scale, pi, precision, enabled=True):
    if not isinstance(dt,Fraction) or dt<=0:raise ValueError('exact positive nuclear interval')
    reactions=model['profile']['reactions']
    if [r['id'] for r in reactions]!=['p_p_d','p_d_he3','he3_he3_p_p_he4']:
        raise ValueError('unsupported network for coupled PP-I solve')
    initial_t=thermodynamics.temperature(model,old['amounts'],scale,density,old['energy'],pi,precision)
    t=initial_t;nb=thermodynamics.fields(model,old['amounts'],scale,density,t,pi)['n_b_m3']
    initial={k:Decimal(n)/scale for k,n in old['amounts'].items()}
    last_counts=None
    for iteration in range(precision+20):
        rates=[nuclear.rate(r,model['constants'],t) for r in reactions]
        xs=extents(initial,[k*nb*decimal(dt) for k in rates],precision) if enabled else (Decimal(0),)*3
        counts=[quantize(x,scale) for x in xs]
        # Deuterium and He3 can exhaust below one event quantum. Preserve positivity.
        counts[1]=min(counts[1],old['amounts']['d']+counts[0])
        counts[2]=min(counts[2],(old['amounts']['he3']+counts[1])//2)
        amounts=dict(old['amounts']);released=Fraction(0);escaped=Fraction(0)
        for r,n in zip(reactions,counts):
            for name,multiplicity in Counter(r['reactants']).items():amounts[name]-=multiplicity*n
            for name,multiplicity in Counter(r['products']).items():amounts[name]+=multiplicity*n
            released+=Fraction(r['q_MeV'])*10**6*Fraction(model['constants']['e'])*Fraction(n,scale)
            if r['neutrino']=='allowed_pp':escaped+=Fraction(model['neutrino']['mean_J'])*Fraction(n,scale)
        if any(n<0 for n in amounts.values()):raise ValueError('coupled extent quantization exhausted nuclei')
        energy=old['energy']+released-escaped
        updated_t=thermodynamics.temperature(model,amounts,scale,density,energy,pi,precision)
        if updated_t>initial_t*Decimal('1.02'):
            raise ValueError('nuclear interval changes temperature by more than two percent; refine time')
        if counts==last_counts and abs(updated_t-t)<abs(t)*Decimal(10)**(12-precision):
            new={'amounts':amounts,'energy':energy,'released':old['released']+released,'escaped':old['escaped']+escaped}
            return new,{'method':'coupled_ppi_backward_euler.v1','temperature':updated_t,
                'coefficients':rates,'extent_q':counts,'released':released,'escaped':escaped,
                'nonlinear_iterations':iteration+1}
        last_counts=counts;t=updated_t
    raise ValueError('coupled caloric nuclear solve did not converge')
