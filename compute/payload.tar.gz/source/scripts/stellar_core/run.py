"""Reproducible component workbench; accepts no requested stellar outcome."""
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path
import argparse, hashlib, json, re, time
from . import source, thermodynamics, nuclear, watchdog
from .arithmetic import pi, text


def encode(value):
    if isinstance(value,Fraction):return text(value)
    if isinstance(value,Decimal):return str(value)
    if isinstance(value,dict):return {k:encode(v) for k,v in value.items()}
    if isinstance(value,list):return [encode(v) for v in value]
    return value


def config(raw):
    # No physical defaults. Validation-only input cannot activate a stellar adapter.
    if len(raw)>65536:raise ValueError('component input exceeds read budget')
    def unique(pairs):
        value={}
        for key,item in pairs:
            if key in value:raise ValueError('duplicate component input key: '+key)
            value[key]=item
        return value
    def exact(value):
        if type(value)is not str or len(value)>256:
            raise ValueError('exact bounded physical coordinate text required')
        if not re.fullmatch(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d{1,3})?|[+-]?\d+/[1-9]\d*',value):
            raise ValueError('unsupported physical coordinate encoding')
        return Fraction(value)
    value=json.loads(raw,object_pairs_hook=unique)
    required={'schema','origin','role','density_kg_m3','temperature_K','nuclei_per_baryon','duration_s','steps','fraction_bits','decimal_digits','nuclear_enabled'}
    if set(value)!=required or value['schema']!='stellar_closed_parcel_v1' or value['origin']!='declared_hypothesis' or value['role']!='operator_validation':
        raise ValueError('explicit operator validation schema required')
    if type(value['steps'])is not int or not 1<=value['steps']<=4096 or type(value['fraction_bits'])is not int or not 128<=value['fraction_bits']<=256:
        raise ValueError('parcel resource and representation contract')
    if type(value['decimal_digits'])is not int or not 64<=value['decimal_digits']<=120 or type(value['nuclear_enabled'])is not bool:
        raise ValueError('parcel precision or control contract')
    if value['decimal_digits'] < (value['fraction_bits']*30103+99999)//100000+16:
        raise ValueError('decimal work precision must exceed nuclear storage precision')
    if not isinstance(value['nuclei_per_baryon'],dict):raise ValueError('nuclei must be explicit')
    if any(exact(v)<0 for v in value['nuclei_per_baryon'].values()):
        raise ValueError('nuclear fractions require exact nonnegative text')
    for key in ['density_kg_m3','temperature_K','duration_s']:
        if not exact(value[key])>0:raise ValueError('exact positive physical input')
    return value


def solve(model, cfg):
    source.validate(model)
    cfg=config(json.dumps(cfg))
    precision=cfg['decimal_digits'];scale=1<<cfg['fraction_bits']
    with localcontext() as context:
        context.prec=precision
        p=pi(precision)
        fine=nuclear.neutrino(model,p);coarse=nuclear.neutrino(model,p,nodes=1024)
        if abs(fine['mean_J']-coarse['mean_J'])>abs(fine['mean_J'])*Decimal('2e-10'):
            raise ValueError('neutrino quadrature refinement limit')
        model={**model,'neutrino':fine}
        watchdog.neutrino(model)
        profile=model['profile']; fractions=cfg['nuclei_per_baryon']
        if set(fractions)!=set(profile['species']):raise ValueError('complete supplied nuclear census')
        amounts={name:int(Fraction(value)*scale) for name,value in fractions.items()}
        if any(Fraction(fractions[n])*scale!=v for n,v in amounts.items()):raise ValueError('initial nuclear census is not representable')
        from .arithmetic import decimal
        density=decimal(Fraction(cfg['density_kg_m3']));initial_t=decimal(Fraction(cfg['temperature_K']))
        f=thermodynamics.fields(model,amounts,scale,density,initial_t,p)
        initial_energy=Fraction(f['u_J_baryon'])
        y={'amounts':amounts,'energy':initial_energy,'released':Fraction(0),'escaped':Fraction(0)}
        dt=Fraction(cfg['duration_s'])/cfg['steps'];frames=[];trace='0'*64
        def frame(i):
            t=thermodynamics.temperature(model,y['amounts'],scale,density,y['energy'],p,precision)
            watchdog.thermal(model,y['amounts'],scale,density,y['energy'],t)
            return encode({'step':i,'time_s':i*dt,'temperature_K':t,**y})
        frames.append(frame(0))
        for i in range(1,cfg['steps']+1):
            new,records=nuclear.advance(model,y,density,dt,scale,p,precision,cfg['nuclear_enabled'])
            watchdog.step(model,y,new,records,density,dt,scale,cfg['nuclear_enabled'])
            trace=hashlib.sha256(bytes.fromhex(trace)+json.dumps(encode(records),sort_keys=True,separators=(',',':')).encode('ascii')).hexdigest()
            y=new;frames.append(frame(i))
        return encode({'schema':'civsim.stellar-thermal.component-run.v1','status':'EXPERIMENTAL_COMPONENT_CHECKED',
            'stellar_ignition':False,'gas_to_star':False,'completed_system':False,'configuration':cfg,
            'floor':model['floor'],'profile_sha256':model['profile_sha256'],'neutrino':fine,
            'equation_witness_sha256':hashlib.sha256(source.normalized(source.ROOT/'sources/stellar_thermal/equations.txt')).hexdigest(),
            'independent_library':{'name':'mpmath','version':watchdog.mp.__version__,'decimal_digits':90},
            'quadrature_relative_change':abs(fine['mean_J']/coarse['mean_J']-1),
            'initial_energy_J_baryon':initial_energy,'energy_balance_residual_J_baryon':y['energy']-initial_energy-y['released']+y['escaped'],
            'trace_sha256':trace,'frames':frames,
            'limitation':'Closed fixed-density hot validation parcel. Bare nominal PP-I fits and allowed zero-incident-energy neutrino approximation; fully ionized ideal ions/electrons and trapped blackbody photons. No hydrodynamics, molecular gas, opacity transport, accretion, physical uncertainty enclosure or stellar ignition classification.'})


def implementation_bindings():
    names=['__init__.py','arithmetic.py','source.py','source_watchdog.py','thermodynamics.py','nuclear.py','implicit.py','watchdog.py','run.py']
    return {str((Path(__file__).parent/n).relative_to(source.ROOT)):
        hashlib.sha256(source.normalized(Path(__file__).parent/n)).hexdigest() for n in names}


def main():
    parser=argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('--floor',required=True,type=Path)
    parser.add_argument('--config',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    if args.output.exists():raise ValueError('refuse overwrite of component receipt')
    cfg=config(args.config.read_text(encoding='ascii'));model=source.load(args.floor)
    bindings=implementation_bindings()
    began=time.monotonic();result=solve(model,cfg)
    if bindings!=implementation_bindings():
        raise ValueError('stellar implementation changed during computation')
    result['implementations']=bindings
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='ascii')
    print(json.dumps({'output':str(args.output),'seconds':time.monotonic()-began,
        'sha256':hashlib.sha256(args.output.read_bytes()).hexdigest(),
        'stellar_ignition':False,'final_temperature_K':result['frames'][-1]['temperature_K']}))


if __name__=='__main__':main()
