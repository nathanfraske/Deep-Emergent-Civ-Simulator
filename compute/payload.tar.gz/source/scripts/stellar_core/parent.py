"""Checked barotropic-core diagnostics and explicit caloric handoff refusal."""
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path
import argparse, hashlib, json, re, sys
from . import source
from .arithmetic import text


def decode(value):
    if isinstance(value,str) and re.fullmatch(r'-?\d+/[1-9]\d*',value):return Fraction(value)
    if isinstance(value,dict):return {k:decode(v) for k,v in value.items()}
    if isinstance(value,list):return [decode(v) for v in value]
    return value


def inspect(parent_path,model):
    raw=parent_path.read_bytes()
    if len(raw)>16*1024**2:raise ValueError('barotropic receipt exceeds read budget')
    receipt=decode(json.loads(raw));directory=source.ROOT/'scripts/radial_core'
    # The old pair has its own independent equations. This observer does not
    # grant the thermal prototype any missing state or physical authority.
    sys.path.insert(0,str(directory))
    import source as radial_source
    import producer as radial_producer
    import watchdog as radial_watchdog
    import lifecycle_watchdog
    import run as radial_run
    if receipt['model_id']!='spherical_bate1998_barotropic_v1' or receipt['schema']!='civsim.radial-barotropic-core.run.v2':
        raise ValueError('unsupported upstream gas model')
    if set(receipt['implementations'])!=set(radial_run.MODULES):raise ValueError('radial semantic census')
    for name,expected in receipt['implementations'].items():
        if hashlib.sha256(radial_source.normalized(directory/name)).hexdigest()!=expected:
            raise ValueError('upstream radial implementation custody: '+name)
    radial_source.validate(receipt['model'])
    if receipt['model']['G']!=Fraction(model['constants']['G']) or receipt['model']['floor_binding']!=model['floor']['floor_digest']:
        raise ValueError('upstream stellar floor mismatch')
    state=receipt['state'];cfg=receipt['numerics'];p=receipt['pi'];s=1<<cfg['fraction_bits']
    context=radial_producer.make_context(state,cfg,receipt['model'],p);context['pi']=p
    mass=receipt['mass_q'];enclosed=receipt['enclosed_q'];frame=receipt['frames'][-1]
    y={'r':frame['r_q'],'v':frame['v_q']}
    radial_watchdog.context(state,cfg,receipt['model'],p,context)
    first=receipt['frames'][0]
    radial_watchdog.projection(state,cfg,receipt['model'],{'r':first['r_q'],'v':first['v_q']},mass,enclosed)
    fields=radial_producer.fields(context,mass,enclosed,y)
    radial_watchdog.fields(context,mass,enclosed,y,fields)
    radial_watchdog.observation(context,mass,enclosed,y,fields,cfg,receipt['final_observation'])
    clock=frame['time_s']/context['time_unit']*s
    if clock.denominator!=1:raise ValueError('upstream exact clock')
    lifecycle_watchdog.body(receipt['stellar_body'],receipt['process_history'],state,cfg,context,enclosed,y,
        receipt['final_observation'],int(clock),receipt['steps'],receipt['trace_sha256'])
    c=model['constants'];atomic_mass=Fraction(c['m_e'])*(1+Fraction(c['m_p_over_m_e']))
    samples=[]
    for i in range(receipt['final_observation']['core_shells']):
        rho=Fraction(fields['rho'][i],s)*context['rho_unit']
        pressure=Fraction(fields['p'][i],s)*context['rho_unit']*receipt['model']['sound_speed_m_s']**2
        # Hypothetical pure neutral atomic ideal-gas P/rho thermometer only.
        # The barotrope supplies neither this material census nor its calorics.
        proxy=pressure/rho*atomic_mass/Fraction(c['k_B'])
        # A separate polynomial integration of the Bate branch gives the same P/rho.
        shape=Fraction(fields['p'][i],fields['rho'][i])
        independent=receipt['model']['sound_speed_m_s']**2*shape*atomic_mass/Fraction(c['k_B'])
        if independent!=proxy:raise ValueError('pressure thermometer unit conversion')
        samples.append({'shell':i,'density_kg_m3':text(rho),'pressure_Pa':text(pressure),
            'neutral_atomic_pressure_temperature_proxy_K':text(proxy)})
    with localcontext() as ctx:
        ctx.prec=16
        def reading(value):return str(Decimal(value.numerator)/Decimal(value.denominator))
        body=receipt['stellar_body']
        return {'schema':'civsim.stellar-thermal.upstream-inspection.v1',
            'status':'THERMAL_HANDOFF_REFUSED','stellar_ignition':False,'parent_sha256':hashlib.sha256(raw).hexdigest(),
            'parent_original_gas_trace_sha256':receipt['trace_sha256'],'saved_endpoint_pair_checked':True,
            'new_full_history_replay':False,'parent_steps':receipt['steps'],
            'core_mass_kg':reading(body['mass_kg']),'core_radius_m':reading(body['radius_m']),
            'maximum_neutral_atomic_pressure_proxy_K':reading(max(Fraction(row['neutral_atomic_pressure_temperature_proxy_K']) for row in samples)),
            'missing_state':['causally evolved internal energy','nuclear and chemical material census','radiation storage and transport state'],
            'refusal':'Barotropic density and pressure do not determine the missing caloric history. No hot seed, temperature, nuclear composition or luminosity is filled in.',
            'samples':samples,'scope':'Saved existing gas endpoint and original source binding only. A pressure-derived neutral-atomic diagnostic is not the gas temperature or a physical thermal upper bound.'}


def main():
    parser=argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('--floor',required=True,type=Path)
    parser.add_argument('--parent',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    if args.output.exists():raise ValueError('refuse overwrite of parent diagnostic')
    result=inspect(args.parent,source.load(args.floor))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='ascii')
    print(json.dumps({k:result[k] for k in ['status','core_mass_kg','core_radius_m','maximum_neutral_atomic_pressure_proxy_K','stellar_ignition']}))


if __name__=='__main__':main()
