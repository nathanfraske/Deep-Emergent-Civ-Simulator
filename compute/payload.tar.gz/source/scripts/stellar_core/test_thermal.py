"""Physical limiting cases, negative controls and independent replay checks."""
from copy import deepcopy
from concurrent.futures import ProcessPoolExecutor
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path
import hashlib, json, unittest
import mpmath as mp
from . import source, source_watchdog, thermodynamics, nuclear, implicit, watchdog, run, benchmark
from .arithmetic import pi


class ThermalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.model=source.load(source.ROOT/'artifacts/stellar-thermal/floor.json')
        cls.cfg=run.config((source.ROOT/'examples/stellar-thermal/hot-control.json').read_text())
        cls.results={}
        with ProcessPoolExecutor(max_workers=4) as pool:
            jobs={n:pool.submit(run.solve,cls.model,{**cls.cfg,'steps':n}) for n in [32,256,512,1024,2048]}
            cls.results={n:job.result() for n,job in jobs.items()}

    def test_published_pp_benchmark(self):
        with localcontext() as c:
            c.prec=64
            reaction=self.model['profile']['reactions'][0]
            rates=[(str(t),nuclear.rate(reaction,self.model['constants'],Decimal(t))) for t in [10000000,12000000,16000000,20000000]]
        comparison=benchmark.compare(self.model,rates)
        for row in comparison['pp_rates']:
            self.assertLess(abs(Decimal(row['relative_difference'])),Decimal('0.05'))

    def test_complete_baryon_and_energy_accounts(self):
        for result in self.results.values():
            self.assertEqual(Fraction(result['energy_balance_residual_J_baryon']),0)
            for f in result['frames']:
                self.assertEqual(sum(self.model['profile']['species'][name]['A']*n for name,n in f['amounts'].items()),1<<128)
                self.assertTrue(all(n>=0 for n in f['amounts'].values()))
            final=result['frames'][-1]
            self.assertGreater(final['amounts']['he4'],0)
            self.assertGreater(Fraction(final['escaped']),0)
            self.assertGreater(Fraction(final['released']),Fraction(final['escaped']))
            self.assertGreater(Decimal(final['temperature_K']),Decimal('12000000'))
            self.assertFalse(result['stellar_ignition'])

    def test_disabled_reactions_preserve_temperature_and_composition(self):
        result=run.solve(self.model,{**self.cfg,'nuclear_enabled':False,'steps':8})
        before=result['frames'][0];after=result['frames'][-1]
        for key in ['amounts','energy','released','escaped','temperature_K']:
            self.assertEqual(before[key],after[key])

    def test_deterministic_replay(self):
        self.assertEqual(self.results[32],run.solve(self.model,{**self.cfg,'steps':32}))

    def test_measured_time_refinement(self):
        # A real long stiff-network trajectory, not the discrete update copied as a test.
        outputs=[self.results[n]['frames'][-1] for n in [256,512,1024,2048]]
        changes=[abs(Decimal(a['temperature_K'])-Decimal(b['temperature_K'])) for a,b in zip(outputs,outputs[1:])]
        self.assertLess(changes[-1],changes[0])
        self.assertLess(changes[-1],Decimal('0.1'))
        helium=[Fraction(r['amounts']['he4'],1<<128) for r in outputs]
        self.assertLess(abs(helium[-1]-helium[-2])/helium[-1],Fraction(1,1000))

    def test_floor_profile_and_requested_outcome_refuse(self):
        for field in ['star_mass_kg','ignite','desired_temperature_K','starting_star']:
            with self.assertRaises(ValueError):run.config(json.dumps({**self.cfg,field:'1'}))
        for key in self.model['constants']:
            model=deepcopy(self.model);model['constants'][key]*=2
            with self.assertRaises(ValueError):run.solve(model,self.cfg)
        model=deepcopy(self.model);model['profile']['reactions'][0]['q_MeV']='9'
        with self.assertRaises(ValueError):run.solve(model,self.cfg)
        raw=source.normalized(source.ROOT/'sources/stellar_thermal/ppi.json')
        with self.assertRaises(ValueError):source_watchdog.check(source.ROOT,self.model['floor'],self.model['profile'],raw+b' ')

    def test_cold_gas_high_density_and_low_precision_refuse(self):
        for patch in [{'temperature_K':'10'},{'density_kg_m3':'1e12'},{'fraction_bits':256,'decimal_digits':64}]:
            with self.assertRaises(ValueError):run.solve(self.model,{**self.cfg,**patch})

    def test_input_duplicates_float_nuclei_and_huge_numbers_refuse(self):
        raw=json.dumps(self.cfg)
        with self.assertRaises(ValueError):run.config(raw[:-1]+',"temperature_K":"14000000"}')
        with self.assertRaises(ValueError):run.config(json.dumps({**self.cfg,'duration_s':'1e999999999'}))
        with self.assertRaises(ValueError):run.config(json.dumps({**self.cfg,'nuclei_per_baryon':{'p':1.0,'d':'0','he3':'0','he4':'0'}}))

    def test_rational_input_encoding_is_equivalent(self):
        cfg={**self.cfg,'steps':1,'duration_s':'1000','density_kg_m3':'1000/1','temperature_K':'12000000/1'}
        a=run.solve(self.model,cfg)
        b=run.solve(self.model,{**cfg,'density_kg_m3':'1000','temperature_K':'12000000'})
        for key in ['frames','trace_sha256','energy_balance_residual_J_baryon']:
            self.assertEqual(a[key],b[key])

    def test_saha_ground_state_limit_independent(self):
        with localcontext() as c,mp.workdps(90):
            c.prec=64;p=pi(64)
            constants=self.model['constants']
            for density,temperature in [('1e-8','10000'),('0.1','16000'),('100','200000')]:
                result=thermodynamics.atomic_hydrogen(constants,Decimal(density),Decimal(temperature),p)
                r={k:mp.mpf(str(v)) for k,v in constants.items()};t=mp.mpf(temperature)
                proton=r['m_e']*r['m_p_over_m_e'];reduced=proton*r['m_e']/(proton+r['m_e'])
                chi=r['alpha']**2*reduced*r['c']**2/2
                n=mp.mpf(density)/(proton+r['m_e'])
                ratio=(2*mp.pi*r['m_e']*r['k_B']*t/r['h']**2)**mp.mpf('1.5')*mp.exp(-chi/(r['k_B']*t))/n
                x=(-ratio+mp.sqrt(ratio**2+4*ratio))/2
                self.assertLess(abs(mp.mpf(str(result['ion_fraction']))/x-1),mp.mpf('1e-50'))
                self.assertGreater(x,0);self.assertLess(x,1)

    def test_reaction_symmetry_and_fast_reactant_depletion(self):
        with localcontext() as c:
            c.prec=64;scale=1<<128
            # The dilute pp limit has the independent pair event factor one-half.
            dilute=implicit.extents({'p':Decimal(1),'d':Decimal(0),'he3':Decimal(0)},
                [Decimal('1e-20'),Decimal(0),Decimal(0)],64)
            self.assertLess(abs(dilute[0]/Decimal('0.5e-20')-1),Decimal('1e-19'))
            # Fast capture finishes within the same coarse interval.
            fast=implicit.extents({'p':Decimal('0.75'),'d':Decimal('0.125'),'he3':Decimal(0)},
                [Decimal(0),Decimal('1e20'),Decimal(0)],64)
            self.assertLess(abs(fast[1]/Decimal('0.125')-1),Decimal('1e-19'))
            # Initially pure He3 creates protons with no supplied proton seed.
            recycle=implicit.extents({'p':Decimal(0),'d':Decimal(0),'he3':Decimal(1)/3},
                [Decimal(0),Decimal(0),Decimal(1)],64)
            self.assertGreater(recycle[2],0)

    def test_independent_checker_rejects_modified_heat_and_extents(self):
        with localcontext() as c:
            c.prec=64;p=pi(64);scale=1<<128
            model={**self.model,'neutrino':nuclear.neutrino(self.model,p)}
            amounts={'p':scale,'d':0,'he3':0,'he4':0};density=Decimal('1000')
            energy=Fraction(thermodynamics.fields(model,amounts,scale,density,Decimal('12000000'),p)['u_J_baryon'])
            old={'amounts':amounts,'energy':energy,'released':Fraction(0),'escaped':Fraction(0)}
            dt=Fraction(10**12)
            new,records=nuclear.advance(model,old,density,dt,scale,p,64)
            watchdog.step(model,old,new,records,density,dt,scale,True)
            for field in ['extent_q','escaped','released','coefficient','temperature']:
                modified=deepcopy(records)
                if field=='extent_q':modified[field][0]+=1
                elif field=='coefficient':modified['coefficients'][0]*=2
                else:modified[field]*=2
                with self.assertRaises(ValueError):watchdog.step(model,old,new,modified,density,dt,scale,True)


if __name__=='__main__':unittest.main(verbosity=2)
