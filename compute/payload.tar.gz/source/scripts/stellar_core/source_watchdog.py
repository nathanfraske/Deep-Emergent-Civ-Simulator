"""Independent exact coordinate checks; no producer imports."""
from fractions import Fraction
from hashlib import sha256
import re

# Populated from independently transcribed, held source records.
PROFILE_SHA256 = '17418fc36b085116c1f297a788938e7454f9403436dfaf44586aed378672d169'
FLOOR_DIGEST = 'e0cfd4a60342488054ddfa936599794e1697c0bd0997122c22e58047cde0aeb5'
FACTS_SHA256 = '7645ac6c0cdafc0e94853cc0ac20fc6ca93d171504e9a78f7f0aef4b09678401'


def check(root, floor, profile, raw):
    if sha256(raw).hexdigest() != PROFILE_SHA256:
        raise ValueError('stellar reaction profile custody')
    witness=(root/'sources/stellar_thermal/equations.txt').read_bytes().replace(b'\r\n',b'\n')
    if sha256(witness).hexdigest()!='68f47d9842c052fa8739b9849433ae859128d108777b220f643a0701ecc65c50':
        raise ValueError('stellar thermal equation custody')
    if set(floor) != {'schema', 'floor_digest', 'representation_schema', 'coordinates'} or floor['schema'] != 'civsim.stellar-thermal.floor.v1':
        raise ValueError('stellar floor schema')
    if floor['floor_digest'] != FLOOR_DIGEST or floor['representation_schema'] != 'civsim.units.si-representation.v1':
        raise ValueError('stellar floor authority binding')
    data = (root / 'crates/units/data/codata_2018_floor_facts.tsv').read_bytes().replace(b'\r\n', b'\n')
    if sha256(data).hexdigest() != FACTS_SHA256:
        raise ValueError('stellar floor factual custody')
    expected = {row[1]: Fraction(row[7]) for row in
                (line.split('\t') for line in data.decode('ascii').splitlines()) if row[0] == 'row'}
    # SI definitions are representation metadata, checked against their Rust rows.
    rust_bytes=(root / 'crates/units/src/fundamentals.rs').read_bytes().replace(b'\r\n',b'\n')
    if sha256(rust_bytes).hexdigest()!='d5c05764692650572b334103084ea3367f3394d8ab2796b5a82ac4475f5a5224':
        raise ValueError('stellar SI definition custody')
    rust=rust_bytes.decode('utf-8')
    for key in ['c', 'h', 'k_B', 'e', 'N_A']:
        matches = re.findall(r'symbol: "' + re.escape(key) + r'",.*?value: "([^"]+)"', rust, re.S)
        if len(matches) != 1:
            raise ValueError('stellar SI coordinate census')
        expected[key] = Fraction(matches[0])
    if set(floor['coordinates']) != set(expected) or any(Fraction(floor['coordinates'][k]) != v for k, v in expected.items()):
        raise ValueError('stellar coordinate substitution')
    species = profile['species']
    for reaction in profile['reactions']:
        if len(reaction['reactants']) != 2 or not reaction['fit_sets']:
            raise ValueError('two-body network structure')
        if sum(species[n]['A'] for n in reaction['reactants']) != sum(species[n]['A'] for n in reaction['products']):
            raise ValueError('reaction baryon balance')
        if any(len(row['coefficients']) != 7 for row in reaction['fit_sets']):
            raise ValueError('REACLIB coefficient census')
        delta = sum(species[n]['Z'] for n in reaction['products']) - sum(species[n]['Z'] for n in reaction['reactants'])
        if delta != (-1 if reaction['neutrino'] == 'allowed_pp' else 0):
            raise ValueError('nuclear charge and positron balance')
