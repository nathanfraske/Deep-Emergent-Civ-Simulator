"""Off-path primary-source comparisons, using direct Maxwell integration."""
from pathlib import Path
import json
import mpmath as mp


def compare(model, coefficients):
    facts=json.loads((Path(__file__).resolve().parents[2]/'sources/stellar_thermal/comparison.json').read_text(encoding='ascii'))
    result=[]
    with mp.workdps(70):
        c={k:mp.mpf(v) for k,v in model['floor']['coordinates'].items()}
        mu=c['m_e']*c['m_p_over_m_e']/2
        eg=2*mu*c['c']**2*(mp.pi*c['alpha'])**2
        unit_MeV=10**6*c['e']; s0=mp.mpf(facts['pp_S0_MeV_barn'])*unit_MeV*mp.mpf('1e-28')
        slope=mp.mpf(facts['pp_Sprime_over_S0_MeV_inverse'])/unit_MeV
        for temperature,rate in coefficients:
            kt=c['k_B']*mp.mpf(temperature)
            # Integrate a dimensionless Maxwell variable on a different scale.
            barrier=eg/kt
            def f(x):
                if x==0:return mp.mpf(0)
                return (1+slope*kt*x)*mp.exp(-x-mp.sqrt(barrier/x))
            integral=s0*kt*mp.quad(f,[0,1,4,8,16,32,64,128,mp.inf])
            reference=mp.sqrt(8/(mp.pi*mu))/kt**mp.mpf('1.5')*integral
            difference=mp.mpf(str(rate))/reference-1
            result.append({'temperature_K':temperature,'reaclib_m3_s':str(rate),
                           'linear_S_factor_m3_s':str(reference),'relative_difference':str(difference)})
    return {'comparison_only':True,'source_facts':facts,'pp_rates':result,
            'scope':'Nominal model sensitivity, not a measured error enclosure or stellar admission.'}
