"""Read immutable floor exports and source-bound effective reaction facts."""
from pathlib import Path
from decimal import Decimal
import hashlib, json

ROOT = Path(__file__).resolve().parents[2]


def normalized(path):
    raw = path.read_bytes().replace(b'\r\n', b'\n')
    if b'\r' in raw:
        raise ValueError('bare carriage return in source')
    return raw


def load(floor_path):
    floor = json.loads(floor_path.read_text(encoding='ascii'))
    path = ROOT / 'sources/stellar_thermal/ppi.json'
    raw = normalized(path)
    profile = json.loads(raw)
    from . import source_watchdog
    source_watchdog.check(ROOT, floor, profile, raw)
    return {'constants': {key: Decimal(value) for key, value in floor['coordinates'].items()},
            'floor': floor, 'profile': profile,
            'profile_sha256': hashlib.sha256(raw).hexdigest()}


def validate(model):
    from . import source_watchdog
    raw=normalized(ROOT/'sources/stellar_thermal/ppi.json')
    source_watchdog.check(ROOT,model['floor'],model['profile'],raw)
    if model['profile']!=json.loads(raw) or model['profile_sha256']!=hashlib.sha256(raw).hexdigest():
        raise ValueError('in-memory reaction source substitution')
    if model['constants']!={k:Decimal(v) for k,v in model['floor']['coordinates'].items()}:
        raise ValueError('in-memory stellar coordinate substitution')
