"""Independent SI and reaction-extent checker, using mpmath at 90 digits.

Never imports a producer, its EOS, rate evaluation, quadrature or decision helpers.
"""
from collections import Counter
from fractions import Fraction
import mpmath as mp


def m(value):
    if isinstance(value,Fraction):
        return mp.mpf(value.numerator)/value.denominator
    return mp.mpf(str(value))


def close(a,b,tolerance=mp.mpf('1e-48')):
    if abs(m(a)-b)>tolerance*max(abs(b),mp.mpf('1e-120')):
        raise ValueError('stellar watchdog numerical discrepancy')


def constants(model):
    return {k:m(v) for k,v in model['floor']['coordinates'].items()}


def rate(model,reaction,temperature):
    t=m(temperature)/10**9
    value=mp.mpf(0)
    for row in reaction['fit_sets']:
        a=list(map(m,row['coefficients']))
        # Different term construction, including direct fractional powers.
        log=a[0]+a[6]*mp.log(t)+a[1]/t+a[2]*mp.power(t,-mp.mpf(1)/3)+a[3]*mp.power(t,mp.mpf(1)/3)+a[4]*t+a[5]*mp.power(t,mp.mpf(5)/3)
        value+=mp.exp(log)
    return value/(10**6*constants(model)['N_A'])


def neutrino(model):
    with mp.workdps(90):
        c=constants(model); electron=c['m_e']*c['c']**2
        row=next(r for r in model['profile']['reactions'] if r['neutrino']=='allowed_pp')
        q=m(row['q_MeV'])*10**6*c['e']-2*electron
        # Direct kinetic energy integration, no x-squared substitution or Simpson.
        def spectrum(t):
            if t==0 or t==q:return mp.mpf(0)
            total=t+electron; pc=mp.sqrt(t*(t+2*electron))
            eta=2*mp.pi*c['alpha']*total/pc
            return pc*total*(q-t)**2*eta/mp.expm1(eta)
        points=[q*i/8 for i in range(9)]
        norm=mp.quad(spectrum,points)
        mean=mp.quad(lambda t:(q-t)*spectrum(t),points)/norm
        close(model['neutrino']['mean_J'],mean,mp.mpf('2e-11'))
        close(model['neutrino']['endpoint_J'],q)
        return str(mean)


def thermal(model,amounts,scale,density,energy,temperature):
    with mp.workdps(90):
        c=constants(model); rho=m(density); t=m(temperature)
        if not 10**7<=t<=2*10**7 or rho<=0:
            raise ValueError('stellar watchdog thermal domain')
        if set(amounts)!=set(model['profile']['species']) or any(type(n) is not int or n<0 for n in amounts.values()):
            raise ValueError('stellar watchdog nuclear census')
        if sum(model['profile']['species'][k]['A']*v for k,v in amounts.items())!=scale:
            raise ValueError('stellar watchdog baryon balance')
        particles=mp.mpf(sum((1+model['profile']['species'][k]['Z'])*v for k,v in amounts.items()))/scale
        nb=rho/(c['m_e']*(1+c['m_p_over_m_e']))
        rad=8*mp.pi**5*c['k_B']**4/(15*c['h']**3*c['c']**3)
        close(energy,3*particles*c['k_B']*t/2+rad*t**4/nb)
        ne=nb*sum(model['profile']['species'][k]['Z']*v for k,v in amounts.items())/scale
        degeneracy=ne*(c['h']**2/(2*mp.pi*c['m_e']*c['k_B']*t))**mp.mpf('1.5')/2
        ni=nb*sum(amounts.values())/scale
        z=max(model['profile']['species'][k]['Z'] for k,v in amounts.items() if v)
        gamma=z**2*c['alpha']*c['h']*c['c']/(2*mp.pi)*(4*mp.pi*ni/3)**(mp.mpf(1)/3)/(c['k_B']*t)
        if degeneracy>mp.mpf('0.1') or gamma>mp.mpf('0.1'):
            raise ValueError('stellar watchdog nonideal domain')


def step(model,old,new,records,density,dt,scale,enabled):
    with mp.workdps(90):
        reactions=model['profile']['reactions']
        if records['method']!='coupled_ppi_backward_euler.v1' or len(records['extent_q'])!=3:
            raise ValueError('stellar watchdog implicit method')
        current=dict(old['amounts']);energy=old['energy'];released=old['released'];escaped=old['escaped']
        c=constants(model); nb=m(density)/(c['m_e']*(1+c['m_p_over_m_e']))
        rates=[rate(model,r,records['temperature']) for r in reactions]
        if len(records['coefficients'])!=3:raise ValueError('implicit rate census')
        for computed,expected in zip(records['coefficients'],rates):close(computed,expected)
        # Independently solve the three backward Euler extents by a scalar
        # bracket. Different coordinates and no analytic Newton derivative.
        initial={k:mp.mpf(v)/scale for k,v in old['amounts'].items()}
        tau=[k*nb*m(dt) for k in rates]
        def ext(p):
            e1=tau[0]*p*p/2
            D=(initial['d']+e1)/(1+tau[1]*p)
            e2=initial['d']+e1-D
            available=initial['he3']+e2
            H=2*available/(1+mp.sqrt(1+4*tau[2]*available))
            return (e1,e2,(available-H)/2),p-initial['p']+2*e1+H-initial['he3']
        lo=mp.mpf(0);hi=initial['p']+initial['he3']
        for _ in range(300):
            p=(lo+hi)/2;xs,residual=ext(p)
            if residual<0:lo=p
            else:hi=p
        expected=ext((lo+hi)/2)[0] if enabled else (mp.mpf(0),)*3
        for i,(r,extent,real) in enumerate(zip(reactions,records['extent_q'],expected)):
            error=abs(extent-real*scale)
            if type(extent)is not int or extent<0 or error>mp.mpf('1.000000000001'):
                raise ValueError('stellar watchdog coupled extent residual')
            if not enabled and extent:raise ValueError('disabled nuclear reaction extent')
            for k,n in Counter(r['reactants']).items():current[k]-=n*extent
            for k,n in Counter(r['products']).items():current[k]+=n*extent
            q=Fraction(r['q_MeV'])*10**6*Fraction(model['floor']['coordinates']['e'])*Fraction(extent,scale)
            nu=Fraction(model['neutrino']['mean_J'])*Fraction(extent,scale) if r['neutrino']=='allowed_pp' else Fraction(0)
            energy+=q-nu;released+=q;escaped+=nu
        if new!={'amounts':current,'energy':energy,'released':released,'escaped':escaped}:
            raise ValueError('stellar watchdog terminal state')
        if new['energy']-old['energy'] != (new['released']-old['released'])-(new['escaped']-old['escaped']):
            raise ValueError('stellar watchdog exact energy ledger')
        if records['released']!=released-old['released'] or records['escaped']!=escaped-old['escaped']:
            raise ValueError('stellar watchdog step energy transfer')
        thermal(model,current,scale,density,energy,records['temperature'])
