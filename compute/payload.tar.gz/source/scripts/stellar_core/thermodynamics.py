"""Caloric ideal ions/electrons and trapped photons; never barotropic heat."""
from decimal import Decimal
from fractions import Fraction
from .arithmetic import decimal


def derived(constants, pi):
    mp = constants['m_e'] * constants['m_p_over_m_e']
    reduced = mp * constants['m_e'] / (mp + constants['m_e'])
    return {'m_p': mp, 'baryon_mass': mp + constants['m_e'],
            'chi_H_J': constants['alpha']**2 * reduced * constants['c']**2 / 2,
            'radiation_a': 8*pi**5 * constants['k_B']**4 / (15*constants['h']**3*constants['c']**3),
            'coulomb_J_m': constants['alpha']*constants['h']*constants['c']/(2*pi)}


def particle_count(profile, amounts, scale):
    # An electron is retained for each unit of nuclear charge.
    return Fraction(sum((1+profile['species'][name]['Z'])*count for name, count in amounts.items()), scale)


def fields(model, amounts, scale, density, temperature, pi):
    if not Decimal('1e7') <= temperature <= Decimal('2e7') or density <= 0:
        raise ValueError('hot PP-I prototype domain: 1e7<=T<=2e7 K, rho>0')
    if set(amounts) != set(model['profile']['species']) or any(type(n) is not int or n < 0 for n in amounts.values()):
        raise ValueError('nuclear census domain')
    if sum(model['profile']['species'][name]['A']*count for name, count in amounts.items()) != scale:
        raise ValueError('exact baryon census')
    c = model['constants']; d = derived(c, pi)
    nb = density / d['baryon_mass']
    count = decimal(particle_count(model['profile'], amounts, scale))
    ne = nb * Decimal(sum(model['profile']['species'][name]['Z']*n for name,n in amounts.items())) / scale
    ni = nb * Decimal(sum(amounts.values())) / scale
    wavelength = c['h'] / (2*pi*c['m_e']*c['k_B']*temperature).sqrt()
    degeneracy = ne*wavelength**3/2
    ion_radius = (3/(4*pi*ni)).ln().__truediv__(3).exp()
    # Maximum nuclear charge gives a conservative classical Coulomb screen.
    maxz = max(model['profile']['species'][name]['Z'] for name,n in amounts.items() if n)
    coupling = maxz**2*d['coulomb_J_m']/(ion_radius*c['k_B']*temperature)
    if degeneracy > Decimal('0.1') or coupling > Decimal('0.1'):
        raise ValueError('nonideal or degenerate hot parcel; unsupported EOS')
    u = Decimal('1.5')*count*c['k_B']*temperature + d['radiation_a']*temperature**4/nb
    pressure = count*nb*c['k_B']*temperature + d['radiation_a']*temperature**4/3
    return {'u_J_baryon': u, 'pressure_Pa': pressure, 'n_b_m3': nb,
            'degeneracy': degeneracy, 'coupling': coupling}


def temperature(model, amounts, scale, density, energy, pi, precision):
    c=model['constants']; d=derived(c,pi)
    capacity=Decimal('1.5')*decimal(particle_count(model['profile'], amounts, scale))*c['k_B']
    radiation=d['radiation_a']*d['baryon_mass']/density
    target=decimal(energy)
    if target <= 0 or capacity <= 0:
        raise ValueError('nonpositive thermal storage')
    lo=Decimal(0); hi=target/capacity
    for _ in range(4*precision):
        mid=(lo+hi)/2
        if capacity*mid+radiation*mid**4 < target: lo=mid
        else: hi=mid
        if hi-lo <= max(Decimal(1),mid)*Decimal(10)**(8-precision): break
    result=(lo+hi)/2
    fields(model,amounts,scale,density,result,pi)
    return result


def atomic_hydrogen(constants, density, temperature, pi):
    """Ground-state Saha diagnostic, not a molecular-cloud initialization."""
    if density <= 0 or temperature < Decimal('1e4'):
        raise ValueError('atomic LTE diagnostic requires rho>0, T>=1e4 K')
    d=derived(constants,pi); k=constants['k_B']
    n=density/d['baryon_mass']
    saha=(2*pi*constants['m_e']*k*temperature/constants['h']**2)**Decimal('1.5')*(-d['chi_H_J']/(k*temperature)).exp()/n
    x=2/(1+(1+4/saha).sqrt())
    u=Decimal('1.5')*(1+x)*k*temperature+x*d['chi_H_J']+d['radiation_a']*temperature**4/n
    return {'ion_fraction':x,'u_J_nucleus':u,
            'pressure_Pa':(1+x)*n*k*temperature+d['radiation_a']*temperature**4/3}
