"""High precision elementary operations and exact rational storage."""
from decimal import Decimal, localcontext, ROUND_HALF_EVEN
from fractions import Fraction


def decimal(value):
    if isinstance(value, Fraction):
        return Decimal(value.numerator) / Decimal(value.denominator)
    return Decimal(value)


def pi(precision):
    # Machin identity; independent checker uses mpmath's own Pi.
    with localcontext() as context:
        context.prec = precision + 12
        def atan_inverse(n):
            x = Decimal(1) / n
            term = x
            total = term
            k = 1
            while abs(term) > Decimal(10) ** (-context.prec):
                term *= -x*x
                total += term / (2*k+1)
                k += 1
            return total
        result = 16*atan_inverse(5) - 4*atan_inverse(239)
        context.prec = precision
        return +result


def quantize(value, scale):
    return int((value*scale).to_integral_value(rounding=ROUND_HALF_EVEN))


def text(value):
    value = Fraction(value)
    return f'{value.numerator}/{value.denominator}'
