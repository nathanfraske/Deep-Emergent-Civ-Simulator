"""Source-bound PP-I rates and neutrino phase space."""
from decimal import Decimal
from fractions import Fraction


def rate(reaction, constants, temperature):
    if not Decimal('1e7') <= temperature <= Decimal('2e7'):
        raise ValueError('REACLIB hot prototype fit domain')
    t=temperature/Decimal('1e9'); root=t**(Decimal(1)/3)
    vector=[Decimal(1),1/t,1/root,root,t,t*root**2,t.ln()]
    molar=sum(sum(Decimal(a)*b for a,b in zip(row['coefficients'],vector)).exp()
              for row in reaction['fit_sets'])
    return molar*Decimal('1e-6')/constants['N_A']


def neutrino(model, pi, nodes=2048):
    """Allowed positron phase space, Coulomb repulsion, zero incident energy.

    The named approximation omits thermal endpoint shifts and nuclear corrections.
    It is not a sourced solar mean-energy constant.
    """
    c=model['constants']
    weak=[r for r in model['profile']['reactions'] if r['neutrino']=='allowed_pp']
    if len(weak)!=1 or nodes%2 or nodes < 32:
        raise ValueError('pp neutrino quadrature contract')
    rest=c['m_e']*c['c']**2
    endpoint=Decimal(weak[0]['q_MeV'])*Decimal('1e6')*c['e']-2*rest
    if endpoint <= 0:
        raise ValueError('positron endpoint')
    norm=Decimal(0); moment=Decimal(0)
    for i in range(1,nodes):
        x=Decimal(i)/nodes
        kinetic=endpoint*x*x; total=kinetic+rest
        pc=(kinetic*(kinetic+2*rest)).sqrt()
        eta=2*pi*c['alpha']*total/pc
        expminus=(-eta).exp()
        fermi=eta*expminus/(1-expminus)
        energy=endpoint-kinetic
        weight=pc*total*energy**2*fermi*2*endpoint*x
        multiplier=4 if i%2 else 2
        norm+=multiplier*weight; moment+=multiplier*weight*energy
    return {'mean_J':moment/norm,'endpoint_J':endpoint,'nodes':nodes,
            'closure':'allowed_zero_incident_energy_pp.v1'}


def advance(model, old, density, dt, scale, pi, precision, enabled=True):
    from . import implicit
    return implicit.advance(model,old,density,dt,scale,pi,precision,enabled)
