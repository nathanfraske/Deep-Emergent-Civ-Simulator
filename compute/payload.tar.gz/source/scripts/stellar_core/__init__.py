"""Experimental caloric and nuclear components. No stellar birth authority."""
