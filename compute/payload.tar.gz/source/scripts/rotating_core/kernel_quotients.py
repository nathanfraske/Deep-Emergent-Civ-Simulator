"""Exact common-denominator evaluation of the existing ring quadrature."""
from functools import lru_cache
from math import lcm,isqrt
from arithmetic import rounded


@lru_cache(maxsize=16)
def quadrature(nodes):
    even=2*nodes;terms=[(even*even+odd*odd,even*even-odd*odd) for odd in range(1,even,2)]
    common=lcm(*(d*d for d,c in terms))
    values=tuple((d,c,even*even*(common//d),even*even*(common//(d*d))) for d,c in terms)
    return values,2*sum(w for d,c,w,v in values)


def row(scale,ri,rj,z,epsilon,nodes):
    quantum=lcm(ri.denominator,rj.denominator,z.denominator,epsilon.denominator)
    a,b,h,e=(q.numerator*(quantum//q.denominator) for q in (ri,rj,z,epsilon))
    terms,weight=quadrature(nodes);base=a*a+b*b+h*h+e*e
    potential=radial=axial=0;root_numerator=scale*scale*quantum*quantum
    for denominator,cosine,w,v in terms:
        for sign in (1,-1):
            distance=base*denominator-sign*2*a*b*cosine
            numerator=root_numerator*denominator
            ceiling=(numerator+distance-1)//distance;q=isqrt(ceiling)
            if q*q!=ceiling:q+=1
            cube=q*q*q;potential+=q*w
            radial+=cube*v*(a*denominator-sign*b*cosine)
            axial+=cube*w*h
    divisor=scale*scale*quantum*weight
    return [rounded(potential,weight),rounded(radial,divisor),rounded(axial,divisor)]
