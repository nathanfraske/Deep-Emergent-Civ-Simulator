"""Exact cylindrical overlap integrals with conservative integer allocations."""
from fractions import Fraction as F
from arithmetic import qfraction


def diagnostics(old,new,cells,projected):
    mass=sum(row[0] for row in cells);density_error=F(0);angular_error=F(0)
    for source,y in enumerate(cells):
        si,sj=source%old['nr'],source//old['nr'];sl,sh=old['rf'][si:si+2];sb,st=old['zf'][sj:sj+2]
        sv=(sh**2-sl**2)*(st-sb)/2;sj4=(sh**4-sl**4)*(st-sb)/4
        for target,v in enumerate(projected):
            ti,tj=target%new['nr'],target//new['nr'];tl,th=new['rf'][ti:ti+2];tb,tt=new['zf'][tj:tj+2]
            lo,hi=max(sl,tl),min(sh,th);bottom,top=max(sb,tb),min(st,tt)
            if lo>=hi or bottom>=top:continue
            nv=(th**2-tl**2)*(tt-tb)/2;nj4=(th**4-tl**4)*(tt-tb)/4
            density_error+=(hi**2-lo**2)*(top-bottom)/2*abs(F(y[0],1)/sv-F(v[0],1)/nv)
            angular_error+=(hi**4-lo**4)*(top-bottom)/4*abs(F(y[3],1)/sj4-F(v[3],1)/nj4)
    def moments(x,rows):
        radial=F(0);axial=F(0);rotation=F(0)
        for k,y in enumerate(rows):
            i,j=k%x['nr'],k//x['nr'];rl,rh=x['rf'][i:i+2];zl,zh=x['zf'][j:j+2];r2=(rl*rl+rh*rh)/2
            radial+=y[0]*r2;axial+=y[0]*(zl*zl+zl*zh+zh*zh)/3;rotation+=F(y[3]**2,y[0])/r2
        return dict(radial_second_moment=radial/mass,axial_second_moment=axial/mass,rotational_quadratic=rotation/mass)
    angular=sum(abs(row[3]) for row in cells)
    return dict(density_l1_mass_fraction=density_error/mass,
                angular_profile_l1_fraction=angular_error/angular if angular else F(0),
                before=moments(old,cells),after=moments(new,projected))


def transfer(old,new,cells):
    projected=[[0,0,0,0] for _ in new['volume']];transfers=[]
    for source,y in enumerate(cells):
        si,sj=source%old['nr'],source//old['nr'];rl,rh=old['rf'][si:si+2];zl,zh=old['zf'][sj:sj+2]
        previous=[0,0,0,0];cumulative=[F(0),F(0)]
        for target in range(len(projected)):
            ti,tj=target%new['nr'],target//new['nr'];a,b=new['rf'][ti:ti+2];c,d=new['zf'][tj:tj+2]
            lo,hi=max(rl,a),min(rh,b);bottom,top=max(zl,c),min(zh,d)
            if lo>=hi or bottom>=top:continue
            cumulative[0]+=(hi**2-lo**2)*(top-bottom)/((rh**2-rl**2)*(zh-zl))
            cumulative[1]+=(hi**4-lo**4)*(top-bottom)/((rh**4-rl**4)*(zh-zl))
            current=[qfraction(y[k]*cumulative[k==3],1) for k in range(4)]
            amount=[a-b for a,b in zip(current,previous)];previous=current
            transfers.append([source,target,*amount])
            for k in range(4):projected[target][k]+=amount[k]
        if cumulative!=[F(1),F(1)] or previous!=y:raise ValueError('remap incomplete source coverage')
    if any(row[0]<=0 for row in projected):raise ValueError('remap below positive mass quantum')
    before=[sum(row[k] for row in cells) for k in range(4)];after=[sum(row[k] for row in projected) for k in range(4)]
    if before!=after:raise ValueError('remap global account defect')
    return dict(schema='civsim.rotating-barotropic.remap.v1',transfers=transfers,next=projected,
                before_totals=before,after_totals=after,diagnostics=diagnostics(old,new,cells,projected))
