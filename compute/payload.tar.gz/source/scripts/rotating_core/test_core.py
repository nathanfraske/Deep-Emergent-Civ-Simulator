"""Physical component benchmarks, mutation controls and trajectory symmetries."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(1,str(ROOT/'scripts/radial_core'))
from fractions import Fraction as F
import copy,json,tempfile,unittest
from scripts.rotating_core import inputs,input_watchdog,mesh,mesh_watchdog,eos,eos_watchdog
from scripts.rotating_core import gravity,gravity_watchdog,transport,transport_watchdog,observe,observe_watchdog,model,run
from arithmetic import qfraction,ceil_sqrt
import pi_pair

STATE=(ROOT/'examples/rotating-core/cloud.state').read_text(encoding='ascii')
CFG=(ROOT/'examples/rotating-core/collapse.numerics').read_text(encoding='ascii')
SMALL=CFG.replace('radial_cells=8','radial_cells=4').replace('vertical_cells=16','vertical_cells=8').replace('max_steps=8192','max_steps=8').replace('sample_every=32','sample_every=4')


class RotatingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scratch=tempfile.TemporaryDirectory(prefix='civsim-rotating-test-')
        floor=Path(cls.scratch.name)/'floor.json'
        # Arithmetic/source fixtures only. Runnable examples acquire the native floor.
        floor.write_text(json.dumps(dict(schema='civsim.radial-core.floor.v1',G='6.67430e-11',floor_digest='e0cfd4a60342488054ddfa936599794e1697c0bd0997122c22e58047cde0aeb5')),encoding='ascii')
        cls.model=model.load(floor);cls.state=inputs.state(STATE);cls.cfg=inputs.numerics(SMALL)
        cls.x=mesh.build(cls.state,cls.cfg,cls.model['pressure'],pi_pair.value(96))
        cls.cells=mesh.project(cls.x,cls.state,cls.model['pressure']);cls.rows=gravity.kernel(cls.x,1)
        cls.matrix=gravity.matrices(cls.x,cls.rows);cls.fields=eos.fields(cls.x,cls.cells);cls.force=gravity.field(cls.x,cls.cells,cls.matrix)

    @classmethod
    def tearDownClass(cls):cls.scratch.cleanup()

    def test_closed_input_and_model_cannot_insert_stars_or_override_pressure(self):
        for bad in [STATE+'requested_stars=1\n',STATE+'mass_kg=1\n',STATE.replace('declared_hypothesis','observed'),STATE.replace('mass_kg=2e30','mass_kg=-1')]:
            with self.assertRaises(ValueError):inputs.state(bad)
            with self.assertRaises(ValueError):input_watchdog.check(bad,self.state,'state')
        for bad in [SMALL+'planet_count=3\n',SMALL.replace('fraction_bits=96','fraction_bits=56'),SMALL.replace('courant_fraction=0.2','courant_fraction=0.5')]:
            with self.assertRaises(ValueError):inputs.numerics(bad)
            with self.assertRaises(ValueError):input_watchdog.check(bad,self.cfg,'numerics')
        for key,value in [('G',F(1)),('sound_speed_m_s',F(300)),('density',[F('1e-9'),F('5.7e-5'),F(1)])]:
            forged=copy.deepcopy(self.model);forged['pressure'][key]=value
            with self.assertRaises(ValueError):run.solve(STATE,SMALL,forged,workers=1)
        forged=dict(self.model,model_id='desired_disk_v1')
        with self.assertRaises(ValueError):model.validate(forged)

    def test_dense_core_is_not_an_admissible_cloud_entry(self):
        dense=dict(self.state,radius_m=F('1e10'),half_height_m=F('1e10'))
        with self.assertRaises(ValueError):input_watchdog.physical(dense,self.cfg,self.model['pressure'],self.x['pi'])

    def test_floor_fact_substitution_cannot_keep_the_old_binding(self):
        import source_watchdog,tomllib
        with tempfile.TemporaryDirectory(prefix='civsim-factual-canary-') as d:
            root=Path(d);facts=root/'crates/units/data/codata_2018_floor_facts.tsv';facts.parent.mkdir(parents=True)
            raw=(ROOT/'crates/units/data/codata_2018_floor_facts.tsv').read_text(encoding='ascii')
            changed=[]
            for line in raw.splitlines():
                parts=line.split('\t')
                if line.startswith('row\tG\t'):parts[7]='1'
                changed.append('\t'.join(parts))
            facts.write_text('\n'.join(changed)+'\n',encoding='ascii')
            profile=tomllib.loads((ROOT/'sources/barotropic_core/bate98.toml').read_text(encoding='ascii'))
            forged=dict(self.model['pressure'],G=F(1))
            floor=dict(schema=forged['floor_schema'],G='1',floor_digest=forged['floor_binding'])
            with self.assertRaisesRegex(ValueError,'factual custody'):source_watchdog.check(root,profile,floor,forged)

    def test_mesh_moments_and_compression_reject_substitutions(self):
        mesh_watchdog.check(self.state,self.cfg,self.model['pressure'],self.x['pi'],self.x,self.cells)
        for key in ('volume','r','z','incidence','faces','gravity','time_unit'):
            bad=copy.deepcopy(self.x)
            if key=='incidence':bad[key][0][0]+=1
            elif key=='faces':bad[key][2]=(0,2,3,F(1))
            elif isinstance(bad[key],list):bad[key][0]+=1
            else:bad[key]+=1
            with self.assertRaises(ValueError):mesh_watchdog.check(self.state,self.cfg,self.model['pressure'],self.x['pi'],bad,self.cells)
        altered=copy.deepcopy(self.cells);altered[0][3]+=1
        with self.assertRaises(ValueError):mesh_watchdog.check(self.state,self.cfg,self.model['pressure'],self.x['pi'],self.x,altered)

    def test_four_source_pressure_regimes_and_power_cells(self):
        for density in ('1e-12','1e-7','0.01','10'):
            x=copy.deepcopy(self.x);x['rho_unit']=F(density)/(F(self.fields[0]['rho'],x['s']))
            fields=eos.fields(x,self.cells);eos_watchdog.check(x,self.cells,fields)
            for key in ('rho','p','cs2','cs','root'):
                bad=copy.deepcopy(fields)
                if key=='root':bad[0][key][1]+=4
                else:bad[0][key]+=4
                with self.assertRaises(ValueError):eos_watchdog.check(x,self.cells,bad)
        x=copy.deepcopy(self.x);x['prefactor']+=4
        with self.assertRaises(ValueError):eos_watchdog.check(x,self.cells,eos.fields(x,self.cells))

    def test_ring_gravity_axis_benchmark_and_force_substitutions(self):
        gravity_watchdog.kernel(self.x,self.rows,1);gravity_watchdog.field(self.x,self.cells,self.rows,self.force)
        for component in range(3):
            bad=copy.deepcopy(self.rows);bad[0][component]+=4
            with self.assertRaises(ValueError):gravity_watchdog.kernel(self.x,bad,1)
        altered=copy.deepcopy(self.force);altered[0][0]+=4
        with self.assertRaises(ValueError):gravity_watchdog.field(self.x,self.cells,self.rows,altered)
        x=copy.deepcopy(self.x);x['r'][0]=F(0);ns=len(x['separations']);j=x['nr']-1;k=ns-1
        row=gravity.kernel_row(x,j*ns+k);distance=x['r'][j]**2+x['separations'][k]**2+x['epsilon']**2
        target=F(x['s']**2)/distance
        inverse=ceil_sqrt(-(-target.numerator//target.denominator))
        self.assertEqual(row,[inverse,0,qfraction(F(inverse,x['s'])**3*x['separations'][k],x['s'])])

    def test_reflecting_zero_force_pressure_benchmark(self):
        # Component fixture, not a solver route that overrides admitted gravity.
        still=copy.deepcopy(self.cells)
        for y in still:y[3]=0
        zero=[[0,0] for y in still];fields=eos.fields(self.x,still)
        dt=qfraction(F(1,10000),self.x['s']);stage=transport.stage(self.x,still,fields,zero,dt)
        transport_watchdog.stage(self.x,still,fields,zero,dt,stage)
        self.assertEqual([y[0] for y in still],[y[0] for y in stage['next']])
        self.assertTrue(all(abs(y[1])<=2 and y[2]==y[3]==0 for y in stage['next']))

    def test_rigid_rotation_has_no_spurious_resting_torque_and_exact_volume_force(self):
        zero=[[0,0] for y in self.cells];s=self.x['s']
        dt=qfraction(F(1,10000),s)
        stage=transport.stage(self.x,self.cells,self.fields,zero,dt)
        transport_watchdog.stage(self.x,self.cells,self.fields,zero,dt,stage)
        self.assertTrue(all(impulse[0]==impulse[3]==0 for impulse in stage['transfers']))
        self.assertEqual([y[3] for y in self.cells],[y[3] for y in stage['next']])
        sources=transport.sources(self.x,self.cells,self.fields,zero)
        spin=self.state['angular_velocity_s_inv']*self.state['radius_m']/self.model['pressure']['sound_speed_m_s']
        for k,y in enumerate(self.cells):
            i=k%self.x['nr'];lo,hi=self.x['rf'][i:i+2]
            volume=self.x['volume'][k];r=self.x['r'][i]
            moment2=(lo*lo+hi*hi)/2
            radial_mean=(hi**3-lo**3)/3/((hi**2-lo**2)/2)
            ideal=self.fields[k]['p']*volume/r+y[0]*spin**2*radial_mean
            projection=F(1,2*y[0])/moment2
            uncertainty=y[0]*radial_mean*(2*abs(spin)*projection+projection**2)+F(1,2)
            self.assertLessEqual(abs(sources[k][0]-ideal),uncertainty)

    def test_every_stage_and_conserved_face_mutation(self):
        dt=transport.timestep(self.x,self.cells,self.fields,self.force)//4
        first=transport.stage(self.x,self.cells,self.fields,self.force,dt)
        transport_watchdog.stage(self.x,self.cells,self.fields,self.force,dt,first)
        fields=eos.fields(self.x,first['next']);force=gravity.field(self.x,first['next'],self.matrix)
        second=transport.stage(self.x,first['next'],fields,force,dt)
        transport_watchdog.stage(self.x,first['next'],fields,force,dt,second)
        accepted=transport.combine(self.x,self.cells,first,second)
        transport_watchdog.combine(self.x,self.cells,first,second,accepted)
        for key in ('transfers','sources','next'):
            bad=copy.deepcopy(first);bad[key][1][0]+=4
            with self.assertRaises(ValueError):transport_watchdog.stage(self.x,self.cells,self.fields,self.force,dt,bad)
        bad=copy.deepcopy(accepted);bad['next'][0][3]+=1
        with self.assertRaises(ValueError):transport_watchdog.combine(self.x,self.cells,first,second,bad)
        with self.assertRaises(ValueError):transport_watchdog.timestep(self.x,self.cells,self.fields,self.force,dt+1,dt,0)

    def test_integer_face_algebra_matches_unrounded_physical_fluxes(self):
        from scripts.rotating_core import flux
        import random
        rng=random.Random(4181)
        # Unequal non-dyadic volumes, signed moving states and both directions.
        for axis in (0,1):
            for _ in range(64):
                s=2**rng.choice((96,128,160))
                a=[rng.randrange(1,s),*[rng.randrange(-s,s) for k in range(3)]]
                b=[rng.randrange(1,s),*[rng.randrange(-s,s) for k in range(3)]]
                va=F(rng.randrange(1,100),rng.randrange(1,100));vb=F(rng.randrange(1,100),rng.randrange(1,100))
                area=F(rng.randrange(0,100),rng.randrange(1,100));dt=rng.randrange(1,s)
                fa=dict(p=rng.randrange(0,s),cs=s);fb=dict(p=rng.randrange(0,s),cs=2*s)
                alpha=transport.signal(s,a,b,fa,fb,axis)
                got=flux.impulses(s,a,b,fa,fb,va,vb,area,alpha,dt,axis)
                for k in range(3):
                    def physical(y,f,v):
                        value=F(y[axis+1],1)/v if k==0 else F(y[k]*y[axis+1],y[0])/v
                        return value+(f['p'] if k==axis+1 else 0)
                    value=F(dt,s)*area*(physical(a,fa,va)+physical(b,fb,vb)-F(alpha,s)*(F(b[k],1)/vb-F(a[k],1)/va))/2
                    mesh_watchdog.round_cell(got[k],value)

    def test_exact_rounding_cells_and_coordinate_cache_keys(self):
        for value in (F(-7,2),F(-5,2),F(-1,2),F(1,2),F(5,2),F(7,2),F(2**400+1,3)):
            q=qfraction(value,1);mesh_watchdog.round_cell(q,value)
            with self.assertRaises(ValueError):mesh_watchdog.round_cell(q+1,value)
            with self.assertRaises(ValueError):mesh_watchdog.round_cell(q-1,value)
        for lo,hi in ((F(0),F(1,64)),(F(1,7),F(2,7)),(F(1,5),F(3,4))):
            a,b=transport.radial_geometry(lo,hi)
            c,d=transport_watchdog.radial_integrals(lo,hi)
            self.assertEqual(a,c);self.assertEqual(b,d)
        self.assertNotEqual(transport.radial_geometry(F(0),F(1,64)),transport.radial_geometry(F(0),F(1,32)))

    def test_independent_flux_quotients_match_physical_fractions_and_ties(self):
        import random
        rng=random.Random(97831)
        for bits in (96,128,160):
            for axis in (0,1):
                for _ in range(32):
                    s=2**bits
                    a=[rng.randrange(1,s),*[rng.randrange(-s,s) for k in range(3)]]
                    b=[rng.randrange(1,s),*[rng.randrange(-s,s) for k in range(3)]]
                    va=F(rng.randrange(1,200),rng.randrange(1,200));vb=F(rng.randrange(1,200),rng.randrange(1,200))
                    area=F(rng.randrange(0,100),rng.randrange(1,100));dt=rng.randrange(1,s)
                    fa=dict(p=rng.randrange(0,s),cs=s);fb=dict(p=rng.randrange(0,s),cs=2*s)
                    speeds=[-(-F(abs(y[axis+1])*s,y[0]).numerator//F(abs(y[axis+1])*s,y[0]).denominator)+f['cs'] for y,f in ((a,fa),(b,fb))]
                    speed=F(max(speeds),s);weight=F(dt,s)*area/2
                    values=[weight*(F(a[axis+1],a[0])+speed)/va*a[k]+weight*(F(b[axis+1],b[0])-speed)/vb*b[k]
                            +(weight*(fa['p']+fb['p']) if k==axis+1 else 0) for k in range(3)]
                    reported=[round(q) for q in values]
                    transport_watchdog.flux_residual(s,a,b,fa,fb,va,vb,area,dt,axis,reported)
                    for k in range(3):
                        bad=reported.copy();bad[k]+=1
                        with self.assertRaises(ValueError):transport_watchdog.flux_residual(s,a,b,fa,fb,va,vb,area,dt,axis,bad)
        # Resting equal fields isolate signed half-cell pressure impulses.
        for pressure,correct in ((1,0),(3,2),(-1,0),(-3,-2)):
            fields=dict(p=pressure,cs=1);cell=[1,0,0,0]
            transport_watchdog.flux_residual(1,cell,cell,fields,fields,F(1),F(1),F(1,2),1,0,[0,correct,0])
            with self.assertRaises(ValueError):transport_watchdog.flux_residual(1,cell,cell,fields,fields,F(1),F(1),F(1,2),1,0,[0,correct+1,0])

    def test_bound_cache_cannot_accept_a_step_for_changed_inputs(self):
        dt=transport_watchdog.bounds(self.x,self.cells,self.fields,self.force)
        transport_watchdog.timestep(self.x,self.cells,self.fields,self.force,dt,dt,0)
        changed=copy.deepcopy(self.force);changed[0][0]=10**20*self.x['s']
        with self.assertRaises(ValueError):transport_watchdog.timestep(self.x,self.cells,self.fields,changed,dt,dt,0)
        acoustic=copy.deepcopy(self.fields)
        for f in acoustic:f['cs']*=10**6
        with self.assertRaises(ValueError):transport_watchdog.timestep(self.x,self.cells,acoustic,self.force,dt,dt,0)
        x=copy.deepcopy(self.x);x['cfl']/=10**6
        with self.assertRaises(ValueError):transport_watchdog.timestep(x,self.cells,self.fields,self.force,dt,dt,0)
        x=copy.deepcopy(self.x);x['faces']=[(a,l,r,area*10**6) for a,l,r,area in x['faces']]
        with self.assertRaises(ValueError):transport_watchdog.timestep(x,self.cells,self.fields,self.force,dt,dt,0)

    def test_observation_and_velocity_screens(self):
        observation=observe.measure(self.x,self.cells,self.fields,self.force,self.state,self.model['pressure'])
        observe_watchdog.check(self.x,self.cells,self.fields,self.force,self.state,self.model['pressure'],observation)
        for key,value in observation.items():
            bad=dict(observation);bad[key]=not value if isinstance(value,bool) else value+1
            with self.assertRaises(ValueError):observe_watchdog.check(self.x,self.cells,self.fields,self.force,self.state,self.model['pressure'],bad)

    def test_repeat_metadata_sampling_spin_and_precision_controls(self):
        cache=Path(self.scratch.name)/'kernel.json'
        base=run.solve(STATE,SMALL,self.model,kernel_cache=cache,workers=1)
        repeat=run.solve(STATE,SMALL,self.model,kernel_cache=cache,workers=1)
        self.assertEqual(base,repeat)
        renamed=STATE.replace('Declared cold rotating cylinder; source-bound pressure, no inserted central object.','Metadata observer')
        observed=run.solve(renamed,SMALL.replace('sample_every=4','sample_every=2'),self.model,kernel_cache=cache,workers=1)
        self.assertEqual(base['physical_identity'],observed['physical_identity']);self.assertEqual(base['trace_sha256'],observed['trace_sha256'])
        reverse=run.solve(STATE.replace('angular_velocity_s_inv=2e-13','angular_velocity_s_inv=-2e-13'),SMALL,self.model,kernel_cache=cache,workers=1)
        for one,two in zip(base['frames'][-1]['cell_q'],reverse['frames'][-1]['cell_q']):self.assertEqual(one[:3]+[-one[3]],two)
        for row in (base,reverse):
            self.assertEqual(row['initial_observation']['total_mass_kg'],row['final_observation']['total_mass_kg'])
            self.assertEqual(row['initial_observation']['angular_momentum_kg_m2_s'],row['final_observation']['angular_momentum_kg_m2_s'])
        higher=run.solve(STATE,SMALL.replace('fraction_bits=96','fraction_bits=128'),self.model,workers=1)
        for one,two in zip(base['frames'][-1]['cell_q'],higher['frames'][-1]['cell_q']):
            for a,b in zip(one,two):self.assertLess(abs(F(a,2**96)-F(b,2**128)),F(1,10**24))


def load_tests(loader,tests,pattern):
    from scripts.rotating_core import test_adapt,test_budget,test_checkpoint,test_refine,test_leaf,test_gravity_exact,test_deferred,test_selective_checkpoint,test_softening,test_open,test_finite,test_disk_observe,test_disk_case,test_finite_checkpoint
    for module in (test_adapt,test_budget,test_checkpoint,test_refine,test_leaf,test_gravity_exact,test_deferred,test_selective_checkpoint,test_softening,test_open,test_finite,test_disk_observe,test_disk_case,test_finite_checkpoint):
        tests.addTests(loader.loadTestsFromModule(module))
    return tests


if __name__=='__main__':unittest.main()
