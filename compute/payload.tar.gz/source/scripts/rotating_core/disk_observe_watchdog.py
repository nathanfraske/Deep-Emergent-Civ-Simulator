"""Independent per-cell incident-face and polynomial-moment observation checks."""
from fractions import Fraction as F
from .leaf_mesh_watchdog import bounds
from .input_watchdog import demand


def check(x,cells,fields,force,state,pressure,edges,density_floor,got):
    demand(isinstance(edges,(tuple,list)) and 2<=len(edges)<=65 and all(type(v) is F for v in edges)
           and edges[0]==0 and edges[-1]==1 and all(0<=edges[i]<edges[i+1]<=1 for i in range(len(edges)-1)),'disk observer partition')
    demand(type(density_floor) is F and density_floor>=0,'disk observer density cut')
    demand(set(got)=={'schema','density_floor_kg_m3','radial_edges','annuli','selected_mass_kg','formed_disk','completed_system','scope'},'disk observation inventory')
    demand(got['schema']=='civsim.rotating-disk.observation.v1' and type(got['density_floor_kg_m3']) is F
           and got['density_floor_kg_m3']==density_floor and type(got['radial_edges']) is list
           and all(type(v) is F for v in got['radial_edges']) and got['radial_edges']==list(edges),'disk observation binding')
    demand(got['formed_disk'] is False and got['completed_system'] is False and got['scope']=='Annular moments and cell-average force diagnostics of the supplied checked barotropic gas. Observer cuts, cell averaging, boundary, and continuum error remain. No disk or stellar classification.','diagnostic authority boundary')
    count=len(cells);demand(count==len(fields)==len(force)==len(x['volume']),'disk observer cell census')
    s=x['s'];R=state['radius_m'];M=state['mass_kg'];c0=pressure['sound_speed_m_s'];boxes=bounds(x)
    incident=[[] for _ in range(count)]
    for axis,left,right,area in x['faces']:
        if axis==0:
            if left>=0:incident[left].append((right if right>=0 else left,-area))
            if right>=0:incident[right].append((left if left>=0 else right,area))
    demand(len(got['annuli'])==len(edges)-1,'disk annulus census')
    expected_total=F(0)
    for index in range(len(edges)-1):
        lower,upper=edges[index:index+2]
        m=ell=r2=z2=kr=kz=kp=fc=fg=fp=F(0)
        for k in range(count):
            a,b,c,d=boxes[k];u=max(lower,a);v=min(upper,b)
            if v<=u or F(fields[k]['rho'],s)*x['rho_unit']<density_floor:continue
            # Independent integrals over a disjoint annular intersection.
            full=(b-a)*(b+a)*(d-c)/2
            volume=(v-u)*(v+u)*(d-c)/2
            ir=(v-u)*(v*v+v*u+u*u)*(d-c)/3
            ir2=(v-u)*(v+u)*(v*v+u*u)*(d-c)/4
            iz2=(v-u)*(v+u)*(d-c)*(d*d+d*c+c*c)/6
            cell=cells[k];demand(all(type(n) is int for n in cell) and len(cell)==4 and cell[0]>0,'disk conserved storage')
            density=F(cell[0],s)/full;spin=2*F(cell[3],cell[0])/(b*b+a*a)
            local_m=density*volume;m+=local_m;ell+=density*spin*ir2
            r2+=density*ir2;z2+=density*iz2;kp+=density*spin*spin*ir2
            kr+=local_m*F(cell[1]*cell[1],cell[0]*cell[0]);kz+=local_m*F(cell[2]*cell[2],cell[0]*cell[0])
            fc+=density*spin*spin*ir;fg+=local_m*F(force[k][0],s)
            normal=F(fields[k]['p'],s)*full*2/(a+b)
            for other,area in incident[k]:normal+=area*F(fields[k]['p']+fields[other]['p'],2*s)
            fp+=normal*volume/full
        expected=dict(r_lo_m=lower*R,r_hi_m=upper*R,mass_kg=m*M,mass_fraction=m,angular_momentum_kg_m2_s=ell*M*R*c0,
            radial_second_moment_m2=r2*R*R/m if m else None,axial_second_moment_m2=z2*R*R/m if m else None,
            thickness_ratio_squared=z2/r2 if r2 else None,rotation_kinetic_2J=kp*M*c0*c0,radial_kinetic_2J=kr*M*c0*c0,
            axial_kinetic_2J=kz*M*c0*c0,radial_motion_to_rotation_squared=kr/kp if kp else None,
            axial_motion_to_rotation_squared=kz/kp if kp else None,centrifugal_force_N=fc*M*c0*c0/R,
            radial_gravity_force_N=fg*M*c0*c0/R,cell_average_pressure_force_N=fp*M*c0*c0/R,
            centrifugal_to_inward_gravity=fc/(-fg) if fg<0 else None,pressure_to_inward_gravity=fp/(-fg) if fg<0 else None,
            radial_support_to_inward_gravity=(fc+fp)/(-fg) if fg<0 else None)
        observed=got['annuli'][index];demand(set(observed)==set(expected),'disk annulus field inventory')
        for key,value in expected.items():
            demand(observed[key] is None if value is None else type(observed[key]) is F and observed[key]==value,'disk annulus '+key)
        expected_total+=m*M
    demand(type(got['selected_mass_kg']) is F and got['selected_mass_kg']==expected_total,'disk selected mass')
