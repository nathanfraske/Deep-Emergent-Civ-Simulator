"""Exact biased radix accumulation for the producer's leaf gravity matrix."""
from dataclasses import dataclass
from arithmetic import rounded


@dataclass(frozen=True)
class Matrix:
    radial:tuple
    axial:tuple
    columns:tuple
    width:int
    offset:int
    mass_bound:int

    def __iter__(self):return iter((self.radial,self.axial))
    def __getitem__(self,key):return (self.radial,self.axial)[key]

    def force(self,x,cells):
        masses=[row[0] for row in cells];total=sum(masses);n=len(self.radial)
        if len(masses)!=n or any(type(m) is not int or m<=0 for m in masses) or total>self.mass_bound:
            return None
        value=sum(m*column for m,column in zip(masses,self.columns))
        raw=value.to_bytes(2*n*self.width,'little');bias=total*self.offset;den=x['s']**2
        return [[rounded(-x['gravity']*(int.from_bytes(raw[(2*i+k)*self.width:(2*i+k+1)*self.width],'little')-bias),den)
                 for k in range(2)] for i in range(n)]


def prepare(radial,axial,mass_bound):
    radial=tuple(tuple(row) for row in radial);axial=tuple(tuple(row) for row in axial);n=len(radial)
    maximum=max(abs(k) for grid in (radial,axial) for row in grid for k in row)
    offset=1<<maximum.bit_length();width=(offset.bit_length()+mass_bound.bit_length()+7)//8
    # Every biased coefficient is below 2*offset; total positive mass bounds
    # every radix digit. No cross-digit carry can reach another output.
    columns=tuple(int.from_bytes(b''.join((grid[i][j]+offset).to_bytes(width,'little')
                    for i in range(n) for grid in (radial,axial)),'little') for j in range(n))
    return Matrix(radial,axial,columns,width,offset,mass_bound)
