"""Bounded dyadic tensor refinement driven by the current Jeans length."""
from fractions import Fraction as F
from . import mesh,remap


def plan(x,fields,state,model,cfg):
    radial=[0]*x['nr'];vertical=[0]*x['nz'];maximum=F(0)
    for k,f in enumerate(fields):
        i,j=k%x['nr'],k//x['nr']
        density=F(f['rho'],x['s'])*x['rho_unit']
        wavelength2=x['pi']*F(f['cs2'],x['s'])*model['sound_speed_m_s']**2/(model['G']*density)
        for axis,index,width in ((radial,i,x['rf'][i+1]-x['rf'][i]),(vertical,j,x['zf'][j+1]-x['zf'][j])):
            ratio=state['radius_m']**2*width**2/wavelength2;maximum=max(maximum,ratio)
            depth=0
            while ratio>cfg['refinement_target_squared']*4**depth and depth<=cfg['refinement_max_depth']:depth+=1
            axis[index]=max(axis[index],depth)
    wanted=sum(2**n for n in radial)*sum(2**n for n in vertical)
    if maximum<=cfg['refinement_trigger_squared']:
        return dict(schema='civsim.rotating-barotropic.refinement-plan.v1',status='unchanged',levels=None,new_faces=None,required_cells=len(fields),max_ratio_squared=maximum)
    levels=dict(r=radial,z=vertical)
    status='depth_limit' if max(radial+vertical)>cfg['refinement_max_depth'] else 'cell_limit' if wanted>cfg['refinement_max_cells'] or max(sum(2**n for n in a) for a in (radial,vertical))>128 else 'accepted'
    faces=None
    if status=='accepted':
        faces={axis:[lo+(hi-lo)*F(j,2**depth) for lo,hi,depth in zip(edges,edges[1:],levels[axis]) for j in range(2**depth)]+[edges[-1]] for axis,edges in (('r',x['rf']),('z',x['zf']))}
    return dict(schema='civsim.rotating-barotropic.refinement-plan.v1',status=status,levels=levels,new_faces=faces,required_cells=wanted,max_ratio_squared=maximum)


def transfer(x,cells,proposal):
    if proposal['status']!='accepted':return None,None
    new=mesh.rebuild(x,proposal['new_faces'])
    return new,remap.transfer(x,new,cells)


def within_budget(allocation,spent,cfg):
    values=allocation['diagnostics']
    return all(spent[key]+values[name]<=cfg[cap] for key,name,cap in (
        ('density','density_l1_mass_fraction','refinement_density_budget'),
        ('angular','angular_profile_l1_fraction','refinement_angular_budget')))
