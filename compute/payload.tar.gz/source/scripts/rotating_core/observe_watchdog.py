"""Independent finite-volume moments, diagnostic bounds and Newtonian screen."""
from fractions import Fraction as F
from .input_watchdog import demand
from .leaf_mesh_watchdog import bounds as cell_bounds


def screens(x,cells,fields,model):
    s=x['s'];sound=model['sound_speed_m_s']
    for k,((m,pr,pz,angular),(lo,hi,bottom,top)) in enumerate(zip(cells,cell_bounds(x))):
        square=(hi**4-lo**4)/(2*(hi**2-lo**2))
        demand(10000*sound**2*(pr*pr+pz*pz+F(angular*angular)*hi**2/square**2)<=299792458**2*m*m,'Newtonian fluid speed')
        demand(10000*sound**2*fields[k]['cs2']<=299792458**2*s,'Newtonian acoustic speed')


def check(x,cells,fields,force,state,model,got):
    screens(x,cells,fields,model)
    s=x['s'];expected_keys={'total_mass_kg','angular_momentum_kg_m2_s','peak_density_kg_m3','radial_second_moment_m2','axial_second_moment_m2','flattening_ratio_squared','inner_quarter_mass_fraction','rotational_virial_ratio','max_jeans_ratio_squared','jeans_width_screen','stiffened_cells'}
    demand(set(got)==expected_keys,'observation inventory')
    mr=mz=F(0);quarter=F(0);rotation=F(0);gravity=F(0);density=[];jeans=[]
    radius=state['radius_m'];sound=model['sound_speed_m_s']
    for k,(lo,hi,bottom,top) in enumerate(cell_bounds(x)):
            m,pr,pz,angular=cells[k]
            volume=x['volume'][k]
            radial_integral=(hi**4-lo**4)*(top-bottom)/4
            vertical_integral=(hi**2-lo**2)*(top**3-bottom**3)/6
            mr+=F(m,s)*radial_integral/volume;mz+=F(m,s)*vertical_integral/volume
            clipped_hi=min(hi,F(1,4));clipped_bottom=max(bottom,F(-1,4));clipped_top=min(top,F(1,4))
            if clipped_hi>lo and clipped_top>clipped_bottom:
                intersection=(clipped_hi-lo)*(clipped_hi+lo)*(clipped_top-clipped_bottom)/2
                quarter+=m*intersection/volume
            mean_square=(hi**4-lo**4)/(2*(hi**2-lo**2))
            rotation+=F(angular*angular,m*s)/mean_square
            gravity+=F(m,s)*F(-force[k][0],s)*(lo+hi)/2
            real=F(fields[k]['rho'],s)*state['mass_kg']/(2*x['pi']*radius**3);density.append(real)
            cell_width=radius*max(hi-lo,top-bottom)
            jeans.append(cell_width**2*model['G']*real/(x['pi']*sound**2*F(fields[k]['cs2'],s)))
    expected=dict(total_mass_kg=F(sum(y[0] for y in cells),s)*state['mass_kg'],
                  angular_momentum_kg_m2_s=F(sum(y[3] for y in cells),s)*state['mass_kg']*sound*radius,
                  peak_density_kg_m3=max(density),radial_second_moment_m2=radius**2*mr,axial_second_moment_m2=radius**2*mz,
                  flattening_ratio_squared=mz*2/mr,inner_quarter_mass_fraction=quarter/s,
                  rotational_virial_ratio=rotation/gravity if gravity>0 else None,
                  max_jeans_ratio_squared=max(jeans),jeans_width_screen=max(jeans)<=F(1,16),
                  stiffened_cells=len([f for f in fields if f['root'][0]!=0]))
    demand(expected==got,'observation reconstruction')
