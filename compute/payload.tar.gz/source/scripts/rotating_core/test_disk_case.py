"""Saved finite gas is measured read-only; rehashed force forgeries still refuse."""
from pathlib import Path
import copy,hashlib,json,sys,tempfile,unittest
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'scripts/radial_core')]
from arithmetic import canonical_json,digest
from scripts.rotating_core import disk_case,model,run
from scripts.rotating_core.test_core import SMALL
from scripts.rotating_core.test_finite import FINITE


class DiskCaseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scratch=tempfile.TemporaryDirectory(prefix='civsim-disk-case-');cls.folder=Path(cls.scratch.name)
        floor=cls.folder/'floor.json'
        # Source/arithmetic fixture only; runnable evidence obtains the native floor.
        floor.write_text(json.dumps(dict(schema='civsim.radial-core.floor.v1',G='6.67430e-11',floor_digest='e0cfd4a60342488054ddfa936599794e1697c0bd0997122c22e58047cde0aeb5')))
        (cls.folder/'state').write_text(FINITE);(cls.folder/'numerics').write_text(SMALL)
        cls.row=run.solve(FINITE,SMALL,model.load(floor,run.FINITE_MODEL_ID),kernel_cache=cls.folder/'kernel.json',workers=1)
        cls.row['implementations']=run.implementations()
        (cls.folder/'receipt.json').write_text(canonical_json(cls.row)+'\n')
        (cls.folder/'frames.jsonl').write_text(''.join(canonical_json(frame) for frame in cls.row['frames']))

    @classmethod
    def tearDownClass(cls):cls.scratch.cleanup()

    def test_saved_and_live_frame_observations_agree_without_mutating_gas(self):
        before={p.name:digest(p.read_bytes()) for p in self.folder.iterdir()}
        terminal,*_=disk_case.observe_case(self.folder);preview,*_=disk_case.observe_case(self.folder,True)
        self.assertEqual(terminal['readings'],preview['readings'])
        self.assertEqual(terminal['frame_sha256'],preview['frame_sha256'])
        self.assertFalse(terminal['formed_disk']);self.assertFalse(terminal['complete_causal_history_checked'])
        self.assertEqual(before,{p.name:digest(p.read_bytes()) for p in self.folder.iterdir()})
        journal=self.folder/'frames.jsonl';original=journal.read_bytes()
        try:
            journal.write_bytes(original+b'{"incomplete":')
            self.assertEqual(disk_case.observe_case(self.folder,True)[0]['readings'],preview['readings'])
        finally:journal.write_bytes(original)

    def test_binding_saved_eos_and_rehashed_kernel_corruptions_refuse(self):
        path=self.folder/'receipt.json';original=path.read_bytes()
        for field in ('implementations','rho_q','time_s'):
            forged=copy.deepcopy(self.row)
            if field=='implementations':forged[field]['scripts/rotating_core/run.py']='0'*64
            elif field=='rho_q':forged['frames'][-1][field][0]+=1
            else:forged['frames'][-1][field]='1/1'
            try:
                path.write_text(canonical_json(forged)+'\n')
                with self.assertRaises(ValueError):disk_case.observe_case(self.folder)
            finally:path.write_bytes(original)
        path=self.folder/'kernel.json';original=path.read_bytes();forged=json.loads(original)
        forged['rows'][0][0]+=2;forged['rows_sha256']=digest(canonical_json(forged['rows']).encode('ascii'))
        try:
            path.write_text(canonical_json(forged)+'\n')
            with self.assertRaises(ValueError):disk_case.observe_case(self.folder)
        finally:path.write_bytes(original)


if __name__=='__main__':unittest.main()
