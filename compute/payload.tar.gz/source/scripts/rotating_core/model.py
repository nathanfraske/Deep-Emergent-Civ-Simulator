"""A separately named spatial model, bound to held primary pressure/fluid laws."""
from pathlib import Path
import tomllib
from arithmetic import digest,normalized
from scripts.radial_core import source as pressure_source
from . import model_watchdog

ROOT=Path(__file__).resolve().parents[2]
PROFILE='sources/barotropic_core/rotating.toml'
OPEN_PROFILE='sources/barotropic_core/rotating-open.toml'
FINITE_PROFILE='sources/barotropic_core/rotating-finite.toml'


def load(floor_path,model_id='axisymmetric_bate1998_barotropic_v1'):
    if model_id not in ('axisymmetric_bate1998_barotropic_v1','axisymmetric_bate1998_barotropic_open_v1','axisymmetric_bate1998_barotropic_finite_cloud_v1'):raise ValueError('unsupported spatial model')
    profile=FINITE_PROFILE if model_id=='axisymmetric_bate1998_barotropic_finite_cloud_v1' else OPEN_PROFILE if model_id=='axisymmetric_bate1998_barotropic_open_v1' else PROFILE
    pressure=pressure_source.load(floor_path)
    record=tomllib.loads(normalized(ROOT/profile).decode('ascii'))
    keys=['pressure_profile','pressure_witness','fluid_witness','mesh_witness','numerical_flux_source','local_derivation']
    if profile in (OPEN_PROFILE,FINITE_PROFILE):keys+=['base_spatial_profile','boundary_source','boundary_license','boundary_derivation']
    value=dict(pressure=pressure,model_id=record['model_id'],scope=record['scope'],uncertainty=record['uncertainty'],
               provenance={path:digest(normalized(ROOT/path)) for path in [profile,*[record[k] for k in keys]]})
    validate(value)
    return value


def validate(value):
    pressure_source.validate(value['pressure'])
    model_watchdog.check(ROOT,value)
