"""Independent trial projection, first admissible move and budget accounting."""
from fractions import Fraction as F
from hashlib import sha256
from arithmetic import parse_rational
from .input_watchdog import demand
from . import adapt_watchdog,remap_watchdog

WITNESS='sources/barotropic_core/remap-budget-equations.txt'
PIN='c046a9e845baec36f6686079e7441e5eb0712512dda4cb354fb435fe4f5afb08'


def source(root):
    data=(root/WITNESS).read_bytes().replace(b'\r\n',b'\n')
    demand(b'\r' not in data and sha256(data).hexdigest()==PIN,'remap-budget witness custody')
    return {WITNESS:PIN}


def prediction(old,faces,cells):
    """Project independently with Fraction's exact half-even primitive."""
    nr,nz=old['nr'],old['nz'];r,z=faces['r'],faces['z']
    volume=[(r[i+1]-r[i])*(r[i+1]+r[i])*(z[j+1]-z[j])/2 for j in range(nz) for i in range(nr)]
    moment=[volume[j*nr+i]*(r[i+1]**2+r[i]**2)/2 for j in range(nz) for i in range(nr)]
    projected=[[0]*4 for _ in volume];overlaps=[]
    for si,values in enumerate(cells):
        i,j=si%nr,si//nr;rl,rh=old['rf'][i:i+2];zb,zt=old['zf'][j:j+2]
        source_volume=old['volume'][si];source_moment=source_volume*(rh*rh+rl*rl)/2
        cumulative=[F(0)]*2;previous=[0]*4
        for tj in range(nz):
            height=min(zt,z[tj+1])-max(zb,z[tj])
            if height<=0:continue
            for ti in range(nr):
                a,b=max(rl,r[ti]),min(rh,r[ti+1])
                if a>=b:continue
                target=tj*nr+ti;area=(b-a)*(b+a)*height/2;inertia=area*(a*a+b*b)/2
                cumulative[0]+=area;cumulative[1]+=inertia
                after=[round(values[k]*(cumulative[1]/source_moment if k==3 else cumulative[0]/source_volume)) for k in range(4)]
                for k in range(4):projected[target][k]+=after[k]-previous[k]
                previous=after;overlaps.append((si,target,area,inertia,source_volume,source_moment))
        demand(cumulative==[source_volume,source_moment] and previous==values,'trial full source account')
    demand(all(sum(y[k] for y in projected)==sum(y[k] for y in cells) for k in range(4)),'trial four-field account')
    if any(y[0]<=0 for y in projected):return projected,None
    errors=[F(0),F(0)]
    for si,ti,area,inertia,sv,sj in overlaps:
        errors[0]+=area*abs(F(cells[si][0],1)/sv-F(projected[ti][0],1)/volume[ti])
        errors[1]+=inertia*abs(F(cells[si][3],1)/sj-F(projected[ti][3],1)/moment[ti])
    angular=sum(abs(row[3]) for row in cells)
    return projected,(errors[0]/sum(row[0] for row in cells),errors[1]/angular if angular else F(0))


def check(old,cells,cfg,spent,got,allocation):
    demand(set(got)=={'schema','proposed_faces','spent_before','spent_after','trials','status','selected_backtrack','selected_faces'}
           and got['schema']=='civsim.rotating-barotropic.remesh-budget.v1','budget decision census')
    demand(set(spent)=={'density','angular'} and all(isinstance(v,(int,F)) and not isinstance(v,bool) and v>=0 for v in spent.values()),'budget ledger domain')
    caps=(cfg['remesh_density_budget'],cfg['remesh_angular_budget']);prior=(spent['density'],spent['angular'])
    demand(all(a<=b for a,b in zip(prior,caps)) and got['spent_before']==spent,'budget prior binding')
    proposed=got['proposed_faces'];adapt_watchdog.check(old,cells,cfg,proposed)
    demand(type(got['trials']) is list and len(got['trials'])<=cfg['remesh_backtracks']+1,'budget trial bound')
    if proposed=={'r':old['rf'],'z':old['zf']} or any(a==b for a,b in zip(prior,caps)):
        status='unchanged' if proposed=={'r':old['rf'],'z':old['zf']} else 'exhausted'
        demand(got['status']==status and not got['trials'] and got['selected_faces'] is None and got['selected_backtrack'] is None
               and got['spent_after']==spent and allocation is None,'budget inactive decision')
        return
    chosen=None;selected_faces=None;selected_rows=None;selected_errors=None
    for level,trial in enumerate(got['trials']):
        demand(set(trial)=={'backtrack','positive_mass','density_l1_mass_fraction','angular_profile_l1_fraction'}
               and type(trial['backtrack']) is int and trial['backtrack']==level,'budget ordered trial prefix')
        divisor=2**level
        faces={axis:[(a*(divisor-1)+b)/divisor for a,b in zip(edges,proposed[axis])]
               for axis,edges in (('r',old['rf']),('z',old['zf']))}
        predicted,errors=prediction(old,faces,cells)
        demand(type(trial['positive_mass']) is bool and trial['positive_mass']==(errors is not None),'trial mass admission')
        reported=(trial['density_l1_mass_fraction'],trial['angular_profile_l1_fraction'])
        if errors is not None:demand(all(isinstance(v,(int,F)) and not isinstance(v,bool) and v>=0 for v in reported),'exact trial-loss domain')
        demand(reported==(errors if errors is not None else (None,None)),'independent trial losses')
        if errors is not None and all(errors[k]<=caps[k]*cfg['remesh_event_fraction'] and prior[k]+errors[k]<=caps[k] for k in (0,1)):
            demand(chosen is None and level==len(got['trials'])-1,'first admissible budget move')
            chosen=level;selected_faces=faces;selected_rows=predicted;selected_errors=errors
    if chosen is None:
        demand(len(got['trials'])==cfg['remesh_backtracks']+1 and got['status']=='backtrack_limit'
               and got['selected_backtrack'] is None and got['selected_faces'] is None
               and got['spent_after']==spent and allocation is None,'complete bounded no-move decision')
    else:
        demand(got['status']=='accepted' and type(got['selected_backtrack']) is int and got['selected_backtrack']==chosen and got['selected_faces']==selected_faces
               and got['spent_after']==dict(density=prior[0]+selected_errors[0],angular=prior[1]+selected_errors[1]),'budget accepted binding')
        demand(allocation is not None and allocation['next']==selected_rows,'budget accepted field binding')
        context=dict(old,rf=selected_faces['r'],zf=selected_faces['z'])
        context['volume']=[(b*b-a*a)*(d-c)/2 for c,d in zip(context['zf'],context['zf'][1:]) for a,b in zip(context['rf'],context['rf'][1:])]
        remap_watchdog.check(old,context,cells,allocation)


def ledger(cfg,decisions,events,spent):
    """Reconstruct the complete serialized history, independently of live sums."""
    demand(len(decisions)<=cfg['remesh_max_events'],'complete decision capacity')
    observed=dict(density=F(0),angular=F(0));position=0;last_clock=0
    for index,record in enumerate(decisions):
        demand(type(record['step']) is int and record['step']==(index+1)*cfg['remesh_interval']
               and type(record['clock_q']) is int and record['clock_q']>last_clock,'decision time ordering')
        last_clock=record['clock_q'];decision=record['decision']
        before={k:parse_rational(v) for k,v in decision['spent_before'].items()}
        after={k:parse_rational(v) for k,v in decision['spent_after'].items()}
        demand(before==observed,'complete budget ancestry')
        if decision['status']=='accepted':
            demand(position<len(events),'missing accepted remap event');event=events[position];position+=1
            demand(type(event['decision_index']) is int and event['decision_index']==index
                   and event['step']==record['step'] and event['clock_q']==record['clock_q']
                   and event['old_cell_q']==record['old_cell_q'] and event['old_faces']==record['old_faces']
                   and event['new_faces']==decision['selected_faces'],'decision and applied remap binding')
            trial=decision['trials'][-1];values=event['allocation']['diagnostics']
            for key,name,cap in (('density','density_l1_mass_fraction',cfg['remesh_density_budget']),
                                 ('angular','angular_profile_l1_fraction',cfg['remesh_angular_budget'])):
                change=parse_rational(values[name]);demand(values[name]==trial[name] and 0<=change<=cap*cfg['remesh_event_fraction'],'applied event loss bound')
                observed[key]+=change;demand(observed[key]<=cap,'complete cumulative budget bound')
        else:demand(decision['status'] in ('unchanged','exhausted','backtrack_limit'),'declined decision status')
        demand(after==observed,'complete budget recurrence')
    demand(position==len(events) and observed==spent,'complete accepted event and final budget census')
    return observed
