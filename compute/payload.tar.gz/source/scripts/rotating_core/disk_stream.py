"""Paired annular measurements from already checked live force contexts."""
from pathlib import Path
from fractions import Fraction as F
from types import MappingProxyType
import hashlib, json
from . import disk_observe, disk_observe_watchdog
from .leaf_mesh import bounds


def immutable_context(x,cells,fields,force,state,pressure):
    """Small observer view excludes the large gravity/operator caches."""
    view=MappingProxyType(dict(s=x['s'],rho_unit=x['rho_unit'],
        cell_bounds=tuple(tuple(b) for b in bounds(x)),
        volume=tuple(x['volume']),faces=tuple(tuple(f) for f in x['faces'])))
    return (view,tuple(tuple(v) for v in cells),
            tuple(MappingProxyType(dict(v)) for v in fields),tuple(tuple(v) for v in force),
            MappingProxyType(dict(state)),MappingProxyType(dict(pressure)))


class DiskJournal:
    def __init__(self,path):
        self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True)
        self.stream=self.path.open('x',encoding='ascii',newline='\n')
        self.initial_peak=None;self.frames=0
        root=Path(__file__).resolve().parents[2]
        paths=('scripts/rotating_core/disk_stream.py','scripts/rotating_core/disk_observe.py',
               'scripts/rotating_core/disk_observe_watchdog.py',
               'sources/barotropic_core/disk-observation-equations.txt')
        self.sources={p:hashlib.sha256((root/p).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for p in paths}

    def capture(self,frame,data,kernel_identity):
        from .run import encoded
        from arithmetic import canonical_json
        x,cells,fields,force,state,pressure=data
        if self.initial_peak is None:
            if frame['step']!=0 or frame['clock_q']!=0:
                raise ValueError('disk stream requires the declared original gas frame')
            self.initial_peak=max(F(v['rho'],x['s'])*x['rho_unit'] for v in fields)
        edges=[F(0)]+[F(1,2**p) for p in range(8,-1,-1)]
        readings=[]
        for multiplier in (0,10,100):
            cutoff=multiplier*self.initial_peak
            value=disk_observe.measure(*data,edges,cutoff)
            disk_observe_watchdog.check(*data,edges,cutoff,value)
            readings.append(dict(initial_peak_multiplier=multiplier,observation=value))
        value=dict(schema='civsim.rotating-disk.checked-frame.v1',step=frame['step'],time_s=frame['time_s'],
            frame_sha256=hashlib.sha256(canonical_json(frame).encode('ascii')).hexdigest(),
            trace_sha256=frame['trace_sha256'],kernel_sha256=kernel_identity,
            observer_sources=self.sources,readings=readings,
            independently_checked_annular_observations=True,
            complete_causal_history_checked=False,formed_disk=False,completed_system=False,
            scope='Read-only paired annular measurements reuse the producer checked geometry, EOS and full resolved gravity at this saved frame. No reconstruction, observer force, disk threshold or causal restart is introduced. Unsaved persistence, model physics and continuum or boundary convergence remain open.')
        self.stream.write(canonical_json(encoded(value)));self.stream.flush();self.frames+=1

    def close(self):
        self.stream.close()
