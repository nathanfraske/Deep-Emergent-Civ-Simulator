"""Checked live observations preserve scientific states and reject corruption."""
from pathlib import Path
import copy, json, tempfile, unittest
from unittest.mock import patch
from . import disk_stream, run, model, disk_observe
from .test_leaf import DILUTE, NUM


class DiskStreamTests(unittest.TestCase):
    def test_immutable_checked_view_and_stream_keep_complete_science_identical(self):
        with tempfile.TemporaryDirectory(prefix='civsim-live-disk-') as raw:
            folder=Path(raw);floor=folder/'floor.json'
            floor.write_text(json.dumps(dict(schema='civsim.radial-core.floor.v1',G='6.67430e-11',floor_digest='e0cfd4a60342488054ddfa936599794e1697c0bd0997122c22e58047cde0aeb5')))
            physical=model.load(floor);cache=folder/'kernel.json'
            plain=run.solve(DILUTE,NUM,physical,kernel_cache=cache,workers=1)
            journal=disk_stream.DiskJournal(folder/'disk.jsonl')
            def capture(frame,data,kernel):
                with self.assertRaises(TypeError):data[0]['s']=1
                with self.assertRaises(TypeError):data[1][0][0]=1
                with self.assertRaises(TypeError):data[2][0]['rho']=1
                self.assertNotIn('kernel_keys',data[0]);journal.capture(frame,data,kernel)
            try:observed=run.solve(DILUTE,NUM,physical,kernel_cache=cache,workers=1,on_measure=capture)
            finally:journal.close()
            self.assertEqual(plain,observed)
            rows=[json.loads(line) for line in journal.path.read_text().splitlines()]
            self.assertEqual(len(rows),len(observed['frames']))
            self.assertEqual(rows[-1]['trace_sha256'],observed['trace_sha256'])
            self.assertTrue(rows[-1]['independently_checked_annular_observations'])
            self.assertFalse(rows[-1]['formed_disk'])
            with self.assertRaises(FileExistsError):disk_stream.DiskJournal(journal.path)

    def test_bad_annular_measurement_never_releases_a_gas_frame(self):
        original=disk_observe.measure
        def corrupt(*args):
            result=original(*args);result['selected_mass_kg']+=1;return result
        with tempfile.TemporaryDirectory(prefix='civsim-live-disk-negative-') as raw:
            folder=Path(raw);floor=folder/'floor.json'
            floor.write_text(json.dumps(dict(schema='civsim.radial-core.floor.v1',G='6.67430e-11',floor_digest='e0cfd4a60342488054ddfa936599794e1697c0bd0997122c22e58047cde0aeb5')))
            journal=disk_stream.DiskJournal(folder/'disk.jsonl');released=[]
            try:
                with patch.object(disk_observe,'measure',corrupt),self.assertRaises(ValueError):
                    run.solve(DILUTE,NUM,model.load(floor),on_frame=released.append,workers=1,on_measure=journal.capture)
            finally:journal.close()
            self.assertEqual(released,[]);self.assertEqual(journal.path.read_text(),'')


if __name__=='__main__':unittest.main()
