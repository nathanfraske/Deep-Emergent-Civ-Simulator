"""Host work deadline: requests a stop only at a fully checked endpoint."""
import time


class Deadline:
    def __init__(self,seconds,clock=time.monotonic):
        if type(seconds) is not int or not 1<=seconds<=86400:
            raise ValueError('execution wall deadline domain')
        self.clock=clock
        self.end=clock()+seconds

    def __call__(self):
        return self.clock()>=self.end
