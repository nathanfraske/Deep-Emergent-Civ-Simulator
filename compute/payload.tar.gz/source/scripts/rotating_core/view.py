"""Read-only scientific plot; floating arithmetic never reaches the solver."""
from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'radial_core'))
from arithmetic import parse_rational as F


def plot(receipt,destination):
    import numpy as np
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.colors import LogNorm
    row=json.loads(receipt.read_text(encoding='ascii'))
    if row['schema'] not in ('civsim.rotating-barotropic.finite.run.v1','civsim.rotating-barotropic.open.run.v1','civsim.rotating-barotropic.run.v1','civsim.rotating-barotropic.run.v2','civsim.rotating-barotropic.run.v3','civsim.rotating-barotropic.run.v4','civsim.rotating-barotropic.run.v5','civsim.rotating-barotropic.run.v6','civsim.rotating-barotropic.run.v7','civsim.rotating-barotropic.run.v8','civsim.rotating-barotropic.run.v9','civsim.rotating-barotropic.run.v10') or not row['accepted']:raise ValueError('checked rotating receipt required')
    frames=row['frames'];last=frames[-1];state=row['state'];a=float(F(state['radius_m']));pi=float(F(row['pi']));s=row['scale']
    coordinates=last.get('coordinate_faces',row['coordinate_faces'])
    unit=float(F(state['mass_kg']))/(2*pi*a**3)
    rho=np.array(last['rho_q'],dtype=float)/float(s)*unit
    if 'cells' not in coordinates:
        nr=len(coordinates['r'])-1;nz=len(coordinates['z'])-1;rho=rho.reshape(nz,nr)
        r=np.array([float(F(q)) for q in coordinates['r']])*a/1e14
        z=np.array([float(F(q)) for q in coordinates['z']])*a/1e14
    times=[float(F(f['time_s']))/31557600/1000 for f in frames]
    flatten=[float(F(f['observation']['flattening_ratio_squared']))**.5 for f in frames]
    inner=[float(F(f['observation']['inner_quarter_mass_fraction'])) for f in frames]
    peaks=[float(F(f['observation']['peak_density_kg_m3'])) for f in frames]
    fig,axes=plt.subplots(1,3,figsize=(15,5),layout='constrained')
    axes[0].semilogy(times,peaks,color='#6531a8');axes[0].axhline(1e-10,color='#555555',ls='--',lw=1,label='First EOS transition')
    axes[0].set(xlabel='Elapsed time (thousand Julian years)',ylabel='Peak cell density (kg/m3)');axes[0].legend(fontsize=8)
    axes[1].plot(times,flatten,color='#168fa1',label='sqrt(2 <z2> / <R2>)')
    axes[1].plot(times,inner,color='#c95b29',label='Mass in inner quarter window')
    axes[1].set(xlabel='Elapsed time (thousand Julian years)',ylabel='Finite gas observations');axes[1].legend(fontsize=8)
    if 'cells' in coordinates:
        from matplotlib.collections import PolyCollection
        polygons=[];colors=[]
        for (lo,hi,bottom,top),density in zip(coordinates['cells'],rho):
            lo,hi,bottom,top=[float(F(q))*a/1e14 for q in (lo,hi,bottom,top)]
            for sign in (-1,1):
                polygons.append([(sign*lo,bottom),(sign*hi,bottom),(sign*hi,top),(sign*lo,top)]);colors.append(density)
        image=PolyCollection(polygons,array=np.array(colors),norm=LogNorm(vmin=rho.min(),vmax=rho.max()),cmap='magma',edgecolors='#ffffff20',linewidths=.1)
        axes[2].add_collection(image);axes[2].autoscale_view()
    else:
        mirror_r=np.concatenate((-r[:0:-1],r));mirror_rho=np.concatenate((rho[:,::-1],rho),axis=1)
        image=axes[2].pcolormesh(mirror_r,z,mirror_rho,norm=LogNorm(vmin=rho.min(),vmax=rho.max()),cmap='magma',shading='flat')
    axes[2].set(xlabel='Cylindrical radius section (1e14 m)',ylabel='Height (1e14 m)',title='Final gas density');axes[2].set_aspect('equal')
    fig.colorbar(image,ax=axes[2],label='kg/m3',shrink=.8)
    for ax in axes[:2]:ax.grid(alpha=.2)
    fig.suptitle('Rotating gas contraction: source-bound barotropic fluid, no inserted star')
    fig.text(.02,-.035,'Conditional reflecting cylinder. Finite softened mesh; no energy/radiation solve or formed-disk claim.',fontsize=9)
    fig.savefig(destination,dpi=160,bbox_inches='tight');plt.close(fig)


if __name__=='__main__':plot(Path(sys.argv[1]),Path(sys.argv[2]))
