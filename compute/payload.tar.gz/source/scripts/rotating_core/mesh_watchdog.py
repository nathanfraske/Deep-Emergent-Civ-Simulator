"""Independent integer-coordinate mesh, volume, face and initial-moment checks."""
from fractions import Fraction as F
from .input_watchdog import demand
from . import softening_watchdog


def round_cell(got,value):
    demand(type(got) is int,'integer projection')
    # Cross-multiply the exact cell inequality, with no rational allocation.
    error=2*abs(got*value.denominator-value.numerator)
    demand(error<value.denominator or (error==value.denominator and got%2==0),'round-half-even cell')


def check(state,cfg,model,pi,x,cells):
    nr,nz=cfg['radial_cells'],cfg['vertical_cells'];p=cfg['mesh_power'];s=2**cfg['fraction_bits'];beta=state['half_height_m']/state['radius_m']
    rf=[F(i**p,nr**p) for i in range(nr+1)]
    zf=[F((1 if 2*j>=nz else -1)*abs(2*j-nz)**p,nz**p)*beta for j in range(nz+1)]
    demand(x['s']==s and x['nr']==nr and x['nz']==nz and x['rf']==rf and x['zf']==zf,'coordinate inventory')
    centers_r=[rf[i]+(rf[i+1]-rf[i])/2 for i in range(nr)]
    centers_z=[zf[j]+(zf[j+1]-zf[j])/2 for j in range(nz)]
    demand(x['r']==centers_r and x['z']==centers_z and x['pi']==pi,'ring centers')
    volumes=[(rf[i+1]-rf[i])*(rf[i+1]+rf[i])*(zf[j+1]-zf[j])/2 for j in range(nz) for i in range(nr)]
    demand(x['volume']==volumes and sum(volumes)==beta,'volume census')
    expected=[]
    for j in range(nz):
        for i in range(nr+1):expected.append((0,j*nr+i-1 if i>0 else -1,j*nr+i if i<nr else -1,rf[i]*(zf[j+1]-zf[j])))
    for j in range(nz+1):
        for i in range(nr):expected.append((1,(j-1)*nr+i if j>0 else -1,j*nr+i if j<nz else -1,(rf[i+1]-rf[i])*(rf[i+1]+rf[i])/2))
    demand(x['faces']==expected,'face incidence and areas')
    distances=sorted(set(abs(a-b) for a in centers_z for b in centers_z))
    demand(x['separations']==distances,'distance coverage')
    demand(x['incidence']==[[distances.index(abs(a-b)) for b in centers_z] for a in centers_z],'distance incidence')
    demand(x['rho_unit']==state['mass_kg']/(2*pi*state['radius_m']**3),'density unit')
    demand(x['time_unit']==state['radius_m']/model['sound_speed_m_s'] and x['transition']==model['density'],'time and EOS units')
    round_cell(x['gravity'],model['G']*state['mass_kg']*s/(state['radius_m']*model['sound_speed_m_s']**2))
    demand(x['cfl']==cfg['courant_fraction'] and x['angles']==cfg['angular_nodes'],'numerical context')
    softening_watchdog.check(x,state,cfg,model)
    demand(len(cells)==nr*nz and all(len(v)==4 for v in cells) and sum(v[0] for v in cells)==s,'initial conserved census')
    tally=0;before=0
    for k,v in enumerate(volumes):
        tally+=v;after=before+cells[k][0]
        round_cell(after,tally*s/beta)
        demand(cells[k][0]>0 and cells[k][1:3]==[0,0],'initial cold bulk motion')
        i=k%nr
        moment=(rf[i+1]**4-rf[i]**4)/(2*(rf[i+1]**2-rf[i]**2))
        round_cell(cells[k][3],cells[k][0]*state['angular_velocity_s_inv']*state['radius_m']*moment/model['sound_speed_m_s'])
        before=after


def geometry(state,cfg,model,pi,x):
    """Derive the complete geometry from a separately checked adapted partition."""
    refining=cfg['schema']=='civsim.rotating-barotropic.numerics.v5'
    nr,nz=(len(x['rf'])-1,len(x['zf'])-1) if refining else (cfg['radial_cells'],cfg['vertical_cells'])
    s=2**cfg['fraction_bits'];beta=state['half_height_m']/state['radius_m']
    if refining:demand(1<=nr<=128 and 1<=nz<=128 and nr*nz<=cfg['refinement_max_cells'],'refined geometry capacity')
    r,z=x['rf'],x['zf']
    demand(x['nr']==nr and x['nz']==nz and x['s']==s and len(r)==nr+1 and len(z)==nz+1,'adapted dimensions')
    demand(all(isinstance(v,F) for v in [*r,*z]) and r[0]==0 and r[-1]==1 and z[0]==-beta and z[-1]==beta,'adapted coordinate domain')
    demand(all(b>a for edges in (r,z) for a,b in zip(edges,edges[1:])),'adapted positive widths')
    rc=[r[i]+(r[i+1]-r[i])/2 for i in range(nr)];zc=[z[j]+(z[j+1]-z[j])/2 for j in range(nz)]
    volumes=[(r[i+1]-r[i])*(r[i+1]+r[i])*(z[j+1]-z[j])/2 for j in range(nz) for i in range(nr)]
    demand(x['r']==rc and x['z']==zc and x['volume']==volumes and sum(volumes)==beta,'adapted centers and volume coverage')
    faces=[]
    for j in range(nz):
        for i in range(nr+1):faces.append((0,j*nr+i-1 if i>0 else -1,j*nr+i if i<nr else -1,r[i]*(z[j+1]-z[j])))
    for j in range(nz+1):
        for i in range(nr):faces.append((1,(j-1)*nr+i if j>0 else -1,j*nr+i if j<nz else -1,(r[i+1]-r[i])*(r[i+1]+r[i])/2))
    demand(x['faces']==faces,'adapted face inventory')
    distances=sorted(set(abs(a-b) for a in zc for b in zc))
    demand(x['separations']==distances and x['incidence']==[[distances.index(abs(a-b)) for b in zc] for a in zc],'adapted actual separation map')
    demand(x['pi']==pi and x['rho_unit']==state['mass_kg']/(2*pi*state['radius_m']**3),'adapted density unit')
    demand(x['time_unit']==state['radius_m']/model['sound_speed_m_s'] and x['transition']==model['density'],'adapted physical units')
    round_cell(x['gravity'],model['G']*state['mass_kg']*s/(state['radius_m']*model['sound_speed_m_s']**2))
    demand(x['cfl']==cfg['courant_fraction'] and x['angles']==cfg['angular_nodes'],'adapted numerical context')
    softening_watchdog.check(x,state,cfg,model)
