"""Decode four fluid fields with the shared source-bound scalar pressure law."""
from arithmetic import rounded
import constitutive


def fields(x,cells):
    s=x['s'];result=[]
    if len(cells)!=len(x['volume']):raise ValueError('fluid cell census')
    for k,y in enumerate(cells):
        if len(y)!=4 or any(type(q) is not int or abs(q).bit_length()>384 for q in y) or y[0]<=0:
            raise ValueError('positive fluid mass and bounded integer state required')
        v=x['volume'][k]
        density=rounded(y[0]*v.denominator,v.numerator)
        result.append(dict(rho=density,**constitutive.pressure(x,density)))
    return result
