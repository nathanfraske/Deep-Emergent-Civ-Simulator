"""Finite gas moments and resolution diagnostics, without a disk classifier."""
from fractions import Fraction as F
from .leaf_mesh import bounds as cell_bounds


def measure(x,cells,fields,force,state,model):
    s=x['s'];nr=x['nr'];radial=F(0);vertical=F(0);rotational=F(0);grav=F(0);central=F(0);jeans=F(0)
    for k,(y,(rl,rh,zl,zh)) in enumerate(zip(cells,cell_bounds(x))):
        radial+=F(y[0],s)*(rl*rl+rh*rh)/2
        vertical+=F(y[0],s)*(zl*zl+zl*zh+zh*zh)/3
        rotational+=F(y[3]**2,y[0]*s)/((rl**2+rh**2)/2)
        grav-=F(y[0]*force[k][0],s*s)*(rl+rh)/2
        rtop=min(rh,F(1,4));zbottom=max(zl,F(-1,4));ztop=min(zh,F(1,4))
        if rtop>rl and ztop>zbottom:
            central+=y[0]*(rtop**2-rl**2)*(ztop-zbottom)/((rh**2-rl**2)*(zh-zl))
        density=F(fields[k]['rho'],s)*x['rho_unit']
        width=max(rh-rl,zh-zl)*state['radius_m']
        wavelength2=x['pi']*F(fields[k]['cs2'],s)*model['sound_speed_m_s']**2/(model['G']*density)
        jeans=max(jeans,width*width/wavelength2)
    return dict(total_mass_kg=F(sum(y[0] for y in cells),s)*state['mass_kg'],
                angular_momentum_kg_m2_s=F(sum(y[3] for y in cells),s)*state['mass_kg']*state['radius_m']*model['sound_speed_m_s'],
                peak_density_kg_m3=max(F(f['rho'],s)*x['rho_unit'] for f in fields),
                radial_second_moment_m2=radial*state['radius_m']**2,
                axial_second_moment_m2=vertical*state['radius_m']**2,
                flattening_ratio_squared=2*vertical/radial,
                inner_quarter_mass_fraction=central/s,
                rotational_virial_ratio=rotational/grav if grav>0 else None,
                max_jeans_ratio_squared=jeans,jeans_width_screen=jeans<=F(1,16),
                stiffened_cells=sum(f['root'][0]>0 for f in fields))
