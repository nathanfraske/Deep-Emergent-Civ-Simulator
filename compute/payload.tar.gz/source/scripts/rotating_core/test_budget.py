"""Finite loss limits, first-choice falsifiers and unchanged gas controls."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(1,str(ROOT/'scripts/radial_core'))
from fractions import Fraction as F
import copy,json,tempfile,unittest
from arithmetic import qfraction,parse_rational
import pi_pair
from scripts.rotating_core import inputs,input_watchdog,mesh,model,run,remap_budget,remap_budget_watchdog

STATE=(ROOT/'examples/rotating-core/cloud.state').read_text(encoding='ascii')
NUM=(ROOT/'examples/rotating-core/budgeted.numerics').read_text(encoding='ascii')
SMALL=NUM.replace('radial_cells=8','radial_cells=4').replace('vertical_cells=16','vertical_cells=8').replace('max_steps=8192','max_steps=8').replace('sample_every=32','sample_every=4').replace('remesh_interval=256','remesh_interval=2').replace('remesh_max_events=16','remesh_max_events=3')


class BudgetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scratch=tempfile.TemporaryDirectory(prefix='civsim-budget-test-')
        floor=Path(cls.scratch.name)/'floor.json'
        floor.write_text(json.dumps(dict(schema='civsim.radial-core.floor.v1',G='6.67430e-11',floor_digest='e0cfd4a60342488054ddfa936599794e1697c0bd0997122c22e58047cde0aeb5')),encoding='ascii')
        cls.model=model.load(floor);cls.state=inputs.state(STATE);cls.cfg=inputs.numerics(SMALL)
        cls.x=mesh.build(cls.state,cls.cfg,cls.model['pressure'],pi_pair.value(96));cls.uniform=mesh.project(cls.x,cls.state,cls.model['pressure'])
        weights=[y[0]*(cls.x['nr']-i%cls.x['nr'])**4 for i,y in enumerate(cls.uniform)]
        total=sum(weights);cumulative=0;previous=0;cls.cells=[]
        for i,weight in enumerate(weights):
            cumulative+=weight;end=qfraction(F(cumulative,total),cls.x['s']);mass=end-previous;previous=end
            lo,hi=cls.x['rf'][i%cls.x['nr']:i%cls.x['nr']+2]
            angular=qfraction(F(mass)*F(7,10)*(lo*lo+hi*hi)/2,1)
            cls.cells.append([mass,qfraction(F(3*mass,7),1),qfraction(F(-2*mass,9),1),angular])

    @classmethod
    def tearDownClass(cls):cls.scratch.cleanup()

    def checked(self,cfg=None,spent=None,cells=None):
        cfg=cfg or self.cfg;spent=spent or dict(density=F(0),angular=F(0));cells=cells or self.cells
        decision,next_x,allocation=remap_budget.select(self.x,cells,cfg,spent)
        remap_budget_watchdog.check(self.x,cells,cfg,spent,decision,allocation)
        return decision,next_x,allocation

    def test_closed_input_and_resource_domain(self):
        parsed=inputs.numerics(SMALL);input_watchdog.check(SMALL,parsed,'numerics')
        for bad in (SMALL.replace('remesh_density_budget=0.02','remesh_density_budget=0'),
                    SMALL.replace('remesh_angular_budget=0.02','remesh_angular_budget=1.1'),
                    SMALL.replace('remesh_event_fraction=0.125','remesh_event_fraction=0'),
                    SMALL.replace('remesh_backtracks=12','remesh_backtracks=17'),
                    SMALL.replace('remesh_backtracks=12','remesh_backtracks=-1'),
                    SMALL.replace('remesh_density_budget=0.02\n',''),
                    SMALL+'remesh_density_budget=0.1\n',SMALL+'desired_star_mass=1\n'):
            with self.assertRaises(ValueError):inputs.numerics(bad)
            with self.assertRaises(ValueError):input_watchdog.check(bad,self.cfg,'numerics')

    def test_first_bounded_move_and_exact_signed_accounts(self):
        decision,next_x,allocation=self.checked()
        self.assertEqual(decision['status'],'accepted');self.assertGreater(decision['selected_backtrack'],0)
        self.assertEqual(len(decision['trials']),decision['selected_backtrack']+1)
        for k in range(4):self.assertEqual(sum(y[k] for y in self.cells),sum(y[k] for y in allocation['next']))
        for field,key in (('density','density_l1_mass_fraction'),('angular','angular_profile_l1_fraction')):
            self.assertLessEqual(allocation['diagnostics'][key],F(1,400))
            self.assertEqual(decision['spent_after'][field],allocation['diagnostics'][key])
        self.assertEqual(next_x['rf'],decision['selected_faces']['r'])

    def test_cumulative_remaining_budget_and_zero_move_paths(self):
        prior=dict(density=F(199,10000),angular=F(199,10000))
        limited,_,_=self.checked(spent=prior)
        self.assertEqual(limited['status'],'backtrack_limit');self.assertEqual(limited['spent_after'],prior)
        decision,_,allocation=self.checked(cfg=dict(self.cfg,remesh_backtracks=16),spent=prior)
        self.assertEqual(decision['status'],'accepted')
        self.assertTrue(all(v<=F(1,50) for v in decision['spent_after'].values()))
        exhausted,context,transfer=self.checked(spent=dict(density=F(1,50),angular=F(0)))
        self.assertEqual(exhausted['status'],'exhausted');self.assertIsNone(context);self.assertIsNone(transfer)
        unchanged,context,transfer=self.checked(cells=self.uniform)
        self.assertEqual(unchanged['status'],'unchanged');self.assertEqual(unchanged['trials'],[])
        self.assertIsNone(context);self.assertIsNone(transfer)
        declined,context,transfer=self.checked(cfg=dict(self.cfg,remesh_backtracks=0))
        self.assertEqual(declined['status'],'backtrack_limit');self.assertEqual(len(declined['trials']),1)
        self.assertIsNone(context);self.assertIsNone(transfer)

    def test_independent_balanced_loss_prefix_and_ledger_mutations(self):
        decision,_,allocation=self.checked();spent=dict(density=F(0),angular=F(0))
        mutations=[]
        bad=copy.deepcopy(decision);bad['trials'][0]['density_l1_mass_fraction']+=F(1,10**6);mutations.append(bad)
        bad=copy.deepcopy(decision);bad['trials'].pop(0);mutations.append(bad)
        bad=copy.deepcopy(decision);bad['selected_backtrack']-=1;mutations.append(bad)
        bad=copy.deepcopy(decision);bad['spent_after']['density']=0;mutations.append(bad)
        bad=copy.deepcopy(decision);bad['selected_faces']['r'][1]+=F(1,10**12);mutations.append(bad)
        bad=copy.deepcopy(decision);bad['status']='backtrack_limit';mutations.append(bad)
        for bad in mutations:
            with self.assertRaises(ValueError):remap_budget_watchdog.check(self.x,self.cells,self.cfg,spent,bad,allocation)
        bad=copy.deepcopy(allocation);bad['transfers'][0][2]+=1;bad['transfers'][1][2]-=1
        with self.assertRaises(ValueError):remap_budget_watchdog.check(self.x,self.cells,self.cfg,spent,decision,bad)

    def test_spin_reversal_and_zero_angular_field(self):
        decision,_,allocation=self.checked()
        negative=[y[:3]+[-y[3]] for y in self.cells];reverse,_,other=self.checked(cells=negative)
        self.assertEqual(decision,reverse)
        for a,b in zip(allocation['next'],other['next']):self.assertEqual(a[:3]+[-a[3]],b)
        zero=[y[:3]+[0] for y in self.cells];empty,_,_=self.checked(cells=zero)
        self.assertEqual(empty['spent_after']['angular'],0)
        self.assertTrue(all(t['angular_profile_l1_fraction']==0 for t in empty['trials']))

    def test_budget_source_witness_is_bound(self):
        remap_budget_watchdog.source(ROOT)
        with tempfile.TemporaryDirectory(prefix='civsim-budget-custody-') as directory:
            path=Path(directory)/remap_budget_watchdog.WITNESS;path.parent.mkdir(parents=True)
            path.write_bytes((ROOT/remap_budget_watchdog.WITNESS).read_bytes()+b'changed\n')
            with self.assertRaises(ValueError):remap_budget_watchdog.source(Path(directory))

    def test_real_gas_repeat_observer_and_exact_budget_ledger(self):
        one=run.solve(STATE,SMALL,self.model,workers=1)
        two=run.solve(STATE,SMALL,self.model,workers=1);self.assertEqual(one,two)
        observer=run.solve(STATE.replace('description=Declared','description=Observer Declared'),SMALL.replace('sample_every=4','sample_every=2'),self.model,workers=1)
        self.assertEqual(one['trace_sha256'],observer['trace_sha256']);self.assertEqual(one['physical_identity'],observer['physical_identity'])
        self.assertEqual(len(one['remesh_decisions']),3)
        for key in ('density','angular'):
            total=sum(parse_rational(e['allocation']['diagnostics']['density_l1_mass_fraction' if key=='density' else 'angular_profile_l1_fraction']) for e in one['remesh_events'])
            self.assertEqual(total,parse_rational(one['remesh_spent'][key]));self.assertLessEqual(total,F(1,50))
        self.assertFalse(one['completed_system']);self.assertFalse(one['disk_assessed'])

    def test_declined_moves_preserve_fixed_gas_and_bound_decision_count(self):
        tight=SMALL.replace('remesh_density_budget=0.02','remesh_density_budget=1e-30').replace('remesh_angular_budget=0.02','remesh_angular_budget=1e-30').replace('remesh_backtracks=12','remesh_backtracks=0')
        kept=run.solve(STATE,tight,self.model,workers=1)
        cfg=inputs.numerics(tight)
        fixed='\n'.join(line for line in tight.splitlines() if line.partition('=')[0] not in inputs.ADAPT_KEYS|inputs.BUDGET_KEYS)+'\n'
        fixed=fixed.replace('numerics.v4','numerics.v2');reference=run.solve(STATE,fixed,self.model,workers=1)
        self.assertEqual(kept['remesh_events'],[]);self.assertEqual(len(kept['remesh_decisions']),3)
        for a,b in zip(kept['frames'],reference['frames']):
            for key in ('step','clock_q','time_s','cell_q','rho_q','pressure_q','observation'):self.assertEqual(a[key],b[key])
        self.assertEqual({k:parse_rational(v) for k,v in kept['remesh_spent'].items()},dict(density=0,angular=0))

    def test_complete_history_reset_omission_and_event_binding_refuse(self):
        result=run.solve(STATE,SMALL,self.model,workers=1)
        decisions=result['remesh_decisions'];events=result['remesh_events']
        spent={k:parse_rational(v) for k,v in result['remesh_spent'].items()}
        self.assertEqual(remap_budget_watchdog.ledger(self.cfg,decisions,events,spent),spent)
        bad=copy.deepcopy(decisions);bad[1]['decision']['spent_before']=dict(density='0/1',angular='0/1')
        with self.assertRaises(ValueError):remap_budget_watchdog.ledger(self.cfg,bad,events,spent)
        with self.assertRaises(ValueError):remap_budget_watchdog.ledger(self.cfg,decisions[1:],events,spent)
        bad=copy.deepcopy(events);bad[0]['decision_index']=1
        with self.assertRaises(ValueError):remap_budget_watchdog.ledger(self.cfg,decisions,bad,spent)
        with self.assertRaises(ValueError):remap_budget_watchdog.ledger(self.cfg,decisions,events,dict(density=F(0),angular=F(0)))


if __name__=='__main__':unittest.main()
