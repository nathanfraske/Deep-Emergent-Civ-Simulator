"""Independent local Jeans depths, descendant coverage and complete ledgers."""
from fractions import Fraction as F
from hashlib import sha256
from arithmetic import parse_rational
from .input_watchdog import demand
from .mesh_watchdog import round_cell
from .leaf_mesh_watchdog import bounds

WITNESS='sources/barotropic_core/selective-equations.txt'
PIN='c61465163d63d1034779e11947911ce2f78750b21958a261729898022ecc0273'


def source(root):
    raw=(root/WITNESS).read_bytes().replace(b'\r\n',b'\n')
    demand(b'\r' not in raw and sha256(raw).hexdigest()==PIN,'selective refinement witness custody')
    return {WITNESS:PIN}


def ratios(x,fields,state,model):
    result=[]
    for box,row in zip(bounds(x),fields):
        a,b,c,d=box
        real=F(row['rho'],x['s'])*state['mass_kg']/(2*x['pi']*state['radius_m']**3)
        denominator=x['pi']*model['sound_speed_m_s']**2*F(row['cs2'],x['s'])
        demand(real>0 and denominator>0,'positive selective state')
        result.append(tuple(model['G']*real*state['radius_m']**2*w*w/denominator for w in (b-a,d-c)))
    demand(len(result)==len(fields)==len(x['volume']),'selective diagnostic census')
    return result


def screen(x,fields,state,model):
    demand(all(16*q<=1 for pair in ratios(x,fields,state,model) for q in pair),'unresolved Jeans width')


def plan(x,fields,state,model,cfg,got):
    demand(set(got)=={'schema','status','levels','new_faces','required_cells','max_ratio_squared'} and got['schema']=='civsim.rotating-barotropic.refinement-plan.v2','selective plan inventory')
    pairs=ratios(x,fields,state,model);maximum=max(q for pair in pairs for q in pair)
    demand(isinstance(got['max_ratio_squared'],F) and got['max_ratio_squared']==maximum,'selective diagnostic binding')
    if maximum<=cfg['refinement_trigger_squared']:
        demand(got['status']=='unchanged' and got['levels'] is None and got['new_faces'] is None and type(got['required_cells']) is int and got['required_cells']==len(fields),'unchanged selective plan');return
    levels=got['levels'];demand(len(levels)==len(fields),'per-parent level census')
    for pair,names in zip(pairs,levels):
        demand(len(names)==2 and all(type(v) is int and 0<=v<=cfg['refinement_max_depth']+1 for v in names),'bounded cell split depths')
        for ratio,depth in zip(pair,names):
            target=cfg['refinement_target_squared']*2**(2*depth)
            demand(ratio<=target or depth==cfg['refinement_max_depth']+1,'sufficient cell depth')
            demand(depth==0 or ratio>target/4,'minimal cell depth')
    wanted=sum((1<<dr)*(1<<dz) for dr,dz in levels)
    demand(type(got['required_cells']) is int and got['required_cells']==wanted,'selective child census')
    status='depth_limit' if any(v>cfg['refinement_max_depth'] for pair in levels for v in pair) else 'cell_limit' if wanted>cfg['refinement_max_cells'] else 'accepted'
    demand(got['status']==status,'independent selective capacity')
    if status!='accepted':demand(got['new_faces'] is None,'no refused child geometry');return
    faces=got['new_faces'];demand(type(faces) is dict and set(faces)=={'cells'},'leaf coordinate inventory')
    boxes=faces['cells'];demand(len(boxes)==wanted,'complete descendant census');position=0
    for (lo,hi,bottom,top),(dr,dz) in zip(bounds(x),levels):
        nr,nz=1<<dr,1<<dz
        for j in range(nz):
            for i in range(nr):
                a,b,c,d=boxes[position];position+=1
                demand(all(isinstance(v,F) for v in (a,b,c,d)),'exact child coordinates')
                demand(nr*(a-lo)==i*(hi-lo) and nr*(b-lo)==(i+1)*(hi-lo),'nested radial descendants')
                demand(nz*(c-bottom)==j*(top-bottom) and nz*(d-bottom)==(j+1)*(top-bottom),'nested axial descendants')


def allocation(old,new,cells,got,spent,cfg):
    demand(set(got)=={'schema','transfers','next','before_totals','after_totals','diagnostics'} and got['schema']=='civsim.rotating-barotropic.remap.v2','selective allocation inventory')
    boxes=bounds(old);targets=bounds(new);rows=got['next'];transfers=got['transfers']
    demand(len(rows)==len(targets)==len(transfers) and all(len(y)==4 and all(type(v) is int for v in y) and y[0]>0 for y in rows),'selective field census')
    covered=[F(0)]*len(cells);moments=[F(0)]*len(cells);running=[[0]*4 for _ in cells];density_error=angular_error=F(0);last=-1
    for target,((a,b,c,d),reported,row) in enumerate(zip(targets,transfers,rows)):
        demand(len(reported)==6 and all(type(v) is int for v in reported),'descendant integer transfer')
        source,index,*amount=reported
        demand(0<=source<len(cells) and source>=last and index==target and amount==row,'ordered unique descendant transfer');last=source
        lo,hi,bottom,top=boxes[source]
        demand(lo<=a<b<=hi and bottom<=c<d<=top,'child lies in source')
        v=(b-a)*(b+a)*(d-c)/2;inertia=v*(a*a+b*b)/2;parent_v=old['volume'][source];parent_j=parent_v*(lo*lo+hi*hi)/2
        covered[source]+=v;moments[source]+=inertia
        for k in range(4):
            running[source][k]+=amount[k]
            round_cell(running[source][k],cells[source][k]*(moments[source]/parent_j if k==3 else covered[source]/parent_v))
        density_error+=v*abs(cells[source][0]/parent_v-row[0]/v)
        angular_error+=inertia*abs(cells[source][3]/parent_j-row[3]/inertia)
    for k,((lo,hi,bottom,top),y) in enumerate(zip(boxes,cells)):
        demand(covered[k]==old['volume'][k] and moments[k]==old['volume'][k]*(lo*lo+hi*hi)/2 and running[k]==y,'complete parent measures and four accounts')
    before=[sum(y[k] for y in cells) for k in range(4)];after=[sum(y[k] for y in rows) for k in range(4)]
    demand(got['before_totals']==before==after==got['after_totals'],'all four selective global accounts')
    angular=sum(abs(y[3]) for y in cells)
    expected=dict(density_l1_mass_fraction=density_error/before[0],angular_profile_l1_fraction=angular_error/angular if angular else F(0))
    for name,context,values in (('before',old,cells),('after',new,rows)):
        sums=[F(0)]*3
        for (lo,hi,bottom,top),y in zip(bounds(context),values):
            v=(hi-lo)*(hi+lo)*(top-bottom)/2;r_integral=(hi**4-lo**4)*(top-bottom)/4;z_integral=(hi*hi-lo*lo)*(top**3-bottom**3)/6
            sums[0]+=y[0]*r_integral/v;sums[1]+=y[0]*z_integral/v;sums[2]+=F(y[3]**2,y[0])*v/r_integral
        expected[name]=dict(radial_second_moment=sums[0]/before[0],axial_second_moment=sums[1]/before[0],rotational_quadratic=sums[2]/before[0])
    demand(got['diagnostics']==expected,'selective representation loss')
    demand(set(spent)=={'density','angular'} and all(isinstance(v,F) and v>=0 for v in spent.values()),'selective prior budget')
    next_spent={k:spent[k]+expected[name] for k,name in (('density','density_l1_mass_fraction'),('angular','angular_profile_l1_fraction'))}
    return all(next_spent[k]<=cfg['refinement_'+k+'_budget'] for k in next_spent),next_spent


def ledger(cfg,decisions,events,spent,steps,pair_steps):
    demand(len(events)<=cfg['refinement_max_events'] and len(decisions)<=cfg['refinement_max_events']+1,'selective event capacity')
    before=dict(density=F(0),angular=F(0));position=0;last=-1;cells=cfg['radial_cells']*cfg['vertical_cells'];work=0;cut=0
    for record in decisions:
        step=record['step'];demand(type(step) is int and last<step<=steps,'selective decision ordering');last=step
        demand({k:parse_rational(v) for k,v in record['spent_before'].items()}==before,'selective budget ancestry')
        if record['status']=='accepted':
            demand(position<len(events),'missing selective event');event=events[position];position+=1
            demand(event['decision_index']==position-1 and event['step']==step and event['clock_q']==record['clock_q'] and event['old_faces']==record['old_faces'] and event['old_cell_q']==record['old_cell_q'] and event['new_faces']==record['plan']['new_faces'],'selective event ancestry')
            demand(len(event['old_cell_q'])==cells,'selective parent dimension ancestry')
            work+=(step-cut)*cells*cells;cut=step;cells=len(event['new_faces']['cells'])
            demand(cells==record['plan']['required_cells'] and len(event['allocation']['next'])==cells<=cfg['refinement_max_cells'],'selective applied census')
            for k,name in (('density','density_l1_mass_fraction'),('angular','angular_profile_l1_fraction')):
                loss=parse_rational(event['allocation']['diagnostics'][name]);demand(loss>=0,'nonnegative selective loss');before[k]+=loss
        else:demand(record['status'] in ('cell_limit','depth_limit','event_limit','loss_limit') and record is decisions[-1],'terminal selective refusal')
        demand({k:parse_rational(v) for k,v in record['spent_after'].items()}==before and all(before[k]<=cfg['refinement_'+k+'_budget'] for k in before),'selective cumulative loss')
    work+=(steps-cut)*cells*cells
    demand(position==len(events) and before==spent,'complete selective event and loss ledger')
    demand(type(pair_steps) is int and pair_steps==work<=cfg['max_pair_steps'],'complete selective pair-work ledger')
