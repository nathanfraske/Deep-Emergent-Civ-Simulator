"""Exact integer evaluation of the three rounded Rusanov face impulses.

This only clears rational denominators before the existing rounding point.
The independent transport watchdog retains the physical-flux formulation.
See docs/working/ROTATING_EXACT_ACCELERATION.md for the algebraic identity.
"""
from arithmetic import rounded


def impulses(s,a,b,fa,fb,va,vb,area,alpha,dt,axis):
    ma,mb=a[0],b[0]
    left=s*a[axis+1]+alpha*ma
    right=s*b[axis+1]-alpha*mb
    vl,vr=va.numerator,vb.numerator
    left*=va.denominator*vr
    right*=vb.denominator*vl
    factor=dt*area.numerator
    denominator=2*s*s*area.denominator*vl*vr
    mass=rounded(factor*(left+right),denominator)
    pressure=s*(fa['p']+fb['p'])*ma*mb*vl*vr
    momentum=[]
    for k in (1,2):
        numerator=a[k]*left*mb+b[k]*right*ma
        if k==axis+1:numerator+=pressure
        momentum.append(rounded(factor*numerator,denominator*ma*mb))
    return [mass,*momentum]
