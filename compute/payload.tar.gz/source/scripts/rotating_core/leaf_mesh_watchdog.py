"""Independent cover, swept face patches and actual ring-pair inventory."""
from fractions import Fraction as F
from .input_watchdog import demand
from . import softening_watchdog
from .mesh_watchdog import round_cell
from .eos_watchdog import coefficients


def bounds(x):
    if 'cell_bounds' in x:return x['cell_bounds']
    return [(x['rf'][k%x['nr']],x['rf'][k%x['nr']+1],
             x['zf'][k//x['nr']],x['zf'][k//x['nr']+1]) for k in range(len(x['volume']))]


def geometry(state,cfg,model,pi,x):
    boxes=x['cell_bounds'];beta=state['half_height_m']/state['radius_m'];s=2**cfg['fraction_bits']
    demand(0<len(boxes)<=cfg['refinement_max_cells'] and x['s']==s,'leaf geometry capacity')
    volume=[];rc=[];zc=[]
    for box in boxes:
        demand(len(box)==4 and all(isinstance(v,F) for v in box),'exact rectangle storage')
        a,b,c,d=box;demand(0<=a<b<=1 and -beta<=c<d<=beta,'leaf domain and positive width')
        volume.append((b-a)*(b+a)*(d-c)/2);rc.append(a+(b-a)/2);zc.append(c+(d-c)/2)
    # Disjoint interiors plus exact total measure establish full domain cover.
    for j in range(len(boxes)):
        for i in range(j):
            a,b,c,d=boxes[i];e,f,g,h=boxes[j]
            demand(min(b,f)<=max(a,e) or min(d,h)<=max(c,g),'nonoverlapping leaf interiors')
    demand(sum(volume)==beta and x['volume']==volume,'complete cylindrical volume cover')
    demand(x['cell_r']==rc and x['cell_z']==zc and x['r']==sorted(set(rc)) and x['z']==sorted(set(zc)), 'leaf centers')
    demand(x['nr']==len(set(rc)) and x['nz']==len(set(zc)) and 'rf' not in x and 'zf' not in x,'leaf is not tensor geometry')
    expected=[];patches=[]
    for axis in (0,1):
        planes=sorted({box[2*axis+side] for box in boxes for side in (0,1)})
        for coordinate in planes:
            touching=[]
            for k,box in enumerate(boxes):
                lo,hi=box[2*axis:2*axis+2];bottom,top=box[2*(1-axis):2*(1-axis)+2]
                if coordinate in (lo,hi):touching.append((bottom,top,k,coordinate==hi))
            edges=sorted({v for a,b,k,left in touching for v in (a,b)})
            for bottom,top in zip(edges,edges[1:]):
                middle=(bottom+top)/2
                left=[k for a,b,k,side in touching if side and a<middle<b]
                right=[k for a,b,k,side in touching if not side and a<middle<b]
                if not left and not right:continue
                demand(len(left)<=1 and len(right)<=1,'single neighbor per face patch')
                wall_low=F(0) if axis==0 else -beta;wall_high=F(1) if axis==0 else beta
                demand(bool(left) or coordinate==wall_low,'no interior low wall')
                demand(bool(right) or coordinate==wall_high,'no interior high wall')
                area=coordinate*(top-bottom) if axis==0 else (top-bottom)*(top+bottom)/2
                expected.append((axis,left[0] if left else -1,right[0] if right else -1,area))
                patches.append((coordinate,bottom,top))
    demand(x['faces']==expected and x['face_patches']==patches,'complete shared partial-face cover')
    # Reconstruct the coefficient inventory from actual cell centers, separately.
    keys=set()
    for source in range(len(boxes)):
        for target in range(len(boxes)):keys.add((rc[target],rc[source],abs(zc[target]-zc[source])))
    demand(x['kernel_keys']==sorted(keys) and x['separations']==sorted({p[2] for p in keys}),'actual leaf ring-pair coverage')
    demand(x['pi']==pi and x['rho_unit']==state['mass_kg']/(2*pi*state['radius_m']**3),'leaf density unit')
    demand(x['time_unit']==state['radius_m']/model['sound_speed_m_s'] and x['transition']==model['density'],'leaf physical units')
    round_cell(x['gravity'],model['G']*state['mass_kg']*s/(state['radius_m']*model['sound_speed_m_s']**2))
    demand(x['cfl']==cfg['courant_fraction'] and x['angles']==cfg['angular_nodes'],'leaf numerical context')
    softening_watchdog.check(x,state,cfg,model)
    coefficients(x)
