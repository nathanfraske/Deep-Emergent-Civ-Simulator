"""Bounded checkpoint proposal IO and observer-neutral continuation records.

Supplied cells have no authority here. checkpoint_watchdog reconstructs the
complete history through the independently checked gas integrator first.
"""
from decimal import Decimal, localcontext
from fractions import Fraction as F
from pathlib import Path
import json
from arithmetic import canonical_json, digest, parse_rational


def text(values):
    lines=[]
    for key,value in values.items():
        if type(value) is int:word=str(value)
        elif isinstance(value,F) or isinstance(value,str) and '/' in value and key!='description':
            q=value if isinstance(value,F) else parse_rational(value)
            if max(q.numerator.bit_length(),q.denominator.bit_length())>256:raise ValueError('checkpoint input magnitude')
            with localcontext() as ctx:
                ctx.prec=300;decimal=Decimal(q.numerator)/Decimal(q.denominator)
                if F(decimal)!=q:raise ValueError('checkpoint nondecimal input')
                word=str(decimal.normalize())
        else:word=value
        if not isinstance(word,str) or '\n' in word or '\r' in word:raise ValueError('checkpoint input text')
        lines.append(key+'='+word)
    return '\n'.join(lines)+'\n'


def read(path):
    path=Path(path)
    if not 0<path.stat().st_size<=128*1024**2:raise ValueError('checkpoint byte resource')
    def object_(pairs):
        result={}
        for key,value in pairs:
            if key in result:raise ValueError('checkpoint duplicate JSON key')
            result[key]=value
        return result
    def nofloat(word):raise ValueError('checkpoint floating input')
    return json.loads(path.read_text(encoding='ascii'),object_pairs_hook=object_,parse_float=nofloat,parse_constant=nofloat)


def science(value):
    return {k:v for k,v in value.items() if k not in ('implementations','execution_identity')}


def record(parent,cfg):
    old=parent.get('continuation')
    origin=old['origin_numerics'] if old else parent['numerics']
    rows=list(old['segments']) if old else []
    entry=dict(numerics=cfg,from_step=parent['steps'],from_clock_q=parent['frames'][-1]['clock_q'],
               from_trace_sha256=parent['trace_sha256'])
    selective=cfg['schema'] in ('civsim.rotating-barotropic.numerics.v6','civsim.rotating-barotropic.numerics.v7')
    if selective:entry['from_stop_reason']=parent['stop_reason']
    rows.append(entry)
    return dict(schema='civsim.rotating-barotropic.continuation.v2' if selective else 'civsim.rotating-barotropic.continuation.v1',origin_numerics=origin,segments=rows)


def marker(parent,cfg):
    # File paths, descriptions, source metadata and output sampling are observers.
    return dict(event='continuation',from_step=parent['steps'],from_clock_q=parent['frames'][-1]['clock_q'],
                physical_identity=parent['physical_identity'],numerics={k:v for k,v in cfg.items() if k!='sample_every'})


def matched(proposal,replayed):
    if digest(canonical_json(science(proposal)).encode('ascii'))!=digest(canonical_json(science(replayed)).encode('ascii')):
        raise ValueError('checkpoint complete scientific replay mismatch')
