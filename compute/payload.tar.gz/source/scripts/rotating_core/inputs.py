"""Closed physical state and separate numerical resource contract."""
from fractions import Fraction as F
import re

STATE_KEYS = {'schema','origin','geometry','boundary','mass_kg','radius_m','half_height_m','angular_velocity_s_inv','description'}
OPEN_KEYS = {'exterior_gravity','radial_edge_velocity_m_s','axial_edge_velocity_m_s'}
FINITE_KEYS = OPEN_KEYS|{'inner_mass_kg','inner_radius_m','inner_half_height_m'}
NUM_KEYS = {'schema','angular_transport','radial_cells','vertical_cells','mesh_power','fraction_bits','angular_nodes','softening_m','courant_fraction','max_steps','max_elapsed_s','sample_every','max_pair_steps'}
ADAPT_KEYS={'mesh_adaptation','remesh_interval','remesh_max_events','remesh_regularization','remesh_relaxation'}
BUDGET_KEYS={'remesh_density_budget','remesh_angular_budget','remesh_event_fraction','remesh_backtracks'}
REFINE_KEYS={'spatial_refinement','refinement_trigger_squared','refinement_target_squared','refinement_max_cells','refinement_max_events','refinement_max_depth','refinement_density_budget','refinement_angular_budget'}


def parse(text, keys):
    if not isinstance(text,str) or len(text.encode('ascii'))>4096:
        raise ValueError('ASCII input resource limit')
    result={}
    for line in text.splitlines():
        if not line.strip() or line.lstrip().startswith('#'):continue
        if '=' not in line:raise ValueError('missing assignment')
        key,value=[x.strip() for x in line.split('=',1)]
        if key not in keys or key in result or not value:raise ValueError('unknown, duplicate or empty input')
        result[key]=value
    if set(result)!=keys:raise ValueError('incomplete input inventory')
    return result


def number(text):
    if len(text)>48 or not re.fullmatch(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d{1,2})?',text):
        raise ValueError('unsupported decimal')
    value=F(text)
    if max(value.numerator.bit_length(),value.denominator.bit_length())>256:raise ValueError('decimal resource limit')
    return value


def state(text):
    if not isinstance(text,str):raise ValueError('text physical input required')
    opened=any(line.partition('=')[0].strip()=='schema' and line.partition('=')[2].strip()=='civsim.rotating-barotropic.state.v2' for line in text.splitlines())
    finite=any(line.partition('=')[0].strip()=='schema' and line.partition('=')[2].strip()=='civsim.rotating-barotropic.state.v3' for line in text.splitlines())
    x=parse(text,STATE_KEYS|(FINITE_KEYS if finite else OPEN_KEYS if opened else set()))
    if [x[k] for k in ('schema','origin','geometry','boundary')]!=[
        'civsim.rotating-barotropic.state.v3' if finite else 'civsim.rotating-barotropic.state.v2' if opened else 'civsim.rotating-barotropic.state.v1',
        'declared_hypothesis','nested_cylinders' if finite else 'uniform_cylinder','extrapolated_cylinder' if opened else 'reflecting_slip']:
        raise ValueError('unsupported physical state or boundary')
    if opened and x['exterior_gravity']!='neglected':raise ValueError('unsupported exterior gravity')
    if finite and x['exterior_gravity']!='all_resolved_gas':raise ValueError('unsupported finite surrounding gravity')
    scalars=['mass_kg','radius_m','half_height_m','angular_velocity_s_inv']
    if opened or finite:scalars+=['radial_edge_velocity_m_s','axial_edge_velocity_m_s']
    if finite:scalars+=['inner_mass_kg','inner_radius_m','inner_half_height_m']
    for key in scalars:x[key]=number(x[key])
    if any(x[k]<=0 for k in ('mass_kg','radius_m','half_height_m')):raise ValueError('nonpositive extent or mass')
    if not F(1,4)<=x['half_height_m']/x['radius_m']<=4:raise ValueError('aspect resource envelope')
    if finite:
        if not all(0<x[a]<x[b] for a,b in (('inner_mass_kg','mass_kg'),('inner_radius_m','radius_m'),('inner_half_height_m','half_height_m'))):raise ValueError('positive finite surrounding gas and nested extents required')
        if not F(1,4)<=x['inner_half_height_m']/x['inner_radius_m']<=4:raise ValueError('inner aspect resource envelope')
    if len(x['description'])>240:raise ValueError('description resource limit')
    return x


def numerics(text):
    # Version determines the closed field set; parse still rejects duplicates.
    if not isinstance(text,str):raise ValueError('text numerical input required')
    versions={line.partition('=')[2].strip() for line in text.splitlines() if line.partition('=')[0].strip()=='schema'}
    width_limited='civsim.rotating-barotropic.numerics.v7' in versions
    selective=width_limited or 'civsim.rotating-barotropic.numerics.v6' in versions
    refining=selective or 'civsim.rotating-barotropic.numerics.v5' in versions
    budgeted=refining or 'civsim.rotating-barotropic.numerics.v4' in versions
    adaptive=budgeted or 'civsim.rotating-barotropic.numerics.v3' in versions
    keys=NUM_KEYS|(ADAPT_KEYS if adaptive else set())|(BUDGET_KEYS if budgeted else set())|(REFINE_KEYS if refining else set())|({'gravity_softening','softening_cell_fraction'} if width_limited else set())
    x=parse(text,keys)
    if x['schema'] not in ('civsim.rotating-barotropic.numerics.v2','civsim.rotating-barotropic.numerics.v3','civsim.rotating-barotropic.numerics.v4','civsim.rotating-barotropic.numerics.v5','civsim.rotating-barotropic.numerics.v6','civsim.rotating-barotropic.numerics.v7') or x['angular_transport']!='regular_rotation_mass_flux':raise ValueError('unsupported numerics or angular transport')
    for key in ('radial_cells','vertical_cells','mesh_power','fraction_bits','angular_nodes','max_steps','sample_every','max_pair_steps'):
        if not re.fullmatch(r'\d{1,'+('13' if refining and key=='max_pair_steps' else '10')+r'}',x[key]):raise ValueError('unsigned integer required')
        x[key]=int(x[key])
    for key in ('softening_m','courant_fraction','max_elapsed_s'):x[key]=number(x[key])
    if width_limited:
        x['softening_cell_fraction']=number(x['softening_cell_fraction'])
        if x['gravity_softening']!='cell_width_limited_global' or not 0<x['softening_cell_fraction']<=1:raise ValueError('cell softening policy domain')
    if x['radial_cells'] not in (4,8,16,32) or x['vertical_cells'] not in (8,16,32):raise ValueError('mesh resource envelope')
    if x['radial_cells']*x['vertical_cells']>512 or x['mesh_power'] not in (1,2):raise ValueError('mesh resource envelope')
    if not 96<=x['fraction_bits']<=160 or not 8<=x['angular_nodes']<=64:raise ValueError('precision or quadrature envelope')
    if not 0<x['courant_fraction']<=F(1,5) or x['softening_m']<=0 or x['max_elapsed_s']<=0:raise ValueError('numerical positive domain')
    cells=x['radial_cells']*x['vertical_cells']
    if not 1<=x['max_steps']<=65536 or not 1<=x['sample_every']<=x['max_steps']:raise ValueError('step or sampling envelope')
    if not cells*cells*x['max_steps']<=x['max_pair_steps']<=(2**40 if refining else 2**30):raise ValueError('declared pair-step budget')
    if x['max_steps']//x['sample_every']>256:raise ValueError('frame resource envelope')
    if adaptive:
        if x['mesh_adaptation']!='regularized_mass_coordinates':raise ValueError('unsupported mesh adaptation')
        for key in ('remesh_interval','remesh_max_events'):
            if not re.fullmatch(r'\d{1,10}',x[key]):raise ValueError('unsigned remesh count required')
            x[key]=int(x[key])
        for key in ('remesh_regularization','remesh_relaxation'):x[key]=number(x[key])
        if not 1<=x['remesh_interval']<=x['max_steps'] or not 1<=x['remesh_max_events']<=32 or x['remesh_interval']*x['remesh_max_events']>x['max_steps']:raise ValueError('remesh resource envelope')
        if not 0<x['remesh_regularization']<=1 or not 0<x['remesh_relaxation']<=F(1,2):raise ValueError('remesh monitor or relaxation domain')
    if budgeted:
        for key in ('remesh_density_budget','remesh_angular_budget','remesh_event_fraction'):x[key]=number(x[key])
        if not all(0<x[k]<=1 for k in ('remesh_density_budget','remesh_angular_budget','remesh_event_fraction')):raise ValueError('remesh representation budget domain')
        if not re.fullmatch(r'\d{1,2}',x['remesh_backtracks']):raise ValueError('unsigned bounded backtrack count required')
        x['remesh_backtracks']=int(x['remesh_backtracks'])
        if not 0<=x['remesh_backtracks']<=16:raise ValueError('remesh backtrack resource envelope')
    if refining:
        if x['spatial_refinement']!=('jeans_dyadic_cells' if selective else 'jeans_dyadic_bands'):raise ValueError('unsupported spatial refinement')
        for key in ('refinement_max_cells','refinement_max_events','refinement_max_depth'):
            if not re.fullmatch(r'\d{1,10}',x[key]):raise ValueError('unsigned refinement count required')
            x[key]=int(x[key])
        for key in ('refinement_trigger_squared','refinement_target_squared','refinement_density_budget','refinement_angular_budget'):x[key]=number(x[key])
        if not 0<x['refinement_target_squared']<x['refinement_trigger_squared']<=F(1,32):raise ValueError('Jeans refinement margin')
        if not cells<=x['refinement_max_cells']<=(4096 if selective else 2048) or not 1<=x['refinement_max_events']<=(64 if selective else 16) or not 1<=x['refinement_max_depth']<=8:raise ValueError('refinement resource envelope')
        if not all(0<x[k]<=1 for k in ('refinement_density_budget','refinement_angular_budget')):raise ValueError('refinement projection budget')
        if x['refinement_max_cells']**2*x['max_steps']>x['max_pair_steps']:raise ValueError('refinement worst-case pair-step capacity')
    return x
