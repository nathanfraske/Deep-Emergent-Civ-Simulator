"""Unreduced arithmetic and packed-force controls against the held equations."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'scripts/radial_core')]
from fractions import Fraction as F
from math import isqrt
import copy,unittest
from arithmetic import qfraction
from scripts.rotating_core import gravity,gravity_watchdog,packed_field,packed_field_watchdog


def fraction_row(x,index):
    a,b,z=x['kernel_keys'][index];s=x['s'];out=[F(0),F(0),F(0)];weight=F(0)
    for k in range(x['angles']):
        t=F(2*k+1,2*x['angles']);w=1/(1+t*t);co=(1-t*t)/(1+t*t)
        for cosine in (co,-co):
            d=a*a+b*b-2*a*b*cosine+z*z+x['epsilon']**2
            inverse2=F(s*s)/d;q=isqrt(inverse2.numerator//inverse2.denominator)
            if q*q<inverse2:q+=1
            h=F(q,s);out[0]+=h*w;out[1]+=h**3*w*(a-b*cosine);out[2]+=h**3*w*z;weight+=w
    return [qfraction(v/weight,s) for v in out]


class ExactGravityTests(unittest.TestCase):
    def test_kernel_primitive_preserves_full_fraction_equations_and_mutations(self):
        keys=[(F(0),F(0),F(0)),(F(0),F(37,51),F(0)),(F(37,51),F(0),F(11,19)),(F(37,51),F(37,51),F(0))]
        keys += [(F(i,31),F(20-i,37),F(i%5,43)) for i in range(1,20)]
        for bits in (96,128,160):
            for angles in (8,16,32):
                x=dict(s=2**bits,epsilon=F(7,103),angles=angles,kernel_keys=keys)
                for index in range(len(keys)):
                    row=gravity.kernel_row(x,index);self.assertEqual(row,fraction_row(x,index));gravity_watchdog.check_row(x,index,row)
                    for component in range(3):
                        bad=row.copy();bad[component]+=1
                        with self.assertRaises(ValueError):gravity_watchdog.check_row(x,index,bad)

    def test_packed_signs_half_ties_and_full_domain_fallback(self):
        radial=[[16,16],[48,48]];axial=[[-16,-16],[-48,-48]];columns=(((16,48),(-16,-48)),((16,48),(-16,-48)))
        matrix=packed_field.prepare(radial,axial,8);sums=packed_field_watchdog.prepare(columns,8)
        checker=gravity_watchdog._PreparedField(8,1,columns,sums);x=dict(s=8,gravity=1)
        for mass in (1,4,5,2**383-1):
            cells=[[mass,0,0,0],[mass,0,0,0]]
            result=gravity.field(x,cells,matrix);self.assertEqual(result,gravity.field(x,cells,(radial,axial)));checker.check(cells,result)
            self.assertEqual(sums.reconstruct(cells) is None,2*mass>8)
            for component in range(2):
                bad=copy.deepcopy(result);bad[0][component]+=1
                with self.assertRaises(ValueError):checker.check(cells,bad)
        self.assertEqual(gravity.field(x,[[1,0,0,0],[1,0,0,0]],matrix),[[0,0],[-2,2]])
        radial[0][0]+=100;axial[0][0]-=100
        self.assertEqual(gravity.field(x,[[1,0,0,0],[1,0,0,0]],matrix),[[0,0],[-2,2]])

    def test_no_cross_digit_carry_at_declared_mass_limit(self):
        for bits in (96,128,160):
            bound=2**bits;radial=[[(-1)**(i+j)*(2**(bits//2)-i-j-1) for j in range(7)] for i in range(7)]
            axial=[[(-1)**j*(2**(bits//2)-2*i-j-1) for j in range(7)] for i in range(7)]
            columns=tuple((tuple(radial[i][j] for i in range(7)),tuple(axial[i][j] for i in range(7))) for j in range(7))
            matrix=packed_field.prepare(radial,axial,bound);sums=packed_field_watchdog.prepare(columns,bound)
            cells=[[bound-6,0,0,0]]+[[1,0,0,0] for _ in range(6)];x=dict(s=bound,gravity=bound//5)
            result=gravity.field(x,cells,matrix);self.assertEqual(result,gravity.field(x,cells,(radial,axial)))
            gravity_watchdog._PreparedField(bound,x['gravity'],columns,sums).check(cells,result)


if __name__=='__main__':unittest.main()
