"""Exact-integer ring gravity, with ordered parallel kernel construction."""
from arithmetic import rounded
from concurrent.futures import ProcessPoolExecutor
import os
from . import packed_field,kernel_quotients


def kernel_row(x,index):
    s=x['s']
    if 'kernel_keys' in x:ri,rj,z=x['kernel_keys'][index]
    else:
        n=len(x['separations']);nr=x['nr'];i=index//(nr*n);j=index//n%nr;z=x['separations'][index%n]
        ri,rj=x['r'][i],x['r'][j]
    return kernel_quotients.row(s,ri,rj,z,x['epsilon'],x['angles'])


def chunk(args):
    x,begin,end=args
    return [kernel_row(x,index) for index in range(begin,end)]


def kernel(x,workers=None):
    count=len(x['kernel_keys']) if 'kernel_keys' in x else x['nr']**2*len(x['separations'])
    workers=max(1,min(workers or os.cpu_count() or 1,16,count))
    width=(count+workers*4-1)//(workers*4)
    jobs=[(x,k,min(k+width,count)) for k in range(0,count,width)]
    if workers==1:return chunk((x,0,count))
    with ProcessPoolExecutor(max_workers=workers) as pool:
        return [row for rows in pool.map(chunk,jobs) for row in rows]


def matrices(x,rows):
    if 'kernel_keys' in x:
        lookup={key:row for key,row in zip(x['kernel_keys'],rows)};radial=[];axial=[]
        for r,z in zip(x['cell_r'],x['cell_z']):
            rr=[];zz=[]
            for q,w in zip(x['cell_r'],x['cell_z']):
                row=lookup[(r,q,abs(z-w))];rr.append(row[1]);zz.append(row[2] if z>=w else -row[2])
            radial.append(rr);axial.append(zz)
        return packed_field.prepare(radial,axial,x['s'])
    radial=[];axial=[];nr=x['nr'];ns=len(x['separations'])
    for target in range(nr*x['nz']):
        tr,tz=target%nr,target//nr;r=[];z=[]
        for source in range(nr*x['nz']):
            sr,sz=source%nr,source//nr
            index=(tr*nr+sr)*ns+x['incidence'][tz][sz]
            row=rows[index];r.append(row[1]);z.append(row[2] if tz>=sz else -row[2])
        radial.append(r);axial.append(z)
    return packed_field.prepare(radial,axial,x['s'])


def field(x,cells,matrix):
    if isinstance(matrix,packed_field.Matrix):
        value=matrix.force(x,cells)
        if value is not None:return value
    masses=[row[0] for row in cells];s=x['s'];g=x['gravity'];radial,axial=matrix
    return [[rounded(-g*sum(m*k for m,k in zip(masses,radial[i])),s*s),
             rounded(-g*sum(m*k for m,k in zip(masses,axial[i])),s*s)] for i in range(len(cells))]
