"""Independent source-cover partition, rounded accounts and remap-error checks."""
from fractions import Fraction as F
from .input_watchdog import demand
from .mesh_watchdog import round_cell


def check(old,new,cells,got):
    demand(set(got)=={'schema','transfers','next','before_totals','after_totals','diagnostics'} and got['schema']=='civsim.rotating-barotropic.remap.v1','remap receipt inventory')
    rows=got['next'];demand(len(rows)==len(new['volume']) and all(len(y)==4 and all(type(v) is int for v in y) and y[0]>0 for y in rows),'remapped field census')
    partitions=[]
    for j in range(old['nz']):
        for i in range(old['nr']):
            source=j*old['nr']+i;rl,rh=old['rf'][i:i+2];zb,zt=old['zf'][j:j+2]
            parts=[]
            for tj in range(new['nz']):
                bottom=max(zb,new['zf'][tj]);top=min(zt,new['zf'][tj+1])
                if top<=bottom:continue
                for ti in range(new['nr']):
                    lo=max(rl,new['rf'][ti]);hi=min(rh,new['rf'][ti+1])
                    if hi<=lo:continue
                    area=(hi-lo)*(hi+lo)*(top-bottom)/2
                    moment=area*(hi*hi+lo*lo)/2
                    parts.append((source,tj*new['nr']+ti,area,moment))
            partitions.append(parts)
    demand(len(got['transfers'])==sum(map(len,partitions)),'complete overlap inventory')
    position=0;accum=[[0]*4 for _ in rows];density_error=F(0);angular_error=F(0)
    for source,parts in enumerate(partitions):
        i=source%old['nr'];r0,r1=old['rf'][i:i+2];volume=old['volume'][source];inertia=volume*(r0*r0+r1*r1)/2
        covered=F(0);covered_moment=F(0);running=[0]*4
        for si,ti,area,moment in parts:
            row=got['transfers'][position];position+=1
            demand(len(row)==6 and row[:2]==[si,ti] and all(type(q) is int for q in row),'overlap order and integer transfer')
            covered+=area;covered_moment+=moment
            for k in range(4):
                running[k]+=row[k+2];round_cell(running[k],cells[source][k]*(covered_moment/inertia if k==3 else covered/volume));accum[ti][k]+=row[k+2]
            n=ti%new['nr'];a,b=new['rf'][n:n+2];target_v=new['volume'][ti];target_j=target_v*(a*a+b*b)/2
            density_error+=area*abs(cells[source][0]/volume-rows[ti][0]/target_v)
            angular_error+=moment*abs(cells[source][3]/inertia-rows[ti][3]/target_j)
        demand(covered==volume and covered_moment==inertia and running==cells[source],'source exact volume and angular coverage')
    demand(rows==accum,'remap scatter residual')
    before=[sum(row[k] for row in cells) for k in range(4)];after=[sum(row[k] for row in rows) for k in range(4)]
    demand(got['before_totals']==before==after==got['after_totals'],'all four remap accounts')
    expected={};mass=before[0];angular=sum(abs(row[3]) for row in cells)
    expected['density_l1_mass_fraction']=density_error/mass
    expected['angular_profile_l1_fraction']=angular_error/angular if angular else F(0)
    for name,context,values in (('before',old,cells),('after',new,rows)):
        sums=[F(0),F(0),F(0)]
        for k,y in enumerate(values):
            i,j=k%context['nr'],k//context['nr'];lo,hi=context['rf'][i:i+2];bottom,top=context['zf'][j:j+2]
            moment=(hi**4-lo**4)/(2*(hi**2-lo**2));zmean=(top**3-bottom**3)/(3*(top-bottom))
            sums[0]+=y[0]*moment;sums[1]+=y[0]*zmean;sums[2]+=F(y[3]**2,y[0]*mass)/moment
        expected[name]=dict(radial_second_moment=sums[0]/mass,axial_second_moment=sums[1]/mass,rotational_quadratic=sums[2])
    demand(got['diagnostics']==expected,'remap information-loss observations')
