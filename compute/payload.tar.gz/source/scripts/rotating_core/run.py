"""Live independently checked rotating gas; no constructed stellar object."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(1,str(ROOT/'scripts/radial_core'))
from fractions import Fraction as F
import argparse,copy,json,time
from arithmetic import canonical_json,digest,normalized,qfraction,rational
import pi_pair
from scripts.rotating_core import inputs,input_watchdog,mesh,mesh_watchdog,eos,eos_watchdog
from scripts.rotating_core import gravity,gravity_watchdog,transport,transport_watchdog,observe,observe_watchdog,model as models
from scripts.rotating_core import adapt,adapt_watchdog,remap,remap_watchdog
from scripts.rotating_core import remap_budget,remap_budget_watchdog
from scripts.rotating_core import checkpoint,checkpoint_watchdog
from scripts.rotating_core import refine,refine_watchdog
from scripts.rotating_core import leaf_mesh,leaf_mesh_watchdog,leaf_refine,leaf_refine_watchdog
from scripts.rotating_core.deferred_observe import Observation
from scripts.rotating_core.resource_stop import Deadline
from scripts.rotating_core import softening_watchdog
from scripts.rotating_core import boundary,boundary_watchdog
from scripts.rotating_core import finite_cloud,finite_cloud_watchdog
from scripts.rotating_core import finite_checkpoint,finite_checkpoint_watchdog

MODEL_ID='axisymmetric_bate1998_barotropic_v1'
OPEN_MODEL_ID='axisymmetric_bate1998_barotropic_open_v1'
FINITE_MODEL_ID='axisymmetric_bate1998_barotropic_finite_cloud_v1'
MODULES=['__init__.py','inputs.py','input_watchdog.py','mesh.py','mesh_watchdog.py','eos.py','eos_watchdog.py',
         'gravity.py','gravity_watchdog.py','flux.py','transport.py','transport_watchdog.py','observe.py','observe_watchdog.py',
         'model.py','model_watchdog.py','run.py']
MODULES += ['adapt.py','adapt_watchdog.py','remap.py','remap_watchdog.py']
MODULES += ['remap_budget.py','remap_budget_watchdog.py']
MODULES += ['checkpoint.py','checkpoint_watchdog.py']
MODULES += ['refine.py','refine_watchdog.py']
MODULES += ['leaf_mesh.py','leaf_mesh_watchdog.py','leaf_refine.py','leaf_refine_watchdog.py']
MODULES += ['packed_field.py','packed_field_watchdog.py']
MODULES += ['kernel_quotients.py','kernel_residuals.py']
MODULES += ['deferred_observe.py']
MODULES += ['resource_stop.py','softening.py','softening_watchdog.py']
MODULES += ['boundary.py','boundary_watchdog.py']
MODULES += ['finite_cloud.py','finite_cloud_watchdog.py']
MODULES += ['finite_checkpoint.py','finite_checkpoint_watchdog.py']
SHARED=['arithmetic.py','constitutive.py','pi_pair.py','source.py','source_watchdog.py']


def encoded(x):
    if isinstance(x,Observation):x=dict(x)
    if isinstance(x,F):return rational(x)
    if isinstance(x,dict):return {k:encoded(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [encoded(v) for v in x]
    return x


def implementations():
    paths=[Path('scripts/rotating_core')/name for name in MODULES]+[Path('scripts/radial_core')/name for name in SHARED]
    paths.append(Path('sources/barotropic_core/exact-gravity-equations.txt'))
    paths.append(Path('sources/barotropic_core/selective-continuation-equations.txt'))
    paths.append(Path('sources/barotropic_core/cell-softening-equations.txt'))
    paths.append(Path('sources/barotropic_core/rotating-open-equations.txt'))
    paths.append(Path('sources/barotropic_core/rotating-finite-equations.txt'))
    paths.append(Path('sources/barotropic_core/finite-continuation-equations.txt'))
    return {str(path).replace('\\','/'):digest(normalized(ROOT/path)) for path in paths}


def get_kernel(x,cache_path,workers,progress):
    specification=encoded({k:x[k] for k in ('s','r','z','epsilon','angles')})
    if 'kernel_keys' in x:specification['kernel_keys']=encoded(x['kernel_keys'])
    binding=digest(canonical_json(specification).encode('ascii'))
    if progress:progress('kernel-start',dict(kernel_rows=len(x['kernel_keys']) if 'kernel_keys' in x else x['nr']**2*len(x['separations'])))
    if cache_path and cache_path.exists():
        if not 0<cache_path.stat().st_size<=1536*1024**2:raise ValueError('kernel cache resource limit')
        cache=json.loads(cache_path.read_text(encoding='ascii'))
        input_watchdog.demand(set(cache)=={'schema','binding','rows','rows_sha256'} and cache['schema']=='civsim.rotating-barotropic.kernel.v1','kernel cache schema')
        input_watchdog.demand(cache['binding']==binding and digest(canonical_json(cache['rows']).encode('ascii'))==cache['rows_sha256'],'kernel cache binding')
        rows=cache['rows']
    else:rows=gravity.kernel(x,workers)
    force_authority=gravity_watchdog.kernel(x,rows,workers)
    kernel_identity=digest(canonical_json(rows).encode('ascii'))
    if cache_path and not cache_path.exists():
        with cache_path.open('x',encoding='ascii',newline='\n') as stream:
            stream.write(canonical_json(dict(schema='civsim.rotating-barotropic.kernel.v1',binding=binding,rows=rows,rows_sha256=kernel_identity)))
    if progress:progress('kernel-checked',dict(kernel_sha256=kernel_identity))
    return rows,kernel_identity,force_authority


# @derives: conditional rotating barotropic trajectory <- sealed nominal G + Bate scalar pressure + cylindrical Euler mass and angular momentum + declared gas cylinder + checked finite numerical contract
def solve(state_text,cfg_text,model,progress=None,on_frame=None,kernel_cache=None,workers=None,_resume=None,_stop_step=None,stop_requested=None):
    models.validate(model);pressure_model=model['pressure']
    state=inputs.state(state_text);cfg=inputs.numerics(cfg_text)
    input_watchdog.check(state_text,state,'state');input_watchdog.check(cfg_text,cfg,'numerics')
    opened=model['model_id']==OPEN_MODEL_ID
    finite=model['model_id']==FINITE_MODEL_ID;accounted=opened or finite
    input_watchdog.demand(state['schema']==('civsim.rotating-barotropic.state.v3' if finite else 'civsim.rotating-barotropic.state.v2' if opened else 'civsim.rotating-barotropic.state.v1'),'model-bound physical state')
    if opened:input_watchdog.demand(_resume is None,'open boundary continuation not admitted')
    width_limited=cfg['schema']=='civsim.rotating-barotropic.numerics.v7'
    selective=width_limited or cfg['schema']=='civsim.rotating-barotropic.numerics.v6'
    if selective:checkpoint_watchdog.source(ROOT,True)
    refining=selective or cfg['schema']=='civsim.rotating-barotropic.numerics.v5'
    splitter,split_watchdog=(leaf_refine,leaf_refine_watchdog) if selective else (refine,refine_watchdog)
    budgeted=refining or cfg['schema']=='civsim.rotating-barotropic.numerics.v4'
    if _resume is not None:input_watchdog.demand(budgeted and (not refining or selective),'budgeted continuation domain')
    if finite and _resume is not None:input_watchdog.demand(selective,'finite continuation numerical domain')
    if _stop_step is not None:input_watchdog.demand((selective or accounted) and type(_stop_step) is int and 0<=_stop_step<=cfg['max_steps'],'execution cut domain')
    if stop_requested is not None:input_watchdog.demand((selective or accounted) and callable(stop_requested),'checked endpoint stop domain')
    adaptive=budgeted or cfg['schema']=='civsim.rotating-barotropic.numerics.v3'
    numerical_provenance=adapt_watchdog.source(ROOT) if adaptive else None
    if budgeted:numerical_provenance.update(remap_budget_watchdog.source(ROOT))
    if refining:numerical_provenance.update(refine_watchdog.source(ROOT))
    if selective:numerical_provenance.update(leaf_refine_watchdog.source(ROOT))
    if width_limited:numerical_provenance.update(softening_watchdog.source(ROOT))
    pi=pi_pair.value(cfg['fraction_bits']);input_watchdog.physical(state,cfg,pressure_model,pi)
    x=mesh.build(state,cfg,pressure_model,pi)
    if finite:
        x.update(boundary_mode='reflecting_slip',gravity_domain='all_resolved_gas')
        mesh_watchdog.geometry(state,cfg,pressure_model,pi,x)
        cells=finite_cloud.project(x,state,pressure_model)
        finite_cloud_watchdog.initial(x,state,cfg,pressure_model,cells)
    else:
        cells=mesh.project(x,state,pressure_model);mesh_watchdog.check(state,cfg,pressure_model,pi,x,cells)
    accounts=None
    if opened:
        x['boundary_mode']='extrapolated_cylinder'
        projected=boundary.project(x,cells,state,pressure_model)
        boundary_watchdog.initial(x,cells,projected,state,pressure_model);cells=projected
        accounts=boundary.start(cells);boundary_watchdog.start(cells,accounts)
    if finite:
        accounts=finite_cloud.start(cells);boundary_watchdog.start(cells,accounts)
        finite_cloud_watchdog.accounts(x,cells,accounts)
    rows,kernel_identity,force_authority=get_kernel(x,kernel_cache,workers,progress);matrix=gravity.matrices(x,rows)
    def checked(y,measure=True):
        if opened:boundary_watchdog.physical(x,y,state,pressure_model)
        if finite:finite_cloud_watchdog.physical(x,y,state,pressure_model)
        fields=eos.fields(x,y);eos_watchdog.check(x,y,fields)
        force=gravity.field(x,y,matrix)
        if force_authority is None:gravity_watchdog.field(x,y,rows,force)
        else:force_authority.check(y,force)
        if measure:
            observe_watchdog.screens(x,y,fields,pressure_model)
            def measurement(context=x,cells=y,thermodynamics=fields,acceleration=force):
                value=observe.measure(context,cells,thermodynamics,acceleration,state,pressure_model)
                observe_watchdog.check(context,cells,thermodynamics,acceleration,state,pressure_model,value)
                return value
            observation=Observation(measurement)
        else:
            observe_watchdog.screens(x,y,fields,pressure_model);observation=None
            if refining:split_watchdog.screen(x,fields,state,pressure_model)
        return fields,force,observation
    fields,force,observation=checked(cells);initial_observation=observation
    mass_total=sum(y[0] for y in cells);angular_total=sum(y[3] for y in cells)
    clock=0;end=qfraction(cfg['max_elapsed_s']/x['time_unit'],x['s'])
    trace=digest(b'civsim.rotating-barotropic.trace.v7' if selective else b'civsim.rotating-barotropic.trace.v6' if refining else b'civsim.rotating-barotropic.trace.v4' if budgeted else b'civsim.rotating-barotropic.trace.v3' if adaptive else b'civsim.rotating-barotropic.trace.v2')
    if opened:trace=digest(b'civsim.rotating-open.trace.v1'+bytes.fromhex(trace)+canonical_json(dict(initial=cells,accounts=accounts)).encode('ascii'))
    if finite:trace=digest(b'civsim.rotating-finite.trace.v1'+bytes.fromhex(trace)+canonical_json(dict(initial=cells,accounts=accounts)).encode('ascii'))
    frames=[];last_saved=-1;retries=0;step=0;events=[]
    decisions=[];spent=dict(density=F(0),angular=F(0))
    continuation=None
    refinement_events=[];refinement_decisions=[];refinement_spent=dict(density=F(0),angular=F(0));pair_steps=0;resolution_stop=None
    if _resume is not None:
        parent,observed=checkpoint_watchdog.restore(_resume,state,cfg,model,implementations(),x['time_unit'],x['s'])
        original_cells=cells
        coordinates=observed['coordinate_faces']
        x=leaf_mesh.rebuild(x,coordinates['cells']) if 'cells' in coordinates else mesh.rebuild(x,coordinates)
        (leaf_mesh_watchdog if 'cell_bounds' in x else mesh_watchdog).geometry(state,cfg,pressure_model,pi,x)
        cells=observed['frames'][-1]['cell_q'];events=parent['remesh_events'];decisions=parent['remesh_decisions']
        if finite:
            accounts=finite_checkpoint.restore_accounts(parent)
            finite_checkpoint_watchdog.restoration(x,original_cells,cells,accounts,parent)
        spent=observed['remesh_spent'];clock=parent['frames'][-1]['clock_q'];step=parent['steps']
        retries=parent['adaptive_retries'];frames=parent['frames'];last_saved=step
        initial_observation=observed['initial_observation']
        if selective:
            refinement_events=parent['refinement_events'];refinement_decisions=parent['refinement_decisions']
            refinement_spent=observed['refinement_spent'];pair_steps=parent['pair_steps_spent']
        input_watchdog.demand(_stop_step is None or _stop_step>=step,'later execution cut')
        suffix=f'-refine-{len(refinement_events):04d}' if refinement_events else f'-remesh-{len(events):04d}' if events else ''
        current_cache=kernel_cache.with_name(kernel_cache.stem+suffix+kernel_cache.suffix) if kernel_cache else None
        rows,kernel_identity,force_authority=get_kernel(x,current_cache,workers,progress);matrix=gravity.matrices(x,rows)
        fields,force,observation=checked(cells)
        checkpoint_watchdog.strict_equal(encoded(observation),parent['final_observation'])
        input_watchdog.demand(sum(y[0] for y in cells)==mass_total and sum(y[3] for y in cells)==angular_total,'restored original conserved totals')
        continuation=checkpoint.record(parent,encoded(cfg));checkpoint_watchdog.lineage(parent,encoded(cfg),continuation)
        numerical_provenance.update(checkpoint_watchdog.source(ROOT,selective))
        if finite:numerical_provenance.update(finite_checkpoint_watchdog.source(ROOT))
        trace=digest(bytes.fromhex(parent['trace_sha256'])+canonical_json(encoded(checkpoint.marker(parent,cfg))).encode('ascii'))
        if on_frame:
            for prefix_frame in frames:on_frame(copy.deepcopy(prefix_frame))
    def refine_now():
        nonlocal x,cells,rows,kernel_identity,matrix,fields,force,force_authority,observation,trace,refinement_spent,resolution_stop
        if not refining:return False
        proposal=splitter.plan(x,fields,state,pressure_model,cfg)
        split_watchdog.plan(x,fields,state,pressure_model,cfg,proposal)
        if proposal['status']=='unchanged':
            split_watchdog.screen(x,fields,state,pressure_model);return False
        status=proposal['status'];new_x=allocation=None;next_spent=refinement_spent
        if status=='accepted' and len(refinement_events)>=cfg['refinement_max_events']:status='event_limit'
        if status=='accepted':
            new_x,allocation=splitter.transfer(x,cells,proposal)
            (leaf_mesh_watchdog if selective else mesh_watchdog).geometry(state,cfg,pressure_model,pi,new_x)
            valid,next_spent=split_watchdog.allocation(x,new_x,cells,allocation,refinement_spent,cfg)
            input_watchdog.demand(valid==splitter.within_budget(allocation,refinement_spent,cfg),'refinement budget decision agreement')
            if not valid:status='loss_limit';next_spent=refinement_spent
        record=dict(step=step,clock_q=clock,old_faces=leaf_mesh.coordinates(x),old_cell_q=cells,
                    plan=proposal,status=status,spent_before=refinement_spent,spent_after=next_spent)
        refinement_decisions.append(encoded(record))
        trace=digest(bytes.fromhex(trace)+canonical_json(encoded(dict(event='refinement-decision',**record))).encode('ascii'))
        if status!='accepted':
            split_watchdog.screen(x,fields,state,pressure_model);resolution_stop='refinement_'+status
            if progress:progress('refinement-stop',dict(step=step,status=status,cells=len(cells),required_cells=proposal['required_cells']))
            return False
        event=dict(step=step,clock_q=clock,decision_index=len(refinement_decisions)-1,old_faces=leaf_mesh.coordinates(x),
                   new_faces=proposal['new_faces'],old_cell_q=cells,allocation=allocation,before_observation=observation)
        if progress:progress('refinement-start',dict(step=step,old_cells=len(cells),new_cells=proposal['required_cells']))
        cache=kernel_cache.with_name(kernel_cache.stem+f'-refine-{len(refinement_events)+1:04d}'+kernel_cache.suffix) if kernel_cache else None
        x=new_x;cells=allocation['next'];refinement_spent=next_spent
        rows,kernel_identity,force_authority=get_kernel(x,cache,workers,progress);matrix=gravity.matrices(x,rows)
        fields,force,observation=checked(cells);split_watchdog.screen(x,fields,state,pressure_model)
        event.update(after_observation=observation,kernel_sha256=kernel_identity)
        refinement_events.append(encoded(event))
        trace=digest(bytes.fromhex(trace)+canonical_json(encoded(dict(event='refinement',**event))).encode('ascii'))
        if progress:progress('refinement-checked',dict(step=step,revision=len(refinement_events),cells=len(cells)))
        return True
    refine_now()
    def save():
        nonlocal last_saved
        if last_saved==step:return
        frame=encoded(dict(step=step,clock_q=clock,time_s=F(clock,x['s'])*x['time_unit'],cell_q=cells,
                           rho_q=[f['rho'] for f in fields],pressure_q=[f['p'] for f in fields],
                           observation=observation,trace_sha256=trace))
        if adaptive:frame.update(coordinate_faces=encoded(leaf_mesh.coordinates(x)),mesh_revision=len(events))
        if refining:frame.update(refinement_revision=len(refinement_events),mesh_dimensions=leaf_mesh.dimensions(x))
        if width_limited:frame['effective_softening_m']=rational(x['epsilon']*state['radius_m'])
        if accounted:
            boundary_watchdog.totals(cells,accounts);frame['boundary_accounts']=copy.deepcopy(accounts)
        frames.append(frame);last_saved=step
        if on_frame:on_frame(copy.deepcopy(frame))
    save()
    if progress:progress('accepted',dict(step=step,time_s=F(clock,x['s'])*x['time_unit'],observation=Observation(lambda reading=observation:copy.deepcopy(dict(reading)))))
    execution_stop=False
    for step in range(step+1,cfg['max_steps']+1):
        if resolution_stop:step-=1;break
        remaining=end-clock
        if remaining<=0:step-=1;break
        if (_stop_step is not None and step>_stop_step) or (stop_requested is not None and stop_requested()):
            step-=1;execution_stop=True;break
        initial_bound=transport.timestep(x,cells,fields,force)
        input_watchdog.demand(initial_bound==transport_watchdog.bounds(x,cells,fields,force),'initial step selection')
        dt=min(initial_bound,remaining);reductions=0
        while True:
            transport_watchdog.timestep(x,cells,fields,force,dt,remaining,reductions)
            first=transport.stage(x,cells,fields,force,dt)
            transport_watchdog.stage(x,cells,fields,force,dt,first)
            midpoint,midforce,_=checked(first['next'],False)
            next_bound=transport.timestep(x,first['next'],midpoint,midforce)
            input_watchdog.demand(next_bound==transport_watchdog.bounds(x,first['next'],midpoint,midforce),'second step selection')
            if dt<=next_bound:break
            reductions+=1;retries+=1
            if reductions>32:raise ValueError('adaptive retry resource limit')
            dt//=2
            if dt<=0:raise ValueError('adaptive retry below representation quantum')
        second=transport.stage(x,first['next'],midpoint,midforce,dt)
        transport_watchdog.stage(x,first['next'],midpoint,midforce,dt,second)
        if selective or accounted:
            auxiliary=eos.fields(x,second['next']);eos_watchdog.check(x,second['next'],auxiliary)
            observe_watchdog.screens(x,second['next'],auxiliary,pressure_model)
            if opened:boundary_watchdog.physical(x,second['next'],state,pressure_model)
            if finite:finite_cloud_watchdog.physical(x,second['next'],state,pressure_model)
            if refining:split_watchdog.screen(x,auxiliary,state,pressure_model)
        average=transport.combine(x,cells,first,second)
        transport_watchdog.combine(x,cells,first,second,average)
        if accounted:
            next_accounts=(finite_cloud if finite else boundary).advance(x,accounts,average)
            boundary_watchdog.advance(x,cells,average,accounts,next_accounts);accounts=next_accounts
            if finite:finite_cloud_watchdog.accounts(x,average['next'],accounts)
        if refining:pair_steps+=len(cells)**2
        cells=average['next'];fields,force,observation=checked(cells);clock+=dt
        if accounted:boundary_watchdog.totals(cells,accounts)
        else:input_watchdog.demand(sum(y[0] for y in cells)==mass_total and sum(y[3] for y in cells)==angular_total,'complete trajectory conserved totals')
        marker=dict(dt_q=dt,halvings=reductions,stage1=first['next'],stage2=second['next'],accepted=cells)
        if accounted:marker['boundary_accounts']=accounts
        trace=digest(bytes.fromhex(trace)+canonical_json(marker).encode('ascii'))
        remeshed=False
        if adaptive and not refinement_events and clock<end and step%cfg['remesh_interval']==0 and (len(decisions) if budgeted else len(events))<cfg['remesh_max_events']:
            if budgeted:
                selection,next_x,allocation=remap_budget.select(x,cells,cfg,spent)
                remap_budget_watchdog.check(x,cells,cfg,spent,selection,allocation)
                record=encoded(dict(step=step,clock_q=clock,old_faces=dict(r=x['rf'],z=x['zf']),old_cell_q=cells,decision=selection))
                trace=digest(bytes.fromhex(trace)+canonical_json(dict(event='remesh-decision',**record)).encode('ascii'))
                decisions.append(record);spent=selection['spent_after'];coordinates=selection['selected_faces']
                if progress:progress('remesh-decision',dict(step=step,status=selection['status'],trials=len(selection['trials']),backtrack=selection['selected_backtrack']))
            else:
                coordinates=adapt.propose(x,cells,cfg);adapt_watchdog.check(x,cells,cfg,coordinates)
                next_x=mesh.rebuild(x,coordinates)
                allocation=remap.transfer(x,next_x,cells);remap_watchdog.check(x,next_x,cells,allocation)
            if allocation is not None:
                mesh_watchdog.geometry(state,cfg,pressure_model,pi,next_x)
                event=dict(step=step,clock_q=clock,old_faces=dict(r=x['rf'],z=x['zf']),new_faces=coordinates,
                           old_cell_q=cells,allocation=allocation,before_observation=observation)
                if budgeted:event['decision_index']=len(decisions)-1
                if progress:progress('remesh-start',dict(step=step,revision=len(events)+1))
                next_cache=kernel_cache.with_name(kernel_cache.stem+f'-remesh-{len(events)+1:04d}'+kernel_cache.suffix) if kernel_cache else None
                x=next_x;cells=allocation['next'];rows,kernel_identity,force_authority=get_kernel(x,next_cache,workers,progress);matrix=gravity.matrices(x,rows)
                fields,force,observation=checked(cells)
                event.update(after_observation=observation,kernel_sha256=kernel_identity)
                trace=digest(bytes.fromhex(trace)+canonical_json(encoded(dict(event='remesh',**event))).encode('ascii'))
                events.append(encoded(event));remeshed=True
                if progress:progress('remesh-checked',dict(step=step,revision=len(events),density_l1_mass_fraction=allocation['diagnostics']['density_l1_mass_fraction']))
        refined=refine_now()
        if step%cfg['sample_every']==0 or clock>=end or remeshed or refined or resolution_stop:save()
        if progress:progress('accepted',dict(step=step,time_s=F(clock,x['s'])*x['time_unit'],observation=Observation(lambda reading=observation:copy.deepcopy(dict(reading)))))
        if clock>=end or resolution_stop:break
    save()
    if budgeted:remap_budget_watchdog.ledger(cfg,decisions,events,spent)
    if refining:split_watchdog.ledger(cfg,refinement_decisions,refinement_events,refinement_spent,step,pair_steps)
    identity=digest(canonical_json(encoded(dict(state={k:v for k,v in state.items() if k!='description'},model=model))).encode('ascii'))
    result=encoded(dict(schema='civsim.rotating-barotropic.run.v10' if width_limited and continuation else 'civsim.rotating-barotropic.run.v9' if width_limited else 'civsim.rotating-barotropic.run.v8' if selective and continuation else 'civsim.rotating-barotropic.run.v7' if selective else 'civsim.rotating-barotropic.run.v6' if refining else 'civsim.rotating-barotropic.run.v5' if continuation else 'civsim.rotating-barotropic.run.v4' if budgeted else 'civsim.rotating-barotropic.run.v3' if adaptive else 'civsim.rotating-barotropic.run.v2',accepted=True,model_id=MODEL_ID,model=model,
                        state=state,numerics=cfg,pi=pi,physical_identity=identity,kernel_sha256=kernel_identity,
                        coordinate_faces=leaf_mesh.coordinates(x),scale=x['s'],
                        units=dict(mass_kg=state['mass_kg'],momentum_kg_m_s=state['mass_kg']*pressure_model['sound_speed_m_s'],
                                   angular_momentum_kg_m2_s=state['mass_kg']*state['radius_m']*pressure_model['sound_speed_m_s']),
                        initial_observation=initial_observation,final_observation=observation,frames=frames,steps=step,
                        reached_requested_time=clock>=end,stop_reason=resolution_stop or ('elapsed_limit' if clock>=end else 'execution_limit' if execution_stop else 'step_limit'),
                        adaptive_retries=retries,trace_sha256=trace,completed_system=False,disk_assessed=False,
                        assigned_stellar_mass_kg=F(0),limitation=model['scope']))
    if adaptive:result.update(remesh_events=events,numerical_provenance=numerical_provenance)
    if budgeted:result.update(remesh_decisions=decisions,remesh_spent=encoded(spent))
    if continuation:result['continuation']=continuation
    if refining:result.update(refinement_events=refinement_events,refinement_decisions=refinement_decisions,refinement_spent=encoded(refinement_spent),pair_steps_spent=pair_steps,
                              mesh_dimensions=leaf_mesh.dimensions(x))
    if width_limited:result['effective_softening_m']=rational(x['epsilon']*state['radius_m'])
    if opened:
        boundary_watchdog.totals(cells,accounts)
        result.update(schema='civsim.rotating-barotropic.open.run.v1',model_id=model['model_id'],
                      boundary_accounts=copy.deepcopy(accounts),continuation_supported=False)
    if finite:
        finite_cloud_watchdog.accounts(x,cells,accounts)
        result.update(schema='civsim.rotating-barotropic.finite.run.v2' if continuation else 'civsim.rotating-barotropic.finite.run.v1',model_id=model['model_id'],
                      boundary_accounts=copy.deepcopy(accounts),continuation_supported=bool(continuation),gravity_domain='all_resolved_gas')
    return result


def main():
    p=argparse.ArgumentParser(allow_abbrev=False)
    p.add_argument('--model',required=True);p.add_argument('--state',type=Path,required=True)
    p.add_argument('--numerics',type=Path,required=True);p.add_argument('--floor-receipt',type=Path,required=True)
    p.add_argument('--journal',type=Path);p.add_argument('--kernel-cache',type=Path);p.add_argument('--workers',type=int)
    p.add_argument('--continue-from',type=Path)
    p.add_argument('--wall-seconds',type=int)
    for flag in ('--model','--state','--numerics','--floor-receipt','--journal','--kernel-cache','--workers','--continue-from','--wall-seconds'):
        if sum(a==flag or a.startswith(flag+'=') for a in sys.argv[1:])>1:raise ValueError('duplicate CLI option')
    args=p.parse_args()
    if args.model not in (MODEL_ID,OPEN_MODEL_ID,FINITE_MODEL_ID):raise ValueError('unsupported spatial model')
    if args.model==OPEN_MODEL_ID and args.continue_from:raise ValueError('open boundary continuation not admitted')
    if args.workers is not None and not 1<=args.workers<=16:raise ValueError('worker resource envelope')
    model=models.load(args.floor_receipt,args.model);start_ids=implementations();journal=None
    if args.journal:journal=args.journal.open('x',encoding='ascii',newline='\n')
    began=time.monotonic();last_progress=began
    deferred_deadline=args.model==FINITE_MODEL_ID and args.continue_from is not None
    requested_deadline=Deadline(args.wall_seconds) if args.wall_seconds is not None else None
    deadline=None if deferred_deadline else requested_deadline
    def frame(value):
        if journal:journal.write(canonical_json(value));journal.flush()
    def progress(kind,value):
        nonlocal last_progress
        now=time.monotonic()
        if kind!='accepted' or value['step']%32==0 or now-last_progress>=10:
            from decimal import Decimal,localcontext
            def display(q):
                with localcontext() as ctx:ctx.prec=9;return str(Decimal(q.numerator)/Decimal(q.denominator))
            reading=dict(value)
            if kind=='accepted':
                obs=value['observation'];reading=dict(step=value['step'],time_s=display(value['time_s']),density_kg_m3=display(obs['peak_density_kg_m3']),flattening2=display(obs['flattening_ratio_squared']),stiffened_cells=obs['stiffened_cells'])
            elif kind=='remesh-checked':
                reading=dict(step=value['step'],revision=value['revision'],density_l1_mass_fraction=display(value['density_l1_mass_fraction']))
            print('CIVSIM_ROTATING_PROGRESS '+kind+' '+json.dumps(reading,sort_keys=True)+f' wall_s={now-began:.1f}',file=sys.stderr,flush=True);last_progress=now
    try:
        state_text=args.state.read_text(encoding='ascii');cfg_text=args.numerics.read_text(encoding='ascii');prefix=None
        if args.continue_from:
            proposal=checkpoint.read(args.continue_from)
            prefix=checkpoint_watchdog.authorize(proposal,state_text,model,solve,start_ids,checkpoint.text,progress,args.kernel_cache,args.workers)
            checkpoint.matched(proposal,prefix.value)
            if deferred_deadline and args.wall_seconds is not None:deadline=Deadline(args.wall_seconds)
        result=solve(state_text,cfg_text,model,progress,frame,args.kernel_cache,args.workers,_resume=prefix,stop_requested=deadline)
    finally:
        if journal:journal.close()
    models.validate(model)
    if result['schema'] in ('civsim.rotating-barotropic.open.run.v1','civsim.rotating-barotropic.finite.run.v1','civsim.rotating-barotropic.finite.run.v2') and result['numerics']['schema']!='civsim.rotating-barotropic.numerics.v2':
        version=int(result['numerics']['schema'].rsplit('v',1)[1]);witnesses=adapt_watchdog.source(ROOT)
        if version>=4:witnesses.update(remap_budget_watchdog.source(ROOT))
        if version>=5:witnesses.update(refine_watchdog.source(ROOT))
        if version>=6:witnesses.update(leaf_refine_watchdog.source(ROOT))
        if version>=7:witnesses.update(softening_watchdog.source(ROOT))
        if result['schema']=='civsim.rotating-barotropic.finite.run.v2':
            witnesses.update(checkpoint_watchdog.source(ROOT,True))
            witnesses.update(finite_checkpoint_watchdog.source(ROOT))
        input_watchdog.demand(result['numerical_provenance']==witnesses,'boundary numerical witness changed during run')
    if result['schema'] in ('civsim.rotating-barotropic.run.v3','civsim.rotating-barotropic.run.v4','civsim.rotating-barotropic.run.v5','civsim.rotating-barotropic.run.v6','civsim.rotating-barotropic.run.v7','civsim.rotating-barotropic.run.v8','civsim.rotating-barotropic.run.v9','civsim.rotating-barotropic.run.v10'):
        witnesses=adapt_watchdog.source(ROOT)
        if result['schema'] in ('civsim.rotating-barotropic.run.v4','civsim.rotating-barotropic.run.v5','civsim.rotating-barotropic.run.v6','civsim.rotating-barotropic.run.v7','civsim.rotating-barotropic.run.v8','civsim.rotating-barotropic.run.v9','civsim.rotating-barotropic.run.v10'):witnesses.update(remap_budget_watchdog.source(ROOT))
        if result['schema'] in ('civsim.rotating-barotropic.run.v5','civsim.rotating-barotropic.run.v8','civsim.rotating-barotropic.run.v10'):witnesses.update(checkpoint_watchdog.source(ROOT,result['schema']!='civsim.rotating-barotropic.run.v5'))
        if result['schema'] in ('civsim.rotating-barotropic.run.v6','civsim.rotating-barotropic.run.v7','civsim.rotating-barotropic.run.v8','civsim.rotating-barotropic.run.v9','civsim.rotating-barotropic.run.v10'):witnesses.update(refine_watchdog.source(ROOT))
        if result['schema'] in ('civsim.rotating-barotropic.run.v7','civsim.rotating-barotropic.run.v8','civsim.rotating-barotropic.run.v9','civsim.rotating-barotropic.run.v10'):witnesses.update(leaf_refine_watchdog.source(ROOT))
        if result['schema'] in ('civsim.rotating-barotropic.run.v9','civsim.rotating-barotropic.run.v10'):witnesses.update(softening_watchdog.source(ROOT))
        input_watchdog.demand(result['numerical_provenance']==witnesses,'numerical witness changed during run')
    if start_ids!=implementations():raise ValueError('implementation changed during run')
    result['implementations']=start_ids
    result['execution_identity']=digest(canonical_json(dict(physical_identity=result['physical_identity'],numerics=result['numerics'],implementations=start_ids)).encode('ascii'))
    sys.stdout.write(canonical_json(result));sys.stdout.flush()


if __name__=='__main__':
    try:main()
    except (ValueError,OSError,KeyError,ZeroDivisionError) as error:
        print('rotating-core refusal: '+str(error),file=sys.stderr);raise SystemExit(2)
