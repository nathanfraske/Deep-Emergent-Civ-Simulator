"""Independent continuation admission, full replay equality and sealed prefix.

The replay callback executes the existing paired gas integrator, including
all independent physical, stage, timestep and remap checks. No supplied cell
or hash skips integration from the original dilute physical entry.
"""
from copy import deepcopy
from hashlib import sha256
from fractions import Fraction as F
from pathlib import Path
from arithmetic import canonical_json, parse_rational
from .input_watchdog import demand

WITNESS='sources/barotropic_core/continuation-equations.txt'
PIN='0183022defbf5e9c1465b7ed11db6dda9b0a5b476d71e47e97e885bbc8eff368'
_SEAL=object()


class _Prefix:
    def __init__(self,result,ids,seal):
        demand(seal is _SEAL,'prefix constructor')
        self.value=deepcopy(result);self.ids=dict(ids)
        self.binding=sha256(canonical_json(self.value).encode('ascii')).hexdigest()


SELECTIVE_WITNESS='sources/barotropic_core/selective-continuation-equations.txt'
SELECTIVE_PIN='5606ec71a90a30d312abcaba43adfe253e84184423feb6136fb8a304f0bc7622'


def source(root,selective=False):
    data=(root/WITNESS).read_bytes().replace(b'\r\n',b'\n')
    demand(sha256(data).hexdigest()==PIN,'continuation source identity')
    result={WITNESS:PIN}
    if selective:
        extra=(root/SELECTIVE_WITNESS).read_bytes().replace(b'\r\n',b'\n')
        demand(sha256(extra).hexdigest()==SELECTIVE_PIN,'selective continuation source identity')
        result[SELECTIVE_WITNESS]=SELECTIVE_PIN
    return result


def strict_equal(a,b):
    demand(type(a) is type(b),'checkpoint value type')
    if isinstance(a,dict):
        demand(set(a)==set(b),'checkpoint complete field inventory')
        for key in a:strict_equal(a[key],b[key])
    elif isinstance(a,list):
        demand(len(a)==len(b),'checkpoint array census')
        for x,y in zip(a,b):strict_equal(x,y)
    else:demand(a==b,'checkpoint exact scientific value')


def extension(before,after,step,clock,time_unit,scale):
    changes={'max_steps','max_elapsed_s','sample_every','max_pair_steps'}
    demand(before['schema']==after['schema'] and before['schema'] in ('civsim.rotating-barotropic.numerics.v4','civsim.rotating-barotropic.numerics.v6','civsim.rotating-barotropic.numerics.v7'),'budgeted continuation domain')
    demand(set(before)==set(after),'continuation numerical inventory')
    for key in set(before)-changes:demand(before[key]==after[key],'unchanged causal numerical field '+key)
    demand(after['max_steps']>=before['max_steps'] and after['max_steps']>step,'cumulative step capacity')
    demand(after['max_elapsed_s']>=before['max_elapsed_s'] and after['max_elapsed_s']>F(clock,scale)*time_unit,'later requested endpoint')
    demand(after['max_pair_steps']>=before['max_pair_steps'],'cumulative work capacity')


def lineage(parent,cfg,got):
    selective=cfg['schema'] in ('civsim.rotating-barotropic.numerics.v6','civsim.rotating-barotropic.numerics.v7')
    schema='civsim.rotating-barotropic.continuation.v2' if selective else 'civsim.rotating-barotropic.continuation.v1'
    demand(set(got)=={'schema','origin_numerics','segments'} and got['schema']==schema,'lineage inventory')
    old=parent.get('continuation');expected=list(old['segments']) if old else []
    expected.append(dict(numerics=cfg,from_step=parent['steps'],from_clock_q=parent['frames'][-1]['clock_q'],from_trace_sha256=parent['trace_sha256']))
    if selective:expected[-1]['from_stop_reason']=parent['stop_reason']
    strict_equal(got['origin_numerics'],old['origin_numerics'] if old else parent['numerics'])
    strict_equal(got['segments'],expected);demand(len(expected)<=8,'continuation segment resource')


def authorize(proposal,state_text,model,integrate,ids,format_input,progress=None,kernel_cache=None,workers=None):
    """Re-integrate original gas and every supplied extension before admission."""
    from . import inputs,input_watchdog
    demand(type(proposal) is dict and proposal.get('accepted') is True,'accepted checkpoint proposal')
    demand(proposal.get('schema') in ('civsim.rotating-barotropic.run.v4','civsim.rotating-barotropic.run.v5','civsim.rotating-barotropic.run.v7','civsim.rotating-barotropic.run.v8','civsim.rotating-barotropic.run.v9','civsim.rotating-barotropic.run.v10','civsim.rotating-barotropic.finite.run.v1','civsim.rotating-barotropic.finite.run.v2'),'checkpoint schema')
    finite=proposal['schema'] in ('civsim.rotating-barotropic.finite.run.v1','civsim.rotating-barotropic.finite.run.v2')
    demand(finite==(model['model_id']=='axisymmetric_bate1998_barotropic_finite_cloud_v1'),'checkpoint model domain')
    # Input formatting is low-level exact decimal serialization, never admission.
    state=inputs.state(state_text);input_watchdog.check(state_text,state,'state')
    original_text=format_input(proposal['state'])
    original_state=inputs.state(original_text);input_watchdog.check(original_text,original_state,'state')
    demand({k:v for k,v in state.items() if k!='description'}=={k:v for k,v in original_state.items() if k!='description'},'same original physical gas')
    def wire(x):
        if isinstance(x,F):return str(x.numerator)+'/'+str(x.denominator)
        if type(x) is dict:return {k:wire(v) for k,v in x.items()}
        if type(x) in (list,tuple):return [wire(v) for v in x]
        return x
    strict_equal(proposal['model'],wire(model))
    origin=proposal['numerics'];segments=[]
    width_limited=proposal['schema'] in ('civsim.rotating-barotropic.run.v9','civsim.rotating-barotropic.run.v10') or finite and origin['schema']=='civsim.rotating-barotropic.numerics.v7'
    selective=width_limited or proposal['schema'] in ('civsim.rotating-barotropic.run.v7','civsim.rotating-barotropic.run.v8')
    if finite:
        demand(origin['schema'] in ('civsim.rotating-barotropic.numerics.v6','civsim.rotating-barotropic.numerics.v7'),'finite continuation numerical domain')
        selective=True
        from . import finite_checkpoint_watchdog
        finite_checkpoint_watchdog.source(Path(__file__).resolve().parents[2])
    if proposal['schema'] in ('civsim.rotating-barotropic.run.v5','civsim.rotating-barotropic.run.v8','civsim.rotating-barotropic.run.v10','civsim.rotating-barotropic.finite.run.v2'):
        chain=proposal['continuation']
        demand(type(chain) is dict and set(chain)=={'schema','origin_numerics','segments'},'supplied lineage inventory')
        demand(chain['schema']==('civsim.rotating-barotropic.continuation.v2' if selective else 'civsim.rotating-barotropic.continuation.v1') and type(chain['segments']) is list and 1<=len(chain['segments'])<=8,'supplied segment domain')
        origin=chain['origin_numerics'];segments=chain['segments']
    origin_text=format_input(origin);cfg=inputs.numerics(origin_text);input_watchdog.check(origin_text,cfg,'numerics')
    demand(cfg['schema']==('civsim.rotating-barotropic.numerics.v7' if width_limited else 'civsim.rotating-barotropic.numerics.v6' if selective else 'civsim.rotating-barotropic.numerics.v4'),'original checkpoint numerics')
    if selective:source(Path(__file__).resolve().parents[2],True)
    def cut(receipt):
        if receipt['stop_reason']!='execution_limit':return None
        demand(selective and type(receipt['steps']) is int and 0<=receipt['steps']<cfg['max_steps'],'checked execution cut domain')
        return receipt['steps']
    first_cut=dict(stop_reason=segments[0]['from_stop_reason'],steps=segments[0]['from_step']) if segments and selective else proposal
    replay_options=dict(_stop_step=cut(first_cut)) if selective else {}
    if progress:progress('prefix-replay-start',dict(segments=len(segments),claimed_steps=proposal['steps']))
    expected=integrate(original_text,origin_text,model,progress=progress,kernel_cache=kernel_cache,workers=workers,**replay_options)
    for index,entry in enumerate(segments):
        inventory={'numerics','from_step','from_clock_q','from_trace_sha256'}|({'from_stop_reason'} if selective else set())
        demand(type(entry) is dict and set(entry)==inventory,'supplied segment fields')
        demand(type(entry['from_step']) is int and type(entry['from_clock_q']) is int,'segment clock types')
        demand(entry['from_step']==expected['steps'] and entry['from_clock_q']==expected['frames'][-1]['clock_q'] and entry['from_trace_sha256']==expected['trace_sha256'],'segment parent binding')
        if selective:demand(entry['from_stop_reason']==expected['stop_reason'],'segment parent stopping condition')
        sealed=_Prefix(expected,ids,_SEAL)
        cfg=inputs.numerics(format_input(entry['numerics']))
        next_cut=dict(stop_reason=segments[index+1]['from_stop_reason'],steps=segments[index+1]['from_step']) if selective and index+1<len(segments) else proposal
        options=dict(_stop_step=cut(next_cut)) if selective else {}
        expected=integrate(original_text,format_input(entry['numerics']),model,progress=progress,kernel_cache=kernel_cache,workers=workers,_resume=sealed,**options)
    strict_equal({k:v for k,v in proposal.items() if k not in ('implementations','execution_identity')},expected)
    # Historical executable claims remain custody metadata. Current replay is authority.
    if 'implementations' in proposal:
        demand(type(proposal['implementations']) is dict and all(type(k) is str and type(v) is str and len(v)==64 and set(v)<=set('0123456789abcdef') for k,v in proposal['implementations'].items()),'claimed implementation hash inventory')
        from arithmetic import digest
        binding=digest(canonical_json(dict(physical_identity=proposal['physical_identity'],numerics=proposal['numerics'],implementations=proposal['implementations'])).encode('ascii'))
        demand(proposal.get('execution_identity')==binding,'claimed execution binding')
    if progress:progress('prefix-replay-checked',dict(steps=expected['steps'],trace_sha256=expected['trace_sha256']))
    return _Prefix(expected,ids,_SEAL)


def restore(prefix,state,cfg,model,ids,time_unit,scale):
    from . import inputs
    demand(type(prefix) is _Prefix and prefix.ids==ids,'current independently replayed prefix')
    value=deepcopy(prefix.value)
    demand(sha256(canonical_json(value).encode('ascii')).hexdigest()==prefix.binding,'immutable prefix state')
    # Independent Fraction wire read; field schema was established by full replay.
    def decode(x):
        if type(x) is str:
            import re
            if re.fullmatch(r'-?\d+/\d+',x):return parse_rational(x)
        if type(x) is list:return [decode(v) for v in x]
        if type(x) is dict:return {k:decode(v) for k,v in x.items()}
        return x
    observed=decode(value)
    demand({k:v for k,v in observed['state'].items() if k!='description'}=={k:v for k,v in state.items() if k!='description'},'restored original entry')
    demand(observed['model']==model,'restored source model')
    extension(observed['numerics'],cfg,value['steps'],value['frames'][-1]['clock_q'],time_unit,scale)
    return value,observed
