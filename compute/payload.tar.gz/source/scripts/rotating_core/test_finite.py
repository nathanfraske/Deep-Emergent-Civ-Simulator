"""Finite gas ownership, independent integrals, surrounding force and refusals."""
from pathlib import Path
from fractions import Fraction as F
import copy,json,sys,tempfile,unittest
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'scripts/radial_core')]
import pi_pair
from arithmetic import qfraction
from scripts.rotating_core import finite_cloud,finite_cloud_watchdog,inputs,input_watchdog,mesh,mesh_watchdog,model,run
from scripts.rotating_core import boundary_watchdog,gravity,gravity_watchdog
from scripts.rotating_core.test_core import STATE,SMALL

FINITE=(ROOT/'examples/rotating-core/finite-cloud.state').read_text(encoding='ascii')


class FiniteTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scratch=tempfile.TemporaryDirectory(prefix='civsim-finite-test-')
        floor=Path(cls.scratch.name)/'floor.json'
        # Arithmetic/source fixture only; runnable cases acquire the native floor.
        floor.write_text(json.dumps(dict(schema='civsim.radial-core.floor.v1',G='6.67430e-11',floor_digest='e0cfd4a60342488054ddfa936599794e1697c0bd0997122c22e58047cde0aeb5')))
        cls.model=model.load(floor,run.FINITE_MODEL_ID);cls.wall=model.load(floor)

    @classmethod
    def tearDownClass(cls):cls.scratch.cleanup()

    def gas(self,text=FINITE,bits=96):
        state=inputs.state(text);cfg=inputs.numerics(SMALL.replace('fraction_bits=96','fraction_bits='+str(bits)))
        pi=pi_pair.value(bits);pressure=self.model['pressure']
        input_watchdog.check(text,state,'state');input_watchdog.physical(state,cfg,pressure,pi)
        x=mesh.build(state,cfg,pressure,pi);x.update(boundary_mode='reflecting_slip',gravity_domain='all_resolved_gas')
        mesh_watchdog.geometry(state,cfg,pressure,pi,x)
        cells=finite_cloud.project(x,state,pressure);finite_cloud_watchdog.initial(x,state,cfg,pressure,cells)
        return state,cfg,x,cells

    def test_closed_domain_and_model_cross_pairing(self):
        state=inputs.state(FINITE);input_watchdog.check(FINITE,state,'state')
        for bad in (FINITE+'stellar_mass_kg=1\n',FINITE.replace('all_resolved_gas','neglected'),
                    FINITE.replace('reflecting_slip','extrapolated_cylinder'),FINITE.replace('inner_mass_kg=2e30','inner_mass_kg=2.5e30'),
                    FINITE.replace('inner_radius_m=7e14','inner_radius_m=1.4e15'),FINITE.replace('declared_hypothesis','observed')):
            with self.subTest(bad=bad),self.assertRaises(ValueError):inputs.state(bad)
            with self.assertRaises(ValueError):input_watchdog.check(bad,state,'state')
        with self.assertRaises(ValueError):run.solve(FINITE,SMALL,self.wall,workers=1)
        with self.assertRaises(ValueError):run.solve(STATE,SMALL,self.model,workers=1)
        changed=copy.deepcopy(self.model);changed['provenance']['sources/barotropic_core/rotating-finite-equations.txt']='0'*64
        with self.assertRaises(ValueError):model.validate(changed)

    def test_hidden_continuous_dense_region_refuses_before_projection(self):
        raw=FINITE.replace('inner_radius_m=7e14','inner_radius_m=1e9').replace('inner_half_height_m=7e14','inner_half_height_m=1e9')
        state=inputs.state(raw);cfg=inputs.numerics(SMALL)
        with self.assertRaisesRegex(ValueError,'both continuous'):input_watchdog.physical(state,cfg,self.model['pressure'],pi_pair.value(96))
        with self.assertRaisesRegex(ValueError,'both continuous'):run.solve(raw,SMALL,self.model,workers=1)

    def test_region_integrals_project_signed_motion_and_moments(self):
        raw=FINITE.replace('radial_edge_velocity_m_s=0','radial_edge_velocity_m_s=-20').replace('axial_edge_velocity_m_s=0','axial_edge_velocity_m_s=30')
        for bits in (96,128,160):
            state,cfg,x,cells=self.gas(raw,bits)
            self.assertEqual(sum(row[0] for row in cells),1<<bits)
            self.assertTrue(any(row[1]<0 for row in cells));self.assertTrue(any(row[2]>0 for row in cells));self.assertTrue(any(row[2]<0 for row in cells))
            f=state['inner_mass_kg']/state['mass_kg'];a=state['inner_radius_m']/state['radius_m'];h=state['inner_half_height_m']/state['radius_m'];beta=state['half_height_m']/state['radius_m']
            exact_r2=f*a*a/2+(1-f)*(beta-a**4*h)/(2*(beta-a*a*h))
            expected=state['angular_velocity_s_inv']*state['radius_m']*exact_r2/self.model['pressure']['sound_speed_m_s']
            self.assertLess(abs(F(sum(row[3] for row in cells),x['s'])-expected),F(2*len(cells)*(1+abs(expected)),x['s']))

    def test_changed_geometry_mass_and_motion_refuse(self):
        state,cfg,x,cells=self.gas()
        for component in range(4):
            bad=copy.deepcopy(cells);bad[6][component]+=1
            with self.assertRaises(ValueError):finite_cloud_watchdog.initial(x,state,cfg,self.model['pressure'],bad)
        bad=copy.deepcopy(x);bad['rf'][2]+=F(1,100)
        with self.assertRaises(ValueError):finite_cloud_watchdog.initial(bad,state,cfg,self.model['pressure'],cells)
        for key,value in (('gravity_domain','inner_only'),('boundary_mode','extrapolated_cylinder')):
            bad=dict(x,**{key:value})
            with self.assertRaises(ValueError):finite_cloud_watchdog.physical(bad,cells,state,self.model['pressure'])

    def test_surrounding_material_contributes_checked_gravity(self):
        state,cfg,x,cells=self.gas();rows=gravity.kernel(x,1)
        gravity_watchdog.kernel(x,rows,1);matrix=gravity.matrices(x,rows)
        full=gravity.field(x,cells,matrix);gravity_watchdog.field(x,cells,rows,full)
        r=state['inner_radius_m']/state['radius_m'];h=state['inner_half_height_m']/state['radius_m'];density=(state['inner_mass_kg']/state['mass_kg'])/(r*r*h)
        inner=[]
        for j in range(x['nz']):
            for i in range(x['nr']):
                lo,hi=x['rf'][i],min(x['rf'][i+1],r);bottom,top=max(x['zf'][j],-h),min(x['zf'][j+1],h)
                mass=qfraction(density*(hi*hi-lo*lo)*(top-bottom)/2,x['s']) if hi>lo and top>bottom else 0
                inner.append([mass,0,0,0])
        inner_force=gravity.field(x,inner,matrix)
        self.assertNotEqual(full,inner_force)
        with self.assertRaises(ValueError):gravity_watchdog.field(x,cells,rows,inner_force)

    def test_uniform_limit_preserves_original_gas_trajectory(self):
        raw=FINITE.replace('mass_kg=2.5e30','mass_kg=2e30').replace('radius_m=1.4e15','radius_m=7e14').replace('half_height_m=1.4e15','half_height_m=7e14')
        raw=raw.replace('inner_mass_kg=2e30','inner_mass_kg=2.5e29').replace('inner_radius_m=7e14','inner_radius_m=3.5e14').replace('inner_half_height_m=7e14','inner_half_height_m=3.5e14')
        state,cfg,x,cells=self.gas(raw)
        reference=mesh.project(x,inputs.state(STATE),self.model['pressure']);self.assertEqual(cells,reference)
        finite=run.solve(raw,SMALL,self.model,workers=1);wall=run.solve(STATE,SMALL,self.wall,workers=1)
        self.assertEqual(finite['final_observation'],wall['final_observation'])
        for one,two in zip(finite['frames'],wall['frames']):
            for key in ('step','clock_q','time_s','cell_q','rho_q','pressure_q','observation'):self.assertEqual(one[key],two[key])

    def test_finite_accounts_reject_material_creation_and_mutation(self):
        row=run.solve(FINITE,SMALL,self.model,workers=1)
        self.assertEqual(row['schema'],'civsim.rotating-barotropic.finite.run.v1')
        self.assertEqual(row['initial_observation']['total_mass_kg'],row['final_observation']['total_mass_kg'])
        self.assertEqual(row['initial_observation']['angular_momentum_kg_m2_s'],row['final_observation']['angular_momentum_kg_m2_s'])
        state,cfg,x,_=self.gas()
        for frame in row['frames']:
            ledger=frame['boundary_accounts'];finite_cloud_watchdog.accounts(x,frame['cell_q'],ledger)
            self.assertEqual(ledger['gross_inward_mass_q'],0);self.assertEqual(ledger['residual_q4'],[0]*4)
        for key in ('initial_q4','outward_q4','endpoint_q4','residual_q4'):
            bad=copy.deepcopy(row['boundary_accounts']);bad[key][0]+=1
            with self.assertRaises(ValueError):finite_cloud_watchdog.accounts(x,row['frames'][-1]['cell_q'],bad)
        bad=copy.deepcopy(row['boundary_accounts']);bad['gross_inward_mass_q']=bad['gross_outward_mass_q']=1
        with self.assertRaises(ValueError):finite_cloud_watchdog.accounts(x,row['frames'][-1]['cell_q'],bad)

    def test_repeat_spin_observer_and_checked_cut(self):
        plus=run.solve(FINITE,SMALL,self.model,workers=1)
        def observer(frame):frame['boundary_accounts']['gross_inward_mass_q']=1;frame['cell_q'][0][0]=1
        self.assertEqual(plus,run.solve(FINITE,SMALL,self.model,workers=1,on_frame=observer))
        sampled=run.solve(FINITE.replace('description=','description=Observer '),SMALL.replace('sample_every=4','sample_every=2'),self.model,workers=1)
        self.assertEqual((plus['trace_sha256'],plus['physical_identity']),(sampled['trace_sha256'],sampled['physical_identity']))
        minus=run.solve(FINITE.replace('angular_velocity_s_inv=2e-13','angular_velocity_s_inv=-2e-13'),SMALL,self.model,workers=1)
        for a,b in zip(plus['frames'][-1]['cell_q'],minus['frames'][-1]['cell_q']):self.assertEqual(a[:3]+[-a[3]],b)
        cut=run.solve(FINITE,SMALL,self.model,workers=1,_stop_step=2)
        self.assertEqual((cut['steps'],cut['stop_reason']),(2,'execution_limit'));self.assertFalse(cut['completed_system']);self.assertFalse(cut['disk_assessed'])
        with self.assertRaisesRegex(ValueError,'continuation'):run.solve(FINITE,SMALL,self.model,workers=1,_resume=object())


if __name__=='__main__':unittest.main()
