"""Independent closed model inventory and immutable source-byte binding."""
from hashlib import sha256
import tomllib
from .input_watchdog import demand

PINNED = {
    'sources/barotropic_core/rotating.toml':'2a557e9e96d69815bee985f78897ccdcab7e090feb6b4797efd271d6abedf6af',
    'sources/barotropic_core/bate98.toml':'1dab4ece44d3a0ef72c92e246ca6d2a561b3d68f952e486d7a1a6ccd5990d9a3',
    'sources/barotropic_core/equations.txt':'2ea85fd8106430f02d09b69a59fefe7e4a893d1d61941b53b50f6a43905ca9b5',
    'sources/axisymmetric_gravity/equations.txt':'77d8a5b1436dba8c27c7076fd78768e437dc7a0911f43b900d5e7a214371dcfe',
    'sources/finite_volume_reconstruction/core-mesh.txt':'41c95df747048af092c8f21bac3e27d587259bce18d715e81a51f998251aafa8',
    'sources/gas_dynamics/Approximate_solvers.ipynb':'b07ac9a06fa386e3f24847ccc5f7982f7032b5c3e6704c60acbd4405705d2cc2',
    'sources/barotropic_core/rotating-equations.txt':'e4dbf5beb818b0bec296450696db2fe02055bf6106a7d26bd7638fd8378e35dc',
}

OPEN_PINNED={**PINNED,**{'sources/barotropic_core/rotating-open.toml': '0b114b87b144fca9e6f3401a93305858a71872d3a78d1f840fd1b9d30646f220', 'sources/barotropic_core/rotating-open-equations.txt': '4325ce06201bd3990a91c49ab793329f2f98d87651615a246ec113945c4a7823', 'sources/open_boundary/bc.rst': 'c31bee71c7e9f154fa5368e45f62ac27bede459e6d5c2af61b78c299bde36a42', 'sources/open_boundary/LICENSE': '2a76c25090cf658402d827f7c7657d85b3b02dc79b2b621b782a5d51556e5de1'}}


FINITE_PINNED={**PINNED,**{'sources/barotropic_core/rotating-finite.toml':'15e1b7ca5c86c1aff9449f473f912210e6e612973a1effea1397686e2d3f4485',
    'sources/barotropic_core/rotating-finite-equations.txt':'5293005082d0173be53d0689f73d6d713c55dff3ea6632d67f5a41fc3b301016',
    'sources/open_boundary/bc.rst':'c31bee71c7e9f154fa5368e45f62ac27bede459e6d5c2af61b78c299bde36a42',
    'sources/open_boundary/LICENSE':'2a76c25090cf658402d827f7c7657d85b3b02dc79b2b621b782a5d51556e5de1'}}


def check(root,model):
    demand(set(model)=={'pressure','model_id','scope','uncertainty','provenance'},'closed spatial model')

    opened=model['model_id']=='axisymmetric_bate1998_barotropic_open_v1'
    finite=model['model_id']=='axisymmetric_bate1998_barotropic_finite_cloud_v1'
    demand(finite or opened or model['model_id']=='axisymmetric_bate1998_barotropic_v1','spatial model identity')
    pinned=FINITE_PINNED if finite else OPEN_PINNED if opened else PINNED
    profile='sources/barotropic_core/rotating-finite.toml' if finite else 'sources/barotropic_core/rotating-open.toml' if opened else 'sources/barotropic_core/rotating.toml'
    record=tomllib.loads((root/profile).read_text(encoding='ascii'))
    names={'schema','model_id','pressure_profile','pressure_witness','fluid_witness','mesh_witness','numerical_flux_source','local_derivation','scope','uncertainty'}
    keys=['pressure_profile','pressure_witness','fluid_witness','mesh_witness','numerical_flux_source','local_derivation']
    if opened or finite:
        names|={'base_spatial_profile','boundary_source','boundary_license','boundary_derivation'}
        keys+=['base_spatial_profile','boundary_source','boundary_license','boundary_derivation']
    demand(set(record)==names and record['schema']==('civsim.rotating-barotropic-profile.v3' if finite else 'civsim.rotating-barotropic-profile.v2' if opened else 'civsim.rotating-barotropic-profile.v1'),'source profile inventory')
    for key in ('model_id','scope','uncertainty'):demand(record[key]==model[key],'model scope '+key)
    demand(len(pinned)==(11 if opened or finite else 7) and set(model['provenance'])==set(pinned),'complete model custody')
    paths=[profile]+[record[k] for k in keys]
    demand(set(paths)==set(pinned),'source path substitutions')
    for path,want in pinned.items():
        data=(root/path).read_bytes().replace(b'\r\n',b'\n')
        demand(b'\r' not in data and sha256(data).hexdigest()==want==model['provenance'][path],'held source identity '+path)
