"""Independent inverse-CDF equations and numerical-witness custody checks."""
from fractions import Fraction as F
from hashlib import sha256
from .input_watchdog import demand
from .mesh_watchdog import round_cell

WITNESS='sources/barotropic_core/remap-equations.txt'
PIN='8150c5d3751b390db8e7e3f51a2fb6a4909507752c59da4403e0db3ca7b78c36'


def source(root):
    data=(root/WITNESS).read_bytes().replace(b'\r\n',b'\n')
    demand(b'\r' not in data and sha256(data).hexdigest()==PIN,'remap numerical witness custody')
    return {WITNESS:PIN}


def check(x,cells,cfg,got):
    demand(set(got)=={'r','z'} and len(got['r'])==x['nr']+1 and len(got['z'])==x['nz']+1,'adaptive face census')
    mass=sum(row[0] for row in cells);eta=cfg['remesh_regularization'];alpha=cfg['remesh_relaxation'];s=x['s']
    for axis,count,edges in ((0,x['nr'],x['rf']),(1,x['nz'],x['zf'])):
        coordinate=[r*r for r in edges] if axis==0 else edges
        base=coordinate[-1]-coordinate[0];weights=[];cdf=[F(0)]
        for index in range(count):
            indices=range(index,len(cells),x['nr']) if axis==0 else range(index*x['nr'],(index+1)*x['nr'])
            amount=sum(cells[k][0] for k in indices)
            weight=F(amount,mass)*(1-eta)+eta*(coordinate[index+1]-coordinate[index])/base
            demand(weight>0,'positive mass-coordinate measure');weights.append(weight);cdf.append(cdf[-1]+weight)
        demand(cdf[-1]==1,'complete regularized measure')
        received=got['r' if axis==0 else 'z']
        demand(received[0]==edges[0] and received[-1]==edges[-1],'fixed outer geometry')
        for index in range(1,count):
            if axis==0:target=F(index**(2*cfg['mesh_power']),count**(2*cfg['mesh_power']))
            else:
                signed=(1 if 2*index>=count else -1)*abs(2*index-count)**cfg['mesh_power']
                target=(F(signed,count**cfg['mesh_power'])+1)/2
            interval=next(k for k in range(count) if cdf[k]<=target<=cdf[k+1])
            value=coordinate[interval]+(coordinate[interval+1]-coordinate[interval])*(target-cdf[interval])/weights[interval]
            projected=edges[index]+(received[index]-edges[index])/alpha
            q=projected*s;demand(q.denominator==1,'coordinate projection lattice');q=q.numerator
            if axis==0:
                square=value*s*s
                demand(q>=0 and (q==0 or F((2*q-1)**2,4)<=square) and square<=F((2*q+1)**2,4),'nearest square-root coordinate cell')
                if square in (F((2*q-1)**2,4),F((2*q+1)**2,4)):demand(q%2==0,'square-root coordinate tie')
            else:round_cell(q,value*s)
        demand(all(a<b for a,b in zip(received,received[1:])),'positive adapted widths')
