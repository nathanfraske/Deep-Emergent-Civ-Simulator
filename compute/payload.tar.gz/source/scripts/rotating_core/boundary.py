"""Declared extrapolated ghosts, initial bulk motion and accepted-step accounts."""
from fractions import Fraction as F
from arithmetic import qfraction
from .leaf_mesh import bounds


def ghost(cell):
    return list(cell)


def project(x,cells,state,pressure):
    result=[list(row) for row in cells]
    speed=pressure['sound_speed_m_s'];beta=state['half_height_m']/state['radius_m']
    for row,(lo,hi,bottom,top) in zip(result,bounds(x)):
        center=2*(hi**3-lo**3)/(3*(hi**2-lo**2))
        row[1]=qfraction(row[0]*state['radial_edge_velocity_m_s']*center/speed,1)
        row[2]=qfraction(row[0]*state['axial_edge_velocity_m_s']*(bottom+top)/(2*beta*speed),1)
    return result


def start(cells):
    totals=[sum(row[k] for row in cells) for k in range(4)]
    return dict(schema='civsim.rotating-open.accounts.v1',initial_q4=totals,
                outward_q4=[0]*4,source_q2=[0]*2,endpoint_q4=list(totals),residual_q4=[0]*4,
                gross_inward_mass_q=0,gross_outward_mass_q=0)


# @derives: signed open-boundary gas accounts <- actual accepted rounded face impulses + cylindrical momentum-source impulses + initial finite gas
def advance(x,previous,accepted):
    result={k:list(v) if isinstance(v,list) else v for k,v in previous.items()}
    for (_,left,right,_),impulse in zip(x['faces'],accepted['transfers']):
        sign=1 if right<0 else -1 if left<0 else 0
        if not sign:continue
        for k in range(4):result['outward_q4'][k]+=sign*impulse[k]
        mass=sign*impulse[0]
        result['gross_outward_mass_q']+=max(mass,0)
        result['gross_inward_mass_q']+=max(-mass,0)
    for row in accepted['sources']:
        for k in range(2):result['source_q2'][k]+=row[k]
    result['endpoint_q4']=[sum(row[k] for row in accepted['next']) for k in range(4)]
    for k in range(4):
        source=result['source_q2'][k-1] if k in (1,2) else 0
        result['residual_q4'][k]=result['endpoint_q4'][k]+result['outward_q4'][k]-source-result['initial_q4'][k]
    return result
