"""Independent original-moment and cumulative-account checks for finite restart."""
from hashlib import sha256
from .input_watchdog import demand
from . import boundary_watchdog,finite_cloud_watchdog,checkpoint_watchdog

WITNESS='sources/barotropic_core/finite-continuation-equations.txt'
PIN='ca28202abb29703e075c6cd9153c1fd7bcd2bbeabd49e9860b971bbd44204373'


def source(root):
    data=(root/WITNESS).read_bytes().replace(b'\r\n',b'\n')
    demand(sha256(data).hexdigest()==PIN,'finite continuation source identity')
    return {WITNESS:PIN}


def restoration(x,original_cells,current_cells,restored,parent):
    # Parent reached here only through the current sealed full-history replay.
    boundary_watchdog.inventory(restored)
    finite_cloud_watchdog.accounts(x,current_cells,restored)
    checkpoint_watchdog.strict_equal(restored,parent['boundary_accounts'])
    checkpoint_watchdog.strict_equal(restored,parent['frames'][-1]['boundary_accounts'])
    for component in range(4):
        demand(restored['initial_q4'][component]==sum(row[component] for row in original_cells),
               'restored original finite moment')
        demand(restored['endpoint_q4'][component]==sum(row[component] for row in current_cells),
               'restored current finite moment')
