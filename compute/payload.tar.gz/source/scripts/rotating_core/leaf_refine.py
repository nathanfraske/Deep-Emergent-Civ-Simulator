"""Jeans-driven cell splits and exact conservative descendant allocations."""
from fractions import Fraction as F
from arithmetic import qfraction
from . import leaf_mesh


def plan(x,fields,state,model,cfg):
    levels=[];maximum=F(0);wanted=0
    for box,f in zip(leaf_mesh.bounds(x),fields):
        a,b,c,d=box;density=F(f['rho'],x['s'])*x['rho_unit']
        wavelength2=x['pi']*F(f['cs2'],x['s'])*model['sound_speed_m_s']**2/(model['G']*density)
        ratios=[state['radius_m']**2*v*v/wavelength2 for v in (b-a,d-c)]
        maximum=max(maximum,*ratios);depths=[0,0]
        for axis,q in enumerate(ratios):
            while q>cfg['refinement_target_squared']*4**depths[axis] and depths[axis]<=cfg['refinement_max_depth']:depths[axis]+=1
        levels.append(depths);wanted+=2**sum(depths)
    if maximum<=cfg['refinement_trigger_squared']:
        return dict(schema='civsim.rotating-barotropic.refinement-plan.v2',status='unchanged',levels=None,new_faces=None,required_cells=len(fields),max_ratio_squared=maximum)
    status='depth_limit' if max(v for pair in levels for v in pair)>cfg['refinement_max_depth'] else 'cell_limit' if wanted>cfg['refinement_max_cells'] else 'accepted'
    faces=None
    if status=='accepted':
        boxes=[]
        for (a,b,c,d),(dr,dz) in zip(leaf_mesh.bounds(x),levels):
            for j in range(2**dz):
                for i in range(2**dr):
                    boxes.append((a+(b-a)*F(i,2**dr),a+(b-a)*F(i+1,2**dr),c+(d-c)*F(j,2**dz),c+(d-c)*F(j+1,2**dz)))
        faces=dict(cells=boxes)
    return dict(schema='civsim.rotating-barotropic.refinement-plan.v2',status=status,levels=levels,new_faces=faces,required_cells=wanted,max_ratio_squared=maximum)


def moments(x,cells):
    mass=sum(y[0] for y in cells);radial=vertical=rotation=F(0)
    for (a,b,c,d),y in zip(leaf_mesh.bounds(x),cells):
        r2=(a*a+b*b)/2;radial+=y[0]*r2;vertical+=y[0]*(c*c+c*d+d*d)/3;rotation+=F(y[3]**2,y[0])/r2
    return dict(radial_second_moment=radial/mass,axial_second_moment=vertical/mass,rotational_quadratic=rotation/mass)


def transfer(x,cells,proposal):
    if proposal['status']!='accepted':return None,None
    new=leaf_mesh.rebuild(x,proposal['new_faces']['cells']);projected=[];transfers=[];density_error=angular_error=F(0);target=0
    for source,((a,b,c,d),(dr,dz),y) in enumerate(zip(leaf_mesh.bounds(x),proposal['levels'],cells)):
        volume=(b*b-a*a)*(d-c)/2;inertia=(b**4-a**4)*(d-c)/4
        covered=moment=F(0);previous=[0]*4
        for _ in range(2**(dr+dz)):
            lo,hi,bottom,top=new['cell_bounds'][target]
            v=(hi*hi-lo*lo)*(top-bottom)/2;j4=(hi**4-lo**4)*(top-bottom)/4
            covered+=v;moment+=j4
            current=[qfraction(value*(moment/inertia if k==3 else covered/volume),1) for k,value in enumerate(y)]
            amount=[v-u for v,u in zip(current,previous)];previous=current
            projected.append(amount);transfers.append([source,target,*amount])
            if amount[0]<=0:raise ValueError('leaf split below positive mass quantum')
            density_error+=v*abs(F(y[0])/volume-F(amount[0])/v)
            angular_error+=j4*abs(F(y[3])/inertia-F(amount[3])/j4)
            target+=1
        if covered!=volume or moment!=inertia or previous!=y:raise ValueError('incomplete leaf source cover')
    totals=[sum(y[k] for y in cells) for k in range(4)];after=[sum(y[k] for y in projected) for k in range(4)]
    if totals!=after:raise ValueError('leaf split global account defect')
    angular=sum(abs(y[3]) for y in cells)
    allocation=dict(schema='civsim.rotating-barotropic.remap.v2',transfers=transfers,next=projected,before_totals=totals,after_totals=after,
                    diagnostics=dict(density_l1_mass_fraction=density_error/totals[0],angular_profile_l1_fraction=angular_error/angular if angular else F(0),before=moments(x,cells),after=moments(new,projected)))
    return new,allocation


def within_budget(allocation,spent,cfg):
    return all(spent[key]+allocation['diagnostics'][name]<=cfg['refinement_'+key+'_budget'] for key,name in
               (('density','density_l1_mass_fraction'),('angular','angular_profile_l1_fraction')))
