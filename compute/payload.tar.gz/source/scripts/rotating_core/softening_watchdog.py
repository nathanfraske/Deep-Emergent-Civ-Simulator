"""Independent order/equality residuals for global cell-limited smoothing."""
from hashlib import sha256
from .input_watchdog import demand

WITNESS='sources/barotropic_core/cell-softening-equations.txt'
PIN='43282060c5d877680444ff950e6b57a4183bf22e75029dc189b9ee811b34cc99'


def source(root):
    raw=(root/WITNESS).read_bytes().replace(b'\r\n',b'\n')
    demand(sha256(raw).hexdigest()==PIN,'cell-softening witness identity')
    return {WITNESS:PIN}


def check(x,state,cfg,model):
    cap=cfg['softening_m']/state['radius_m'];e=x['epsilon']
    adaptive=cfg['schema']=='civsim.rotating-barotropic.numerics.v7'
    if not adaptive:
        demand(e==cap and 'softening_ceiling' not in x and 'softening_cell_fraction' not in x,'fixed softening context')
        return
    f=cfg['softening_cell_fraction']
    demand(x.get('softening_ceiling')==cap and x.get('softening_cell_fraction')==f and 0<f<=1,'declared softening coordinates')
    demand(0<e<=cap,'positive bounded effective smoothing')
    equal=e==cap
    if 'cell_bounds' in x:
        edges=[(a,b) for a,b,c,d in reversed(x['cell_bounds'])]+[(c,d) for a,b,c,d in x['cell_bounds']]
    else:
        edges=[(v[i],v[i+1]) for v in (x['zf'],x['rf']) for i in range(len(v)-1)]
    for lower,upper in edges:
        demand(upper>lower and e<=f*(upper-lower),'smoothing cell-span upper bound')
        equal=equal or e==f*(upper-lower)
    demand(equal,'greatest admissible smoothing bound')
    demand(1000*model['G']*state['mass_kg']<=e*state['radius_m']*299792458**2,'effective Newtonian potential screen')
