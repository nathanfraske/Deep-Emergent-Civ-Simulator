"""Read-only deferred diagnostics; no physical acceptance is deferred here."""
from collections.abc import Mapping


class Observation(Mapping):
    def __init__(self,checked_factory):
        self._factory=checked_factory;self._values=None

    def _materialize(self):
        if self._values is None:
            values=self._factory()
            self._values=values;self._factory=None
        return self._values

    def __getitem__(self,key):return self._materialize()[key]
    def __iter__(self):return iter(self._materialize())
    def __len__(self):return len(self._materialize())
