"""Run a native-floor rotating example and retain all raw evidence."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys,time


def main():
    p=argparse.ArgumentParser(allow_abbrev=False)
    for key in ('floor-executable','state','numerics','output-dir'):p.add_argument('--'+key,type=Path,required=True)
    p.add_argument('--continue-from',type=Path)
    p.add_argument('--wall-seconds',type=int)
    p.add_argument('--model',default='axisymmetric_bate1998_barotropic_v1',choices=['axisymmetric_bate1998_barotropic_v1','axisymmetric_bate1998_barotropic_open_v1','axisymmetric_bate1998_barotropic_finite_cloud_v1'])
    p.add_argument('--workers',type=int,default=8);args=p.parse_args();out=args.output_dir.resolve()
    if out.exists():raise ValueError('output exists; choose a fresh evidence directory')
    ancestor=out.parent
    while not ancestor.exists():ancestor=ancestor.parent
    if shutil.disk_usage(ancestor).free<1024**3:raise ValueError('insufficient evidence space')
    if not 1<=args.workers<=16:raise ValueError('worker envelope')
    if args.wall_seconds is not None:
        if not 1<=args.wall_seconds<=86400:raise ValueError('execution wall deadline domain')
    state=args.state.read_bytes();numerics=args.numerics.read_bytes()
    parent=None
    if args.continue_from:
        if not 0<args.continue_from.stat().st_size<=128*1024**2:raise ValueError('checkpoint byte resource')
        parent=args.continue_from.read_bytes()
    native=subprocess.run([str(args.floor_executable.resolve())],capture_output=True,check=True,timeout=120)
    out.mkdir(parents=True);(out/'floor.json').write_bytes(native.stdout);(out/'floor.stderr.txt').write_bytes(native.stderr)
    (out/'state').write_bytes(state);(out/'numerics').write_bytes(numerics)
    command=[sys.executable,'-B',str(Path(__file__).with_name('run.py')),'--model',args.model,
             '--state',str(out/'state'),'--numerics',str(out/'numerics'),'--floor-receipt',str(out/'floor.json'),
             '--journal',str(out/'frames.jsonl'),'--kernel-cache',str(out/'kernel.json'),'--workers',str(args.workers)]
    if parent is not None:
        (out/'parent-receipt.json').write_bytes(parent);command+=['--continue-from',str(out/'parent-receipt.json')]
    if args.wall_seconds is not None:command+=['--wall-seconds',str(args.wall_seconds)]
    start=time.monotonic()
    with (out/'receipt.json').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
        process=subprocess.Popen(command,stdout=stdout,stderr=subprocess.PIPE)
        for line in process.stderr:
            stderr.write(line);stderr.flush();sys.stderr.buffer.write(line);sys.stderr.buffer.flush()
        code=process.wait()
    status=dict(exit_code=code,elapsed_s=time.monotonic()-start,command=command,
                floor_executable_sha256=hashlib.sha256(args.floor_executable.read_bytes()).hexdigest(),
                files={f.name:dict(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in out.iterdir() if f.is_file()})
    (out/'status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='ascii')
    if code:raise SystemExit(code)
    subprocess.run([sys.executable,'-B',str(Path(__file__).with_name('view.py')),str(out/'receipt.json'),str(out/'collapse.png')],check=True)
    print('Checked rotating gas evidence: '+str(out))


if __name__=='__main__':
    try:main()
    except (ValueError,OSError,subprocess.SubprocessError) as error:
        print('rotating example refusal: '+str(error),file=sys.stderr);raise SystemExit(2)
