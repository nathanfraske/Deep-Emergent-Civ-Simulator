"""Source-bound per-stage parallel exact gravity and independent checks."""
import argparse,hashlib,json,sys,time
from pathlib import Path
from scripts.compute.exact_reduce import ExactReducer,available_cpus
from scripts.compute.check_reduce import CheckReducer

class ParallelExecution:
    def __init__(self,run,binary,workers,output,minimum_cells=128):
        from . import packed_field,packed_field_watchdog
        self.run=run;self.binary=Path(binary);self.workers=workers;self.output=Path(output);self.minimum=minimum_cells
        if not 1<=workers<=min(64,available_cpus()):raise ValueError('allocated parallel CPU envelope')
        self.output.mkdir(parents=True,exist_ok=False)
        self.original_force=packed_field.Matrix.force;self.original_check=packed_field_watchdog.SignedSums.reconstruct
        self.producer_context=None;self.check_context=None;self.producer=None;self.checker=None;self.records=[]
        def force(matrix,x,cells):return self.force(matrix,x,cells)
        def reconstruct(context,cells):return self.check(context,cells)
        packed_field.Matrix.force=force;packed_field_watchdog.SignedSums.reconstruct=reconstruct
        self.classes=(packed_field.Matrix,packed_field_watchdog.SignedSums)
        self.original_ids=run.implementations
        root=Path(__file__).resolve().parents[2]
        paths=('scripts/rotating_core/parallel_execution.py','scripts/compute/__init__.py','scripts/compute/exact_reduce.py','scripts/compute/check_reduce.py','scripts/compute/exact_reduce.cpp','scripts/compute/run_gas.py','sources/compute/parallel-equations.txt')
        self.paths={name:root/name for name in paths}
        self.paths['execution/exact_reduce.binary']=self.binary
        self.bindings={name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in self.paths.items()}
        run.implementations=lambda:dict(self.original_ids(),**{name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in self.paths.items()})
        self.start_bindings=dict(run.implementations())
        self.save()
    def save(self):
        row=dict(schema='civsim.parallel-exact-execution.v1',workers=self.workers,minimum_cells=self.minimum,bindings=self.bindings,contexts=self.records,
            producer=self.producer.metrics() if self.producer else None,checker=self.checker.metrics() if self.checker else None,
            scope='Per-stage exact arithmetic; independent Python sign-separated checks remain active. Solver stages and physical admission are separate.')
        tmp=self.output/'execution.tmp';tmp.write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8');tmp.replace(self.output/'execution.json')
    def retire_producer(self):
        if self.producer:self.records.append(dict(kind='producer',**self.producer.metrics()));self.producer.close();self.producer=None
    def retire_checker(self):
        if self.checker:self.records.append(dict(kind='checker',**self.checker.metrics()));self.checker.close();self.checker=None
    def force(self,matrix,x,cells):
        masses=[row[0] for row in cells];n=len(matrix.radial)
        if n<self.minimum or len(masses)!=n or any(type(m) is not int or m<=0 for m in masses) or sum(masses)>matrix.mass_bound:
            return self.original_force(matrix,x,cells)
        if self.producer_context is not matrix:
            self.retire_producer();self.producer=ExactReducer(self.binary,matrix.columns,self.workers);self.producer_context=matrix
        value=self.producer.sum(masses)
        raw=value.to_bytes(2*n*matrix.width,'little');bias=sum(masses)*matrix.offset;den=x['s']**2
        from arithmetic import rounded
        got=[[rounded(-x['gravity']*(int.from_bytes(raw[(2*i+k)*matrix.width:(2*i+k+1)*matrix.width],'little')-bias),den) for k in range(2)] for i in range(n)]
        if self.producer.host_calls<=2 and got!=self.original_force(matrix,x,cells):raise ValueError('parallel producer qualification mismatch')
        if self.producer.host_calls%64==0:self.save()
        return got
    def check(self,context,cells):
        mass=[cell[0] for cell in cells]
        if context.targets<self.minimum or sum(mass)>context.mass_limit:return self.original_check(context,cells)
        if self.check_context is not context:
            self.retire_checker();self.checker=CheckReducer(context.positive,context.negative,self.workers);self.check_context=context
        upper,lower=self.checker.sum(mass);length=2*context.targets*context.digit_bytes
        pos=upper.to_bytes(length,'big');neg=lower.to_bytes(length,'big');out=[]
        for i in range(context.targets):
            out.append([int.from_bytes(pos[(2*i+k)*context.digit_bytes:(2*i+k+1)*context.digit_bytes],'big')-int.from_bytes(neg[(2*i+k)*context.digit_bytes:(2*i+k+1)*context.digit_bytes],'big') for k in (0,1)])
        if self.checker.calls<=2 and out!=self.original_check(context,cells):raise ValueError('parallel independent-check qualification mismatch')
        if self.checker.calls%64==0:self.save()
        return out
    def close(self):
        self.save();self.retire_producer();self.retire_checker();self.save()
        self.classes[0].force=self.original_force;self.classes[1].reconstruct=self.original_check
        current=self.run.implementations();self.run.implementations=self.original_ids
        if current!=self.start_bindings:raise ValueError('parallel execution source changed during run')
    def __enter__(self):return self
    def __exit__(self,*args):self.close()

def main():
    parser=argparse.ArgumentParser(allow_abbrev=False);parser.add_argument('--exact-binary',type=Path,required=True);parser.add_argument('--execution-record-dir',type=Path,required=True);parser.add_argument('--execution-workers',type=int,default=min(16,available_cpus()))
    args,remaining=parser.parse_known_args()
    root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'scripts/radial_core'))
    from . import run
    with ParallelExecution(run,args.exact_binary,args.execution_workers,args.execution_record_dir):
        sys.argv=[str(root/'scripts/rotating_core/run.py')]+remaining;run.main()

if __name__=='__main__':main()
