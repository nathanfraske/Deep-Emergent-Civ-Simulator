"""Selective annular rectangles and one shared impulse per partial face."""
from fractions import Fraction as F
from . import softening


def bounds(x):
    if 'cell_bounds' in x:return x['cell_bounds']
    return [(x['rf'][i],x['rf'][i+1],x['zf'][j],x['zf'][j+1])
            for j in range(x['nz']) for i in range(x['nr'])]


def rebuild(old,rectangles):
    x=dict(old);rectangles=[tuple(v) for v in rectangles]
    x['cell_bounds']=rectangles
    x['volume']=[(b*b-a*a)*(d-c)/2 for a,b,c,d in rectangles]
    x['r']=sorted({(a+b)/2 for a,b,c,d in rectangles})
    x['z']=sorted({(c+d)/2 for a,b,c,d in rectangles})
    x['nr']=len(x['r']);x['nz']=len(x['z'])
    x['cell_r']=[(a+b)/2 for a,b,c,d in rectangles]
    x['cell_z']=[(c+d)/2 for a,b,c,d in rectangles]
    # rf/zf belong only to a tensor partition. Leaf bounds own all geometry.
    x.pop('rf',None);x.pop('zf',None);x.pop('incidence',None)
    faces=[];patches=[]
    for axis in (0,1):
        planes={}
        for k,(a,b,c,d) in enumerate(rectangles):
            lo,hi,bottom,top=(a,b,c,d) if axis==0 else (c,d,a,b)
            planes.setdefault(lo,[[],[]])[1].append((bottom,top,k))
            planes.setdefault(hi,[[],[]])[0].append((bottom,top,k))
        for coordinate,(left,right) in sorted(planes.items()):
            pieces=[]
            if not left or not right:
                for lo,hi,k in left or right:
                    pieces.append((lo,hi,k if left else -1,k if right else -1))
            else:
                for a,b,i in left:
                    for c,d,j in right:
                        lo,hi=max(a,c),min(b,d)
                        if lo<hi:pieces.append((lo,hi,i,j))
            for lo,hi,i,j in sorted(pieces):
                area=coordinate*(hi-lo) if axis==0 else (hi*hi-lo*lo)/2
                faces.append((axis,i,j,area));patches.append((coordinate,lo,hi))
    x['faces']=faces;x['face_patches']=patches
    # Only actual center pairs need ring coefficients; no empty tensor product.
    x['kernel_keys']=sorted({(r,q,abs(z-w)) for r,z in zip(x['cell_r'],x['cell_z'])
                             for q,w in zip(x['cell_r'],x['cell_z'])})
    x['separations']=sorted({v[2] for v in x['kernel_keys']})
    return softening.update(x)


def coordinates(x):
    return dict(cells=bounds(x)) if 'cell_bounds' in x else dict(r=x['rf'],z=x['zf'])


def dimensions(x):
    return dict(cells=len(x['volume'])) if 'cell_bounds' in x else dict(radial=x['nr'],vertical=x['nz'])
