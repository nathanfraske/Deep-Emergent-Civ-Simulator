"""Independent boundary projection, integer telescoping and exterior scope."""
from fractions import Fraction as F
from .input_watchdog import demand
from .mesh_watchdog import round_cell
from .leaf_mesh_watchdog import bounds


def initial(x,before,after,state,pressure):
    demand(state['schema']=='civsim.rotating-barotropic.state.v2' and state['boundary']=='extrapolated_cylinder'
           and state['exterior_gravity']=='neglected' and x.get('boundary_mode')=='extrapolated_cylinder','declared exterior binding')
    demand(len(before)==len(after)==len(x['volume']),'bulk projection census')
    radius=state['radius_m'];height=state['half_height_m'];speed=pressure['sound_speed_m_s']
    for old,new,(r0,r1,z0,z1) in zip(before,after,bounds(x)):
        demand(len(new)==4 and old[0]==new[0] and old[3]==new[3],'bulk projection material and spin')
        volume=(r1*r1-r0*r0)*(z1-z0)/2
        radial_integral=(r1**3-r0**3)*(z1-z0)/3
        axial_integral=(r1*r1-r0*r0)*(z1*z1-z0*z0)/4
        round_cell(new[1],old[0]*state['radial_edge_velocity_m_s']*radial_integral/(volume*speed))
        round_cell(new[2],old[0]*state['axial_edge_velocity_m_s']*radius*axial_integral/(height*volume*speed))


def physical(x,cells,state,pressure):
    demand(x.get('boundary_mode')=='extrapolated_cylinder' and state['exterior_gravity']=='neglected','open exterior scope')
    mass=F(sum(row[0] for row in cells),x['s'])*state['mass_kg']
    demand(mass>0 and 1000*pressure['G']*mass<=x['epsilon']*state['radius_m']*299792458**2,'current enclosed Newtonian potential screen')


def balance(x,old,stage):
    """Sum each interior cell incidence, then compare with volume sources."""
    for component in range(4):
        crossing=0
        for (_,left,right,_),row in zip(x['faces'],stage['transfers']):
            crossing+=(int(left>=0)-int(right>=0))*row[component]
        change=sum(row[component] for row in stage['next'])-sum(row[component] for row in old)
        source=sum(row[component-1] for row in stage['sources']) if component in (1,2) else 0
        demand(change+crossing==source,'signed four-field stage boundary balance')


def inventory(value):
    demand(set(value)=={'schema','initial_q4','outward_q4','source_q2','endpoint_q4','residual_q4','gross_inward_mass_q','gross_outward_mass_q'}
           and value['schema'] in ('civsim.rotating-open.accounts.v1','civsim.rotating-finite.accounts.v1'),'closed boundary ledger')
    for name,width in (('initial_q4',4),('outward_q4',4),('source_q2',2),('endpoint_q4',4),('residual_q4',4)):
        demand(isinstance(value[name],list) and len(value[name])==width and all(type(n) is int for n in value[name]),'boundary integer ledger '+name)
    demand(all(type(value[k]) is int and value[k]>=0 for k in ('gross_inward_mass_q','gross_outward_mass_q')),'gross boundary mass domain')


def totals(cells,ledger):
    inventory(ledger)
    for k in range(4):
        present=sum(row[k] for row in cells)
        volume=ledger['source_q2'][k-1] if k in (1,2) else 0
        demand(ledger['endpoint_q4'][k]==present and ledger['residual_q4'][k]==0
               and present+ledger['outward_q4'][k]==ledger['initial_q4'][k]+volume,'cumulative four-field boundary identity')
    demand(ledger['gross_outward_mass_q']-ledger['gross_inward_mass_q']==ledger['outward_q4'][0],'gross and net boundary mass agreement')


def start(cells,ledger):
    totals(cells,ledger)
    demand(ledger['outward_q4']==[0,0,0,0] and ledger['source_q2']==[0,0]
           and ledger['gross_inward_mass_q']==ledger['gross_outward_mass_q']==0,'zero initial boundary account')


def advance(x,old,stage,before,after):
    totals(old,before);totals(stage['next'],after);balance(x,old,stage)
    demand(before['initial_q4']==after['initial_q4'],'original boundary state binding')
    changes=[0]*4;incoming=outgoing=0
    for face,transfer in zip(x['faces'],stage['transfers']):
        _,left,right,_=face
        if left>=0 and right>=0:continue
        exterior_to_interior=1 if left<0 else -1
        mass=exterior_to_interior*transfer[0]
        incoming+=max(mass,0);outgoing+=max(-mass,0)
        for k in range(4):changes[k]-=exterior_to_interior*transfer[k]
    for k in range(4):demand(after['outward_q4'][k]-before['outward_q4'][k]==changes[k],'accepted rounded boundary transfer')
    for k in range(2):demand(after['source_q2'][k]-before['source_q2'][k]==sum(row[k] for row in stage['sources']),'accepted volume-source transfer')
    demand(after['gross_inward_mass_q']-before['gross_inward_mass_q']==incoming
           and after['gross_outward_mass_q']-before['gross_outward_mass_q']==outgoing,'accepted gross boundary mass')
