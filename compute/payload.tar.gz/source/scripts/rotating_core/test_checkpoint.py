"""Continuation admits only a complete replay from the original dilute gas."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(1,str(ROOT/'scripts/radial_core'))
from fractions import Fraction as F
import copy,json,tempfile,unittest
from arithmetic import canonical_json,digest,parse_rational
from scripts.rotating_core import checkpoint,checkpoint_watchdog,model,run
from scripts.rotating_core.test_budget import STATE,SMALL


class CheckpointTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scratch=tempfile.TemporaryDirectory(prefix='civsim-continuation-test-')
        cls.directory=Path(cls.scratch.name);floor=cls.directory/'floor.json'
        floor.write_text(json.dumps(dict(schema='civsim.radial-core.floor.v1',G='6.67430e-11',floor_digest='e0cfd4a60342488054ddfa936599794e1697c0bd0997122c22e58047cde0aeb5')),encoding='ascii')
        cls.model=model.load(floor);cls.cache=cls.directory/'kernel.json'
        cls.parent=run.solve(STATE,SMALL,cls.model,kernel_cache=cls.cache,workers=1)
        cls.longer=SMALL.replace('max_steps=8','max_steps=16')

    @classmethod
    def tearDownClass(cls):cls.scratch.cleanup()

    def admit(self,proposal=None,state=STATE):
        proposal=self.parent if proposal is None else proposal
        prefix=checkpoint_watchdog.authorize(proposal,state,self.model,run.solve,run.implementations(),checkpoint.text,kernel_cache=self.cache,workers=1)
        checkpoint.matched(proposal,prefix.value);return prefix

    def continued(self,prefix=None,state=STATE,cfg=None):
        prefix=self.admit() if prefix is None else prefix
        return run.solve(state,cfg or self.longer,self.model,kernel_cache=self.cache,workers=1,_resume=prefix)

    def test_no_reset_exact_prefix_and_original_conserved_accounts(self):
        result=self.continued();direct=run.solve(STATE,self.longer,self.model,kernel_cache=self.cache,workers=1)
        self.assertEqual(result['schema'],'civsim.rotating-barotropic.run.v5')
        self.assertEqual(result['steps'],16);self.assertEqual(result['frames'][:len(self.parent['frames'])],self.parent['frames'])
        for key in ('cell_q','rho_q','pressure_q','clock_q','observation','coordinate_faces','mesh_revision'):
            self.assertEqual(result['frames'][-1][key],direct['frames'][-1][key])
        for key in ('initial_observation','remesh_events','remesh_decisions','remesh_spent','adaptive_retries'):
            self.assertEqual(result[key],direct[key])
        self.assertEqual(len(result['remesh_decisions']),3)
        self.assertGreater(result['frames'][-1]['clock_q'],self.parent['frames'][-1]['clock_q'])
        self.assertNotEqual(result['trace_sha256'],direct['trace_sha256'])
        for key in ('total_mass_kg','angular_momentum_kg_m2_s'):
            self.assertEqual(result['initial_observation'][key],result['final_observation'][key])
        self.assertFalse(result['completed_system']);self.assertEqual(result['assigned_stellar_mass_kg'],'0/1')

    def test_full_replay_refuses_forged_cells_history_and_types(self):
        variants=[]
        for change in ('cells','trace','spent','decisions','frames','step_type','assigned_star','origin'):
            bad=copy.deepcopy(self.parent)
            if change=='cells':bad['frames'][-1]['cell_q'][0][0]+=1
            elif change=='trace':bad['trace_sha256']='0'*64
            elif change=='spent':bad['remesh_spent']['density']='0/1'
            elif change=='decisions':bad['remesh_decisions'].pop()
            elif change=='frames':bad['frames'].pop(0)
            elif change=='step_type':bad['steps']=True
            elif change=='assigned_star':bad['assigned_stellar_mass_kg']='1/1'
            else:bad['state']['mass_kg']='1/1'
            variants.append(bad)
        for bad in variants:
            with self.subTest(change=bad):
                with self.assertRaises(ValueError):self.admit(bad)

    def test_unchecked_or_modified_prefix_cannot_start_gas(self):
        with self.assertRaises(ValueError):self.continued(prefix=self.parent)
        prefix=self.admit();prefix.value['frames'][-1]['cell_q'][0][0]+=1
        with self.assertRaises(ValueError):self.continued(prefix=prefix)
        prefix=self.admit();prefix.ids['unknown']='0'*64
        with self.assertRaises(ValueError):self.continued(prefix=prefix)

    def test_causal_controls_and_cumulative_limits_cannot_change(self):
        prefix=self.admit()
        for before,after in (('courant_fraction=0.2','courant_fraction=0.1'),('softening_m=1.75e13','softening_m=1e13'),
                             ('remesh_density_budget=0.02','remesh_density_budget=0.1'),('fraction_bits=96','fraction_bits=128'),
                             ('max_pair_steps=134217728','max_pair_steps=16777216'),('max_elapsed_s=2.45e12','max_elapsed_s=2e12')):
            with self.subTest(before=before):
                with self.assertRaises(ValueError):self.continued(prefix=prefix,cfg=self.longer.replace(before,after))
        with self.assertRaises(ValueError):self.continued(prefix=prefix,cfg=SMALL)

    def test_repeat_observers_and_journal_keep_exact_history(self):
        prefix=self.admit();one=self.continued(prefix);two=self.continued(prefix);self.assertEqual(one,two)
        state=STATE.replace('Declared cold rotating cylinder; source-bound pressure, no inserted central object.','Observer label')
        other=self.continued(prefix,state=state,cfg=self.longer.replace('sample_every=4','sample_every=2'))
        self.assertEqual(one['trace_sha256'],other['trace_sha256']);self.assertEqual(one['physical_identity'],other['physical_identity'])
        self.assertEqual(one['frames'][-1]['cell_q'],other['frames'][-1]['cell_q'])
        frames=[];journal=run.solve(STATE,self.longer,self.model,on_frame=frames.append,kernel_cache=self.cache,workers=1,_resume=prefix)
        self.assertEqual(frames,journal['frames'])

    def test_chained_restart_reconstructs_each_cut_and_refuses_forged_lineage(self):
        first=self.continued();prefix=self.admit(first)
        second=self.continued(prefix,cfg=self.longer.replace('max_steps=16','max_steps=24'))
        self.assertEqual(len(second['continuation']['segments']),2)
        self.admit(second)
        for key,value in (('from_step',0),('from_clock_q',True),('from_trace_sha256','0'*64)):
            bad=copy.deepcopy(first);bad['continuation']['segments'][0][key]=value
            with self.assertRaises(ValueError):self.admit(bad)
        bad=copy.deepcopy(first);bad['continuation']['segments']*=9
        with self.assertRaises(ValueError):self.admit(bad)

    def test_clipped_time_endpoint_preserves_clock_without_a_time_jump(self):
        endpoint=SMALL.replace('max_elapsed_s=2.45e12','max_elapsed_s=1e8')
        cache=self.directory/'clipped-kernel.json'
        parent=run.solve(STATE,endpoint,self.model,kernel_cache=cache,workers=1)
        self.assertTrue(parent['reached_requested_time'])
        prefix=checkpoint_watchdog.authorize(parent,STATE,self.model,run.solve,run.implementations(),checkpoint.text,kernel_cache=cache,workers=1)
        result=run.solve(STATE,self.longer,self.model,kernel_cache=cache,workers=1,_resume=prefix)
        self.assertEqual(result['frames'][:len(parent['frames'])],parent['frames'])
        self.assertGreater(parse_rational(result['frames'][-1]['time_s']),F('1e8'))
        cfg=endpoint.replace('max_steps=8','max_steps=16')
        with self.assertRaises(ValueError):run.solve(STATE,cfg,self.model,kernel_cache=cache,workers=1,_resume=prefix)

    def test_bounded_wire_and_historical_execution_binding(self):
        original=checkpoint.text(self.parent['numerics'])
        self.assertEqual(run.inputs.numerics(original),run.inputs.numerics(SMALL))
        file=self.directory/'proposal.json';file.write_text(canonical_json(self.parent),encoding='ascii')
        self.assertEqual(checkpoint.read(file),self.parent)
        for text in ('{"x":1,"x":2}','{"x":1.5}','{"x":NaN}'):
            file.write_text(text,encoding='ascii')
            with self.assertRaises(ValueError):checkpoint.read(file)
        old=copy.deepcopy(self.parent);old['implementations']={'historical.py':'0'*64}
        old['execution_identity']=digest(canonical_json(dict(physical_identity=old['physical_identity'],numerics=old['numerics'],implementations=old['implementations'])).encode('ascii'))
        self.admit(old)
        old['execution_identity']='0'*64
        with self.assertRaises(ValueError):self.admit(old)

    def test_continuation_witness_is_bound(self):
        with tempfile.TemporaryDirectory(prefix='civsim-continuation-witness-') as folder:
            root=Path(folder);path=root/checkpoint_watchdog.WITNESS;path.parent.mkdir(parents=True)
            path.write_bytes((ROOT/checkpoint_watchdog.WITNESS).read_bytes()+b'forged\n')
            with self.assertRaises(ValueError):checkpoint_watchdog.source(root)


if __name__=='__main__':unittest.main()
