"""Checked conditional rotating barotropic fluid, with separate semantic watchdogs."""
