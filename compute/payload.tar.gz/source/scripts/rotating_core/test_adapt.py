"""Conservation, analytic profiles, adversarial remaps and integrated gas controls."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(1,str(ROOT/'scripts/radial_core'))
from fractions import Fraction as F
import copy,json,tempfile,unittest
from arithmetic import qfraction,rational,parse_rational,integer_text,integer_from_text,WIRE_BITS
import pi_pair
from scripts.rotating_core import inputs,input_watchdog,mesh,mesh_watchdog,model,run
from scripts.rotating_core import adapt,adapt_watchdog,remap,remap_watchdog,eos,observe,observe_watchdog

STATE=(ROOT/'examples/rotating-core/cloud.state').read_text(encoding='ascii')
NUM=(ROOT/'examples/rotating-core/adaptive.numerics').read_text(encoding='ascii')
SMALL=NUM.replace('radial_cells=8','radial_cells=4').replace('vertical_cells=16','vertical_cells=8').replace('max_steps=8192','max_steps=8').replace('sample_every=32','sample_every=4').replace('remesh_interval=256','remesh_interval=2').replace('remesh_max_events=16','remesh_max_events=3')


class RemeshTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scratch=tempfile.TemporaryDirectory(prefix='civsim-remap-test-')
        floor=Path(cls.scratch.name)/'floor.json'
        floor.write_text(json.dumps(dict(schema='civsim.radial-core.floor.v1',G='6.67430e-11',floor_digest='e0cfd4a60342488054ddfa936599794e1697c0bd0997122c22e58047cde0aeb5')),encoding='ascii')
        cls.model=model.load(floor);cls.state=inputs.state(STATE);cls.cfg=inputs.numerics(SMALL)
        cls.x=mesh.build(cls.state,cls.cfg,cls.model['pressure'],pi_pair.value(96));cls.cells=mesh.project(cls.x,cls.state,cls.model['pressure'])
        cls.coordinates=dict(r=list(map(F,('0','0.02','0.07','0.3','1'))),z=list(map(F,('-1','-0.6','-0.21','-0.02','0','0.11','0.44','0.9','1'))))
        cls.other=mesh.rebuild(cls.x,cls.coordinates)

    @classmethod
    def tearDownClass(cls):cls.scratch.cleanup()

    def test_closed_adaptation_contract_and_bounds(self):
        for text in (SMALL,SMALL.replace('schema=','schema = ')):
            got=inputs.numerics(text);input_watchdog.check(text,got,'numerics');self.assertEqual(got,self.cfg)
        for bad in (SMALL+'requested_core_radius=1\n',SMALL+'remesh_interval=1\n',SMALL.replace('remesh_regularization=0.25','remesh_regularization=0'),SMALL.replace('remesh_relaxation=0.5','remesh_relaxation=1'),SMALL.replace('remesh_max_events=3','remesh_max_events=33'),SMALL.replace('remesh_interval=2','remesh_interval=4')):
            with self.assertRaises(ValueError):inputs.numerics(bad)
            with self.assertRaises(ValueError):input_watchdog.check(bad,self.cfg,'numerics')

    def test_exact_large_receipt_wire_and_unchanged_host_guard(self):
        # A known decimal word gives an independent expected answer above4300digits.
        digits='123456789'*600;number=0
        for part in [digits[i:i+9] for i in range(0,len(digits),9)]:number=number*1000000000+int(part)
        limit=sys.get_int_max_str_digits()
        self.assertEqual(integer_text(number),digits);self.assertEqual(integer_from_text(digits),number)
        for value in (F(number,17),F(-number,19),F(0),F(-7,3)):
            self.assertEqual(parse_rational(rational(value)),value)
        self.assertEqual(sys.get_int_max_str_digits(),limit)
        if limit and len(digits)>limit:
            with self.assertRaises(ValueError):str(number)
        for bad in ('1/-2','1/0','1/2/3','1e4','1.5','', '\u0661'):
            with self.assertRaises(ValueError):parse_rational(bad)
        with self.assertRaises(ValueError):integer_text(1<<WIRE_BITS)

    def test_uniform_monitor_and_concentrated_mass_following(self):
        proposal=adapt.propose(self.x,self.cells,self.cfg);adapt_watchdog.check(self.x,self.cells,self.cfg,proposal)
        self.assertEqual(proposal,dict(r=self.x['rf'],z=self.x['zf']))
        values=[y[0]*(self.x['nr']-k%self.x['nr'])**4 for k,y in enumerate(self.cells)]
        total=sum(values);running=0;previous=0;cells=[]
        for amount in values:
            running+=amount;now=qfraction(F(running,total),self.x['s']);cells.append([now-previous,0,0,0]);previous=now
        proposal=adapt.propose(self.x,cells,self.cfg);adapt_watchdog.check(self.x,cells,self.cfg,proposal)
        self.assertLess(proposal['r'][1],self.x['rf'][1])
        for axis,edges in (('r',self.x['rf']),('z',self.x['zf'])):
            for i in range(len(edges)-1):self.assertGreaterEqual(proposal[axis][i+1]-proposal[axis][i],(edges[i+1]-edges[i])*(1-self.cfg['remesh_relaxation']))
        bad=copy.deepcopy(proposal);bad['r'][1]+=F(1,10**9)
        with self.assertRaises(ValueError):adapt_watchdog.check(self.x,cells,self.cfg,bad)

    def test_source_witness_mutation_refuses(self):
        adapt_watchdog.source(ROOT)
        with tempfile.TemporaryDirectory(prefix='civsim-remap-custody-') as directory:
            root=Path(directory);path=root/adapt_watchdog.WITNESS;path.parent.mkdir(parents=True)
            path.write_bytes((ROOT/adapt_watchdog.WITNESS).read_bytes()+b'altered\n')
            with self.assertRaises(ValueError):adapt_watchdog.source(root)

    def test_overlap_conserves_signed_fields_and_regular_rotation(self):
        mesh_watchdog.geometry(self.state,self.cfg,self.model['pressure'],self.x['pi'],self.other)
        cells=copy.deepcopy(self.cells)
        for row in cells:row[1]=qfraction(F(3*row[0],7),1);row[2]=qfraction(F(-2*row[0],9),1)
        got=remap.transfer(self.x,self.other,cells);remap_watchdog.check(self.x,self.other,cells,got)
        for k in range(4):self.assertEqual(sum(y[k] for y in cells),sum(y[k] for y in got['next']))
        self.assertLess(got['diagnostics']['density_l1_mass_fraction'],F(1,10**23))
        spin=self.state['angular_velocity_s_inv']*self.state['radius_m']/self.model['pressure']['sound_speed_m_s']
        for k,row in enumerate(got['next']):
            lo,hi=self.other['rf'][k%self.other['nr']:k%self.other['nr']+2]
            self.assertLess(abs(F(row[3],row[0])/((lo*lo+hi*hi)/2)-spin),F(1,10**19))

    def test_identity_and_three_precisions(self):
        for bits in (96,128,160):
            cfg=dict(self.cfg,fraction_bits=bits);x=mesh.build(self.state,cfg,self.model['pressure'],pi_pair.value(bits));cells=mesh.project(x,self.state,self.model['pressure'])
            identical=remap.transfer(x,x,cells);remap_watchdog.check(x,x,cells,identical)
            self.assertEqual(identical['next'],cells);self.assertEqual(identical['diagnostics']['density_l1_mass_fraction'],0)
            self.assertEqual(identical['diagnostics']['angular_profile_l1_fraction'],0)
            other=mesh.rebuild(x,self.coordinates);got=remap.transfer(x,other,cells);remap_watchdog.check(x,other,cells,got)
            self.assertEqual(got['before_totals'],got['after_totals'])

    def test_balanced_corruption_missing_coverage_and_geometry_refuse(self):
        got=remap.transfer(self.x,self.other,self.cells)
        for key in ('transfers','next','before_totals','after_totals','diagnostics'):
            bad=copy.deepcopy(got)
            if key=='transfers':bad[key][0][2]+=3;bad[key][1][2]-=3
            elif key=='next':bad[key][0][3]+=3;bad[key][1][3]-=3
            elif key=='diagnostics':bad[key]['density_l1_mass_fraction']+=F(1,10**9)
            else:bad[key][0]+=1
            with self.assertRaises(ValueError):remap_watchdog.check(self.x,self.other,self.cells,bad)
        bad=copy.deepcopy(got);bad['transfers'].pop()
        with self.assertRaises(ValueError):remap_watchdog.check(self.x,self.other,self.cells,bad)
        for key in ('volume','r','incidence','epsilon'):
            bad=copy.deepcopy(self.other)
            if key=='incidence':bad[key][0][1]+=1
            elif isinstance(bad[key],list):bad[key][0]+=F(1,10**6)
            else:bad[key]*=2
            with self.assertRaises(ValueError):mesh_watchdog.geometry(self.state,self.cfg,self.model['pressure'],self.x['pi'],bad)

    def test_moved_face_observer_integrates_the_same_uniform_window(self):
        got=remap.transfer(self.x,self.other,self.cells);rows=got['next'];fields=eos.fields(self.other,rows);force=[[0,0] for _ in rows]
        observation=observe.measure(self.other,rows,fields,force,self.state,self.model['pressure'])
        observe_watchdog.check(self.other,rows,fields,force,self.state,self.model['pressure'],observation)
        self.assertLess(abs(observation['inner_quarter_mass_fraction']-F(1,64)),F(1000,self.x['s']))

    def test_integrated_three_remaps_repeat_spin_and_observer_invariance(self):
        base=run.solve(STATE,SMALL,self.model,workers=1)
        repeated=run.solve(STATE,SMALL,self.model,workers=1);self.assertEqual(base,repeated)
        observed=run.solve(STATE.replace('description=Declared','description=Observer Declared'),SMALL.replace('sample_every=4','sample_every=2'),self.model,workers=1)
        self.assertEqual(base['physical_identity'],observed['physical_identity']);self.assertEqual(base['trace_sha256'],observed['trace_sha256'])
        reverse=run.solve(STATE.replace('angular_velocity_s_inv=2e-13','angular_velocity_s_inv=-2e-13'),SMALL,self.model,workers=1)
        self.assertEqual(len(base['remesh_events']),3)
        self.assertEqual(base['coordinate_faces'],reverse['coordinate_faces'])
        for one,two in zip(base['frames'][-1]['cell_q'],reverse['frames'][-1]['cell_q']):self.assertEqual(one[:3]+[-one[3]],two)
        for row in (base,reverse):
            self.assertEqual(row['initial_observation']['total_mass_kg'],row['final_observation']['total_mass_kg'])
            self.assertEqual(row['initial_observation']['angular_momentum_kg_m2_s'],row['final_observation']['angular_momentum_kg_m2_s'])
            self.assertEqual(row['frames'][-1]['mesh_revision'],3);self.assertEqual(row['frames'][-1]['coordinate_faces'],row['coordinate_faces'])
            self.assertFalse(row['completed_system']);self.assertFalse(row['disk_assessed'])


if __name__=='__main__':unittest.main()
