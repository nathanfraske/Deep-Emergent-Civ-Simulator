"""Copy the checked finite gas accounts without rebasing their history."""
from copy import deepcopy


# @derives: finite gas continuation accounts <- independently replayed original nested gas + cumulative checked wall and volume impulses
def restore_accounts(parent):
    return deepcopy(parent['boundary_accounts'])
