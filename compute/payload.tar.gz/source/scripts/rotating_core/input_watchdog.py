"""Independent input inventory, rational units and physical entry screens."""
from fractions import Fraction as F
from decimal import Decimal


def demand(ok,why):
    if not ok:raise ValueError('rotating checker: '+why)


def check(text,got,kind):
    names=('schema origin geometry boundary mass_kg radius_m half_height_m angular_velocity_s_inv description' if kind=='state'
           else 'schema angular_transport radial_cells vertical_cells mesh_power fraction_bits angular_nodes softening_m courant_fraction max_steps max_elapsed_s sample_every max_pair_steps').split()
    demand(isinstance(text,str) and text.isascii() and len(text)<=4096,'input resource')
    lines=[line.partition('=') for line in text.splitlines() if line.strip() and not line.lstrip().startswith('#')]
    keys=[a.strip() for a,sep,b in lines]
    opened=kind=='state' and any(a.strip()=='schema' and b.strip()=='civsim.rotating-barotropic.state.v2' for a,sep,b in lines)
    finite=kind=='state' and any(a.strip()=='schema' and b.strip()=='civsim.rotating-barotropic.state.v3' for a,sep,b in lines)
    if opened or finite:names += 'exterior_gravity radial_edge_velocity_m_s axial_edge_velocity_m_s'.split()
    if finite:names += 'inner_mass_kg inner_radius_m inner_half_height_m'.split()
    width_limited=kind=='numerics' and any(a.strip()=='schema' and b.strip()=='civsim.rotating-barotropic.numerics.v7' for a,sep,b in lines)
    selective=width_limited or kind=='numerics' and any(a.strip()=='schema' and b.strip()=='civsim.rotating-barotropic.numerics.v6' for a,sep,b in lines)
    refining=selective or kind=='numerics' and any(a.strip()=='schema' and b.strip()=='civsim.rotating-barotropic.numerics.v5' for a,sep,b in lines)
    budgeted=refining or kind=='numerics' and any(a.strip()=='schema' and b.strip()=='civsim.rotating-barotropic.numerics.v4' for a,sep,b in lines)
    adaptive=budgeted or kind=='numerics' and any(a.strip()=='schema' and b.strip()=='civsim.rotating-barotropic.numerics.v3' for a,sep,b in lines)
    if adaptive:names += 'mesh_adaptation remesh_interval remesh_max_events remesh_regularization remesh_relaxation'.split()
    if budgeted:names += 'remesh_density_budget remesh_angular_budget remesh_event_fraction remesh_backtracks'.split()
    if refining:names += 'spatial_refinement refinement_trigger_squared refinement_target_squared refinement_max_cells refinement_max_events refinement_max_depth refinement_density_budget refinement_angular_budget'.split()
    if width_limited:names += ['gravity_softening','softening_cell_fraction']
    demand(all(sep=='=' and b.strip() for a,sep,b in lines) and len(keys)==len(set(keys)) and set(keys)==set(names),'closed input inventory')
    observed={a.strip():b.strip() for a,sep,b in lines}
    scalars=('mass_kg radius_m half_height_m angular_velocity_s_inv' if kind=='state' else 'softening_m courant_fraction max_elapsed_s').split()
    if opened or finite:scalars += ['radial_edge_velocity_m_s','axial_edge_velocity_m_s']
    if finite:scalars += ['inner_mass_kg','inner_radius_m','inner_half_height_m']
    integer_names=[] if kind=='state' else 'radial_cells vertical_cells mesh_power fraction_bits angular_nodes max_steps sample_every max_pair_steps'.split()
    if adaptive:scalars += ['remesh_regularization','remesh_relaxation'];integer_names += ['remesh_interval','remesh_max_events']
    if budgeted:scalars += ['remesh_density_budget','remesh_angular_budget','remesh_event_fraction'];integer_names += ['remesh_backtracks']
    if refining:scalars += ['refinement_trigger_squared','refinement_target_squared','refinement_density_budget','refinement_angular_budget'];integer_names += ['refinement_max_cells','refinement_max_events','refinement_max_depth']
    if width_limited:scalars += ['softening_cell_fraction']
    for key,value in observed.items():
        if key in scalars:
            demand(len(value)<=48 and '/' not in value and '_' not in value and value.lower() not in ('nan','inf','infinity'), 'decimal syntax')
            decimal=Decimal(value);demand(decimal.is_finite(),'finite decimal')
            demand(got[key]==F(*decimal.as_integer_ratio()),'physical decimal '+key)
        elif key in integer_names:
            demand(value.isascii() and value.isdecimal() and len(value)<=(13 if refining and key=='max_pair_steps' else 10) and got[key]==int(value),'integer '+key)
        else:demand(got[key]==value,'text '+key)
    demand(set(got)==set(names),'parsed field census')
    if kind=='state':
        demand(observed['schema']==('civsim.rotating-barotropic.state.v3' if finite else 'civsim.rotating-barotropic.state.v2' if opened else 'civsim.rotating-barotropic.state.v1') and observed['origin']=='declared_hypothesis','state origin')
        demand(observed['geometry']==('nested_cylinders' if finite else 'uniform_cylinder') and observed['boundary']==('extrapolated_cylinder' if opened else 'reflecting_slip'),'state geometry')
        if opened:demand(observed['exterior_gravity']=='neglected','declared unresolved exterior gravity')
        if finite:
            demand(observed['exterior_gravity']=='all_resolved_gas','finite surrounding gravity')
            demand(0<got['inner_mass_kg']<got['mass_kg'] and 0<got['inner_radius_m']<got['radius_m'] and 0<got['inner_half_height_m']<got['half_height_m'],'finite nested gas domain')
            demand(got['inner_radius_m']/4<=got['inner_half_height_m']<=4*got['inner_radius_m'],'inner aspect bounds')
        demand(all(got[k]>0 for k in ('mass_kg','radius_m','half_height_m')),'positive entry')
        demand(got['radius_m']/4<=got['half_height_m']<=4*got['radius_m'] and len(got['description'])<=240,'entry bounds')
    else:
        demand(observed['schema'] in ('civsim.rotating-barotropic.numerics.v2','civsim.rotating-barotropic.numerics.v3','civsim.rotating-barotropic.numerics.v4','civsim.rotating-barotropic.numerics.v5','civsim.rotating-barotropic.numerics.v6','civsim.rotating-barotropic.numerics.v7') and observed['angular_transport']=='regular_rotation_mass_flux','numerical schema and angular law')
        nr,nz=got['radial_cells'],got['vertical_cells']
        demand(nr in (4,8,16,32) and nz in (8,16,32) and nr*nz<=512 and got['mesh_power'] in (1,2),'mesh bounds')
        demand(96<=got['fraction_bits']<=160 and 8<=got['angular_nodes']<=64,'precision bounds')
        demand(0<got['courant_fraction']<=F(1,5) and got['softening_m']>0 and got['max_elapsed_s']>0,'numerical domain')
        demand(1<=got['sample_every']<=got['max_steps']<=65536 and got['max_steps']//got['sample_every']<=256,'step bounds')
        demand((nr*nz)**2*got['max_steps']<=got['max_pair_steps']<=(1099511627776 if refining else 1073741824),'work bounds')
        if width_limited:demand(got['gravity_softening']=='cell_width_limited_global' and 0<got['softening_cell_fraction']<=1,'cell softening closed policy')
        if adaptive:
            demand(got['mesh_adaptation']=='regularized_mass_coordinates','mesh policy identity')
            demand(1<=got['remesh_interval']<=got['max_steps'] and 1<=got['remesh_max_events']<=32 and got['remesh_interval']*got['remesh_max_events']<=got['max_steps'],'remesh work bounds')
            demand(0<got['remesh_regularization']<=1 and 0<got['remesh_relaxation']<=F(1,2),'remesh numerical parameter bounds')
        if budgeted:
            demand(all(0<got[k]<=1 for k in ('remesh_density_budget','remesh_angular_budget','remesh_event_fraction')),'representation budget bounds')
            demand(0<=got['remesh_backtracks']<=16 and len(observed['remesh_backtracks'])<=2,'bounded remesh backtracking')
        if refining:
            demand(got['spatial_refinement']==('jeans_dyadic_cells' if selective else 'jeans_dyadic_bands'),'refinement policy identity')
            demand(0<got['refinement_target_squared']<got['refinement_trigger_squared']<=F(1,32),'refinement numerical margin')
            demand(nr*nz<=got['refinement_max_cells']<=(4096 if selective else 2048) and 1<=got['refinement_max_events']<=(64 if selective else 16) and 1<=got['refinement_max_depth']<=8,'refinement resource caps')
            demand(all(0<got[k]<=1 for k in ('refinement_density_budget','refinement_angular_budget')),'refinement loss domain')
            demand(got['refinement_max_cells']**2*got['max_steps']<=got['max_pair_steps'],'bounded refined pair-step capacity')


def physical(state,cfg,model,pi):
    radius=state['radius_m'];height=state['half_height_m'];mass=state['mass_kg']
    density=mass/(2*pi*radius*radius*height)
    demand(0<density<=F(1,16*10**10),'initial dilute cloud, no assigned dense core')
    demand(cfg['softening_m']<=min(radius,height),'softening extent')
    demand(100*abs(state['angular_velocity_s_inv'])*radius<=299792458,'Newtonian entry velocity')
    if state['schema'] in ('civsim.rotating-barotropic.state.v2','civsim.rotating-barotropic.state.v3'):
        demand(100*(abs(state['radial_edge_velocity_m_s'])+abs(state['axial_edge_velocity_m_s'])+abs(state['angular_velocity_s_inv'])*radius)<=299792458,'Newtonian declared bulk velocity')
    demand(1000*model['G']*mass<=cfg['softening_m']*299792458**2,'Newtonian potential screen')
    demand(model['sound_speed_m_s']==200,'bound low-density pressure coefficient')
    if state['schema']=='civsim.rotating-barotropic.state.v3':
        inner_volume=2*pi*state['inner_radius_m']**2*state['inner_half_height_m']
        outer_volume=2*pi*radius*radius*height
        demand(0<state['inner_mass_kg']/inner_volume<=F(1,16*10**10)
               and 0<(mass-state['inner_mass_kg'])/(outer_volume-inner_volume)<=F(1,16*10**10),
               'both continuous gas regions start dilute, no assigned dense core')
