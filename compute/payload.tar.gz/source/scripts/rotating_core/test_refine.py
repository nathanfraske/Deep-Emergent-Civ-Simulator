"""Exact split, resolution, resource and original-gas trajectory falsifiers."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(1,str(ROOT/'scripts/radial_core'))
from fractions import Fraction as F
import copy,json,tempfile,unittest
from arithmetic import parse_rational
import pi_pair
from scripts.rotating_core import inputs,input_watchdog,mesh,mesh_watchdog,eos,eos_watchdog,model,refine,refine_watchdog,run,checkpoint
from scripts.rotating_core.test_budget import SMALL,STATE

OPTIONS='''spatial_refinement=jeans_dyadic_bands
refinement_trigger_squared=0.00390625
refinement_target_squared=0.001953125
refinement_max_cells=256
refinement_max_events=4
refinement_max_depth=4
refinement_density_budget=1e-12
refinement_angular_budget=1e-12
'''
NUM=SMALL.replace('numerics.v4','numerics.v5')+OPTIONS
DILUTE=STATE.replace('mass_kg=2e30','mass_kg=2e29')


class RefinementTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scratch=tempfile.TemporaryDirectory(prefix='civsim-jeans-test-');cls.directory=Path(cls.scratch.name)
        floor=cls.directory/'floor.json';floor.write_text(json.dumps(dict(schema='civsim.radial-core.floor.v1',G='6.67430e-11',floor_digest='e0cfd4a60342488054ddfa936599794e1697c0bd0997122c22e58047cde0aeb5')),encoding='ascii')
        cls.model=model.load(floor);cls.state=inputs.state(DILUTE);cls.cfg=inputs.numerics(NUM)
        cls.x=mesh.build(cls.state,cls.cfg,cls.model['pressure'],pi_pair.value(96));cls.cells=mesh.project(cls.x,cls.state,cls.model['pressure'])
        cls.fields=eos.fields(cls.x,cls.cells);eos_watchdog.check(cls.x,cls.cells,cls.fields)
        cls.proposal=refine.plan(cls.x,cls.fields,cls.state,cls.model['pressure'],cls.cfg)
        cls.result=run.solve(DILUTE,NUM,cls.model,kernel_cache=cls.directory/'kernel.json',workers=1)

    @classmethod
    def tearDownClass(cls):cls.scratch.cleanup()

    def test_closed_input_resource_and_resolution_margin(self):
        input_watchdog.check(NUM,self.cfg,'numerics')
        for before,after in [('refinement_max_cells=256','refinement_max_cells=31'),('refinement_max_depth=4','refinement_max_depth=0'),('refinement_max_events=4','refinement_max_events=17'),('refinement_target_squared=0.001953125','refinement_target_squared=0.00390625'),('refinement_trigger_squared=0.00390625','refinement_trigger_squared=0.0625'),('refinement_density_budget=1e-12','refinement_density_budget=0'),('max_pair_steps=134217728','max_pair_steps=524287'),('spatial_refinement=jeans_dyadic_bands','spatial_refinement=insert_core')]:
            with self.subTest(before=before):
                with self.assertRaises(ValueError):inputs.numerics(NUM.replace(before,after))
        with self.assertRaises(ValueError):inputs.numerics(NUM+'refinement_max_cells=512\n')

    def test_nested_minimal_band_splits_and_exact_geometry(self):
        proposal=self.proposal;self.assertEqual(proposal['status'],'accepted')
        refine_watchdog.plan(self.x,self.fields,self.state,self.model['pressure'],self.cfg,proposal)
        new,allocation=refine.transfer(self.x,self.cells,proposal)
        self.assertGreater(len(new['volume']),len(self.cells));self.assertLessEqual(len(new['volume']),256)
        for old_faces,new_faces in ((self.x['rf'],new['rf']),(self.x['zf'],new['zf'])):self.assertTrue(set(old_faces)<=set(new_faces))
        mesh_watchdog.geometry(self.state,self.cfg,self.model['pressure'],self.x['pi'],new)
        fields=eos.fields(new,allocation['next']);eos_watchdog.check(new,allocation['next'],fields)
        refine_watchdog.screen(new,fields,self.state,self.model['pressure'])
        self.assertTrue(all(q<=self.cfg['refinement_target_squared']+F(1,10**24) for pair in refine_watchdog.ratios(new,fields,self.state,self.model['pressure']) for q in pair))

    def test_signed_four_field_projection_and_lattice_loss(self):
        cells=[[m,3*m//7,-2*m//9,-angular] for m,pr,pz,angular in self.cells]
        new,allocation=refine.transfer(self.x,cells,self.proposal)
        valid,spent=refine_watchdog.allocation(self.x,new,cells,allocation,dict(density=F(0),angular=F(0)),self.cfg)
        self.assertTrue(valid);self.assertTrue(refine.within_budget(allocation,dict(density=F(0),angular=F(0)),self.cfg))
        self.assertEqual([sum(y[k] for y in cells) for k in range(4)],[sum(y[k] for y in allocation['next']) for k in range(4)])
        self.assertTrue(all(v<F(1,10**24) for v in spent.values()))
        bad=copy.deepcopy(allocation);bad['next'][0][0]+=1;bad['next'][1][0]-=1
        with self.assertRaises(ValueError):refine_watchdog.allocation(self.x,new,cells,bad,dict(density=F(0),angular=F(0)),self.cfg)

    def test_threshold_tie_and_capacity_are_explicit(self):
        maximum=self.proposal['max_ratio_squared'];cfg=dict(self.cfg,refinement_trigger_squared=maximum,refinement_target_squared=maximum/2)
        same=refine.plan(self.x,self.fields,self.state,self.model['pressure'],cfg)
        self.assertEqual(same['status'],'unchanged');refine_watchdog.plan(self.x,self.fields,self.state,self.model['pressure'],cfg,same)
        for capacity,status in ((dict(refinement_max_cells=32),'cell_limit'),(dict(refinement_max_depth=0),'depth_limit')):
            cfg=dict(self.cfg,**capacity);proposal=refine.plan(self.x,self.fields,self.state,self.model['pressure'],cfg)
            self.assertEqual(proposal['status'],status);self.assertIsNone(proposal['new_faces'])
            refine_watchdog.plan(self.x,self.fields,self.state,self.model['pressure'],cfg,proposal)

    def test_plan_mutations_and_unresolved_screen_refuse(self):
        for change in ('missing_face','face','depth','type','status','count','diagnostic'):
            bad=copy.deepcopy(self.proposal)
            if change=='missing_face':bad['new_faces']['z'].pop()
            elif change=='face':bad['new_faces']['r'][1]+=F(1,2**96)
            elif change=='depth':bad['levels']['r'][0]+=1
            elif change=='type':bad['levels']['r'][0]=False
            elif change=='status':bad['status']='unchanged'
            elif change=='count':bad['required_cells']+=1
            else:bad['max_ratio_squared']+=F(1,2**96)
            with self.subTest(change=change):
                with self.assertRaises((ValueError,IndexError)):refine_watchdog.plan(self.x,self.fields,self.state,self.model['pressure'],self.cfg,bad)
        dense=copy.deepcopy(self.fields)
        for field in dense:field['rho']*=100
        with self.assertRaises(ValueError):refine_watchdog.screen(self.x,dense,self.state,self.model['pressure'])

    def test_real_gas_starts_at_original_state_and_preserves_accounts(self):
        row=self.result;self.assertEqual(row['schema'],'civsim.rotating-barotropic.run.v6');self.assertEqual(row['steps'],8)
        self.assertTrue(row['refinement_events']);self.assertFalse(row['remesh_events'])
        self.assertEqual(row['refinement_events'][0]['old_cell_q'],self.cells)
        for frame in row['frames']:
            nr=frame['mesh_dimensions']['radial'];nz=frame['mesh_dimensions']['vertical']
            self.assertEqual(len(frame['cell_q']),nr*nz);self.assertTrue(frame['observation']['jeans_width_screen'])
            self.assertEqual(len(frame['coordinate_faces']['r']),nr+1);self.assertEqual(len(frame['coordinate_faces']['z']),nz+1)
        for name in ('total_mass_kg','angular_momentum_kg_m2_s'):self.assertEqual(row['initial_observation'][name],row['final_observation'][name])
        self.assertFalse(row['completed_system']);self.assertFalse(row['disk_assessed']);self.assertEqual(row['assigned_stellar_mass_kg'],'0/1')

    def test_repeat_sampling_and_spin_covariance(self):
        row=run.solve(DILUTE,NUM,self.model,kernel_cache=self.directory/'kernel.json',workers=1);self.assertEqual(row,self.result)
        observed=run.solve(DILUTE.replace('Declared cold rotating cylinder; source-bound pressure, no inserted central object.','Observer description'),NUM.replace('sample_every=4','sample_every=2'),self.model,kernel_cache=self.directory/'kernel.json',workers=1)
        self.assertEqual(observed['physical_identity'],row['physical_identity']);self.assertEqual(observed['trace_sha256'],row['trace_sha256'])
        self.assertEqual(observed['refinement_events'],row['refinement_events']);self.assertEqual(observed['frames'][-1]['cell_q'],row['frames'][-1]['cell_q'])
        reverse=run.solve(DILUTE.replace('angular_velocity_s_inv=2e-13','angular_velocity_s_inv=-2e-13'),NUM,self.model,kernel_cache=self.directory/'kernel.json',workers=1)
        for a,b in zip(row['frames'][-1]['cell_q'],reverse['frames'][-1]['cell_q']):self.assertEqual(a[:3]+[-a[3]],b)

    def test_complete_split_and_pair_step_ledger(self):
        row=self.result;spent={k:parse_rational(v) for k,v in row['refinement_spent'].items()}
        refine_watchdog.ledger(self.cfg,row['refinement_decisions'],row['refinement_events'],spent,8,row['pair_steps_spent'])
        for change in ('event','budget','work','type','history'):
            bad=copy.deepcopy(row)
            if change=='event':bad['refinement_events'].clear()
            elif change=='budget':bad['refinement_decisions'][0]['spent_after']['density']='1/1'
            elif change=='work':bad['pair_steps_spent']-=1
            elif change=='type':bad['refinement_decisions'][0]['step']=False
            else:bad['refinement_decisions'].clear()
            with self.subTest(change=change):
                with self.assertRaises(ValueError):refine_watchdog.ledger(self.cfg,bad['refinement_decisions'],bad['refinement_events'],spent,8,bad['pair_steps_spent'])

    def test_resource_stop_retains_resolved_gas_and_no_false_endpoint(self):
        cfg=NUM.replace('refinement_max_cells=256','refinement_max_cells=32')
        row=run.solve(DILUTE,cfg,self.model,kernel_cache=self.directory/'kernel.json',workers=1)
        self.assertEqual(row['steps'],0);self.assertEqual(row['stop_reason'],'refinement_cell_limit')
        self.assertFalse(row['reached_requested_time']);self.assertEqual(row['frames'][-1]['cell_q'],self.cells)
        self.assertTrue(row['final_observation']['jeans_width_screen']);self.assertEqual(row['pair_steps_spent'],0)
        self.assertFalse(row['refinement_events']);self.assertEqual(row['refinement_spent'],dict(density='0/1',angular='0/1'))
        with self.assertRaises(ValueError):run.solve(DILUTE,NUM,self.model,_resume=self.result,workers=1)

    def test_witness_is_bound(self):
        self.assertEqual(refine_watchdog.source(ROOT),{refine_watchdog.WITNESS:refine_watchdog.PIN})
        with tempfile.TemporaryDirectory(prefix='civsim-jeans-witness-') as directory:
            root=Path(directory);file=root/refine_watchdog.WITNESS;file.parent.mkdir(parents=True)
            file.write_bytes((ROOT/refine_watchdog.WITNESS).read_bytes()+b'changed\n')
            with self.assertRaises(ValueError):refine_watchdog.source(root)


if __name__=='__main__':unittest.main()
