"""Independent polynomial cells for pressure and acoustic derivatives.

No producer constitutive or EOS module is imported here.
"""
from fractions import Fraction as F
from .input_watchdog import demand
from .mesh_watchdog import round_cell


def nearest(value):
    q,r=divmod(value.numerator,value.denominator)
    return q+(2*r>value.denominator or (2*r==value.denominator and q%2))


def coefficients(x):
    s=x['s']
    for ratio,power,degree,key in [(F(570000),2,5,'b1'),(F(1000000,57),3,20,'b2')]:
        q=nearest(ratio*s);target=q**power*s**(degree-power);root=x[key]
        demand(type(root) is int and root**degree<=target<(root+1)**degree,'transition power cell')
    round_cell(x['prefactor'],F(x['b1']*x['b2'],s))


def check(x,cells,record):
    s=x['s'];coefficients(x)
    demand(len(record)==len(cells)==len(x['volume']),'EOS record census')
    for k in range(len(cells)-1,-1,-1):
        y=cells[k];f=record[k]
        demand(len(y)==4 and all(type(a) is int and abs(a).bit_length()<=384 for a in y) and y[0]>0,'conserved storage domain')
        demand(set(f)=={'rho','p','cs2','cs','root'},'EOS field inventory')
        volume=x['volume'][k];round_cell(f['rho'],F(y[0])/volume)
        density=F(f['rho'],s)*x['rho_unit'];demand(0<density<=10000,'source EOS density domain')
        if density<=F(1,10**10):branch,degree,power,normal,gamma=0,1,0,F(1),F(1)
        elif density<=F(57,10**6):branch,degree,power,normal,gamma=1,5,2,density*10**10,F(7,5)
        elif density<=1:branch,degree,power,normal,gamma=2,20,3,density*10**6/57,F(23,20)
        else:branch,degree,power,normal,gamma=3,3,2,density,F(5,3)
        demand(len(f['root'])==2 and f['root'][0]==branch,'constitutive branch')
        root=f['root'][1]
        if branch==0:demand(root==s,'isothermal power');shape=s
        else:
            target=nearest(normal*s)**power*s**(degree-power)
            demand(type(root) is int and root**degree<=target<(root+1)**degree,'constitutive power cell')
            shape=root if branch==1 else nearest(F((x['b1'] if branch==2 else x['prefactor'])*root,s))
        round_cell(f['p'],F(f['rho']*shape,s))
        round_cell(f['cs2'],gamma*F(f['p']*s,f['rho']))
        c=f['cs'];demand(type(c) is int and c>0 and (c-1)**2<f['cs2']*s<=c*c,'upper acoustic square cell')
