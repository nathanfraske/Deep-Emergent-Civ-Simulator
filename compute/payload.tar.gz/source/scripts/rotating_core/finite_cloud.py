"""Finite nested gas regions: exact cell averages and closed material accounts."""
from fractions import Fraction as F
from arithmetic import qfraction
from .leaf_mesh import bounds
from . import boundary


def integrals(box):
    lo,hi,bottom,top=box
    if hi<=lo or top<=bottom:return [F(0)]*4
    return [(hi**2-lo**2)*(top-bottom)/2,
            (hi**3-lo**3)*(top-bottom)/3,
            (hi**2-lo**2)*(top**2-bottom**2)/4,
            (hi**4-lo**4)*(top-bottom)/4]


# @derives: finite surrounding-cloud cell masses and moments <- declared nested gas masses and extents + exact cylindrical intersection integrals + independent projection checks
def project(x,state,pressure):
    inner_r=state['inner_radius_m']/state['radius_m']
    inner_h=state['inner_half_height_m']/state['radius_m']
    fraction=state['inner_mass_kg']/state['mass_kg']
    inside_volume=inner_r**2*inner_h
    inside_density=fraction/inside_volume
    outside_density=(1-fraction)/(sum(x['volume'])-inside_volume)
    spin=state['angular_velocity_s_inv']*state['radius_m']/pressure['sound_speed_m_s']
    radial=state['radial_edge_velocity_m_s']/pressure['sound_speed_m_s']
    axial=state['axial_edge_velocity_m_s']*state['radius_m']/(pressure['sound_speed_m_s']*state['half_height_m'])
    cells=[];cumulative=F(0);previous=0
    for lo,hi,bottom,top in bounds(x):
        full=integrals((lo,hi,bottom,top))
        clipped=integrals((lo,min(hi,inner_r),max(bottom,-inner_h),min(top,inner_h)))
        moments=[outside_density*a+(inside_density-outside_density)*b for a,b in zip(full,clipped)]
        cumulative+=moments[0];current=qfraction(cumulative,x['s']);mass=current-previous;previous=current
        if mass<=0:raise ValueError('finite cloud cell below positive representation domain')
        cells.append([mass,qfraction(mass*radial*moments[1]/moments[0],1),
                      qfraction(mass*axial*moments[2]/moments[0],1),
                      qfraction(mass*spin*moments[3]/moments[0],1)])
    return cells


def start(cells):
    result=boundary.start(cells);result['schema']='civsim.rotating-finite.accounts.v1'
    return result


def advance(x,previous,accepted):
    return boundary.advance(x,previous,accepted)
