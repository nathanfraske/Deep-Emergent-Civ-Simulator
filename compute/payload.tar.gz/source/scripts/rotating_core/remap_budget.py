"""Exact bounded search for a mesh move inside two representation budgets."""
from fractions import Fraction as F
from . import adapt,mesh,remap


def select(x,cells,cfg,spent):
    proposed=adapt.propose(x,cells,cfg)
    decision=dict(schema='civsim.rotating-barotropic.remesh-budget.v1',
                  proposed_faces=proposed,spent_before=dict(spent),spent_after=dict(spent),
                  trials=[],status=None,selected_backtrack=None,selected_faces=None)
    if proposed==dict(r=x['rf'],z=x['zf']):
        decision['status']='unchanged';return decision,None,None
    limits=dict(density=cfg['remesh_density_budget'],angular=cfg['remesh_angular_budget'])
    if any(spent[k]>=limits[k] for k in limits):
        decision['status']='exhausted';return decision,None,None
    for backtrack in range(cfg['remesh_backtracks']+1):
        fraction=F(1,2**backtrack)
        coordinates={axis:[a+fraction*(b-a) for a,b in zip(edges,proposed[axis])]
                     for axis,edges in (('r',x['rf']),('z',x['zf']))}
        next_x=mesh.rebuild(x,coordinates)
        try:allocation=remap.transfer(x,next_x,cells)
        except ValueError as error:
            if str(error)!='remap below positive mass quantum':raise
            decision['trials'].append(dict(backtrack=backtrack,positive_mass=False,
                                           density_l1_mass_fraction=None,angular_profile_l1_fraction=None))
            continue
        values=allocation['diagnostics'];density=values['density_l1_mass_fraction'];angular=values['angular_profile_l1_fraction']
        decision['trials'].append(dict(backtrack=backtrack,positive_mass=True,
                                       density_l1_mass_fraction=density,angular_profile_l1_fraction=angular))
        losses=dict(density=density,angular=angular)
        if all(losses[k]<=cfg['remesh_event_fraction']*limits[k] and spent[k]+losses[k]<=limits[k] for k in limits):
            decision.update(status='accepted',selected_backtrack=backtrack,selected_faces=coordinates,
                            spent_after={k:spent[k]+losses[k] for k in limits})
            return decision,next_x,allocation
    decision['status']='backtrack_limit';return decision,None,None
