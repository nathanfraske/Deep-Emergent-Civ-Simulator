"""Replay original gas through execution cuts and selective continuation."""
from pathlib import Path
import copy,json,sys,tempfile,unittest
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(1,str(ROOT/'scripts/radial_core'))
from scripts.rotating_core import checkpoint,checkpoint_watchdog,model,run
from scripts.rotating_core.resource_stop import Deadline
from scripts.rotating_core.test_leaf import NUM,DILUTE


class SelectiveCheckpointTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scratch=tempfile.TemporaryDirectory(prefix='civsim-selective-checkpoint-')
        cls.directory=Path(cls.scratch.name);floor=cls.directory/'floor.json'
        floor.write_text(json.dumps(dict(schema='civsim.radial-core.floor.v1',G='6.67430e-11',floor_digest='e0cfd4a60342488054ddfa936599794e1697c0bd0997122c22e58047cde0aeb5')),encoding='ascii')
        cls.model=model.load(floor);cls.cache=cls.directory/'kernel.json'
        cls.parent=run.solve(DILUTE,NUM,cls.model,kernel_cache=cls.cache,workers=1,_stop_step=3)
        cls.longer=NUM.replace('max_steps=8','max_steps=16')

    @classmethod
    def tearDownClass(cls):cls.scratch.cleanup()

    def admit(self,parent=None,state=DILUTE,cache=None):
        value=self.parent if parent is None else parent
        return checkpoint_watchdog.authorize(value,state,self.model,run.solve,run.implementations(),checkpoint.text,kernel_cache=cache or self.cache,workers=1)

    def continued(self,prefix=None,cfg=None,**options):
        return run.solve(DILUTE,cfg or self.longer,self.model,kernel_cache=self.cache,workers=1,_resume=self.admit() if prefix is None else prefix,**options)

    def test_selective_prefix_restores_all_ledgers_and_actual_leaf_geometry(self):
        self.assertEqual(self.parent['stop_reason'],'execution_limit')
        self.assertEqual(self.parent['steps'],3)
        self.assertIn('cells',self.parent['coordinate_faces'])
        result=self.continued();direct=run.solve(DILUTE,self.longer,self.model,kernel_cache=self.cache,workers=1)
        self.assertEqual(result['schema'],'civsim.rotating-barotropic.run.v8')
        self.assertEqual(result['frames'][:len(self.parent['frames'])],self.parent['frames'])
        for key in ('cell_q','rho_q','pressure_q','clock_q','observation','coordinate_faces','refinement_revision','mesh_dimensions'):
            self.assertEqual(result['frames'][-1][key],direct['frames'][-1][key])
        for key in ('initial_observation','final_observation','remesh_events','remesh_decisions','remesh_spent',
                    'refinement_events','refinement_decisions','refinement_spent','pair_steps_spent','adaptive_retries'):
            self.assertEqual(result[key],direct[key])
        self.assertGreater(result['pair_steps_spent'],self.parent['pair_steps_spent'])
        self.assertEqual(result['assigned_stellar_mass_kg'],'0/1');self.assertFalse(result['completed_system'])
        self.admit(result)

    def test_deadline_cut_is_full_checked_prefix_and_can_replay_chained_cuts(self):
        calls=[0]
        def stop():
            calls[0]+=1
            return calls[0]>3
        timed=run.solve(DILUTE,NUM,self.model,kernel_cache=self.cache,workers=1,stop_requested=stop)
        self.assertEqual(timed,self.parent)
        first=self.continued(_stop_step=9)
        self.assertEqual(first['stop_reason'],'execution_limit')
        self.assertEqual(first['continuation']['segments'][0]['from_stop_reason'],'execution_limit')
        prefix=self.admit(first)
        second=self.continued(prefix,self.longer.replace('max_steps=16','max_steps=24'),_stop_step=20)
        self.assertEqual(second['steps'],20)
        self.assertEqual(second['continuation']['segments'][1]['from_stop_reason'],'execution_limit')
        self.admit(second)

    def test_stop_cuts_do_not_change_steps_or_force_an_endpoint_timestep(self):
        full=run.solve(DILUTE,NUM,self.model,kernel_cache=self.cache,workers=1)
        for frame in self.parent['frames']:
            match=next((q for q in full['frames'] if q['step']==frame['step']),None)
            if match:self.assertEqual(frame,match)
        for invalid in (True,-1,9):
            with self.assertRaises(ValueError):run.solve(DILUTE,NUM,self.model,workers=1,_stop_step=invalid)
        zero=run.solve(DILUTE,NUM,self.model,kernel_cache=self.cache,workers=1,_stop_step=0)
        self.assertEqual(zero['steps'],0);self.admit(zero)

    def test_full_replay_refuses_forged_split_work_loss_clock_and_stop_history(self):
        changes=('cells','pair','loss','refinements','geometry','clock','stop','step_type')
        for change in changes:
            bad=copy.deepcopy(self.parent)
            if change=='cells':bad['frames'][-1]['cell_q'][0][0]+=1
            elif change=='pair':bad['pair_steps_spent']-=1
            elif change=='loss':bad['refinement_spent']['density']='1/1'
            elif change=='refinements':bad['refinement_events'].pop()
            elif change=='geometry':bad['coordinate_faces']['cells'].pop()
            elif change=='clock':bad['frames'][-1]['clock_q']+=1
            elif change=='stop':bad['stop_reason']='step_limit'
            else:bad['steps']=True
            with self.subTest(change=change):
                with self.assertRaises(ValueError):self.admit(bad)
        first=self.continued(_stop_step=9)
        bad=copy.deepcopy(first);bad['continuation']['segments'][0]['from_stop_reason']='step_limit'
        with self.assertRaises(ValueError):self.admit(bad)

    def test_limits_cannot_reset_or_change_the_physical_and_causal_contract(self):
        prefix=self.admit()
        for before,after in [('fraction_bits=96','fraction_bits=128'),('softening_m=1.75e13','softening_m=8.75e12'),
                             ('refinement_max_depth=4','refinement_max_depth=5'),('refinement_density_budget=1e-12','refinement_density_budget=1e-6')]:
            with self.subTest(before=before):
                with self.assertRaises(ValueError):self.continued(prefix,cfg=self.longer.replace(before,after))
        forged=self.admit();forged.value['pair_steps_spent']=0
        with self.assertRaises(ValueError):self.continued(forged)

    def test_tensor_prefix_and_leaf_prefix_both_preserve_full_geometry(self):
        state=DILUTE.replace('mass_kg=2e29','mass_kg=2e26');cache=self.directory/'dilute.json'
        parent=run.solve(state,NUM,self.model,kernel_cache=cache,workers=1,_stop_step=3)
        self.assertIn('r',parent['coordinate_faces'])
        prefix=self.admit(parent,state,cache)
        got=run.solve(state,self.longer,self.model,kernel_cache=cache,workers=1,_resume=prefix)
        direct=run.solve(state,self.longer,self.model,kernel_cache=cache,workers=1)
        self.assertEqual(got['frames'][-1]['cell_q'],direct['frames'][-1]['cell_q'])
        self.assertEqual(got['pair_steps_spent'],direct['pair_steps_spent'])

    def test_deadline_domain_and_monotonic_work_clock(self):
        now=[100];deadline=Deadline(10,lambda:now[0])
        self.assertFalse(deadline());now[0]=109;self.assertFalse(deadline());now[0]=110;self.assertTrue(deadline())
        for bad in (0,-1,True,1.5,86401):
            with self.assertRaises(ValueError):Deadline(bad)


if __name__=='__main__':unittest.main()
