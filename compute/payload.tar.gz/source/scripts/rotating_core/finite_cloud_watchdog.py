"""Independent disjoint-region integrals and finite material ownership checks."""
from fractions import Fraction as F
from .input_watchdog import demand
from .mesh_watchdog import round_cell
from . import boundary_watchdog


def initial(x,state,cfg,pressure,cells):
    demand(state['schema']=='civsim.rotating-barotropic.state.v3' and state['geometry']=='nested_cylinders'
           and state['boundary']=='reflecting_slip' and state['exterior_gravity']=='all_resolved_gas','finite gas state binding')
    nr,nz,p=cfg['radial_cells'],cfg['vertical_cells'],cfg['mesh_power']
    radius,height=state['radius_m'],state['half_height_m'];beta=height/radius
    rf=[F(i**p,nr**p) for i in range(nr+1)]
    zf=[F((1 if 2*j>=nz else -1)*abs(2*j-nz)**p,nz**p)*beta for j in range(nz+1)]
    demand(x['rf']==rf and x['zf']==zf and len(cells)==nr*nz,'finite initial power partition')
    inner_r=state['inner_radius_m']/radius;inner_h=state['inner_half_height_m']/radius
    vin=inner_r*inner_r*inner_h
    coefficients=[state['inner_mass_kg']/(state['mass_kg']*vin),
                  (state['mass_kg']-state['inner_mass_kg'])/(state['mass_kg']*(beta-vin))]
    total=F(0);prior=0;speed=pressure['sound_speed_m_s']
    for j in range(nz):
        for i in range(nr):
            a,b=rf[i],rf[i+1];c,d=zf[j],zf[j+1]
            # Cut the cell into disjoint rectangles at the physical region edges.
            redges=sorted({a,b,*([inner_r] if a<inner_r<b else [])})
            zedges=sorted({c,d,*([v for v in (-inner_h,inner_h) if c<v<d])})
            moments=[F(0)]*4
            for r0,r1 in zip(redges,redges[1:]):
                for z0,z1 in zip(zedges,zedges[1:]):
                    coefficient=coefficients[0 if r1<=inner_r and z0>=-inner_h and z1<=inner_h else 1]
                    area=(r1-r0)*(r1+r0)
                    moments[0]+=coefficient*area*(z1-z0)/2
                    moments[1]+=coefficient*(r1-r0)*(r1*r1+r1*r0+r0*r0)*(z1-z0)/3
                    moments[2]+=coefficient*area*(z1-z0)*(z1+z0)/4
                    moments[3]+=coefficient*area*(r1*r1+r0*r0)*(z1-z0)/4
            row=cells[j*nr+i]
            demand(isinstance(row,list) and len(row)==4 and all(type(v) is int for v in row) and row[0]>0,'finite cell storage')
            total+=moments[0];after=prior+row[0];round_cell(after,total*x['s']);prior=after
            round_cell(row[1],row[0]*state['radial_edge_velocity_m_s']*moments[1]/(speed*moments[0]))
            round_cell(row[2],row[0]*state['axial_edge_velocity_m_s']*radius*moments[2]/(height*speed*moments[0]))
            round_cell(row[3],row[0]*state['angular_velocity_s_inv']*radius*moments[3]/(speed*moments[0]))
    demand(total==1 and sum(row[0] for row in cells)==x['s'],'complete finite gas mass')


def physical(x,cells,state,pressure):
    demand(x.get('boundary_mode')=='reflecting_slip' and x.get('gravity_domain')=='all_resolved_gas'
           and state['exterior_gravity']=='all_resolved_gas','all resolved surrounding gravity binding')
    demand(sum(row[0] for row in cells)==x['s'],'finite gas material ownership')
    demand(1000*pressure['G']*state['mass_kg']<=x['epsilon']*state['radius_m']*299792458**2,
           'finite current-softening Newtonian potential screen')


def accounts(x,cells,ledger):
    demand(x.get('boundary_mode')=='reflecting_slip' and ledger['schema']=='civsim.rotating-finite.accounts.v1','finite boundary account binding')
    boundary_watchdog.totals(cells,ledger)
    demand(ledger['gross_inward_mass_q']==ledger['gross_outward_mass_q']==0
           and ledger['outward_q4'][0]==ledger['outward_q4'][3]==0,'no exterior material or torque source')
