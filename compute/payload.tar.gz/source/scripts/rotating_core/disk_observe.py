"""Read-only annular gas diagnostics; no formation or simulation authority."""
from fractions import Fraction as F
from .leaf_mesh import bounds

# @derives: read-only annular gas support, motion and thickness <- checked cylindrical cell moments, complete gas gravity and incident pressure; no formed-disk authority


def measure(x,cells,fields,force,state,pressure,edges,density_floor=F(0)):
    """All cuts are observer arguments; exact quantities are never fed to evolution."""
    if not isinstance(edges,(list,tuple)) or not 2<=len(edges)<=65 or any(type(v) is not F for v in edges) or edges[0]!=0 or edges[-1]!=1 or any(a>=b for a,b in zip(edges,edges[1:])):
        raise ValueError('closed increasing exact radial observer partition required')
    if type(density_floor) is not F or density_floor<0:raise ValueError('exact nonnegative observer density cut required')
    if not len(cells)==len(fields)==len(force)==len(x['volume']):raise ValueError('observer cell census')
    s=x['s'];radius=state['radius_m'];mass=state['mass_kg'];sound=pressure['sound_speed_m_s'];boxes=bounds(x)
    pressure_force=[F(f['p'],s)*v/((box[0]+box[1])/2) for f,v,box in zip(fields,x['volume'],boxes)]
    for axis,left,right,area in x['faces']:
        if axis:continue
        pa=fields[left if left>=0 else right]['p'];pb=fields[right if right>=0 else left]['p']
        impulse=area*F(pa+pb,2*s)
        if left>=0:pressure_force[left]-=impulse
        if right>=0:pressure_force[right]+=impulse
    result=[]
    for lo,hi in zip(edges,edges[1:]):
        totals={name:F(0) for name in ('m','angular','r2','z2','rotation','radial','axial','centrifugal','gravity','pressure')}
        for k,(a,b,c,d) in enumerate(boxes):
            if F(fields[k]['rho'],s)*x['rho_unit']<density_floor:continue
            l,h=max(a,lo),min(b,hi)
            if l>=h:continue
            y=cells[k];portion=(h*h-l*l)/(b*b-a*a);m=F(y[0],s)*portion
            mean_r=2*(h**3-l**3)/(3*(h*h-l*l));mean_r2=(l*l+h*h)/2
            omega=F(y[3],y[0])/((a*a+b*b)/2)
            totals['m']+=m;totals['angular']+=m*omega*mean_r2
            totals['r2']+=m*mean_r2;totals['z2']+=m*(c*c+c*d+d*d)/3
            totals['rotation']+=m*omega*omega*mean_r2
            totals['radial']+=m*F(y[1],y[0])**2;totals['axial']+=m*F(y[2],y[0])**2
            totals['centrifugal']+=m*omega*omega*mean_r
            totals['gravity']+=m*F(force[k][0],s)
            totals['pressure']+=portion*pressure_force[k]
        m=totals['m'];rotation=totals['rotation'];inward=-totals['gravity']
        result.append(dict(r_lo_m=lo*radius,r_hi_m=hi*radius,mass_kg=m*mass,mass_fraction=m,
            angular_momentum_kg_m2_s=totals['angular']*mass*radius*sound,
            radial_second_moment_m2=totals['r2']*radius**2/m if m else None,
            axial_second_moment_m2=totals['z2']*radius**2/m if m else None,
            thickness_ratio_squared=totals['z2']/totals['r2'] if totals['r2'] else None,
            rotation_kinetic_2J=rotation*mass*sound**2,radial_kinetic_2J=totals['radial']*mass*sound**2,
            axial_kinetic_2J=totals['axial']*mass*sound**2,
            radial_motion_to_rotation_squared=totals['radial']/rotation if rotation else None,
            axial_motion_to_rotation_squared=totals['axial']/rotation if rotation else None,
            centrifugal_force_N=totals['centrifugal']*mass*sound**2/radius,
            radial_gravity_force_N=totals['gravity']*mass*sound**2/radius,
            cell_average_pressure_force_N=totals['pressure']*mass*sound**2/radius,
            centrifugal_to_inward_gravity=totals['centrifugal']/inward if inward>0 else None,
            pressure_to_inward_gravity=totals['pressure']/inward if inward>0 else None,
            radial_support_to_inward_gravity=(totals['centrifugal']+totals['pressure'])/inward if inward>0 else None))
    return dict(schema='civsim.rotating-disk.observation.v1',density_floor_kg_m3=density_floor,radial_edges=list(edges),annuli=result,
                selected_mass_kg=sum(row['mass_kg'] for row in result),formed_disk=False,completed_system=False,
                scope='Annular moments and cell-average force diagnostics of the supplied checked barotropic gas. Observer cuts, cell averaging, boundary, and continuum error remain. No disk or stellar classification.')
