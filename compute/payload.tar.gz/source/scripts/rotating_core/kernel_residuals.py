"""Independent integer-root and rational-residual ring reconstruction."""
from fractions import Fraction as F
from math import gcd,isqrt
from .input_watchdog import demand
from .mesh_watchdog import round_cell


def accumulate(pair,numerator,denominator):
    a,b=pair;g=gcd(b,denominator)
    return a*(denominator//g)+numerator*(b//g),b*(denominator//g)


def check(scale,a,b,separation,epsilon,nodes,got):
    denominator=1
    for value in (epsilon,separation,b,a):
        denominator=denominator//gcd(denominator,value.denominator)*value.denominator
    a,b,z,e=(value.numerator*(denominator//value.denominator) for value in (a,b,separation,epsilon))
    totals=[(0,1),(0,1),(0,1)];weights=(0,1);even=2*nodes
    for odd in reversed(range(1,even,2)):
        d=even*even+odd*odd;c=even*even-odd*odd;w=even*even
        for sign in (-1,1):
            distance=(a-b)**2*d+2*a*b*(d-sign*c)+(z*z+e*e)*d
            square=scale*scale*denominator*denominator*d
            q=isqrt(square//distance)
            if q*q*distance<square:q+=1
            demand((q-1)**2*distance<square<=q*q*distance,'inverse distance square cell')
            totals[0]=accumulate(totals[0],w*q,d)
            totals[1]=accumulate(totals[1],w*q**3*((a-b)*d+b*(d-sign*c)),d*d)
            totals[2]=accumulate(totals[2],w*q**3*z,d)
            weights=accumulate(weights,w,d)
    demand(len(got)==3 and all(type(v) is int for v in got),'ring coefficient census')
    measure=F(*weights)
    for component,pair in enumerate(totals):
        value=F(*pair)/measure
        if component:value/=scale*scale*denominator
        round_cell(got[component],value)
