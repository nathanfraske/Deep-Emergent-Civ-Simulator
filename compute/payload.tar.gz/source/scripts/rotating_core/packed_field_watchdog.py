"""Independent sign-separated exact sums of the checker's own columns."""
from dataclasses import dataclass


@dataclass(frozen=True)
class SignedSums:
    positive:tuple
    negative:tuple
    digit_bytes:int
    targets:int
    mass_limit:int

    def reconstruct(self,cells):
        mass=[cell[0] for cell in cells]
        if sum(mass)>self.mass_limit:return None
        upper=sum(weight*column for weight,column in zip(mass,self.positive))
        lower=sum(weight*column for weight,column in zip(mass,self.negative))
        length=2*self.targets*self.digit_bytes
        pos=upper.to_bytes(length,'big');neg=lower.to_bytes(length,'big');out=[]
        for target in range(self.targets):
            pair=[]
            for component in (0,1):
                start=(2*target+component)*self.digit_bytes;end=start+self.digit_bytes
                pair.append(int.from_bytes(pos[start:end],'big')-int.from_bytes(neg[start:end],'big'))
            out.append(pair)
        return out


def prepare(columns,mass_limit):
    n=len(columns);bits=max(abs(k).bit_length() for pair in columns for component in pair for k in component)
    digit_bytes=(bits+mass_limit.bit_length()+7)//8;positive=[];negative=[]
    for radial,axial in columns:
        positive.append(int.from_bytes(b''.join(max(0,k).to_bytes(digit_bytes,'big')
                        for pair in zip(radial,axial) for k in pair),'big'))
        negative.append(int.from_bytes(b''.join(max(0,-k).to_bytes(digit_bytes,'big')
                        for pair in zip(radial,axial) for k in pair),'big'))
    return SignedSums(tuple(positive),tuple(negative),digit_bytes,n,mass_limit)
