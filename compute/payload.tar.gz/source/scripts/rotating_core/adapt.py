"""Regularized mass-coordinate redistribution; no body or outcome selector."""
from fractions import Fraction as F
from math import isqrt
from arithmetic import qfraction


def inverse(edges,weights,target):
    before=F(0)
    for lo,hi,weight in zip(edges,edges[1:],weights):
        if target<=before+weight:
            return lo+(hi-lo)*(target-before)/weight
        before+=weight
    raise ValueError('mass-coordinate target outside coverage')


def root_coordinate(value,scale):
    q=isqrt((value*scale*scale).__floor__())
    difference=4*value*scale*scale-(2*q+1)**2
    if difference>0 or (difference==0 and q%2):q+=1
    return F(q,scale)


def propose(x,cells,cfg):
    nr,nz=x['nr'],x['nz'];total=sum(y[0] for y in cells)
    eta=cfg['remesh_regularization'];relax=cfg['remesh_relaxation'];power=cfg['mesh_power']
    radial=[sum(cells[j*nr+i][0] for j in range(nz)) for i in range(nr)]
    axial=[sum(y[0] for y in cells[j*nr:(j+1)*nr]) for j in range(nz)]
    u=[r*r for r in x['rf']];beta=x['zf'][-1]
    rw=[eta*(b-a)+(1-eta)*F(m,total) for a,b,m in zip(u,u[1:],radial)]
    zw=[eta*(b-a)/(2*beta)+(1-eta)*F(m,total) for a,b,m in zip(x['zf'],x['zf'][1:],axial)]
    target_r=[F(0)]+[root_coordinate(inverse(u,rw,F(i,nr)**(2*power)),x['s']) for i in range(1,nr)]+[F(1)]
    target_z=[-beta]
    for j in range(1,nz):
        initial=(1 if 2*j>=nz else -1)*abs(F(2*j,nz)-1)**power*beta
        z=inverse(x['zf'],zw,(initial+beta)/(2*beta))
        target_z.append(F(qfraction(z,x['s']),x['s']))
    target_z.append(beta)
    return dict(r=[a+relax*(b-a) for a,b in zip(x['rf'],target_r)],
                z=[a+relax*(b-a) for a,b in zip(x['zf'],target_z)])
