"""Finite continuation: original gas, whole history and signed wall accounts."""
from pathlib import Path
import copy,io,json,subprocess,sys,tempfile,unittest
from unittest.mock import patch
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'scripts/radial_core')]
from arithmetic import canonical_json,digest
from scripts.rotating_core import checkpoint,checkpoint_watchdog,finite_checkpoint,finite_checkpoint_watchdog
from scripts.rotating_core import model,run,inputs,mesh
from scripts.rotating_core.test_finite import FINITE
from scripts.rotating_core.test_leaf import NUM
from scripts.rotating_core.test_softening import WIDTH
import pi_pair

GAS=FINITE.replace('mass_kg=2.5e30','mass_kg=2.5e29').replace('inner_mass_kg=2e30','inner_mass_kg=2e29')


class FiniteCheckpointTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scratch=tempfile.TemporaryDirectory(prefix='civsim-finite-continuation-')
        cls.directory=Path(cls.scratch.name);cls.floor=cls.directory/'floor.json'
        # Arithmetic/source fixture; executable formation runs acquire native floor.
        cls.floor.write_text(json.dumps(dict(schema='civsim.radial-core.floor.v1',G='6.67430e-11',floor_digest='e0cfd4a60342488054ddfa936599794e1697c0bd0997122c22e58047cde0aeb5')),encoding='ascii')
        cls.model=model.load(cls.floor,run.FINITE_MODEL_ID)
        cls.cache=cls.directory/'kernel.json'
        cls.parent=run.solve(GAS,WIDTH,cls.model,kernel_cache=cls.cache,workers=1,_stop_step=3)
        cls.longer=WIDTH.replace('max_steps=8','max_steps=16')

    @classmethod
    def tearDownClass(cls):cls.scratch.cleanup()

    def admit(self,value=None,state=GAS,cache=None):
        return checkpoint_watchdog.authorize(self.parent if value is None else value,state,self.model,run.solve,
            run.implementations(),checkpoint.text,kernel_cache=cache or self.cache,workers=1)

    def continued(self,prefix=None,cfg=None,state=GAS,cache=None,**options):
        return run.solve(state,cfg or self.longer,self.model,kernel_cache=cache or self.cache,workers=1,
            _resume=self.admit() if prefix is None else prefix,**options)

    def test_uninterrupted_equivalence_preserves_all_finite_and_projection_accounts(self):
        got=self.continued();direct=run.solve(GAS,self.longer,self.model,kernel_cache=self.cache,workers=1)
        self.assertEqual(got['schema'],'civsim.rotating-barotropic.finite.run.v2')
        self.assertEqual(got['frames'][:len(self.parent['frames'])],self.parent['frames'])
        for key in ('initial_observation','final_observation','boundary_accounts','coordinate_faces','adaptive_retries',
                    'remesh_events','remesh_decisions','remesh_spent','refinement_events','refinement_decisions',
                    'refinement_spent','pair_steps_spent','effective_softening_m'):
            self.assertEqual(got[key],direct[key],key)
        for key in ('cell_q','clock_q','time_s','rho_q','pressure_q','observation','boundary_accounts','coordinate_faces'):
            self.assertEqual(got['frames'][-1][key],direct['frames'][-1][key],key)
        self.assertTrue(got['continuation_supported']);self.assertFalse(got['completed_system']);self.assertFalse(got['disk_assessed'])
        self.assertEqual(got['assigned_stellar_mass_kg'],'0/1')
        self.assertEqual(got['boundary_accounts']['initial_q4'],self.parent['boundary_accounts']['initial_q4'])
        self.assertNotEqual(self.parent['boundary_accounts']['outward_q4'],[0]*4)
        self.assertGreater(got['frames'][-1]['clock_q'],self.parent['frames'][-1]['clock_q'])
        self.admit(got)

    def test_chained_execution_cuts_preserve_global_steps_and_stop_history(self):
        first=self.continued(_stop_step=7);second=self.continued(self.admit(first),cfg=self.longer.replace('max_steps=16','max_steps=24'),_stop_step=10)
        self.assertEqual(second['steps'],10);self.assertEqual(len(second['continuation']['segments']),2)
        self.assertEqual(second['frames'][:len(first['frames'])],first['frames']);self.admit(second)
        bad=copy.deepcopy(second);bad['continuation']['segments'][0]['from_stop_reason']='step_limit'
        with self.assertRaises(ValueError):self.admit(bad)
        bad=copy.deepcopy(second);bad['continuation']['segments']*=5
        with self.assertRaises(ValueError):self.admit(bad)

    def test_zero_step_and_clipped_clock_do_not_create_time(self):
        zero=run.solve(GAS,WIDTH,self.model,kernel_cache=self.cache,workers=1,_stop_step=0)
        self.assertEqual(self.continued(self.admit(zero),_stop_step=3)['frames'][-1]['cell_q'],self.parent['frames'][-1]['cell_q'])
        raw=WIDTH.replace('max_elapsed_s=2.45e12','max_elapsed_s=1e8')
        parent=run.solve(GAS,raw,self.model,kernel_cache=self.cache,workers=1)
        self.assertTrue(parent['reached_requested_time'])
        got=self.continued(self.admit(parent),_stop_step=parent['steps']+1)
        self.assertEqual(got['frames'][:len(parent['frames'])],parent['frames'])
        self.assertGreater(got['frames'][-1]['clock_q'],parent['frames'][-1]['clock_q'])

    def test_rebased_balanced_ledger_and_corrupted_history_refuse(self):
        for change in ('wall','source','initial','rebase','clock','cells','frames','geometry','spent','pair','flag','type','trace'):
            bad=copy.deepcopy(self.parent)
            if change in ('wall','source','initial'):
                key={'wall':'outward_q4','source':'source_q2','initial':'initial_q4'}[change];bad['boundary_accounts'][key][1]+=1
            elif change=='rebase':
                ledger=bad['boundary_accounts'];ledger['initial_q4']=list(ledger['endpoint_q4']);ledger['outward_q4']=[0]*4;ledger['source_q2']=[0]*2
                bad['frames'][-1]['boundary_accounts']=copy.deepcopy(ledger)
            elif change=='clock':bad['frames'][-1]['clock_q']+=1
            elif change=='cells':bad['frames'][-1]['cell_q'][0][1]+=1
            elif change=='frames':bad['frames'].pop(0)
            elif change=='geometry':bad['coordinate_faces']['cells'].pop()
            elif change=='spent':bad['refinement_spent']['density']='1/1'
            elif change=='pair':bad['pair_steps_spent']-=1
            elif change=='flag':bad['disk_assessed']=True
            elif change=='type':bad['boundary_accounts']['gross_inward_mass_q']=False
            else:bad['trace_sha256']='0'*64
            with self.subTest(change=change),self.assertRaises(ValueError):self.admit(bad)

    def test_unchecked_changed_and_cross_model_prefixes_refuse(self):
        with self.assertRaises(ValueError):self.continued(self.parent)
        with self.assertRaises(ValueError):self.continued(self.admit(),state=GAS.replace('inner_mass_kg=2e29','inner_mass_kg=1e29'))
        prefix=self.admit();prefix.value['boundary_accounts']['source_q2'][0]+=1
        with self.assertRaises(ValueError):self.continued(prefix)
        prefix=self.admit();prefix.ids['unknown']='0'*64
        with self.assertRaises(ValueError):self.continued(prefix)
        bad=copy.deepcopy(self.parent);bad['schema']='civsim.rotating-barotropic.run.v9'
        with self.assertRaises(ValueError):self.admit(bad)

    def test_causal_contract_and_capacities_stay_fixed(self):
        prefix=self.admit()
        for a,b in (('courant_fraction=0.2','courant_fraction=0.1'),('fraction_bits=96','fraction_bits=128'),
                    ('softening_cell_fraction=0.125','softening_cell_fraction=0.25'),('refinement_max_cells=256','refinement_max_cells=512'),
                    ('refinement_density_budget=1e-12','refinement_density_budget=1e-6'),('max_pair_steps=134217728','max_pair_steps=16777216')):
            with self.subTest(a=a),self.assertRaises(ValueError):self.continued(prefix,cfg=self.longer.replace(a,b))
        with self.assertRaises(ValueError):self.continued(prefix,cfg=WIDTH.replace('max_steps=8','max_steps=2'))
        unsupported=run.solve(GAS,WIDTH.replace('numerics.v7','numerics.v5').replace('jeans_dyadic_cells','jeans_dyadic_bands').split('gravity_softening=')[0],self.model,workers=1)
        with self.assertRaises(ValueError):self.admit(unsupported)

    def test_v6_tensor_v7_leaves_and_signed_motion_preserve_direct_evolution(self):
        for index,(raw,numeric) in enumerate(((GAS,NUM),(GAS.replace('mass_kg=2.5e29','mass_kg=2.5e26').replace('inner_mass_kg=2e29','inner_mass_kg=2e26'),WIDTH),
                (GAS.replace('angular_velocity_s_inv=2e-13','angular_velocity_s_inv=-2e-13').replace('radial_edge_velocity_m_s=0','radial_edge_velocity_m_s=-20'),WIDTH))):
            cache=self.directory/f'control-{index}.json';parent=run.solve(raw,numeric,self.model,kernel_cache=cache,workers=1,_stop_step=3)
            longer=numeric.replace('max_steps=8','max_steps=12');got=self.continued(self.admit(parent,raw,cache),cfg=longer,state=raw,cache=cache)
            direct=run.solve(raw,longer,self.model,kernel_cache=cache,workers=1)
            self.assertEqual(got['boundary_accounts'],direct['boundary_accounts']);self.assertEqual(got['frames'][-1]['cell_q'],direct['frames'][-1]['cell_q'])
            self.assertEqual(got['coordinate_faces'],direct['coordinate_faces'])
            self.assertIn('r' if index==1 else 'cells',parent['coordinate_faces'])

    def test_observers_and_historical_source_claims_cannot_change_gas(self):
        parent=copy.deepcopy(self.parent);parent['implementations']={'historical.py':'0'*64}
        parent['execution_identity']=digest(canonical_json(dict(physical_identity=parent['physical_identity'],numerics=parent['numerics'],implementations=parent['implementations'])).encode('ascii'))
        one=self.continued(self.admit(parent));other=self.continued(self.admit(),cfg=self.longer.replace('sample_every=4','sample_every=2'),state=GAS.replace('description=','description=Observer '))
        self.assertEqual(one['trace_sha256'],other['trace_sha256']);self.assertEqual(one['boundary_accounts'],other['boundary_accounts'])
        def mutate(frame):frame['boundary_accounts']['source_q2'][0]=0;frame['cell_q'][0][0]=1
        self.assertEqual(one,self.continued(self.admit(parent),on_frame=mutate))
        parent['execution_identity']='0'*64
        with self.assertRaises(ValueError):self.admit(parent)

    def test_source_and_independent_account_restoration_refuse_mutants(self):
        with tempfile.TemporaryDirectory(prefix='civsim-finite-witness-') as folder:
            root=Path(folder);path=root/finite_checkpoint_watchdog.WITNESS;path.parent.mkdir(parents=True)
            path.write_bytes((ROOT/finite_checkpoint_watchdog.WITNESS).read_bytes()+b'changed\n')
            with self.assertRaises(ValueError):finite_checkpoint_watchdog.source(root)
        with patch.object(finite_checkpoint,'restore_accounts',side_effect=lambda parent:dict(copy.deepcopy(parent['boundary_accounts']),outward_q4=[0]*4)):
            with self.assertRaises(ValueError):self.continued()

    def test_cli_replays_parent_and_checks_new_witness_without_reset(self):
        parent=self.directory/'parent.json';parent.write_text(canonical_json(self.parent),encoding='ascii')
        state=self.directory/'state';state.write_text(GAS,encoding='ascii');cfg=self.directory/'numerics';cfg.write_text(self.longer,encoding='ascii')
        command=[sys.executable,'-B',str(ROOT/'scripts/rotating_core/run.py'),'--model',run.FINITE_MODEL_ID,'--state',str(state),'--numerics',str(cfg),
            '--floor-receipt',str(self.floor),'--continue-from',str(parent),'--kernel-cache',str(self.cache),'--workers','1']
        result=subprocess.run(command,capture_output=True,timeout=120)
        self.assertEqual(result.returncode,0,result.stderr.decode())
        got=json.loads(result.stdout);checkpoint_watchdog.strict_equal(checkpoint.science(got),self.continued())

    def test_large_cached_kernel_bounds_retain_full_mathematical_checks(self):
        state=inputs.state(GAS);cfg=inputs.numerics(WIDTH);x=mesh.build(state,cfg,self.model['pressure'],pi_pair.value(96))
        x.update(boundary_mode='reflecting_slip',gravity_domain='all_resolved_gas')
        expected=run.get_kernel(x,self.cache,1,None)[1]
        with patch.object(Path,'stat',return_value=SimpleNamespace(st_size=65*1024**2)):
            self.assertEqual(run.get_kernel(x,self.cache,1,None)[1],expected)
        for size in (0,1536*1024**2+1):
            with patch.object(Path,'stat',return_value=SimpleNamespace(st_size=size)),self.assertRaisesRegex(ValueError,'kernel cache resource'):
                run.get_kernel(x,self.cache,1,None)

    def test_forward_deadline_starts_after_replay_and_invalid_budget_refuses_first(self):
        from scripts.rotating_core.resource_stop import Deadline
        parent=self.directory/'deadline-parent.json';parent.write_text(canonical_json(self.parent),encoding='ascii')
        state=self.directory/'deadline-state';state.write_text(GAS,encoding='ascii')
        cfg=self.directory/'deadline-numerics';cfg.write_text(self.longer,encoding='ascii')
        argv=['run.py','--model',run.FINITE_MODEL_ID,'--state',str(state),'--numerics',str(cfg),'--floor-receipt',str(self.floor),
              '--continue-from',str(parent),'--kernel-cache',str(self.cache),'--workers','1','--wall-seconds','1']
        now=[0];authorize=checkpoint_watchdog.authorize
        def replay(*args,**options):
            result=authorize(*args,**options);now[0]+=2;return result
        output=io.StringIO()
        with patch.object(sys,'argv',argv),patch.object(sys,'stdout',output),patch.object(sys,'stderr',io.StringIO()),\
                patch.object(run,'Deadline',side_effect=lambda seconds:Deadline(seconds,lambda:now[0])),\
                patch.object(checkpoint_watchdog,'authorize',side_effect=replay):
            run.main()
        got=json.loads(output.getvalue());self.assertEqual(got['steps'],16)
        argv[-1]='0'
        with patch.object(sys,'argv',argv),patch.object(checkpoint_watchdog,'authorize') as admission,self.assertRaises(ValueError):
            run.main()
        admission.assert_not_called()


if __name__=='__main__':unittest.main()
