"""Real declared exterior inputs, signed physical fluxes and corruption controls."""
from pathlib import Path
import copy,json,sys,tempfile,unittest
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'scripts/radial_core')]
from arithmetic import rounded
import pi_pair
from scripts.rotating_core import boundary,boundary_watchdog,inputs,input_watchdog,mesh,mesh_watchdog,model,run
from scripts.rotating_core import eos,eos_watchdog,gravity,transport,transport_watchdog
from scripts.rotating_core.test_core import STATE,SMALL

OPEN=(ROOT/'examples/rotating-core/open-cloud.state').read_text(encoding='ascii')


class OpenTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scratch=tempfile.TemporaryDirectory(prefix='civsim-open-test-');cls.directory=Path(cls.scratch.name)
        floor=cls.directory/'floor.json'
        floor.write_text(json.dumps(dict(schema='civsim.radial-core.floor.v1',G='6.67430e-11',floor_digest='e0cfd4a60342488054ddfa936599794e1697c0bd0997122c22e58047cde0aeb5')),encoding='ascii')
        cls.model=model.load(floor,run.OPEN_MODEL_ID);cls.wall=model.load(floor)

    @classmethod
    def tearDownClass(cls):cls.scratch.cleanup()

    def setup_gas(self,velocity,spin='2e-13'):
        raw=OPEN.replace('radial_edge_velocity_m_s=0','radial_edge_velocity_m_s='+str(velocity)).replace('axial_edge_velocity_m_s=0','axial_edge_velocity_m_s='+str(velocity)).replace('angular_velocity_s_inv=2e-13','angular_velocity_s_inv='+spin)
        state=inputs.state(raw);cfg=inputs.numerics(SMALL);pressure=self.model['pressure']
        input_watchdog.check(raw,state,'state');input_watchdog.physical(state,cfg,pressure,pi_pair.value(96))
        x=mesh.build(state,cfg,pressure,pi_pair.value(96));original=mesh.project(x,state,pressure)
        mesh_watchdog.check(state,cfg,pressure,x['pi'],x,original);x['boundary_mode']='extrapolated_cylinder'
        cells=boundary.project(x,original,state,pressure);boundary_watchdog.initial(x,original,cells,state,pressure)
        fields=eos.fields(x,cells);eos_watchdog.check(x,cells,fields)
        force=[[0,0] for _ in cells];dt=transport.timestep(x,cells,fields,force)
        stage=transport.stage(x,cells,fields,force,dt);transport_watchdog.stage(x,cells,fields,force,dt,stage)
        return raw,state,x,cells,fields,force,dt,stage

    def test_closed_state_boundary_and_exterior_custody(self):
        state=inputs.state(OPEN);input_watchdog.check(OPEN,state,'state')
        for bad in (OPEN.replace('exterior_gravity=neglected','exterior_gravity=uniform'),
                    OPEN.replace('extrapolated_cylinder','vacuum'),OPEN.replace('state.v2','state.v1'),
                    OPEN.replace('radial_edge_velocity_m_s=0\n',''),OPEN+'requested_stars=1\n'):
            with self.subTest(bad=bad),self.assertRaises(ValueError):inputs.state(bad)
            with self.assertRaises(ValueError):input_watchdog.check(bad,state,'state')
        for key,value in (('boundary','reflecting_slip'),('exterior_gravity','solved'),('radial_edge_velocity_m_s',F(1))):
            with self.assertRaises(ValueError):input_watchdog.check(OPEN,dict(state,**{key:value}),'state')
        with self.assertRaises(ValueError):run.solve(OPEN,SMALL,self.wall,workers=1)
        with self.assertRaises(ValueError):run.solve(STATE,SMALL,self.model,workers=1)
        forged=copy.deepcopy(self.model);forged['provenance']['sources/open_boundary/bc.rst']='0'*64
        with self.assertRaises(ValueError):model.validate(forged)

    def test_integrated_bulk_motion_refuses_changed_momenta(self):
        _,state,x,cells,_,_,_,_=self.setup_gas(20)
        original=mesh.project(x,state,self.model['pressure'])
        for component in (0,1,2,3):
            altered=copy.deepcopy(cells);altered[7][component]+=1
            with self.assertRaises(ValueError):boundary_watchdog.initial(x,original,altered,state,self.model['pressure'])

    def test_signed_inflow_outflow_spin_and_zero_axis(self):
        for velocity in (-20,20):
            for spin in ('-2e-13','2e-13'):
                _,state,x,cells,fields,force,dt,stage=self.setup_gas(velocity,spin)
                first=boundary.start(cells);boundary_watchdog.start(cells,first)
                second=boundary.advance(x,first,stage);boundary_watchdog.advance(x,cells,stage,first,second)
                self.assertGreater(second['outward_q4'][0]*velocity,0)
                self.assertGreater(F(second['outward_q4'][3])*F(velocity)*F(spin),0)
                self.assertEqual(second['residual_q4'],[0]*4)
                self.assertEqual(second['gross_inward_mass_q']>0,velocity<0)
                self.assertEqual(second['gross_outward_mass_q']>0,velocity>0)
                for face,impulse in zip(x['faces'],stage['transfers']):
                    if face[3]==0:self.assertEqual(impulse,[0]*4)
                boundary_watchdog.physical(x,stage['next'],state,self.model['pressure'])

    def test_ghost_copy_has_no_alias_or_normal_reversal(self):
        _,_,x,cells,fields,_,_,_=self.setup_gas(-20)
        face=next(face for face in x['faces'] if face[1]<0 and face[3]>0)
        a,b,*_=transport.sides(x,cells,fields,face);self.assertEqual(a,b)
        remembered=b[2];a[2]=1;self.assertEqual(b[2],remembered)

    def test_corrupt_flux_and_accounts_refuse(self):
        _,_,x,cells,fields,force,dt,stage=self.setup_gas(-20)
        index=next(k for k,f in enumerate(x['faces']) if f[2]<0 and f[3]>0)
        for component in range(4):
            bad=copy.deepcopy(stage);bad['transfers'][index][component]+=1
            with self.assertRaises(ValueError):transport_watchdog.stage(x,cells,fields,force,dt,bad)
        first=boundary.start(cells);second=boundary.advance(x,first,stage)
        for name,component in (('initial_q4',0),('outward_q4',0),('outward_q4',3),('source_q2',0),('endpoint_q4',2),('residual_q4',0)):
            bad=copy.deepcopy(second);bad[name][component]+=1
            with self.assertRaises(ValueError):boundary_watchdog.advance(x,cells,stage,first,bad)
        bad=copy.deepcopy(second);bad['gross_inward_mass_q']+=1
        with self.assertRaises(ValueError):boundary_watchdog.advance(x,cells,stage,first,bad)
        forged=copy.deepcopy(x);del forged['boundary_mode']
        with self.assertRaises(ValueError):transport_watchdog.stage(forged,cells,fields,force,dt,stage)

    def test_actual_face_rounding_controls_boundary_account(self):
        x=dict(faces=[(0,0,-1,F(1)),(1,0,-1,F(1))]);old=[[100,0,0,0]]
        first=dict(transfers=[[1,0,0,1],[1,0,0,1]],sources=[[0,0]])
        second=dict(transfers=[[0]*4,[0]*4],sources=[[0,0]])
        average=transport.combine(x,old,first,second)
        initial=boundary.start(old);actual=boundary.advance(x,initial,average)
        boundary_watchdog.advance(x,old,average,initial,actual)
        self.assertEqual(actual['outward_q4'],[0]*4)
        self.assertEqual(rounded(sum(row[0] for row in first['transfers']),2),1)
        bad=copy.deepcopy(actual);bad['outward_q4'][0]=1
        with self.assertRaises(ValueError):boundary_watchdog.advance(x,old,average,initial,bad)

    def test_current_mass_potential_is_screened(self):
        _,state,x,cells,_,_,_,_=self.setup_gas(0)
        boundary_watchdog.physical(x,cells,state,self.model['pressure'])
        huge=[[row[0]*10**12,*row[1:]] for row in cells]
        with self.assertRaisesRegex(ValueError,'current enclosed'):boundary_watchdog.physical(x,huge,state,self.model['pressure'])

    def test_no_open_continuation_and_checked_execution_cut(self):
        with self.assertRaisesRegex(ValueError,'continuation'):run.solve(OPEN,SMALL,self.model,workers=1,_resume=object())
        result=run.solve(OPEN,SMALL,self.model,workers=1,_stop_step=2)
        self.assertEqual((result['steps'],result['stop_reason']),(2,'execution_limit'))
        self.assertFalse(result['continuation_supported']);self.assertFalse(result['disk_assessed']);self.assertFalse(result['completed_system'])
        self.assertEqual(result['assigned_stellar_mass_kg'],'0/1')
        self.assertEqual(result['boundary_accounts']['residual_q4'],[0]*4)

    def test_observers_cannot_change_gas_receipts_or_eagerly_force_diagnostics(self):
        plain=run.solve(OPEN,SMALL,self.model,workers=1)
        def changed(frame):
            frame['cell_q'][0][0]=1;frame['boundary_accounts']['outward_q4'][0]=1
        def progress(kind,value):
            if kind=='accepted':
                value['observation']._materialize()['total_mass_kg']=F(1)
        protected=run.solve(OPEN,SMALL,self.model,workers=1,on_frame=changed,progress=progress)
        self.assertEqual(plain,protected)

    def test_spin_reversal_and_sampling_preserve_transport(self):
        raw,*_=self.setup_gas(-20)
        plus=run.solve(raw,SMALL,self.model,workers=1)
        minus=run.solve(raw.replace('angular_velocity_s_inv=2e-13','angular_velocity_s_inv=-2e-13'),SMALL,self.model,workers=1)
        for a,b in zip(plus['frames'][-1]['cell_q'],minus['frames'][-1]['cell_q']):self.assertEqual(a[:3]+[-a[3]],b)
        self.assertEqual(plus['boundary_accounts']['outward_q4'][:3]+[-plus['boundary_accounts']['outward_q4'][3]],minus['boundary_accounts']['outward_q4'])
        sampled=run.solve(raw.replace('description=','description=Observer '),SMALL.replace('sample_every=4','sample_every=2'),self.model,workers=1)
        self.assertEqual((plus['physical_identity'],plus['trace_sha256']),(sampled['physical_identity'],sampled['trace_sha256']))


if __name__=='__main__':unittest.main()
