"""Finite cylindrical cells; exact volume and face identities, no fake calorics."""
from fractions import Fraction as F
from arithmetic import qfraction
import constitutive
from . import softening


def build(state,cfg,model,pi):
    s=1<<cfg['fraction_bits'];nr=cfg['radial_cells'];nz=cfg['vertical_cells'];power=cfg['mesh_power']
    beta=state['half_height_m']/state['radius_m']
    rf=[F(i,nr)**power for i in range(nr+1)]
    zf=[(1 if 2*j>=nz else -1)*abs(F(2*j,nz)-1)**power*beta for j in range(nz+1)]
    r=[(a+b)/2 for a,b in zip(rf,rf[1:])];z=[(a+b)/2 for a,b in zip(zf,zf[1:])]
    volume=[(rf[i+1]**2-rf[i]**2)*(zf[j+1]-zf[j])/2 for j in range(nz) for i in range(nr)]
    faces=[]
    for j in range(nz):
        for i in range(nr+1):
            faces.append((0,j*nr+i-1 if i else -1,j*nr+i if i<nr else -1,rf[i]*(zf[j+1]-zf[j])))
    for j in range(nz+1):
        for i in range(nr):
            faces.append((1,(j-1)*nr+i if j else -1,j*nr+i if j<nz else -1,(rf[i+1]**2-rf[i]**2)/2))
    separations=sorted({abs(a-b) for a in z for b in z})
    incidence=[[separations.index(abs(a-b)) for b in z] for a in z]
    x=dict(s=s,nr=nr,nz=nz,rf=rf,zf=zf,r=r,z=z,volume=volume,faces=faces,
                separations=separations,incidence=incidence,pi=pi,
                rho_unit=state['mass_kg']/(2*pi*state['radius_m']**3),
                transition=model['density'],**constitutive.coefficients(s,model['density']),
                gravity=qfraction(model['G']*state['mass_kg']/(state['radius_m']*model['sound_speed_m_s']**2),s),
                time_unit=state['radius_m']/model['sound_speed_m_s'],
                epsilon=cfg['softening_m']/state['radius_m'],cfl=cfg['courant_fraction'],angles=cfg['angular_nodes'])
    return softening.configure(x,state,cfg)


def project(x,state,model):
    s=x['s'];total=sum(x['volume']);cumulative=F(0);previous=0;cells=[]
    spin=state['angular_velocity_s_inv']*state['radius_m']/model['sound_speed_m_s']
    for k,v in enumerate(x['volume']):
        cumulative+=v;current=qfraction(cumulative/total,s);mass=current-previous;previous=current
        i=k%x['nr'];r2=(x['rf'][i]**2+x['rf'][i+1]**2)/2
        cells.append([mass,0,0,qfraction(F(mass,s)*spin*r2,s)])
    return cells


def rebuild(old,coordinates):
    """Replace the partition while retaining the same domain, units and laws."""
    x=dict(old);rf,zf=coordinates['r'],coordinates['z'];nr,nz=len(rf)-1,len(zf)-1
    x.update(nr=nr,nz=nz)
    x.update(rf=list(rf),zf=list(zf),r=[(a+b)/2 for a,b in zip(rf,rf[1:])],z=[(a+b)/2 for a,b in zip(zf,zf[1:])])
    x['volume']=[(rf[i+1]**2-rf[i]**2)*(zf[j+1]-zf[j])/2 for j in range(nz) for i in range(nr)]
    x['faces']=[(0,j*nr+i-1 if i else -1,j*nr+i if i<nr else -1,rf[i]*(zf[j+1]-zf[j])) for j in range(nz) for i in range(nr+1)]
    x['faces'] += [(1,(j-1)*nr+i if j else -1,j*nr+i if j<nz else -1,(rf[i+1]**2-rf[i]**2)/2) for j in range(nz+1) for i in range(nr)]
    x['separations']=sorted({abs(a-b) for a in x['z'] for b in x['z']})
    x['incidence']=[[x['separations'].index(abs(a-b)) for b in x['z']] for a in x['z']]
    return softening.update(x)
