"""Independent Jeans inequalities, nested coverage and complete split accounts."""
from fractions import Fraction as F
from hashlib import sha256
from arithmetic import parse_rational
from .input_watchdog import demand
from . import remap_watchdog

WITNESS='sources/barotropic_core/refinement-equations.txt'
PIN='a713168edaad61a22b502acead767de2fb6ec24c307a7affce8ea248df44d664'


def source(root):
    raw=(root/WITNESS).read_bytes().replace(b'\r\n',b'\n')
    demand(b'\r' not in raw and sha256(raw).hexdigest()==PIN,'refinement witness custody')
    return {WITNESS:PIN}


def ratios(x,fields,state,model):
    result=[]
    for j in range(x['nz']):
        for i in range(x['nr']):
            row=fields[j*x['nr']+i]
            real=F(row['rho'],x['s'])*state['mass_kg']/(2*x['pi']*state['radius_m']**3)
            denominator=x['pi']*model['sound_speed_m_s']**2*F(row['cs2'],x['s'])
            demand(real>0 and denominator>0,'positive refinement state')
            result.append(tuple(model['G']*real*state['radius_m']**2*(edges[index+1]-edges[index])**2/denominator for edges,index in ((x['rf'],i),(x['zf'],j))))
    return result


def screen(x,fields,state,model):
    demand(all(16*q<=1 for pair in ratios(x,fields,state,model) for q in pair),'unresolved Jeans width')


def plan(x,fields,state,model,cfg,got):
    demand(set(got)=={'schema','status','levels','new_faces','required_cells','max_ratio_squared'} and got['schema']=='civsim.rotating-barotropic.refinement-plan.v1','refinement plan inventory')
    pairs=ratios(x,fields,state,model);maximum=max(q for pair in pairs for q in pair)
    demand(isinstance(got['max_ratio_squared'],F) and got['max_ratio_squared']==maximum,'refinement diagnostic binding')
    if maximum<=cfg['refinement_trigger_squared']:
        demand(got['status']=='unchanged' and got['levels'] is None and got['new_faces'] is None and type(got['required_cells']) is int and got['required_cells']==len(fields),'unchanged refinement')
        return
    levels=got['levels'];demand(type(levels) is dict and set(levels)=={'r','z'},'refinement level inventory')
    expected_counts=[]
    for axis,count,edges in ((0,x['nr'],x['rf']),(1,x['nz'],x['zf'])):
        names=levels['r' if axis==0 else 'z']
        demand(len(names)==count and all(type(v) is int and 0<=v<=cfg['refinement_max_depth']+1 for v in names),'bounded integer split levels')
        for index,depth in enumerate(names):
            band=range(index,len(fields),x['nr']) if axis==0 else range(index*x['nr'],(index+1)*x['nr'])
            largest=max(pairs[k][axis] for k in band)
            target=cfg['refinement_target_squared']*2**(2*depth)
            demand(largest<=target or depth==cfg['refinement_max_depth']+1,'sufficient bounded split depth')
            demand(depth==0 or largest>target/4,'minimal dyadic depth')
        expected_counts.append(sum(1<<v for v in names))
    demand(type(got['required_cells']) is int and got['required_cells']==expected_counts[0]*expected_counts[1],'tensor split census')
    status='depth_limit' if any(v>cfg['refinement_max_depth'] for a in levels.values() for v in a) else 'cell_limit' if got['required_cells']>cfg['refinement_max_cells'] or any(n>128 for n in expected_counts) else 'accepted'
    demand(got['status']==status,'independent refinement capacity decision')
    if status!='accepted':demand(got['new_faces'] is None,'no refused geometry');return
    faces=got['new_faces'];demand(type(faces) is dict and set(faces)=={'r','z'},'refined face inventory')
    for name,edges in (('r',x['rf']),('z',x['zf'])):
        received=faces[name];position=0
        demand(all(isinstance(v,F) for v in received),'exact split faces')
        for index,depth in enumerate(levels[name]):
            n=1<<depth;lo,hi=edges[index:index+2]
            demand(received[position]==lo,'nested parent face')
            for child in range(n):
                demand(n*(received[position+child]-lo)==child*(hi-lo),'uniform dyadic child coordinates')
            position+=n
        demand(len(received)==position+1 and received[-1]==edges[-1],'complete split domain')


def allocation(old,new,cells,got,spent,cfg):
    remap_watchdog.check(old,new,cells,got)
    demand(set(spent)=={'density','angular'} and all(isinstance(v,F) and v>=0 for v in spent.values()),'refinement prior loss domain')
    next_spent={key:spent[key]+got['diagnostics'][name] for key,name in (('density','density_l1_mass_fraction'),('angular','angular_profile_l1_fraction'))}
    valid=all(next_spent[key]<=cfg['refinement_'+key+'_budget'] for key in next_spent)
    return valid,next_spent


def ledger(cfg,decisions,events,spent,steps,pair_steps):
    demand(len(events)<=cfg['refinement_max_events'] and len(decisions)<=cfg['refinement_max_events']+1,'complete refinement capacity')
    before=dict(density=F(0),angular=F(0));position=0;last=-1;cells=cfg['radial_cells']*cfg['vertical_cells'];work=0;cut=0
    for record in decisions:
        step=record['step'];demand(type(step) is int and last<step<=steps,'refinement decision ordering');last=step
        prior={k:parse_rational(v) for k,v in record['spent_before'].items()}
        demand(prior==before,'refinement budget ancestry')
        status=record['status']
        if status=='accepted':
            demand(position<len(events),'missing refinement event');event=events[position];position+=1
            demand(event['decision_index']==position-1 and event['step']==step and event['clock_q']==record['clock_q'] and event['old_faces']==record['old_faces'] and event['old_cell_q']==record['old_cell_q'] and event['new_faces']==record['plan']['new_faces'],'complete refinement event binding')
            demand(len(event['old_cell_q'])==cells,'refinement old dimension ancestry')
            work+=(step-cut)*cells*cells;cut=step
            cells=(len(event['new_faces']['r'])-1)*(len(event['new_faces']['z'])-1)
            demand(cells==record['plan']['required_cells'] and len(event['allocation']['next'])==cells<=cfg['refinement_max_cells'],'applied refinement census')
            for key,name in (('density','density_l1_mass_fraction'),('angular','angular_profile_l1_fraction')):
                loss=parse_rational(event['allocation']['diagnostics'][name]);demand(loss>=0,'refinement nonnegative loss');before[key]+=loss
        else:
            demand(status in ('cell_limit','depth_limit','event_limit','loss_limit') and record is decisions[-1],'terminal refinement refusal')
        after={k:parse_rational(v) for k,v in record['spent_after'].items()}
        demand(after==before and all(before[k]<=cfg['refinement_'+k+'_budget'] for k in before),'refinement cumulative loss')
    work+=(steps-cut)*cells*cells
    demand(position==len(events) and before==spent,'complete refinement event and loss ledger')
    demand(type(pair_steps) is int and pair_steps==work<=cfg['max_pair_steps'],'complete accepted-step pair-work account')
