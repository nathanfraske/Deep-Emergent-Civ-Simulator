"""Reconstruct a saved finite-cloud frame, then measure it without evolving gas."""
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,json,sys
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'scripts/radial_core')]
import pi_pair
from arithmetic import canonical_json,digest,parse_rational
from scripts.rotating_core import inputs,input_watchdog,model,mesh,mesh_watchdog,leaf_mesh,leaf_mesh_watchdog
from scripts.rotating_core import finite_cloud,finite_cloud_watchdog,eos,eos_watchdog,gravity,gravity_watchdog
from scripts.rotating_core import run,observe_watchdog,disk_observe,disk_observe_watchdog,checkpoint,checkpoint_watchdog


def decode(value):
    if isinstance(value,str) and '/' in value:
        try:return parse_rational(value)
        except (ValueError,ZeroDivisionError):pass
    if isinstance(value,list):return [decode(v) for v in value]
    if isinstance(value,dict):return {k:decode(v) for k,v in value.items()}
    return value


def observe_case(folder,live=False,frame_index=-1,workers=1):
    """Check one frame; complete causal history remains a separate replay claim."""
    if type(workers) is not int or not 1<=workers<=16:raise ValueError('disk observer worker resource envelope')
    folder=Path(folder)
    state_text=(folder/'state').read_text(encoding='ascii');cfg_text=(folder/'numerics').read_text(encoding='ascii')
    state=inputs.state(state_text);cfg=inputs.numerics(cfg_text)
    physical=model.load(folder/'floor.json',run.FINITE_MODEL_ID);pressure=physical['pressure'];pi=pi_pair.value(cfg['fraction_bits'])
    input_watchdog.check(state_text,state,'state');input_watchdog.check(cfg_text,cfg,'numerics');input_watchdog.physical(state,cfg,pressure,pi)
    x=mesh.build(state,cfg,pressure,pi);x.update(boundary_mode='reflecting_slip',gravity_domain='all_resolved_gas')
    mesh_watchdog.geometry(state,cfg,pressure,pi,x)
    initial=finite_cloud.project(x,state,pressure);finite_cloud_watchdog.initial(x,state,cfg,pressure,initial)
    first=eos.fields(x,initial);eos_watchdog.check(x,initial,first)
    initial_peak=max(F(f['rho'],x['s'])*x['rho_unit'] for f in first)
    if live:
        path=folder/'frames.jsonl'
        if not 0<path.stat().st_size<=128*1024**2:raise ValueError('disk preview journal byte limit')
        raw=path.read_bytes();lines=raw.splitlines()
        if not raw.endswith(b'\n'):lines=lines[:-1]
        lines=[line for line in lines if line.strip()]
        frame_raw=json.loads(lines[frame_index]);frame=decode(frame_raw)
    else:
        path=folder/'receipt.json'
        if not path.exists():path=folder/'stdout.json'
        receipt=checkpoint.read(path)
        input_watchdog.demand(receipt['accepted'] is True and receipt['schema'] in ('civsim.rotating-barotropic.finite.run.v1','civsim.rotating-barotropic.finite.run.v2')
                             and receipt['model_id']==run.FINITE_MODEL_ID,'disk case supported receipt')
        checkpoint_watchdog.strict_equal(receipt['implementations'],run.implementations())
        for key,expected in (('state',state),('numerics',cfg),('model',physical)):
            checkpoint_watchdog.strict_equal(receipt[key],run.encoded(expected))
        frame_raw=receipt['frames'][frame_index];frame=decode(frame_raw)
    coords=frame.get('coordinate_faces',leaf_mesh.coordinates(x))
    x=leaf_mesh.rebuild(x,coords['cells']) if 'cells' in coords else mesh.rebuild(x,coords)
    (leaf_mesh_watchdog if 'cells' in coords else mesh_watchdog).geometry(state,cfg,pressure,pi,x)
    input_watchdog.demand(type(frame['step']) is int and frame['step']>=0 and type(frame['clock_q']) is int
        and frame['clock_q']>=0 and type(frame['time_s']) is F
        and frame['time_s']==F(frame['clock_q'],x['s'])*x['time_unit'],'disk observer clock binding')
    cells=frame['cell_q'];fields=eos.fields(x,cells);eos_watchdog.check(x,cells,fields)
    finite_cloud_watchdog.physical(x,cells,state,pressure);finite_cloud_watchdog.accounts(x,cells,frame['boundary_accounts'])
    refinement=frame.get('refinement_revision',0);revision=frame.get('mesh_revision',0)
    suffix=f"-refine-{refinement:04d}" if refinement else f"-remesh-{revision:04d}" if revision else ''
    path=folder/f'kernel{suffix}.json'
    if not 0<path.stat().st_size<=1536*1024**2:raise ValueError('disk observer kernel byte limit')
    cache=json.loads(path.read_text(encoding='ascii'))
    input_watchdog.demand(set(cache)=={'schema','binding','rows','rows_sha256'} and cache['schema']=='civsim.rotating-barotropic.kernel.v1','disk observer kernel inventory')
    spec={k:x[k] for k in ('s','r','z','epsilon','angles')}
    if 'kernel_keys' in x:spec['kernel_keys']=x['kernel_keys']
    input_watchdog.demand(cache['binding']==digest(canonical_json(run.encoded(spec)).encode('ascii'))
        and cache['rows_sha256']==digest(canonical_json(cache['rows']).encode('ascii')),'disk observer kernel binding')
    authority=gravity_watchdog.kernel(x,cache['rows'],workers)
    force=gravity.field(x,cells,gravity.matrices(x,cache['rows']));authority.check(cells,force)
    observe_watchdog.check(x,cells,fields,force,state,pressure,frame['observation'])
    input_watchdog.demand(frame['rho_q']==[f['rho'] for f in fields] and frame['pressure_q']==[f['p'] for f in fields],'disk observer saved EOS')
    edges=[F(0)]+[F(1,2**p) for p in range(8,-1,-1)];readings=[]
    for multiplier in (0,10,100):
        cutoff=multiplier*initial_peak;reading=disk_observe.measure(x,cells,fields,force,state,pressure,edges,cutoff)
        disk_observe_watchdog.check(x,cells,fields,force,state,pressure,edges,cutoff,reading)
        readings.append(dict(initial_peak_multiplier=multiplier,observation=reading))
    paths=['scripts/rotating_core/'+name for name in ('disk_case.py','disk_observe.py','disk_observe_watchdog.py')]
    paths+=['sources/barotropic_core/disk-observation-equations.txt','sources/disk_identification/citation.toml']
    result=dict(schema='civsim.rotating-disk.case-diagnostic.v1',case=folder.name,live=live,step=frame['step'],time_s=frame['time_s'],
        frame_sha256=hashlib.sha256(canonical_json(frame_raw).encode('ascii')).hexdigest(),initial_peak_density_kg_m3=initial_peak,
        current_kernel_sha256=cache['rows_sha256'],observer_implementations={path:digest((ROOT/path).read_bytes()) for path in paths},
        readings=readings,formed_disk=False,completed_system=False,complete_causal_history_checked=False,
        scope='Saved EOS, complete kernel coefficients, force contraction, geometry, observations and finite accounts reconstructed. Complete causal history and continuum or boundary convergence remain separate; a live preview is provisional.')
    return result,x,frame,state,pressure


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case-dir',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--live',action='store_true');parser.add_argument('--frame-index',type=int,default=-1);parser.add_argument('--workers',type=int,default=1)
    args=parser.parse_args()
    if args.output.exists():raise ValueError('fresh diagnostic output required')
    result,*_=observe_case(args.case_dir,args.live,args.frame_index,args.workers)
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(canonical_json(run.encoded(result)),encoding='ascii')
    print(json.dumps(dict(case=result['case'],step=result['step'],time_s=float(result['time_s']),live=result['live'],formed_disk=False,
        output=str(args.output),sha256=digest(args.output.read_bytes()))))


if __name__=='__main__':main()
