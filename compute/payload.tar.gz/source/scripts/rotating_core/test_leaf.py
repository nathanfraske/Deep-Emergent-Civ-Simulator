"""Selective geometry, exact tensor parity, realistic gas and mutation controls."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(1,str(ROOT/'scripts/radial_core'))
from fractions import Fraction as F
import copy,json,tempfile,unittest
from dataclasses import FrozenInstanceError
import pi_pair
from arithmetic import parse_rational
from scripts.rotating_core import inputs,input_watchdog,mesh,model,eos,eos_watchdog,gravity,gravity_watchdog,transport,transport_watchdog,observe,observe_watchdog,run
from scripts.rotating_core import leaf_mesh,leaf_mesh_watchdog,leaf_refine,leaf_refine_watchdog
from scripts.rotating_core.test_refine import NUM as BANDS,DILUTE

NUM=BANDS.replace('numerics.v5','numerics.v6').replace('jeans_dyadic_bands','jeans_dyadic_cells')


def decoded(value):
    if isinstance(value,str) and '/' in value:return parse_rational(value)
    if isinstance(value,list):return [decoded(v) for v in value]
    if isinstance(value,dict):return {k:decoded(v) for k,v in value.items()}
    return value


class LeafTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scratch=tempfile.TemporaryDirectory(prefix='civsim-leaf-test-');cls.directory=Path(cls.scratch.name)
        floor=cls.directory/'floor.json';floor.write_text(json.dumps(dict(schema='civsim.radial-core.floor.v1',G='6.67430e-11',floor_digest='e0cfd4a60342488054ddfa936599794e1697c0bd0997122c22e58047cde0aeb5')),encoding='ascii')
        cls.model=model.load(floor);cls.pressure=cls.model['pressure'];cls.state=inputs.state(DILUTE);cls.cfg=inputs.numerics(NUM)
        cls.x=mesh.build(cls.state,cls.cfg,cls.pressure,pi_pair.value(96));cls.cells=mesh.project(cls.x,cls.state,cls.pressure)
        cls.fields=eos.fields(cls.x,cls.cells);cls.proposal=leaf_refine.plan(cls.x,cls.fields,cls.state,cls.pressure,cls.cfg)
        cls.new,cls.allocation=leaf_refine.transfer(cls.x,cls.cells,cls.proposal)
        boxes=leaf_mesh.bounds(cls.x);a,b,c,d=boxes[0];r=(a+b)/2;z=(c+d)/2
        local_boxes=[(a,r,c,z),(r,b,c,z),(a,r,z,d),(r,b,z,d)]+boxes[1:]
        local_plan=dict(status='accepted',levels=[[1,1]]+[[0,0] for _ in boxes[1:]],new_faces=dict(cells=local_boxes))
        cls.local,cls.local_allocation=leaf_refine.transfer(cls.x,cls.cells,local_plan)
        cls.result=run.solve(DILUTE,NUM,cls.model,kernel_cache=cls.directory/'kernel.json',workers=1)

    @classmethod
    def tearDownClass(cls):cls.scratch.cleanup()

    def test_closed_inputs_and_distinct_resource_caps(self):
        input_watchdog.check(NUM,self.cfg,'numerics')
        for a,b in [('refinement_max_cells=256','refinement_max_cells=4097'),('refinement_max_events=4','refinement_max_events=65'),('spatial_refinement=jeans_dyadic_cells','spatial_refinement=jeans_dyadic_bands'),('refinement_trigger_squared=0.00390625','refinement_trigger_squared=0.0625'),('refinement_density_budget=1e-12','refinement_density_budget=0')]:
            with self.subTest(a=a):
                with self.assertRaises(ValueError):inputs.numerics(NUM.replace(a,b))
        large=(ROOT/'examples/rotating-core/selective.numerics').read_text();cfg=inputs.numerics(large);input_watchdog.check(large,cfg,'numerics')

    def test_minimal_local_depth_and_complete_patch_geometry(self):
        leaf_refine_watchdog.plan(self.x,self.fields,self.state,self.pressure,self.cfg,self.proposal)
        leaf_mesh_watchdog.geometry(self.state,self.cfg,self.pressure,self.x['pi'],self.new)
        self.assertTrue(any(d==[0,0] for d in self.proposal['levels']))
        self.assertLess(len(self.new['volume']),256)
        self.assertEqual(sum(self.new['volume']),sum(self.x['volume']))
        leaf_mesh_watchdog.geometry(self.state,self.cfg,self.pressure,self.x['pi'],self.local)
        sides={}
        for axis,left,right,area in self.local['faces']:
            if left>=0:sides[(axis,left)]=sides.get((axis,left),0)+1
            if right>=0:sides[(axis,right)]=sides.get((axis,right),0)+1
        self.assertTrue(any(n>2 for n in sides.values()),'coarse side must meet multiple fine patches')

    def test_full_tensor_conversion_preserves_force_steps_and_observers(self):
        leaf=leaf_mesh.rebuild(self.x,leaf_mesh.bounds(self.x));leaf_mesh_watchdog.geometry(self.state,self.cfg,self.pressure,self.x['pi'],leaf)
        results=[]
        for x in (self.x,leaf):
            rows=gravity.kernel(x,1);gravity_watchdog.kernel(x,rows,1);matrix=gravity.matrices(x,rows)
            force=gravity.field(x,self.cells,matrix);gravity_watchdog.field(x,self.cells,rows,force)
            fields=eos.fields(x,self.cells);eos_watchdog.check(x,self.cells,fields)
            dt=transport.timestep(x,self.cells,fields,force);self.assertEqual(dt,transport_watchdog.bounds(x,self.cells,fields,force))
            stage=transport.stage(x,self.cells,fields,force,dt);transport_watchdog.stage(x,self.cells,fields,force,dt,stage)
            obs=observe.measure(x,self.cells,fields,force,self.state,self.pressure);observe_watchdog.check(x,self.cells,fields,force,self.state,self.pressure,obs)
            results.append((force,dt,stage['next'],stage['sources'],obs))
        self.assertEqual(*results)

    def test_signed_parent_allocation_and_loss_are_exact(self):
        signed=[[m,3*m//7,-2*m//9,-spin] for m,pr,pz,spin in self.cells]
        new,allocation=leaf_refine.transfer(self.x,signed,self.proposal)
        valid,spent=leaf_refine_watchdog.allocation(self.x,new,signed,allocation,dict(density=F(0),angular=F(0)),self.cfg)
        self.assertTrue(valid);self.assertTrue(all(q<F(1,10**24) for q in spent.values()))
        self.assertEqual(allocation['before_totals'],allocation['after_totals'])
        for change in ('mass','angular','transfer','loss'):
            bad=copy.deepcopy(allocation)
            if change=='mass':bad['next'][0][0]+=1;bad['next'][1][0]-=1
            elif change=='angular':bad['next'][0][3]+=1;bad['next'][1][3]-=1
            elif change=='transfer':bad['transfers'][0][0]+=1
            else:bad['diagnostics']['density_l1_mass_fraction']+=F(1,2**96)
            with self.subTest(change=change):
                with self.assertRaises(ValueError):leaf_refine_watchdog.allocation(self.x,new,signed,bad,dict(density=F(0),angular=F(0)),self.cfg)

    def test_geometry_and_kernel_mutations_refuse(self):
        for change in ('face','missing','patch','center','overlap','key'):
            bad=copy.deepcopy(self.new)
            if change=='face':axis,left,right,area=bad['faces'][2];bad['faces'][2]=(axis,left,right,area+F(1,2**96))
            elif change=='missing':bad['faces'].pop()
            elif change=='patch':bad['face_patches'][0]=(F(1,2**96),*bad['face_patches'][0][1:])
            elif change=='center':bad['cell_z'][0]+=F(1,2**96)
            elif change=='overlap':bad['cell_bounds'][0]=bad['cell_bounds'][1]
            else:bad['kernel_keys'].pop()
            with self.subTest(change=change):
                with self.assertRaises(ValueError):leaf_mesh_watchdog.geometry(self.state,self.cfg,self.pressure,self.x['pi'],bad)
        rows=gravity.kernel(self.new,1);rows[0][1]+=1
        with self.assertRaises(ValueError):gravity_watchdog.kernel(self.new,rows,1)

    def test_prepared_checker_is_independent_immutable_and_field_equivalent(self):
        x=self.local;cells=self.local_allocation['next'];rows=gravity.kernel(x,1)
        authority=gravity_watchdog.kernel(x,rows,1);self.assertIsNotNone(authority)
        matrix=gravity.matrices(x,rows);force=gravity.field(x,cells,matrix)
        gravity_watchdog.field(x,cells,rows,force);authority.check(cells,force)
        with self.assertRaises(FrozenInstanceError):authority.coupling+=1
        original=copy.deepcopy(rows);rows[0][1]+=1000000
        authority.check(cells,force);self.assertEqual(original[0][1],matrix[0][0][0])
        for changes in ('force','shape','bool','negative','coupling'):
            y=copy.deepcopy(cells);bad=copy.deepcopy(force)
            if changes=='force':bad[0][0]+=1
            elif changes=='shape':bad.pop()
            elif changes=='bool':y[0][0]=True
            elif changes=='negative':y[0][0]=-y[0][0]
            else:bad=gravity.field(dict(x,gravity=2*x['gravity']),cells,matrix)
            with self.subTest(changes=changes):
                with self.assertRaises(ValueError):authority.check(y,bad)
        with self.assertRaises(ValueError):gravity_watchdog.kernel(x,rows,1)

    def test_shared_patch_uniform_pressure_and_rigid_spin(self):
        x=self.local;y=self.local_allocation['next'];fields=eos.fields(x,y);eos_watchdog.check(x,y,fields)
        zero=[[0,0] for _ in y];dt=transport.timestep(x,y,fields,zero)
        stage=transport.stage(x,y,fields,zero,dt);transport_watchdog.stage(x,y,fields,zero,dt,stage)
        self.assertTrue(all(v[0]==v[3]==0 for v in stage['transfers']))
        stopped=[[m,0,0,0] for m,pr,pz,angular in y];fields=eos.fields(x,stopped)
        stage=transport.stage(x,stopped,fields,zero,dt);transport_watchdog.stage(x,stopped,fields,zero,dt,stage)
        self.assertLessEqual(max(abs(v[1]) for v in stage['next']),4)
        self.assertLessEqual(max(abs(v[2]) for v in stage['next']),4)

    def test_threshold_plan_and_depth_capacity_mutations(self):
        maximum=self.proposal['max_ratio_squared'];cfg=dict(self.cfg,refinement_trigger_squared=maximum,refinement_target_squared=maximum/2)
        same=leaf_refine.plan(self.x,self.fields,self.state,self.pressure,cfg);self.assertEqual(same['status'],'unchanged');leaf_refine_watchdog.plan(self.x,self.fields,self.state,self.pressure,cfg,same)
        for caps,status in ((dict(refinement_max_cells=32),'cell_limit'),(dict(refinement_max_depth=0),'depth_limit')):
            cfg=dict(self.cfg,**caps);got=leaf_refine.plan(self.x,self.fields,self.state,self.pressure,cfg)
            self.assertEqual(got['status'],status);self.assertIsNone(got['new_faces']);leaf_refine_watchdog.plan(self.x,self.fields,self.state,self.pressure,cfg,got)
        for change in ('count','type','depth','face','status'):
            bad=copy.deepcopy(self.proposal)
            if change=='count':bad['required_cells']+=1
            elif change=='type':bad['levels'][0][0]=False
            elif change=='depth':bad['levels'][0][0]+=1
            elif change=='face':bad['new_faces']['cells'][0]=bad['new_faces']['cells'][1]
            else:bad['status']='unchanged'
            with self.subTest(change=change):
                with self.assertRaises(ValueError):leaf_refine_watchdog.plan(self.x,self.fields,self.state,self.pressure,self.cfg,bad)

    def test_original_gas_receipt_repeat_observers_and_spin_covariance(self):
        row=self.result;self.assertEqual(row['schema'],'civsim.rotating-barotropic.run.v7');self.assertEqual(row['steps'],8)
        self.assertFalse(row['completed_system']);self.assertEqual(row['assigned_stellar_mass_kg'],'0/1')
        self.assertTrue(row['refinement_events']);self.assertTrue(all(f['observation']['jeans_width_screen'] for f in row['frames']))
        self.assertEqual(row['initial_observation']['total_mass_kg'],row['final_observation']['total_mass_kg']);self.assertEqual(row['initial_observation']['angular_momentum_kg_m2_s'],row['final_observation']['angular_momentum_kg_m2_s'])
        cache=self.directory/'kernel.json';repeat=run.solve(DILUTE,NUM,self.model,kernel_cache=cache,workers=1);self.assertEqual(row,repeat)
        observed=run.solve(DILUTE.replace('Declared cold rotating cylinder','Observer description'),NUM.replace('sample_every=4','sample_every=2'),self.model,kernel_cache=cache,workers=1)
        self.assertEqual(row['trace_sha256'],observed['trace_sha256']);self.assertEqual(row['physical_identity'],observed['physical_identity'])
        reverse=run.solve(DILUTE.replace('angular_velocity_s_inv=2e-13','angular_velocity_s_inv=-2e-13'),NUM,self.model,kernel_cache=cache,workers=1)
        for a,b in zip(row['frames'][-1]['cell_q'],reverse['frames'][-1]['cell_q']):self.assertEqual(a[:3]+[-a[3]],b)

    def test_full_loss_and_pair_work_ledger_mutation(self):
        row=self.result;spent={k:parse_rational(v) for k,v in row['refinement_spent'].items()}
        leaf_refine_watchdog.ledger(self.cfg,row['refinement_decisions'],row['refinement_events'],spent,row['steps'],row['pair_steps_spent'])
        with self.assertRaises(ValueError):leaf_refine_watchdog.ledger(self.cfg,row['refinement_decisions'],row['refinement_events'],spent,row['steps'],row['pair_steps_spent']+1)
        bad=copy.deepcopy(row['refinement_events']);bad[0]['step']+=1
        with self.assertRaises(ValueError):leaf_refine_watchdog.ledger(self.cfg,row['refinement_decisions'],bad,spent,row['steps'],row['pair_steps_spent'])
        stopped=run.solve(DILUTE,NUM.replace('refinement_max_cells=256','refinement_max_cells=32'),self.model,kernel_cache=self.directory/'limit.json',workers=1)
        self.assertEqual(stopped['stop_reason'],'refinement_cell_limit');self.assertEqual(stopped['steps'],0);self.assertFalse(stopped['reached_requested_time'])
        loss=run.solve(DILUTE.replace('angular_velocity_s_inv=2e-13','angular_velocity_s_inv=2.1e-13'),NUM.replace('refinement_angular_budget=1e-12','refinement_angular_budget=1e-40'),self.model,workers=1)
        self.assertEqual(loss['stop_reason'],'refinement_loss_limit');self.assertEqual(loss['steps'],0);self.assertEqual(loss['refinement_spent'],dict(density='0/1',angular='0/1'))

    def test_witness_custody_and_unresolved_state(self):
        self.assertIn(leaf_refine_watchdog.WITNESS,leaf_refine_watchdog.source(ROOT))
        temp=self.directory/'mutated-source';target=temp/leaf_refine_watchdog.WITNESS;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/leaf_refine_watchdog.WITNESS).read_bytes()+b'changed\n')
        with self.assertRaises(ValueError):leaf_refine_watchdog.source(temp)
        fields=copy.deepcopy(self.fields)
        for f in fields:f['rho']*=100
        with self.assertRaises(ValueError):leaf_refine_watchdog.screen(self.x,fields,self.state,self.pressure)


if __name__=='__main__':unittest.main()
