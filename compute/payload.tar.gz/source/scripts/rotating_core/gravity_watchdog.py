"""Independent softened ring and source-major force accumulation checks."""
from fractions import Fraction as F
from concurrent.futures import ProcessPoolExecutor
from functools import lru_cache
from dataclasses import dataclass
import os
from .input_watchdog import demand
from .mesh_watchdog import round_cell
from . import packed_field_watchdog,kernel_residuals


def check_row(x,index,got):
    s=x['s']
    if 'kernel_keys' in x:a,b,separation=x['kernel_keys'][index]
    else:
        nr=x['nr'];nz=len(x['separations']);target=index//(nr*nz);source=(index//nz)%nr
        separation=x['separations'][index%nz];a,b=x['r'][target],x['r'][source]
    kernel_residuals.check(s,a,b,separation,x['epsilon'],x['angles'],got)


def chunk(args):
    x,start,rows=args
    for offset,row in enumerate(rows):check_row(x,start+offset,row)
    return len(rows)


def kernel(x,rows,workers=None):
    count=len(x['kernel_keys']) if 'kernel_keys' in x else x['nr']**2*len(x['separations'])
    demand(len(rows)==count,'ring inventory')
    workers=max(1,min(workers or os.cpu_count() or 1,16,count));width=(count+workers*4-1)//(workers*4)
    jobs=[(x,k,rows[k:k+width]) for k in range(0,count,width)]
    if workers==1:chunk((x,0,rows))
    else:
        with ProcessPoolExecutor(max_workers=workers) as pool:demand(sum(pool.map(chunk,jobs))==count,'ring check census')
    if 'kernel_keys' in x:
        lookup={key:row for key,row in zip(x['kernel_keys'],rows)}
        for (a,b,z),row in lookup.items():
            other=lookup[(b,a,z)];demand(row[0]==other[0] and row[2]==other[2],'leaf potential and axial symmetry')
        columns=leaf_traversal(tuple(tuple(v) for v in x['cell_bounds']),tuple(x['kernel_keys']),tuple(tuple(v) for v in rows))
        return _PreparedField(x['s'],x['gravity'],columns,packed_field_watchdog.prepare(columns,x['s']))
    n=len(x['separations'])
    for i in range(x['nr']):
        for j in range(x['nr']):
            for k in range(n):
                a=rows[(i*x['nr']+j)*n+k];b=rows[(j*x['nr']+i)*n+k]
                demand(a[0]==b[0] and a[2]==b[2],'ring potential and axial symmetry')
    columns=tensor_traversal(x,rows)
    return _PreparedField(x['s'],x['gravity'],columns,packed_field_watchdog.prepare(columns,x['s']))


def tensor_traversal(x,rows):
    """Own source-major tensor indices, retained after full physical checks."""
    nr=x['nr'];n=nr*x['nz'];ns=len(x['separations']);distance={z:i for i,z in enumerate(x['separations'])};columns=[]
    for source in range(n):
        sz,sr=divmod(source,nr);radial=[];axial=[]
        for target in range(n):
            tz,tr=divmod(target,nr)
            row=rows[(tr*nr+sr)*ns+distance[abs(x['z'][tz]-x['z'][sz])]]
            radial.append(row[1]);axial.append(row[2] if tz>=sz else -row[2])
        columns.append((tuple(radial),tuple(axial)))
    return tuple(columns)


def field(x,cells,rows,got):
    nr=x['nr'];n=len(cells);s=x['s'];nz=len(x['separations'])
    demand(len(got)==n and all(len(row)==2 for row in got),'force census')
    accum=[[0,0] for _ in range(n)]
    if 'cell_bounds' in x:
        columns=leaf_traversal(tuple(tuple(v) for v in x['cell_bounds']),tuple(x['kernel_keys']),tuple(tuple(v) for v in rows))
        for source,cell in enumerate(cells):
            radial,axial=columns[source]
            for target,(r,z) in enumerate(zip(radial,axial)):
                accum[target][0]-=cell[0]*r;accum[target][1]-=cell[0]*z
        for target in range(n):
            for component in range(2):round_cell(got[target][component],F(accum[target][component]*x['gravity'],s*s))
        return
    lookup={value:index for index,value in enumerate(x['separations'])}
    distances=[[lookup[abs(a-b)] for b in x['z']] for a in x['z']]
    # Independent source-major traversal derives every compressed index anew.
    for source,cell in enumerate(cells):
        sz,sr=divmod(source,nr)
        for target in range(n):
            tz,tr=divmod(target,nr)
            index=(tr*nr+sr)*nz+distances[tz][sz]
            row=rows[index]
            accum[target][0]-=cell[0]*row[1]
            accum[target][1]+=cell[0]*row[2]*(1 if tz<sz else -1)
    for target in range(n):
        for component in range(2):round_cell(got[target][component],F(accum[target][component]*x['gravity'],s*s))


@lru_cache(maxsize=1)
def leaf_traversal(boxes,keys,rows):
    """Own immutable source-major layout, never a producer expected answer."""
    centers=[(a+(b-a)/2,c+(d-c)/2) for a,b,c,d in boxes];lookup=dict(zip(keys,rows));columns=[]
    for r,z in centers:
        radial=[];axial=[]
        for q,w in centers:
            row=lookup[(q,r,abs(w-z))];radial.append(row[1]);axial.append(row[2] if w>=z else -row[2])
        columns.append((tuple(radial),tuple(axial)))
    return tuple(columns)


@dataclass(frozen=True)
class _PreparedField:
    """Own immutable force context minted only after the full kernel checks."""
    scale:int
    coupling:int
    columns:tuple
    packed:object

    def check(self,cells,got):
        n=len(self.columns);s=self.scale
        demand(len(cells)==len(got)==n and all(len(y)==4 and all(type(v) is int and abs(v).bit_length()<=384 for v in y) and y[0]>0 for y in cells),'prepared force state domain')
        demand(all(len(y)==2 and all(type(v) is int for v in y) for y in got),'prepared force output domain')
        sums=self.packed.reconstruct(cells)
        if sums is None:
            accum=[[0,0] for _ in cells]
            for cell,(radial,axial) in zip(cells,self.columns):
                for target,(r,z) in enumerate(zip(radial,axial)):
                    accum[target][0]-=cell[0]*r;accum[target][1]-=cell[0]*z
        else:accum=[[-r,-z] for r,z in sums]
        for target in range(n):
            for component in range(2):round_cell(got[target][component],F(accum[target][component]*self.coupling,s*s))
