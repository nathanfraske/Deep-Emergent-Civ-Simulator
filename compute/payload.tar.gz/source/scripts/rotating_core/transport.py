"""Conservative four-field Euler stages and face-wise two-stage averaging."""
from fractions import Fraction as F
from math import isqrt
from functools import lru_cache
from arithmetic import qfraction,rounded
from .flux import impulses as face_impulses
from .leaf_mesh import bounds as cell_bounds
from . import boundary


@lru_cache(maxsize=128)
def radial_geometry(lo,hi):
    return (hi**2+lo**2)/2,2*(hi**3-lo**3)/(3*(hi**2-lo**2))


def ghost(cell,axis):
    out=cell.copy();out[axis+1]=-out[axis+1];return out


def sides(x,cells,fields,face):
    axis,left,right,area=face
    li=left if left>=0 else right;ri=right if right>=0 else left
    opened=x.get('boundary_mode')=='extrapolated_cylinder'
    a=cells[li] if left>=0 else boundary.ghost(cells[li]) if opened else ghost(cells[li],axis)
    b=cells[ri] if right>=0 else boundary.ghost(cells[ri]) if opened else ghost(cells[ri],axis)
    return a,b,fields[li],fields[ri],x['volume'][li],x['volume'][ri]


def signal(s,a,b,fa,fb,axis):
    def speed(y):return (abs(y[axis+1])*s+y[0]-1)//y[0]
    return max(speed(a)+fa['cs'],speed(b)+fb['cs'])


def timestep(x,cells,fields,gravity):
    s=x['s'];rates=[F(0) for _ in cells]
    for face in x['faces']:
        axis,left,right,area=face
        a,b,fa,fb,va,vb=sides(x,cells,fields,face);alpha=signal(s,a,b,fa,fb,axis)
        for k in (left,right):
            if k>=0:rates[k]+=area*alpha
    bounds=[(x['cfl']*v*s*s/rate).__floor__() for v,rate in zip(x['volume'],rates) if rate]
    for k,(y,(lo,hi,bottom,top)) in enumerate(zip(cells,cell_bounds(x))):
        moment2,centroid=radial_geometry(lo,hi)
        centrifugal=qfraction(F(y[3]**2,y[0]**2)*centroid/moment2**2,s)
        acceleration=max(abs(gravity[k][0])+abs(centrifugal),abs(gravity[k][1]))
        if acceleration:
            width=min(hi-lo,top-bottom)
            bounds.append(isqrt((width*s**3/(100*acceleration)).__floor__()))
    dt=min(bounds)
    if dt<=0:raise ValueError('time step below representation quantum')
    return dt


def sources(x,cells,fields,gravity):
    s=x['s'];result=[]
    for k,(y,(lo,hi,bottom,top)) in enumerate(zip(cells,cell_bounds(x))):
        r=(lo+hi)/2;p=fields[k]['p'];volume=x['volume'][k]
        moment2,centroid=radial_geometry(lo,hi)
        radial=F(p)*volume/r+F(y[3]**2,y[0])*centroid/moment2**2+F(y[0]*gravity[k][0],s)
        axial=F(y[0]*gravity[k][1],s)
        result.append([qfraction(radial,1),qfraction(axial,1)])
    return result


def assemble(x,old,transfers,sources):
    out=[y.copy() for y in old]
    for face,transfer in zip(x['faces'],transfers):
        _,left,right,_=face
        for k in range(4):
            if left>=0:out[left][k]-=transfer[k]
            if right>=0:out[right][k]+=transfer[k]
    for y,source in zip(out,sources):y[1]+=source[0];y[2]+=source[1]
    return out


def stage(x,old,fields,gravity,dt):
    transfers=[];boxes=cell_bounds(x)
    for index,face in enumerate(x['faces']):
        axis,left,right,area=face;s=x['s']
        a,b,fa,fb,va,vb=sides(x,old,fields,face)
        alpha=signal(s,a,b,fa,fb,axis)
        impulse=face_impulses(s,a,b,fa,fb,va,vb,area,alpha,dt,axis)
        # Spin follows the shared mass impulse with a regular angular velocity.
        axis,left,right,_=face;mass=impulse[0];donor=left if mass>=0 else right
        if donor<0 and x.get('boundary_mode')=='extrapolated_cylinder':donor=max(left,right)
        if mass==0:angular=0
        elif donor<0:raise ValueError('nonzero wall mass impulse')
        elif axis==0:
            lo,hi=boxes[donor][:2];moment2,_=radial_geometry(lo,hi)
            face_radius=x['face_patches'][index][0] if 'cell_bounds' in x else x['rf'][index%(x['nr']+1)]
            angular=qfraction(F(mass*old[donor][3],old[donor][0])*face_radius**2/moment2,1)
        else:angular=qfraction(F(mass*old[donor][3],old[donor][0]),1)
        transfers.append(impulse+[angular])
    force=sources(x,old,fields,gravity)
    impulses=[[rounded(dt*v,x['s']) for v in row] for row in force]
    return dict(transfers=transfers,sources=impulses,next=assemble(x,old,transfers,impulses))


def combine(x,old,first,second):
    faces=[[rounded(a+b,2) for a,b in zip(one,two)] for one,two in zip(first['transfers'],second['transfers'])]
    forces=[[rounded(a+b,2) for a,b in zip(one,two)] for one,two in zip(first['sources'],second['sources'])]
    return dict(transfers=faces,sources=forces,next=assemble(x,old,faces,forces))
