"""Explicit numerical ceiling limited by the current smallest cell span."""


def update(x):
    if 'softening_cell_fraction' not in x:return x
    if 'cell_bounds' in x:
        spans=[v for a,b,c,d in x['cell_bounds'] for v in (b-a,d-c)]
    else:
        spans=[b-a for edges in (x['rf'],x['zf']) for a,b in zip(edges,edges[1:])]
    new=dict(x)
    new['epsilon']=min(x['softening_ceiling'],x['softening_cell_fraction']*min(spans))
    return new


def configure(x,state,cfg):
    if cfg['schema']!='civsim.rotating-barotropic.numerics.v7':return x
    new=dict(x,softening_ceiling=cfg['softening_m']/state['radius_m'],
             softening_cell_fraction=cfg['softening_cell_fraction'])
    return update(new)
