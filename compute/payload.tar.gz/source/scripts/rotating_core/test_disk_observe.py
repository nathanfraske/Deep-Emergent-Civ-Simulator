"""Analytic observer controls only; synthetic forces do not form a physical disk."""
from pathlib import Path
from fractions import Fraction as F
import copy,sys,unittest
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'scripts/radial_core')]
from scripts.rotating_core import disk_observe,disk_observe_watchdog


def fixture(bits=96,split=False):
    s=2**bits
    if not split:
        boxes=[(F(0),F(1),F(-1),F(1))];volume=[F(1)];cells=[[s,0,0,3*s//2]]
        faces=[(0,-1,0,F(0)),(0,0,-1,F(2)),(1,-1,0,F(1,2)),(1,0,-1,F(1,2))]
        force=[[-6*s,0]]
    else:
        boxes=[(F(a),F(b),F(c),F(d)) for c,d in ((-1,0),(0,1)) for a,b in ((0,F(1,2)),(F(1,2),1))]
        volume=[(b*b-a*a)*(d-c)/2 for a,b,c,d in boxes]
        cells=[[int(s*v),0,0,int(3*s*v*(a*a+b*b)/2)] for v,(a,b,c,d) in zip(volume,boxes)]
        faces=[(0,-1,0,F(0)),(0,0,1,F(1,2)),(0,1,-1,F(1)),(0,-1,2,F(0)),(0,2,3,F(1,2)),(0,3,-1,F(1))]
        force=[[-3*s,0],[-7*s,0],[-3*s,0],[-7*s,0]]
    fields=[dict(rho=s,p=7*s) for _ in cells]
    x=dict(s=s,volume=volume,cell_bounds=boxes,faces=faces,rho_unit=F(3))
    return x,cells,fields,force,dict(radius_m=F(2),mass_kg=F(30)),dict(sound_speed_m_s=F(5))


class DiskObservationTests(unittest.TestCase):
    def observe(self,data,edges=None,floor=F(0)):
        edges=edges or [F(0),F(1)]
        got=disk_observe.measure(*data,edges,floor);disk_observe_watchdog.check(*data,edges,floor,got)
        return got

    def test_exact_rotation_force_benchmark_and_uniform_pressure_cancellation(self):
        got=self.observe(fixture());row=got['annuli'][0]
        self.assertEqual(row['mass_kg'],30);self.assertEqual(row['centrifugal_to_inward_gravity'],1)
        self.assertEqual(row['centrifugal_force_N'],2250);self.assertEqual(row['cell_average_pressure_force_N'],0)
        self.assertEqual(row['rotation_kinetic_2J'],F(3375));self.assertEqual(row['angular_momentum_kg_m2_s'],450)
        self.assertEqual(row['thickness_ratio_squared'],F(2,3));self.assertFalse(got['formed_disk'])

    def test_disjoint_nonbinary_annuli_conserve_mass_and_angular_momentum(self):
        data=fixture(split=True);whole=self.observe(data);parts=self.observe(data,[F(0),F(1,3),F(2,3),F(1)])
        self.assertEqual(sum(r['mass_kg'] for r in parts['annuli']),whole['selected_mass_kg'])
        self.assertEqual(sum(r['angular_momentum_kg_m2_s'] for r in parts['annuli']),whole['annuli'][0]['angular_momentum_kg_m2_s'])
        self.assertEqual(sum(r['rotation_kinetic_2J'] for r in parts['annuli']),whole['annuli'][0]['rotation_kinetic_2J'])

    def test_partition_and_precision_preserve_analytic_moments(self):
        whole=self.observe(fixture())['annuli'][0]
        for bits in (96,128,160):self.assertEqual(self.observe(fixture(bits,True))['annuli'][0],whole)

    def test_spin_reversal_and_zero_rotation_are_visible(self):
        data=fixture(split=True);base=self.observe(data);reverse=copy.deepcopy(data)
        for y in reverse[1]:y[3]=-y[3]
        got=self.observe(reverse)
        self.assertEqual(got['annuli'][0]['angular_momentum_kg_m2_s'],-base['annuli'][0]['angular_momentum_kg_m2_s'])
        for key in base['annuli'][0]:
            if key!='angular_momentum_kg_m2_s':self.assertEqual(got['annuli'][0][key],base['annuli'][0][key])
        for y in reverse[1]:y[3]=0
        empty=self.observe(reverse)['annuli'][0]
        self.assertEqual(empty['centrifugal_to_inward_gravity'],0);self.assertIsNone(empty['radial_motion_to_rotation_squared'])

    def test_inward_and_vertical_motion_remain_separate(self):
        data=fixture();data[1][0][1]=-data[0]['s']//2;data[1][0][2]=data[0]['s']//4
        row=self.observe(data)['annuli'][0]
        self.assertEqual(row['radial_motion_to_rotation_squared'],F(1,18));self.assertEqual(row['axial_motion_to_rotation_squared'],F(1,72))

    def test_density_cut_is_read_only_and_keeps_outside_pressure_neighbours(self):
        data=fixture(split=True);data[2][1]['rho']=2*data[0]['s'];data[2][3]['rho']=2*data[0]['s']
        prior=copy.deepcopy(data);got=self.observe(data,floor=F(4));self.assertEqual(got['selected_mass_kg'],F(45,2));self.assertEqual(data,prior)
        for k in (0,2):data[2][k]['p']=9*data[0]['s']
        changed=self.observe(data,floor=F(4));self.assertNotEqual(changed['annuli'][0]['cell_average_pressure_force_N'],got['annuli'][0]['cell_average_pressure_force_N'])
        none=self.observe(data,floor=F(10));self.assertEqual(none['selected_mass_kg'],0)
        self.assertIsNone(none['annuli'][0]['thickness_ratio_squared'])

    def test_outward_gravity_does_not_mint_support(self):
        data=fixture();data[3][0][0]=data[0]['s'];row=self.observe(data)['annuli'][0]
        self.assertIsNone(row['centrifugal_to_inward_gravity']);self.assertGreater(row['radial_gravity_force_N'],0)

    def test_every_observation_field_and_authority_flag_refuses_corruption(self):
        data=fixture();edges=[F(0),F(1)];base=self.observe(data)
        for key,value in base['annuli'][0].items():
            forged=copy.deepcopy(base);forged['annuli'][0][key]=True if value==1 else value+1 if value is not None else F(0)
            with self.assertRaises(ValueError):disk_observe_watchdog.check(*data,edges,F(0),forged)
        for key in ('formed_disk','completed_system'):
            forged=copy.deepcopy(base);forged[key]=True
            with self.assertRaises(ValueError):disk_observe_watchdog.check(*data,edges,F(0),forged)
        forged=copy.deepcopy(base);forged['annuli'][0]['radius_of_desired_disk']=F(1)
        with self.assertRaises(ValueError):disk_observe_watchdog.check(*data,edges,F(0),forged)

    def test_observer_argument_inventory_and_numeric_type_refusals(self):
        data=fixture()
        for edges in ([0,1],[F(0),F(1,2),F(1,3),F(1)],[F(0),F(1),F(1)]):
            with self.assertRaises(ValueError):disk_observe.measure(*data,edges)
            with self.assertRaises(ValueError):disk_observe_watchdog.check(*data,edges,F(0),{})
        with self.assertRaises(ValueError):disk_observe.measure(*data,[F(0),F(1)],F(-1))
        forged=self.observe(data);forged['annuli'][0]['r_lo_m']=False
        with self.assertRaises(ValueError):disk_observe_watchdog.check(*data,[F(0),F(1)],F(0),forged)
        for key,value in (('density_floor_kg_m3',False),('radial_edges',[0,1])):
            forged=self.observe(data);forged[key]=value
            with self.assertRaises(ValueError):disk_observe_watchdog.check(*data,[F(0),F(1)],F(0),forged)


if __name__=='__main__':unittest.main()
