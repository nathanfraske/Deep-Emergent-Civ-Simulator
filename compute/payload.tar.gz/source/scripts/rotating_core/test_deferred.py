"""Observer timing cannot alter gas; invalid diagnostics never release."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'scripts/radial_core')]
import json,tempfile,unittest
from unittest.mock import patch
from scripts.rotating_core import run,model,observe
from scripts.rotating_core.test_leaf import DILUTE,NUM


class DeferredTests(unittest.TestCase):
    def test_eager_observer_and_unread_observer_preserve_complete_science(self):
        with tempfile.TemporaryDirectory(prefix='civsim-deferred-') as raw:
            folder=Path(raw);floor=folder/'floor.json';floor.write_text(json.dumps(dict(schema='civsim.radial-core.floor.v1',G='6.67430e-11',floor_digest='e0cfd4a60342488054ddfa936599794e1697c0bd0997122c22e58047cde0aeb5')));physics=model.load(floor)
            cache=folder/'kernel.json';plain=run.solve(DILUTE,NUM,physics,kernel_cache=cache,workers=1)
            def eager(kind,value):
                if kind=='accepted':dict(value['observation'])
            inspected=run.solve(DILUTE,NUM,physics,progress=eager,kernel_cache=cache,workers=1)
            self.assertEqual(plain,inspected)
            changed=run.solve(DILUTE.replace('Declared cold rotating cylinder','Observer description'),NUM.replace('sample_every=4','sample_every=2'),physics,progress=eager,kernel_cache=cache,workers=1)
            self.assertEqual(plain['trace_sha256'],changed['trace_sha256']);self.assertEqual(plain['physical_identity'],changed['physical_identity'])

    def test_corrupt_observation_refuses_before_frame_release(self):
        original=observe.measure
        def corrupt(*args):
            value=original(*args);value['peak_density_kg_m3']+=1;return value
        with tempfile.TemporaryDirectory(prefix='civsim-deferred-') as raw:
            floor=Path(raw)/'floor.json';floor.write_text(json.dumps(dict(schema='civsim.radial-core.floor.v1',G='6.67430e-11',floor_digest='e0cfd4a60342488054ddfa936599794e1697c0bd0997122c22e58047cde0aeb5')));physics=model.load(floor);released=[]
            with patch.object(observe,'measure',corrupt),self.assertRaises(ValueError):run.solve(DILUTE,NUM,physics,on_frame=released.append,workers=1)
            self.assertEqual(released,[])


if __name__=='__main__':unittest.main()
