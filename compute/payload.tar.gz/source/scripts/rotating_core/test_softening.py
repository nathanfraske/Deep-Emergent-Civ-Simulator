"""Exact geometry, changed-force controls and full width-limited cut replay."""
from pathlib import Path
import copy,json,sys,tempfile,unittest
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(1,str(ROOT/'scripts/radial_core'))
import pi_pair
from arithmetic import parse_rational
from scripts.rotating_core import inputs,input_watchdog,mesh,mesh_watchdog,leaf_mesh,leaf_mesh_watchdog
from scripts.rotating_core import model,run,checkpoint,checkpoint_watchdog,softening_watchdog
from scripts.rotating_core.test_leaf import NUM,DILUTE

WIDTH=NUM.replace('numerics.v6','numerics.v7')+'gravity_softening=cell_width_limited_global\nsoftening_cell_fraction=0.125\n'


class CellSofteningTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scratch=tempfile.TemporaryDirectory(prefix='civsim-cell-softening-');cls.directory=Path(cls.scratch.name)
        floor=cls.directory/'floor.json'
        floor.write_text(json.dumps(dict(schema='civsim.radial-core.floor.v1',G='6.67430e-11',floor_digest='e0cfd4a60342488054ddfa936599794e1697c0bd0997122c22e58047cde0aeb5')),encoding='ascii')
        cls.model=model.load(floor);cls.pressure=cls.model['pressure'];cls.state=inputs.state(DILUTE);cls.cfg=inputs.numerics(WIDTH)
        cls.pi=pi_pair.value(96);cls.x=mesh.build(cls.state,cls.cfg,cls.pressure,cls.pi)
        cls.cache=cls.directory/'width.json'
        cls.parent=run.solve(DILUTE,WIDTH,cls.model,kernel_cache=cls.cache,workers=1,_stop_step=3)

    @classmethod
    def tearDownClass(cls):cls.scratch.cleanup()

    def test_closed_numerical_policy_and_independent_decimal_domain(self):
        input_watchdog.check(WIDTH,self.cfg,'numerics')
        for before,after in [('softening_cell_fraction=0.125','softening_cell_fraction=0'),
                             ('softening_cell_fraction=0.125','softening_cell_fraction=1.01'),
                             ('gravity_softening=cell_width_limited_global','gravity_softening=per_source'),
                             ('numerics.v7','numerics.v6')]:
            with self.subTest(after=after):
                with self.assertRaises(ValueError):inputs.numerics(WIDTH.replace(before,after))
        for name,value in [('softening_cell_fraction',F(3,4)),('gravity_softening','clamped'),('schema','civsim.rotating-barotropic.numerics.v6')]:
            bad=dict(self.cfg);bad[name]=value
            with self.assertRaises(ValueError):input_watchdog.check(WIDTH,bad,'numerics')

    def test_tensor_and_local_leaf_geometry_recompute_the_global_bound(self):
        cells=mesh.project(self.x,self.state,self.pressure)
        mesh_watchdog.check(self.state,self.cfg,self.pressure,self.pi,self.x,cells)
        faces=dict(r=list(self.x['rf']),z=list(self.x['zf']));faces['r'][1]=F(1,1024)
        shifted=mesh.rebuild(self.x,faces);mesh_watchdog.geometry(self.state,self.cfg,self.pressure,self.pi,shifted)
        self.assertEqual(shifted['epsilon'],F(1,8192));self.assertLess(shifted['epsilon'],self.x['epsilon'])
        boxes=leaf_mesh.bounds(self.x);a,b,c,d=boxes[0];r=a+(b-a)/16
        leaf=leaf_mesh.rebuild(self.x,[(a,r,c,d),(r,b,c,d)]+boxes[1:])
        leaf_mesh_watchdog.geometry(self.state,self.cfg,self.pressure,self.pi,leaf)
        self.assertEqual(leaf['epsilon'],(r-a)/8)
        merged=leaf_mesh.rebuild(leaf,boxes)
        self.assertEqual(merged['epsilon'],self.x['epsilon'])
        self.assertEqual(self.x['epsilon'],F(1,128))

    def test_bound_mutations_and_unattained_lower_value_refuse(self):
        boxes=leaf_mesh.bounds(self.x);a,b,c,d=boxes[0];r=a+(b-a)/16
        leaf=leaf_mesh.rebuild(self.x,[(a,r,c,d),(r,b,c,d)]+boxes[1:])
        for key,value in [('epsilon',leaf['epsilon']/2),('epsilon',leaf['epsilon']*2),
                          ('softening_ceiling',leaf['softening_ceiling']*2),
                          ('softening_cell_fraction',F(3,4))]:
            bad=dict(leaf);bad[key]=value
            with self.subTest(key=key,value=value):
                with self.assertRaises(ValueError):softening_watchdog.check(bad,self.state,self.cfg,self.pressure)
        bad=dict(leaf);bad.pop('softening_ceiling')
        with self.assertRaises(ValueError):softening_watchdog.check(bad,self.state,self.cfg,self.pressure)

    def test_effective_potential_screen_uses_smallest_span_not_the_ceiling(self):
        text=WIDTH.replace('softening_cell_fraction=0.125','softening_cell_fraction=1e-12')
        cfg=inputs.numerics(text);input_watchdog.check(text,cfg,'numerics')
        input_watchdog.physical(self.state,cfg,self.pressure,self.pi)
        x=mesh.build(self.state,cfg,self.pressure,self.pi)
        with self.assertRaisesRegex(ValueError,'effective Newtonian potential screen'):
            mesh_watchdog.check(self.state,cfg,self.pressure,self.pi,x,mesh.project(x,self.state,self.pressure))
        with self.assertRaisesRegex(ValueError,'effective Newtonian potential screen'):
            run.solve(DILUTE,text,self.model,workers=1)

    def test_changed_effective_smoothing_cannot_reuse_a_cached_kernel(self):
        path=self.directory/'single-kernel.json';run.get_kernel(self.x,path,1,None)
        changed=dict(self.x);changed['epsilon']/=2
        with self.assertRaisesRegex(ValueError,'kernel cache binding'):run.get_kernel(changed,path,1,None)

    def test_inactive_ceiling_is_exact_fixed_force_and_gas_control(self):
        old=NUM.replace('softening_m=1.75e13','softening_m=1e9')
        width=old.replace('numerics.v6','numerics.v7')+'gravity_softening=cell_width_limited_global\nsoftening_cell_fraction=0.5\n'
        direct=run.solve(DILUTE,old,self.model,workers=1)
        selected=run.solve(DILUTE,width,self.model,workers=1)
        for a,b in zip(direct['frames'],selected['frames']):
            reduced=dict(b);self.assertEqual(reduced.pop('effective_softening_m'),'1000000000/1');self.assertEqual(a,reduced)
        for key in ('final_observation','refinement_events','refinement_decisions','refinement_spent',
                    'remesh_events','remesh_decisions','remesh_spent','pair_steps_spent','trace_sha256'):
            self.assertEqual(direct[key],selected[key])

    def test_actual_width_limited_gas_records_effective_scale_and_replays_cut(self):
        self.assertEqual(self.parent['schema'],'civsim.rotating-barotropic.run.v9')
        self.assertEqual(self.parent['stop_reason'],'execution_limit')
        self.assertEqual(self.parent['frames'][-1]['effective_softening_m'],self.parent['effective_softening_m'])
        ceiling=parse_rational(self.parent['numerics']['softening_m'])
        self.assertTrue(any(parse_rational(f['effective_softening_m'])<ceiling for f in self.parent['frames']))
        prefix=checkpoint_watchdog.authorize(self.parent,DILUTE,self.model,run.solve,run.implementations(),checkpoint.text,kernel_cache=self.cache,workers=1)
        longer=WIDTH.replace('max_steps=8','max_steps=16')
        result=run.solve(DILUTE,longer,self.model,kernel_cache=self.cache,workers=1,_resume=prefix)
        direct=run.solve(DILUTE,longer,self.model,kernel_cache=self.cache,workers=1)
        self.assertEqual(result['schema'],'civsim.rotating-barotropic.run.v10')
        a,b=result['frames'][-1],direct['frames'][-1]
        self.assertEqual(set(a),set(b));self.assertNotEqual(a['trace_sha256'],b['trace_sha256'])
        for key in set(a)-{'trace_sha256'}:self.assertEqual(a[key],b[key])
        for key in ('effective_softening_m','final_observation','refinement_events','refinement_decisions',
                    'refinement_spent','remesh_events','remesh_decisions','remesh_spent','pair_steps_spent'):
            self.assertEqual(result[key],direct[key])
        checkpoint_watchdog.authorize(result,DILUTE,self.model,run.solve,run.implementations(),checkpoint.text,kernel_cache=self.cache,workers=1)
        for a,b in [('softening_cell_fraction=0.125','softening_cell_fraction=0.25'),
                    ('softening_m=1.75e13','softening_m=8.75e12')]:
            with self.assertRaises(ValueError):run.solve(DILUTE,longer.replace(a,b),self.model,workers=1,_resume=prefix)
        bad=copy.deepcopy(self.parent);bad['frames'][-1]['effective_softening_m']='1/1'
        with self.assertRaises(ValueError):checkpoint_watchdog.authorize(bad,DILUTE,self.model,run.solve,run.implementations(),checkpoint.text,kernel_cache=self.cache,workers=1)

    def test_held_numerical_witness_is_independently_pinned(self):
        softening_watchdog.source(ROOT)
        with tempfile.TemporaryDirectory(prefix='civsim-cell-witness-') as scratch:
            root=Path(scratch);path=root/softening_watchdog.WITNESS;path.parent.mkdir(parents=True)
            path.write_bytes((ROOT/softening_watchdog.WITNESS).read_bytes()+b'changed\n')
            with self.assertRaises(ValueError):softening_watchdog.source(root)


if __name__=='__main__':unittest.main()
