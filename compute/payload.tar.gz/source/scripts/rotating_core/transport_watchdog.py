"""Independent face impulses, cylindrical sources, stages and conserved totals."""
from fractions import Fraction as F
from math import isqrt
from functools import lru_cache
from .input_watchdog import demand
from .mesh_watchdog import round_cell
from .eos_watchdog import nearest
from .leaf_mesh_watchdog import bounds as cell_bounds
from . import boundary_watchdog


@lru_cache(maxsize=128)
def radial_integrals(lo,hi):
    volume=(hi**2-lo**2)/2
    return (hi**4-lo**4)/(4*volume),(hi**3-lo**3)/(3*volume)


def bounds(x,cells,fields,force):
    context=(x['s'],tuple(tuple(v) for v in cell_bounds(x)),tuple(x['volume']),tuple(x['faces']),x['cfl'])
    return bound_cell(context,tuple(tuple(y) for y in cells),tuple(f['cs'] for f in fields),tuple(tuple(g) for g in force))


@lru_cache(maxsize=16)
def bound_cell(context,cells,acoustic,force):
    # Own independent result, keyed by every geometry/state quantity read here.
    # Keys are immutable snapshots; no producer bound or acceptance is cached.
    s,boxes,volume,faces,cfl=context;incident=[F(0) for _ in cells]
    for direction,left,right,area in faces:
        present=[k for k in (left,right) if k>=0]
        speeds=[]
        for k in present:
            speed=F(abs(cells[k][direction+1])*s,cells[k][0])
            upper=-(-speed.numerator//speed.denominator)
            speeds.append(upper+acoustic[k])
        signal=max(speeds)
        for k in present:incident[k]+=signal*area
    limits=[]
    for k in range(len(cells)):
        if incident[k]:
            budget=cfl*volume[k]*s*s/incident[k]
            limits.append(budget.numerator//budget.denominator)
        y=cells[k];lo,hi,bottom,top=boxes[k]
        second,center=radial_integrals(lo,hi)
        centrifugal=nearest((F(y[3],y[0])/second)**2*center*s)
        maximum=max(abs(force[k][0])+abs(centrifugal),abs(force[k][1]))
        if maximum:
            width=min(hi-lo,top-bottom)
            square=width*s**3/(100*maximum)
            limit=isqrt(square.numerator//square.denominator)
            demand(limit**2<=square<(limit+1)**2,'acceleration time cell')
            limits.append(limit)
    demand(limits and min(limits)>0,'positive resolved step')
    return min(limits)


def timestep(x,cells,fields,force,dt,remaining,reductions):
    base=min(bounds(x,cells,fields,force),remaining)
    demand(type(dt) is int and dt>0 and 0<=reductions<=32 and dt==base//(2**reductions),'deterministic clipped adaptive step')


def side(cells,fields,volume,index,other,direction,opened=False):
    k=index if index>=0 else other
    values=list(cells[k])
    if index<0 and not opened:values[direction+1]=-values[direction+1]
    return values,fields[k],volume[k]


def flux_residual(s,a,b,fa,fb,va,vb,area,dt,axis,reported):
    """Generic physical quotient residual, independently of producer impulses.

    Clear each side's velocity/volume denominator separately. No Fraction
    normalization or expected rounded output is needed for the exact
    half-even cell inequality. See ROTATING_EXACT_ACCELERATION.md.
    """
    upper=max((abs(a[axis+1])*s+a[0]-1)//a[0]+fa['cs'],
              (abs(b[axis+1])*s+b[0]-1)//b[0]+fb['cs'])
    ln=(a[axis+1]*s+upper*a[0])*va.denominator;ld=a[0]*s*va.numerator
    rn=(b[axis+1]*s-upper*b[0])*vb.denominator;rd=b[0]*s*vb.numerator
    common=ld*rd
    for component in range(3):
        numerator=a[component]*ln*rd+b[component]*rn*ld
        if component==axis+1:numerator+=(fa['p']+fb['p'])*common
        numerator*=dt*area.numerator;denominator=2*s*area.denominator*common
        q=reported[component]
        demand(type(q) is int and denominator>0,'physical flux quotient domain')
        residual=2*abs(q*denominator-numerator)
        demand(residual<denominator or residual==denominator and q%2==0,'independent half-even flux residual')


def stage(x,old,fields,force,dt,got):
    s=x['s'];boxes=cell_bounds(x);demand(set(got)=={'transfers','sources','next'},'stage inventory')
    opened=x.get('boundary_mode')=='extrapolated_cylinder'
    demand(len(got['transfers'])==len(x['faces']) and len(got['sources'])==len(old),'stage census')
    for index,(axis,left,right,area) in enumerate(x['faces']):
        a,fa,va=side(old,fields,x['volume'],left,right,axis,opened)
        b,fb,vb=side(old,fields,x['volume'],right,left,axis,opened)
        flux_residual(s,a,b,fa,fb,va,vb,area,dt,axis,got['transfers'][index])
        mass=got['transfers'][index][0]
        if mass==0:demand(got['transfers'][index][3]==0,'no spin flux without mass flux')
        else:
            donor=right if mass<0 else left
            if donor<0 and opened:donor=left if left>=0 else right
            demand(donor>=0,'declared boundary carrier')
            specific=F(old[donor][3],old[donor][0])
            if axis==0:
                lo,hi=boxes[donor][:2]
                mean_square,_=radial_integrals(lo,hi)
                radius=x['face_patches'][index][0] if 'cell_bounds' in x else x['rf'][index%(x['nr']+1)]
                specific=specific/mean_square*radius*radius
            round_cell(got['transfers'][index][3],mass*specific)
        if not opened and (left<0 or right<0):
            demand(got['transfers'][index][0]==got['transfers'][index][3]==0,'impermeable mass and torque boundary')
    for k,y in enumerate(old):
        lo,hi,bottom,top=boxes[k];r=(lo+hi)/2;v=x['volume'][k]
        average_square,radial_moment=radial_integrals(lo,hi)
        angular_velocity=F(y[3],y[0])/average_square
        radial=fields[k]['p']*v/r+y[0]*angular_velocity**2*radial_moment+F(y[0]*force[k][0],s)
        axial=F(y[0]*force[k][1],s)
        for component,value in enumerate((radial,axial)):
            source=nearest(value)
            round_cell(got['sources'][k][component],F(dt*source,s))
    transition(x,old,got)
    demand(dt<=bounds(x,old,fields,force),'stage Courant and acceleration contract')


def transition(x,old,got):
    n=len(old);demand(len(got['next'])==n and all(len(row)==4 for row in got['next']),'next-state census')
    # Assemble incoming/outgoing accounts by cell, rather than the face scatter.
    incoming=[[0,0,0,0] for _ in old];outgoing=[[0,0,0,0] for _ in old]
    for face,impulse in zip(x['faces'],got['transfers']):
        demand(len(impulse)==4 and all(type(a) is int for a in impulse),'face storage')
        _,left,right,_=face
        for component in range(4):
            if left>=0:outgoing[left][component]+=impulse[component]
            if right>=0:incoming[right][component]+=impulse[component]
    for k in range(n):
        demand(len(got['sources'][k])==2,'source storage')
        for component in range(4):
            source=got['sources'][k][component-1] if component in (1,2) else 0
            demand(got['next'][k][component]==old[k][component]+incoming[k][component]-outgoing[k][component]+source,'finite-volume residual')
        demand(got['next'][k][0]>0 and all(type(a) is int and abs(a).bit_length()<=384 for a in got['next'][k]),'next-state domain')
    if x.get('boundary_mode')=='extrapolated_cylinder':boundary_watchdog.balance(x,old,got)
    else:
        for component in (0,3):demand(sum(row[component] for row in got['next'])==sum(row[component] for row in old),'exact mass or angular momentum')


def combine(x,old,first,second,got):
    demand(set(got)=={'transfers','sources','next'} and len(got['transfers'])==len(x['faces']) and len(got['sources'])==len(old),'averaged-stage census')
    for name in ('transfers','sources'):
        for one,two,result in zip(first[name],second[name],got[name]):
            demand(len(one)==len(two)==len(result),'averaged record width')
            for a,b,c in zip(one,two,result):round_cell(c,F(a+b,2))
    transition(x,old,got)
