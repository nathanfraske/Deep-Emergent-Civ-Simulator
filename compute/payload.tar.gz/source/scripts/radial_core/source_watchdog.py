"""Independent profile, custody and sealed-floor coordinate checker."""
from fractions import Fraction
from hashlib import sha256

def check(root,record,floor,model):
    if set(model)!={'G','sound_speed_m_s','density','floor_binding','floor_schema','profile_sha256','equation_witness_sha256','source_id','uncertainty','scope'}:raise ValueError('complete sealed model required')
    if any(type(z) is not Fraction for z in [model['G'],model['sound_speed_m_s'],*model['density']]):raise ValueError('exact model coordinates required')
    if any(model[k]!=record[k] for k in ['source_id','uncertainty','scope']):raise ValueError('model scope substitution')
    if set(floor)!={'schema','G','floor_digest'} or floor['schema']!='civsim.radial-core.floor.v1':raise ValueError('floor export schema')
    if floor['floor_digest']!='e0cfd4a60342488054ddfa936599794e1697c0bd0997122c22e58047cde0aeb5':raise ValueError('floor authority identity')
    facts_bytes=(root/'crates/units/data/codata_2018_floor_facts.tsv').read_bytes().replace(b'\r\n',b'\n')
    if b'\r' in facts_bytes or sha256(facts_bytes).hexdigest()!='7645ac6c0cdafc0e94853cc0ac20fc6ca93d171504e9a78f7f0aef4b09678401':raise ValueError('sealed floor factual custody')
    facts=facts_bytes.decode('ascii')
    rows=[line.split('\t') for line in facts.splitlines() if line.startswith('row\tG\t')]
    if len(rows)!=1 or rows[0][10]!='3,-1,-2,0,0,0,0':raise ValueError('gravity factual row')
    if Fraction(rows[0][7])!=model['G'] or Fraction(floor['G'])!=model['G']:raise ValueError('sealed G substitution')
    if record.get('schema')!='civsim.bate1998-barotropic-profile.v1' or record.get('model_id')!='spherical_bate1998_barotropic_v1' or record.get('source_id')!='bate_1998_barotropic_collapse':raise ValueError('EOS identity')
    if record.get('exponents')!=['1','7/5','23/20','5/3'] or model['density']!=[Fraction(1,10**10),Fraction(57,10**6),Fraction(1)] or model['sound_speed_m_s']!=200:raise ValueError('EOS source transcription')
    for relative,want in [('sources/barotropic_core/bate98.toml','1dab4ece44d3a0ef72c92e246ca6d2a561b3d68f952e486d7a1a6ccd5990d9a3'),
                          ('sources/barotropic_core/equations.txt','2ea85fd8106430f02d09b69a59fefe7e4a893d1d61941b53b50f6a43905ca9b5')]:
        raw=(root/relative).read_bytes().replace(b'\r\n',b'\n')
        if b'\r' in raw or sha256(raw).hexdigest()!=want:raise ValueError('profile custody')
    for relative,key in [('sources/barotropic_core/bate98.toml','profile_sha256'),('sources/barotropic_core/equations.txt','equation_witness_sha256')]:
        data=(root/relative).read_bytes().replace(b'\r\n',b'\n')
        if b'\r' in data or sha256(data).hexdigest()!=model[key]:raise ValueError('model custody binding')
    if model['floor_binding']!=floor['floor_digest'] or model['floor_schema']!=floor['schema']:raise ValueError('model floor binding')
