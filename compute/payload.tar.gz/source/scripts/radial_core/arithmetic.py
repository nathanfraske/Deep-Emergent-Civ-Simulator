"""Exact numerical primitives, with no model, input or evolution decisions."""
from fractions import Fraction
from hashlib import sha256

def rounded(num, den):
    if den <= 0:
        raise ValueError('nonpositive divisor')
    sign = -1 if num < 0 else 1
    q, r = divmod(abs(num), den)
    return sign * (q + (2*r > den or (2*r == den and q % 2)))

def qfraction(x, scale):
    return rounded(x.numerator * scale, x.denominator)

WIRE_BITS=1<<20


def integer_text(value):
    """Bounded exact decimal output without changing the host input guard."""
    if type(value) is not int or value.bit_length()>WIRE_BITS:
        raise ValueError('receipt integer bit resource limit')
    if value.bit_length()<=512:return str(value)
    sign='-' if value<0 else '';value=abs(value);chunks=[]
    while value:
        value,tail=divmod(value,10**9);chunks.append(tail)
    return sign+str(chunks[-1])+''.join(f'{part:09d}' for part in reversed(chunks[:-1]))


def integer_from_text(text):
    if not isinstance(text,str) or not text or len(text)>WIRE_BITS//3+2:
        raise ValueError('receipt decimal resource limit')
    negative=text.startswith('-');digits=text[1:] if negative else text
    if not digits or not digits.isascii() or not digits.isdecimal():raise ValueError('receipt integer syntax')
    value=0
    for begin in range(0,len(digits),9):
        part=digits[begin:begin+9];value=value*10**len(part)+int(part)
        if value.bit_length()>WIRE_BITS:raise ValueError('receipt integer bit resource limit')
    return -value if negative else value


def rational(x):
    return integer_text(x.numerator)+'/'+integer_text(x.denominator)


def parse_rational(text):
    """Read exact receipt strings only; physical input parsers remain separate."""
    if type(text) is int:return Fraction(text)
    if not isinstance(text,str) or text.count('/')>1:raise ValueError('receipt rational syntax')
    numerator,separator,denominator=text.partition('/')
    n=integer_from_text(numerator);d=integer_from_text(denominator) if separator else 1
    if d<=0:raise ValueError('receipt rational denominator')
    return Fraction(n,d)

def canonical_json(x):
    import json
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=True) + '\n'

def digest(x):
    return sha256(x).hexdigest()

def normalized(path):
    raw = path.read_bytes()
    raw = raw.replace(b'\r\n', b'\n')
    if b'\r' in raw:
        raise ValueError('bare carriage return')
    return raw

def ceil_sqrt(x):
    from math import isqrt
    y = isqrt(x)
    return y + (y*y != x)

def root_floor(x, degree):
    if x < 0 or degree < 1:
        raise ValueError('root domain')
    if x == 0:
        return 0
    y = 1 << ((x.bit_length() + degree - 1) // degree)
    while True:
        z = ((degree-1)*y + x // y**(degree-1)) // degree
        if z >= y:
            return y
        y = z
