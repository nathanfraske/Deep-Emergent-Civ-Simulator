"""Source-bound barotropic pressure primitive shared by both fluid geometries.

The independent radial and spatial watchdogs do not import this module.
"""
from fractions import Fraction
from arithmetic import rounded, qfraction, root_floor, ceil_sqrt


def coefficients(scale, transition):
    first = root_floor(qfraction(transition[1] / transition[0], scale)**2 * scale**3, 5)
    second = root_floor(qfraction(transition[2] / transition[1], scale)**3 * scale**17, 20)
    return dict(b1=first, b2=second, prefactor=rounded(first * second, scale))


def pressure(ctx, density_q):
    s = ctx['s']
    physical = Fraction(density_q, s) * ctx['rho_unit']
    if not 0 < physical <= 10000:
        raise ValueError('barotropic density outside (0,10000] kg/m3')
    transition = ctx['transition']
    if physical <= transition[0]:
        branch, root, shape, gamma = 0, s, s, Fraction(1)
    elif physical <= transition[1]:
        x = qfraction(physical / transition[0], s)
        root = root_floor(x**2 * s**3, 5)
        branch, shape, gamma = 1, root, Fraction(7, 5)
    elif physical <= transition[2]:
        x = qfraction(physical / transition[1], s)
        root = root_floor(x**3 * s**17, 20)
        branch, shape, gamma = 2, rounded(ctx['b1'] * root, s), Fraction(23, 20)
    else:
        x = qfraction(physical / transition[2], s)
        root = root_floor(x**2 * s, 3)
        branch, shape, gamma = 3, rounded(ctx['prefactor'] * root, s), Fraction(5, 3)
    p = rounded(density_q * shape, s)
    cs2 = rounded(gamma.numerator * p * s, gamma.denominator * density_q)
    return dict(p=p, cs2=cs2, cs=ceil_sqrt(cs2*s), root=[branch, root])
