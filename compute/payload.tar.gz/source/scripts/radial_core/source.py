"""Load one source-bound effective EOS and the existing sealed nominal G."""
from fractions import Fraction
from pathlib import Path
import json,tomllib
from arithmetic import digest,normalized

ROOT=Path(__file__).resolve().parents[2]

def load(floor_path):
    record=tomllib.loads(normalized(ROOT/'sources/barotropic_core/bate98.toml').decode())
    floor=json.loads(floor_path.read_text(encoding='ascii'))
    value=dict(G=Fraction(floor['G']),sound_speed_m_s=Fraction(record['sound_speed_m_s']),
               density=[Fraction(z) for z in record['transition_density_kg_m3']],
               floor_binding=floor['floor_digest'],floor_schema=floor['schema'],
               profile_sha256=digest(normalized(ROOT/'sources/barotropic_core/bate98.toml')),
               equation_witness_sha256=digest(normalized(ROOT/'sources/barotropic_core/equations.txt')),
               source_id=record['source_id'],uncertainty=record['uncertainty'],scope=record['scope'])
    import source_watchdog
    source_watchdog.check(ROOT,record,floor,value)
    return value

def validate(value):
    """The callable solver also requires the complete source-bound model."""
    record=tomllib.loads(normalized(ROOT/'sources/barotropic_core/bate98.toml').decode())
    floor={'schema':value['floor_schema'],'floor_digest':value['floor_binding'],'G':str(value['G'])}
    import source_watchdog
    source_watchdog.check(ROOT,record,floor,value)
