"""Two exact alternating-series Pi enclosures, followed by one binary cell."""
from fractions import Fraction
from arithmetic import qfraction

def series(q,bits):
    total=Fraction(0);k=0
    while True:
        term=Fraction((-1)**k,(2*k+1)*q**(2*k+1));total+=term
        next_term=Fraction((-1)**(k+1),(2*k+3)*q**(2*k+3))
        if abs(next_term)<Fraction(1,2**(bits+12)):
            return min(total,total+next_term),max(total,total+next_term)
        k+=1

def value(bits):
    a,b=series(5,bits);c,d=series(239,bits)
    lo=16*a-4*d;hi=16*b-4*c;s=1<<bits
    i=qfraction(lo,s)
    if i!=qfraction(hi,s):raise ValueError('Pi terminal cell straddled')
    # The other identity atan(1/2)+atan(1/3)=pi/4 has positive angles
    # and tangent (1/2+1/3)/(1-1/6)=1. Separate reversed summation below.
    def other(den):
        count=bits+20
        terms=[Fraction(1 if k%2==0 else -1,(2*k+1)*den**(2*k+1)) for k in range(count)]
        t=sum(reversed(terms),Fraction(0));next_value=Fraction((-1)**count,(2*count+1)*den**(2*count+1))
        return min(t,t+next_value),max(t,t+next_value)
    e,f=other(2);g,h=other(3)
    if i!=qfraction(4*(e+g),s) or i!=qfraction(4*(f+h),s):raise ValueError('Pi independent enclosure disagreement')
    return Fraction(i,s)
