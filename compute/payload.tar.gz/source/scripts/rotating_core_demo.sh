#!/usr/bin/env bash
# Copyright 2026 Nathan M. Fraske
# Licensed under the Apache License, Version 2.0; see LICENSE.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
bash scripts/cargo_dev.sh build --release -q -p civsim-planet --bin core_floor
if [ -z "${CARGO_TARGET_DIR:-}" ] && [ -n "${WSL_DISTRO_NAME:-}" ]; then
  source scripts/wsl_dev_env.sh --quiet
fi
python3 -B scripts/rotating_core/demo.py --floor-executable "${CARGO_TARGET_DIR:-target}/release/core_floor" "$@"
